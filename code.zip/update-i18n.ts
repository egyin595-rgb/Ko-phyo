import fs from 'fs'
let content = fs.readFileSync('artifacts/recap-studio/src/lib/i18n.ts', 'utf-8')

const replaceStage = `
export function localizeStage(stage: string) {
  if (!stage) return "";
  if (stageLabels[stage]) return stageLabels[stage];
  
  const s = stage.toLowerCase();
  if (s.includes("rendering myanmar")) return "မြန်မာဗီဒီယို ဖန်တီးနေသည်";
  if (s.includes("rendering english")) return "အင်္ဂလိပ်ဗီဒီယို ဖန်တီးနေသည်";
  if (s.includes("rendering")) return "ဗီဒီယို ဖန်တီးနေသည်";
  if (s.includes("self-heal") || s.includes("self heal")) return "အမှားများကို အလိုအလျောက် ပြင်ဆင်နေသည်";
  if (s.includes("uploading export") || s.includes("uploading completed")) return "ပြီးစီးသောဗီဒီယိုများကို သိမ်းဆည်းနေသည်";
  if (s.includes("uploading")) return "ဖိုင်သိမ်းဆည်းနေသည်";
  if (s.includes("downloading")) return "ဒေါင်းလုဒ်လုပ်နေသည်";
  
  return stage.replaceAll("_", " ");
}
`

content = content.replace(
  /export function localizeStage\(stage: string\) \{[\s\S]*?\}/,
  replaceStage.trim()
)

fs.writeFileSync('artifacts/recap-studio/src/lib/i18n.ts', content)
