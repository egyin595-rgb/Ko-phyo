import * as React from "react"
import { useForm, FormProvider, Controller, useFormContext } from "react-hook-form"
import type { UseFormReturn } from "react-hook-form"

const Form = FormProvider

const FormField = Controller

const FormItemContext = React.createContext<{ id: string } | null>(null)

const FormItem = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => {
  const id = React.useId()
  return (
    <FormItemContext.Provider value={{ id }}>
      <div ref={ref} className={className} {...props} />
    </FormItemContext.Provider>
  )
})
FormItem.displayName = "FormItem"

function useFormField() {
  const fieldContext = React.useContext(FormItemContext)
  const itemContext = React.useContext(FormItemContext)
  const { getFieldState, formState } = useFormContext()
  const fieldState = getFieldState("dummy", formState) // simplistic mock

  if (!fieldContext) {
    throw new Error("useFormField should be used within <FormField>")
  }

  return {
    id: itemContext?.id,
    ...fieldState,
  }
}

const FormControl = React.forwardRef<
  React.ElementRef<typeof Slot>,
  React.ComponentPropsWithoutRef<typeof Slot>
>(({ ...props }, ref) => {
  const { id } = useFormField()

  return <Slot ref={ref} id={id} {...props} />
})
FormControl.displayName = "FormControl"

import { Slot } from "@radix-ui/react-slot"
import { cn } from "@/lib/utils"
import { Label } from "@/components/ui/label"

const FormLabel = React.forwardRef<
  React.ElementRef<typeof Label>,
  React.ComponentPropsWithoutRef<typeof Label>
>(({ className, ...props }, ref) => {
  const { id } = useFormField()

  return (
    <Label
      ref={ref}
      className={cn("mb-2 block", className)}
      htmlFor={id}
      {...props}
    />
  )
})
FormLabel.displayName = "FormLabel"

const FormMessage = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, children, ...props }, ref) => {
  return (
    <p
      ref={ref}
      className={cn("text-sm font-medium text-destructive mt-1", className)}
      {...props}
    >
      {children}
    </p>
  )
})
FormMessage.displayName = "FormMessage"

export { Form, FormItem, FormLabel, FormControl, FormMessage, FormField, useFormField }
