import { CheckCircle2, Loader2, Upload, FileAudio, Languages, AudioLines, Film } from "lucide-react"
import { localizeError, localizeStage } from "@/lib/i18n"
import type { Project } from "@workspace/api-client-react"

type StageCategory = "upload" | "transcribe" | "translate" | "tts" | "render"

const getCategoryForStage = (stage: string): StageCategory => {
  const s = stage.toLowerCase()
  if (s.includes("အလိုအလျောက်") || s.includes("ပြီးစီးသောဖိုင်") || s.includes("တင်ပို့မှု") || s.includes("heal")) return "render"
  if (s === "character dialogue ready") return "translate"
  if (s.includes("render") || s.includes("export") || s.includes("uploading completed")) return "render"
  if (s.includes("voice") || s.includes("narration") || s.includes("tts")) return "tts"
  if (s.includes("translat") || s.includes("script")) return "translate"
  if (s.includes("transcrib") || s.includes("dialogue ready") || s.includes("transcript")) return "transcribe"
  return "upload"
}

const PIPELINE_STEPS = [
  { id: "upload", label: "ဖိုင်တင်ခြင်း", icon: Upload },
  { id: "transcribe", label: "စာသားပြောင်းခြင်း", icon: FileAudio },
  { id: "translate", label: "ဘာသာပြန်ခြင်း", icon: Languages },
  { id: "tts", label: "အသံဖန်တီးခြင်း", icon: AudioLines },
  { id: "render", label: "ဗီဒီယိုထုတ်ခြင်း", icon: Film },
]

export function ProgressPipeline({ project }: { project: Project }) {
  const { stage, progress, status } = project
  const translationFallback = Boolean(
    (project as Project & { translationFallback?: boolean }).translationFallback,
  )
  
  const isFailed = status === "failed"
  const isProcessing = status === "processing" || status === "queued"
  const isCompleted = status === "completed"

  let currentCategory: StageCategory = "upload"
  let targetCategory: StageCategory = "render"

  // Derive target category based on what exists
  if (project.exports && project.exports.length > 0) {
    targetCategory = "render"
  } else if (project.englishScript || project.myanmarScript) {
    targetCategory = "translate"
  } else if (project.transcript) {
    targetCategory = "transcribe"
  } else {
    targetCategory = "upload"
  }

  // If completed or ready, we are at the target category
  if (isCompleted || stage === "Ready" || stage === "Export complete") {
    currentCategory = targetCategory
  } else {
    currentCategory = getCategoryForStage(stage)
  }

  const currentIndex = PIPELINE_STEPS.findIndex(s => s.id === currentCategory)
  const targetIndex = PIPELINE_STEPS.findIndex(s => s.id === targetCategory)
  
  // If completed, only steps up to targetIndex are done
  const maxActiveIndex = isCompleted ? targetIndex : currentIndex
  
  return (
    <div className="w-full px-4 py-4" aria-live="polite">
      <div className="flex justify-between items-center relative">
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-white/10 rounded-full" />
        <div 
          className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-primary rounded-full transition-all duration-500" 
          style={{ width: `${Math.max(0, (maxActiveIndex / (PIPELINE_STEPS.length - 1)) * 100)}%` }}
        />
        
        {PIPELINE_STEPS.map((step, index) => {
          const isDone = (isCompleted && index <= targetIndex) || (!isCompleted && !isFailed && index < currentIndex)
          const isActive = !isCompleted && !isFailed && isProcessing && index === currentIndex
          
          return (
            <div key={step.id} className="relative z-10 flex flex-col items-center gap-2">
              <div 
                className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-colors
                  ${isDone 
                    ? 'bg-primary border-primary text-primary-foreground shadow-[0_0_15px_rgba(var(--primary),0.5)]' 
                    : isActive
                      ? 'bg-card border-primary text-primary animate-pulse shadow-[0_0_10px_rgba(var(--primary),0.3)]'
                      : 'bg-card border-white/20 text-muted-foreground'
                  }
                `}
              >
                {isDone ? (
                  <CheckCircle2 className="w-5 h-5" />
                ) : isActive ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <step.icon className="w-5 h-5" />
                )}
              </div>
              <div className="text-center absolute -bottom-10 w-14 sm:w-24">
                <span className={`text-[10px] sm:text-[11px] break-words font-medium ${isActive || isDone ? 'text-foreground' : 'text-muted-foreground'}`}>
                  {step.label}
                </span>
                {isActive && (
                  <div className="text-[10px] text-primary mt-0.5">{Math.round(progress)}%</div>
                )}
              </div>
            </div>
          )
        })}
      </div>
      <div className="mt-12 text-center">
        <p className={`text-sm ${isProcessing ? 'text-primary animate-pulse font-medium' : 'text-muted-foreground'}`}>
          {isFailed
            ? localizeError(project.error || stage)
            : isCompleted
              ? "လုပ်ဆောင်မှု ပြီးစီးပါပြီ"
              : localizeStage(stage)}
        </p>
        {translationFallback && (
          <p className="mt-2 text-xs text-amber-300/90">
            Gemini ယာယီကန့်သတ်ထားသဖြင့် အစားထိုးဘာသာပြန်ကို အသုံးပြုထားပါသည်။
          </p>
        )}
      </div>
    </div>
  )
}
