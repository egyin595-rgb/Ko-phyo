import { useState } from "react"
import type { Export as ExportRecord } from "@workspace/api-client-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Archive, Copy, Download, FileJson2, Loader2, Sparkles, Type, Volume2 } from "lucide-react"
import { DownloadFileButton } from "@/components/download-file-button"
import { VideoPlayer } from "@/components/export-media-panel"
import { useToast } from "@/components/ui/use-toast"

type ReadyToPostSuiteProps = {
  projectTitle: string
  projectNumber: number
  exports: ExportRecord[]
  hookTitle: string
  caption: string
  hashtags: string[]
  metadataLoading: boolean
  onGenerateMetadata: () => void
}

type PackagedExport = ExportRecord & {
  metadataUrl?: string
  packageUrl?: string
}

async function copyWithFallback(value: string) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value)
      return
    }
  } catch {
    // Continue with the textarea fallback for mobile and restricted frames.
  }
  const textarea = document.createElement("textarea")
  textarea.value = value
  textarea.setAttribute("readonly", "")
  textarea.style.position = "fixed"
  textarea.style.opacity = "0"
  document.body.appendChild(textarea)
  textarea.select()
  const copied = document.execCommand("copy")
  textarea.remove()
  if (!copied) throw new Error("Clipboard access was not available.")
}

export function ReadyToPostSuite({
  projectTitle,
  projectNumber,
  exports,
  hookTitle,
  caption,
  hashtags,
  metadataLoading,
  onGenerateMetadata,
}: ReadyToPostSuiteProps) {
  const { toast } = useToast()
  const [copied, setCopied] = useState("")
  const primaryExport = exports.find((item) => item.language === "myanmar") || exports[0]
  const packagedPrimaryExport = primaryExport as PackagedExport | undefined
  const copy = async (value: string, key: string, label: string) => {
    try {
      await copyWithFallback(value)
      setCopied(key)
      toast({ title: `${label} copied`, description: "Clipboard ထဲသို့ သိမ်းပြီးပါပြီ။" })
      window.setTimeout(() => setCopied((current) => current === key ? "" : current), 1600)
    } catch {
      toast({ variant: "destructive", title: "Copy မလုပ်နိုင်ပါ", description: "စာသားကို manually ရွေးပြီး copy လုပ်ပါ။" })
    }
  }

  return (
    <Card className="overflow-hidden border-primary/30 bg-[#0B0F19] shadow-[0_0_36px_rgba(124,92,255,0.18)] animate-in fade-in slide-in-from-bottom-3 duration-700">
      <CardHeader className="relative overflow-hidden border-b border-white/10 bg-gradient-to-br from-primary/20 via-[#0B0F19] to-accent/10">
        <div className="pointer-events-none absolute -right-8 -top-10 h-32 w-32 rounded-full bg-primary/20 blur-3xl" />
        <CardTitle className="relative flex items-center gap-2 text-lg text-white">
          <Sparkles className="h-5 w-5 text-yellow-300" />
           ဗီဒီယို တင်လို့ရတဲ့ အဆင့် ဖြစ်ပါပြီ
        </CardTitle>
        <p className="relative text-xs text-white/60">Thumbnail, ခေါင်းစဉ်နှင့် hashtag များကို တစ်နေရာတည်းမှ ပြင်ဆင်ပါ။</p>
      </CardHeader>
      <CardContent className="space-y-5 p-5">
        {primaryExport && (
          <>
            <div className="rounded-xl border border-accent/25 bg-accent/5 p-3">
              <p className="mb-2 text-sm font-semibold text-white">Final Video Preview</p>
              <div className="overflow-hidden rounded-lg border border-white/10 bg-black">
                <VideoPlayer
                  src={primaryExport.videoUrl}
                  label={`${projectTitle} final video preview`}
                />
              </div>
              <p className="mt-2 text-xs text-white/50">
                Download မလုပ်ခင် အသံ၊ crop၊ blur၊ subtitle နဲ့ timing ကို ဒီနေရာမှာ စစ်နိုင်ပါတယ်။
              </p>
            </div>

            <div className="rounded-xl border border-accent/25 bg-accent/5 p-3">
              <p className="mb-2 text-sm font-semibold text-white">Downloads</p>
              <div className="grid gap-2 sm:grid-cols-4 lg:grid-cols-6">
                <DownloadFileButton
                  url={primaryExport.downloadUrl || primaryExport.videoUrl}
                  filename={`Project_${projectNumber}_Final.mp4`}
                  icon={<Download className="h-4 w-4" />}
                  className="flex h-10 items-center justify-center gap-2 rounded-md bg-accent px-3 text-sm font-semibold text-white transition-colors hover:bg-accent/90"
                >
                  Download Final MP4
                </DownloadFileButton>
                <DownloadFileButton
                  url={primaryExport.subtitleUrl}
                  filename={`SRT No. ${primaryExport.srtSequence || projectNumber}.srt`}
                  icon={<Type className="h-4 w-4 text-accent" />}
                  className="flex h-10 items-center justify-center gap-2 rounded-md border border-accent/30 bg-accent/10 px-3 text-sm font-medium text-white transition-colors hover:bg-accent/20"
                >
                  Download Synced SRT
                </DownloadFileButton>
                <DownloadFileButton
                  url={primaryExport.thumbnailDownloadUrl || primaryExport.thumbnailUrl}
                  filename={`Project_${projectNumber}_Thumbnail.jpg`}
                  icon={<Download className="h-4 w-4" />}
                  className="flex h-10 items-center justify-center gap-2 rounded-md border border-white/10 bg-white/5 px-3 text-sm font-medium text-white transition-colors hover:bg-white/10"
                >
                  Download Clean Thumbnail JPG
                </DownloadFileButton>
                <DownloadFileButton
                  url={primaryExport.audioUrl}
                  filename={`Project_${projectNumber}_Narration.mp3`}
                  icon={<Volume2 className="h-4 w-4 text-accent" />}
                  className="flex h-10 items-center justify-center gap-2 rounded-md border border-accent/30 bg-accent/10 px-3 text-sm font-medium text-white transition-colors hover:bg-accent/20"
                >
                  Download Narration MP3
                </DownloadFileButton>
                <DownloadFileButton
                  url={packagedPrimaryExport?.metadataUrl}
                  filename={`Project_${projectNumber}_Metadata.json`}
                  icon={<FileJson2 className="h-4 w-4 text-accent" />}
                  className="flex h-10 items-center justify-center gap-2 rounded-md border border-accent/30 bg-accent/10 px-3 text-sm font-medium text-white transition-colors hover:bg-accent/20"
                >
                  Download Metadata JSON
                </DownloadFileButton>
                <DownloadFileButton
                  url={packagedPrimaryExport?.packageUrl}
                  filename={`Project_${projectNumber}_Export.zip`}
                  icon={<Archive className="h-4 w-4 text-accent" />}
                  className="flex h-10 items-center justify-center gap-2 rounded-md border border-accent/30 bg-accent/10 px-3 text-sm font-medium text-white transition-colors hover:bg-accent/20"
                >
                  Download Export ZIP
                </DownloadFileButton>
              </div>
            </div>
          </>
        )}
        <div className="grid gap-4 sm:grid-cols-2">
          {exports.map((item) => (
            <div key={item.language} className="rounded-xl border border-white/10 bg-black/20 p-3">
              <div className="mb-2 text-xs font-semibold text-white/70">
                {item.language === "myanmar" ? "မြန်မာ Thumbnail" : "English Thumbnail"}
              </div>
              <img
                src={item.thumbnailUrl}
                alt={`${projectTitle} thumbnail`}
                className="aspect-[9/16] max-h-[520px] w-full rounded-lg border border-white/10 object-contain bg-black"
                loading="lazy"
              />
            </div>
          ))}
        </div>

        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
               <p className="text-sm font-semibold text-white">AI Generated Burmese Title & Caption</p>
              <p className="text-xs text-white/50">မြန်မာ narration script အပေါ်အခြေခံထားသည်။</p>
            </div>
            <Button
              type="button"
              size="sm"
              variant="secondary"
              className="gap-2 border-white/10 bg-white/5 hover:bg-white/10"
              onClick={onGenerateMetadata}
              disabled={metadataLoading}
            >
              {metadataLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              {hookTitle || caption ? "Regenerate" : "Generate Metadata"}
            </Button>
          </div>
             {hookTitle || caption ? (
             <div className="space-y-2">
                {hookTitle && (
                  <div className="flex items-center gap-2 rounded-lg border border-primary/25 bg-primary/10 p-2.5">
                    <div className="min-w-0 flex-1">
                      <p className="text-[11px] text-white/50">AI Generated Burmese Title</p>
                      <p className="mt-1 text-sm font-semibold leading-relaxed text-white">{hookTitle}</p>
                    </div>
                    <Button type="button" size="icon" variant="ghost" className="shrink-0" onClick={() => void copy(hookTitle, "title", "Burmese title")} aria-label="Copy AI generated Burmese title">
                      <Copy className={`h-4 w-4 ${copied === "title" ? "text-emerald-400" : ""}`} />
                    </Button>
                  </div>
                )}
               <div className="flex items-start gap-2 rounded-lg border border-white/10 bg-white/[0.03] p-2.5">
                 <div className="min-w-0 flex-1 space-y-2">
                   <p className="text-sm font-semibold text-white">{hookTitle || "Hook title မရသေးပါ။"}</p>
                   <p className="whitespace-pre-line text-sm leading-relaxed text-white/75">{caption || "Caption မရသေးပါ။"}</p>
                 </div>
                 <Button type="button" size="icon" variant="ghost" className="shrink-0" onClick={() => void copy(`${hookTitle}\n\n${caption}`, "metadata", "Metadata")} aria-label="Copy hook title and caption">
                   <Copy className={`h-4 w-4 ${copied === "metadata" ? "text-emerald-400" : ""}`} />
                 </Button>
               </div>
             </div>
          ) : (
            <div className="rounded-lg border border-dashed border-white/10 p-4 text-center text-xs text-white/50">
              Metadata ထုတ်ပေးရန် Generate Metadata ကိုနှိပ်ပါ။
            </div>
          )}
        </div>

        <div className="rounded-xl border border-accent/20 bg-accent/5 p-3">
          <div className="flex items-center justify-between gap-2">
            <p className="text-sm font-semibold text-white">Targeted Viral Hashtags</p>
            <Button type="button" size="sm" variant="ghost" className="gap-2 text-accent hover:bg-accent/10" disabled={!hashtags.length} onClick={() => void copy(hashtags.join(" "), "hashtags", "Hashtags")}>
              <Copy className={`h-4 w-4 ${copied === "hashtags" ? "text-emerald-400" : ""}`} /> Copy All
            </Button>
          </div>
          <p className="mt-2 text-sm leading-relaxed text-accent">{hashtags.join(" ") || "Hashtags မရသေးပါ။"}</p>
        </div>
      </CardContent>
    </Card>
  )
}