import { useEffect, useRef, useState } from "react"
import type { Export as ExportRecord } from "@workspace/api-client-react"
import { Button } from "@/components/ui/button"
import { DownloadFileButton } from "@/components/download-file-button"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog"
import { Archive, Download, FileJson2, Pause, Play, Save, Trash2, Type, Video, Volume2 } from "lucide-react"
import { localizeLanguage } from "@/lib/i18n"

type ExportMediaPanelProps = {
  exportItem: ExportRecord
  projectTitle: string
  projectNumber: number
  compact?: boolean
  showVideoPreview?: boolean
  onDelete?: () => void
  isDeleting?: boolean
}

type PackagedExport = ExportRecord & {
  metadataUrl?: string
  packageUrl?: string
}

export function ExportMediaPanel({
  exportItem,
  projectTitle,
  projectNumber,
  compact = false,
  showVideoPreview = true,
  onDelete,
  isDeleting = false,
}: ExportMediaPanelProps) {
  const packagedExport = exportItem as PackagedExport
  const language = localizeLanguage(exportItem.language)
  const isMyanmar = exportItem.language === "myanmar"
  const [deleteOpen, setDeleteOpen] = useState(false)

  return (
    <div className="rounded-xl bg-card border border-white/10 overflow-hidden shadow-sm group">
      <div className="p-3 border-b border-white/5 flex flex-wrap items-center justify-between gap-2 bg-background/50">
        <div className="flex items-center gap-2">
          <Video className={`h-4 w-4 ${isMyanmar ? 'text-accent' : 'text-primary'}`} />
          <span className="text-sm font-semibold">{language}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-muted-foreground bg-background px-1.5 py-0.5 rounded border border-white/5">
            {Math.floor(exportItem.duration / 60)} မိနစ် {Math.floor(exportItem.duration % 60)} စက္ကန့်
          </span>
          {onDelete && (
            <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
              <AlertDialogTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-muted-foreground hover:bg-destructive/15 hover:text-destructive"
                  aria-label={`${language} export ဖျက်ရန်`}
                  disabled={isDeleting}
                >
                  {isDeleting ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" /> : <Trash2 className="h-3.5 w-3.5" />}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>ပြီးသား video ကို ဖျက်မည်လား။</AlertDialogTitle>
                  <AlertDialogDescription>
                    {language} export ရဲ့ video၊ thumbnail၊ audio နဲ့ subtitle ဖိုင်များကို အပြီးတိုင် ဖျက်ပါမည်။ Project မူရင်း video မထိခိုက်ပါ။
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>မဖျက်တော့ပါ</AlertDialogCancel>
                  <AlertDialogAction
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    onClick={() => {
                      setDeleteOpen(false)
                      onDelete()
                    }}
                  >
                    ဖျက်ရန်
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
      </div>
      
      <div className="p-3 space-y-3">
        <img
          src={exportItem.thumbnailUrl}
          alt={`${projectTitle} ${language} thumbnail`}
          className="aspect-[9/16] max-h-[520px] w-full rounded-lg border border-white/10 object-contain bg-black"
          loading="lazy"
        />
        {showVideoPreview && (
          <div className={`overflow-hidden rounded-lg border border-white/10 bg-black relative ${compact ? "w-full" : ""}`}>
            <VideoPlayer src={exportItem.videoUrl} label={`${language} ဗီဒီယိုကြည့်ရန်`} />
          </div>
        )}

        <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 shadow-inner">
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-4 lg:grid-cols-6">
            <DownloadFileButton
              url={exportItem.downloadUrl || exportItem.videoUrl}
              filename={`Project_${projectNumber}_Final${exportItem.language === "english" ? "_English" : ""}.mp4`}
              icon={<Save className="h-4 w-4" />}
              className={`flex h-9 w-full items-center justify-center gap-2 rounded-md px-3 text-sm font-medium text-white shadow-lg transition-colors ${isMyanmar ? "bg-accent hover:bg-accent/90" : "bg-primary hover:bg-primary/90"}`}
            >
              Download Final MP4
            </DownloadFileButton>
            <DownloadFileButton
              url={exportItem.thumbnailDownloadUrl || exportItem.thumbnailUrl}
              filename={`Project_${projectNumber}_Thumbnail.jpg`}
              icon={<Download className="h-4 w-4" />}
              className="flex h-9 w-full items-center justify-center gap-2 rounded-md border border-white/10 bg-white/5 px-3 text-sm font-medium text-white transition-colors hover:bg-white/10"
            >
              Download Clean Thumbnail JPG
            </DownloadFileButton>
            <DownloadFileButton
              url={exportItem.subtitleUrl}
              filename={`SRT No. ${exportItem.srtSequence || projectNumber}.srt`}
              icon={<Type className="h-4 w-4 text-accent" />}
              className="flex h-9 w-full items-center justify-center gap-2 rounded-md border border-accent/30 bg-accent/10 px-3 text-sm font-medium text-white transition-colors hover:bg-accent/20"
            >
              Download Synced SRT
            </DownloadFileButton>
            <DownloadFileButton
              url={exportItem.audioUrl}
              filename={`Project_${projectNumber}_Narration.mp3`}
              icon={<Volume2 className="h-4 w-4 text-accent" />}
              className="flex h-9 w-full items-center justify-center gap-2 rounded-md border border-accent/30 bg-accent/10 px-3 text-sm font-medium text-white transition-colors hover:bg-accent/20"
            >
              Download Narration MP3
            </DownloadFileButton>
            <DownloadFileButton
              url={packagedExport.metadataUrl}
              filename={`Project_${projectNumber}_Metadata.json`}
              icon={<FileJson2 className="h-4 w-4 text-accent" />}
              className="flex h-9 w-full items-center justify-center gap-2 rounded-md border border-accent/30 bg-accent/10 px-3 text-sm font-medium text-white transition-colors hover:bg-accent/20"
            >
              Download Metadata JSON
            </DownloadFileButton>
            <DownloadFileButton
              url={packagedExport.packageUrl}
              filename={`Project_${projectNumber}_Export.zip`}
              icon={<Archive className="h-4 w-4 text-accent" />}
              className="flex h-9 w-full items-center justify-center gap-2 rounded-md border border-accent/30 bg-accent/10 px-3 text-sm font-medium text-white transition-colors hover:bg-accent/20"
            >
              Download Export ZIP
            </DownloadFileButton>
          </div>
        </div>
        <SubtitlePreview url={exportItem.subtitleUrl} />
      </div>
    </div>
  )
}

type SubtitleCue = {
  timing: string
  text: string
}

function parseSubtitlePreview(value: string): SubtitleCue[] {
  return value
    .replace(/\r\n?/gu, "\n")
    .trim()
    .split(/\n{2,}/u)
    .flatMap((block) => {
      const lines = block.split("\n")
      const timingIndex = lines.findIndex((line) => line.includes("-->"))
      if (timingIndex < 0) return []
      const text = lines.slice(timingIndex + 1).join("\n").trim()
      const timing = lines[timingIndex].trim()
      return text ? [{ timing, text }] : []
    })
}

function SubtitlePreview({ url }: { url?: string | null }) {
  const [open, setOpen] = useState(false)
  const [cues, setCues] = useState<SubtitleCue[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(false)

  useEffect(() => {
    setOpen(false)
    setCues([])
    setError(false)
  }, [url])

  useEffect(() => {
    if (!open || !url || cues.length || isLoading || error) return
    let cancelled = false
    setIsLoading(true)
    fetch(url, { credentials: "include" })
      .then(async (response) => {
        if (!response.ok) throw new Error("Subtitle preview unavailable.")
        return response.text()
      })
      .then((text) => {
        if (!cancelled) setCues(parseSubtitlePreview(text))
      })
      .catch(() => {
        if (!cancelled) setError(true)
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [open, url, cues.length, isLoading, error])

  if (!url) return null

  return (
    <div className="rounded-lg border border-white/10 bg-background/30">
      <button
        type="button"
        className="flex w-full items-center justify-between gap-3 px-3 py-2 text-left text-xs font-medium text-white/80 hover:bg-white/5"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
      >
        <span>Readable synced SRT preview</span>
        <span className="text-muted-foreground">{open ? "Hide" : "Show"}</span>
      </button>
      {open && (
        <div className="border-t border-white/10 p-3">
          {isLoading ? (
            <p className="text-xs text-muted-foreground">Loading subtitles…</p>
          ) : error ? (
            <button type="button" className="text-xs text-destructive underline" onClick={() => setError(false)}>
              Preview failed. Try again.
            </button>
          ) : cues.length ? (
            <div className="max-h-64 space-y-2 overflow-y-auto pr-1">
              {cues.map((cue, index) => (
                <div key={`${cue.timing}-${index}`} className="rounded-md border border-white/5 bg-black/20 p-2">
                  <p className="text-[10px] tabular-nums text-accent">{cue.timing}</p>
                  <p className="mt-1 whitespace-pre-wrap text-xs leading-relaxed text-white/80">{cue.text}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">No readable subtitle cues were found.</p>
          )}
        </div>
      )}
    </div>
  )
}

function formatPlaybackTime(value: number) {
  const seconds = Math.max(0, Math.floor(Number.isFinite(value) ? value : 0))
  const minutes = Math.floor(seconds / 60)
  return `${minutes}:${String(seconds % 60).padStart(2, "0")}`
}

export function VideoPlayer({ src, label }: { src: string; label: string }) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [duration, setDuration] = useState(0)
  const [currentTime, setCurrentTime] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isReady, setIsReady] = useState(false)

  useEffect(() => {
    setIsReady(false)
    setDuration(0)
    setCurrentTime(0)
    setIsPlaying(false)

    return () => {
      const video = videoRef.current
      if (!video) return
      video.pause()
    }
  }, [src])

  const togglePlayback = async () => {
    const video = videoRef.current
    if (!video || !isReady) return
    if (video.paused) {
      await video.play().catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") return
        if (error && typeof error === "object" && "name" in error && error.name === "AbortError") return
        console.error(error)
      })
    } else {
      video.pause()
    }
  }

  const seek = (value: number) => {
    const video = videoRef.current
    if (!video || !isReady) return
    const nextTime = Math.max(0, Math.min(value, duration || 0))
    video.currentTime = nextTime
    setCurrentTime(nextTime)
  }

  return (
    <div className="relative bg-black">
      <video
        ref={videoRef}
        className="aspect-[9/16] w-full max-h-[400px] object-contain"
        src={src}
        playsInline
        preload="metadata"
        onLoadStart={() => {
          setIsReady(false)
          setIsPlaying(false)
        }}
        onLoadedMetadata={(event) => {
          const video = videoRef.current ?? event.currentTarget
          if (!video) return
          const nextDuration = Number.isFinite(video.duration) ? Math.max(0, video.duration) : 0
          const nextTime = Number.isFinite(video.currentTime) ? Math.max(0, video.currentTime) : 0
          setDuration(nextDuration)
          setCurrentTime(nextTime)
          setIsReady(true)
        }}
        onTimeUpdate={(event) => {
          const video = videoRef.current ?? event.currentTarget
          if (!video || video.readyState < 1) return
          const nextTime = Number.isFinite(video.currentTime) ? Math.max(0, video.currentTime) : 0
          setCurrentTime(nextTime)
        }}
        onError={() => {
          setIsReady(false)
          setIsPlaying(false)
        }}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={() => setIsPlaying(false)}
        aria-label={label}
      />
      {!isReady && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/45 text-xs text-white/80">
          ဗီဒီယိုကို ပြင်ဆင်နေသည်…
        </div>
      )}
      <div className="border-t border-white/10 bg-background/95 p-3">
        <div className="flex items-center gap-3">
          <Button
            type="button"
            variant="secondary"
            size="icon"
            className="h-9 w-9 shrink-0"
            onClick={() => void togglePlayback()}
            disabled={!isReady}
            aria-label={isPlaying ? "ခဏရပ်ရန်" : "ဖွင့်ရန်"}
          >
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <input
            type="range"
            min={0}
            max={duration || 0}
            step={0.01}
            value={Math.min(currentTime, duration || 0)}
            onChange={(event) => seek(Number(event.target.value))}
            disabled={!isReady}
            className="h-2 min-w-0 flex-1 accent-primary"
            aria-label="ဗီဒီယို timeline"
          />
          <span className="min-w-[76px] text-right text-xs tabular-nums text-muted-foreground">
            {formatPlaybackTime(currentTime)} / {formatPlaybackTime(duration)}
          </span>
        </div>
      </div>
    </div>
  )
}
