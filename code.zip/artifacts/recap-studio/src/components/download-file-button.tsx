import { useState, type ReactNode } from "react"
import { Download, Loader2, RefreshCw } from "lucide-react"

type DownloadState = "idle" | "checking" | "requested" | "error"

type DownloadFileButtonProps = {
  url?: string | null
  filename: string
  children: ReactNode
  icon?: ReactNode
  className?: string
  disabled?: boolean
}

export function DownloadFileButton({
  url,
  filename,
  children,
  icon,
  className = "",
  disabled = false,
}: DownloadFileButtonProps) {
  const [state, setState] = useState<DownloadState>("idle")

  const download = async () => {
    if (!url || disabled) return
    setState("checking")
    try {
      const response = await fetch(url, {
        method: "HEAD",
        credentials: "include",
        cache: "no-store",
      })
      if (!response.ok) {
        throw new Error(`Download check failed with HTTP ${response.status}.`)
      }

      // Keep the actual file on the browser's streamed download path so large
      // videos are not buffered into a JavaScript Blob.
      const link = document.createElement("a")
      link.href = url
      link.download = filename
      link.rel = "noopener"
      document.body.appendChild(link)
      link.click()
      link.remove()
      setState("requested")
    } catch (error) {
      console.error("File download request failed", error)
      setErrorMessage(
        error instanceof Error
          ? error.message
          : "Could not check the download. Try again.",
      )
      setState("error")
    }
  }

  const [errorMessage, setErrorMessage] = useState("")
  const isUnavailable = !url || disabled || state === "checking"
  const buttonLabel = state === "error"
    ? "Retry download"
    : state === "checking"
      ? "Checking download…"
      : state === "requested"
        ? "Download requested — check your browser"
      : children

  return (
    <div className="min-w-0">
      <button
        type="button"
        onClick={download}
        disabled={isUnavailable}
        aria-busy={state === "checking"}
        className={`min-w-0 ${className} disabled:cursor-not-allowed disabled:opacity-60`}
        aria-label={typeof children === "string" ? children : undefined}
      >
        {state === "checking"
          ? <Loader2 className="h-4 w-4 animate-spin" />
          : state === "error"
            ? <RefreshCw className="h-4 w-4" />
            : state === "requested"
              ? <Download className="h-4 w-4" />
              : icon}
        <span className="min-w-0 flex-1 truncate">{buttonLabel}</span>
      </button>
      {state === "requested" && (
        <p className="mt-1 text-[10px] text-emerald-400" aria-live="polite">
          Request accepted. Check your browser downloads.
        </p>
      )}
      {state === "error" && (
        <p className="mt-1 text-[10px] text-destructive" aria-live="polite" role="alert">
          {errorMessage || "Download failed. Try again."}
        </p>
      )}
    </div>
  )
}