import * as React from "react"
import { Link, useLocation } from "wouter"
import { Film, LayoutDashboard, Settings, Video, Download, Calendar, Radio, Radar } from "lucide-react"
import { cn } from "@/lib/utils"

const navItems = [
  { icon: LayoutDashboard, label: "အနှစ်ချုပ်", href: "/" },
  { icon: Film, label: "ပရောဂျက်များ", href: "/projects" },
  { icon: Radar, label: "ဗိုင်းရယ်ရှာဖွေစက်", href: "/viral-finder" },
  { icon: Calendar, label: "အချိန်ဇယား", href: "/scheduler" },
  { icon: Download, label: "ထုတ်ယူထားသောဗီဒီယိုများ", href: "/exports" },
  { icon: Settings, label: "ဆက်တင်များ", href: "/settings" },
]

export function Sidebar() {
  const [location] = useLocation()
  
  return (
    <aside className="fixed inset-x-0 bottom-0 z-50 flex h-[5.25rem] border-t border-white/[0.08] bg-[#10131c]/[0.97] pb-[env(safe-area-inset-bottom)] shadow-[0_-12px_32px_rgba(0,0,0,.28)] backdrop-blur-2xl md:inset-y-0 md:left-0 md:right-auto md:h-auto md:w-64 md:flex-col md:border-r md:border-t-0 md:px-3 md:py-5 md:shadow-none">
      <div className="hidden items-center gap-3 px-3 md:mb-10 md:flex">
        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-[0_8px_24px_hsl(var(--primary)/.22)]">
          <Video className="w-4 h-4 text-primary-foreground" />
        </div>
        <div>
          <span className="block text-[15px] font-semibold tracking-tight text-foreground">Recap Studio</span>
          <span className="studio-kicker block text-[8px] text-primary/80">တည်းဖြတ် / ဘာသာပြန် / ထုတ်ဝေ</span>
        </div>
      </div>
      
      <div className="hidden px-3 pb-3 md:block">
        <span className="studio-kicker">အလုပ်ခွင်</span>
      </div>
      <nav className="flex w-full items-stretch justify-around gap-1 px-1.5 pt-1.5 md:flex-col md:gap-1.5 md:px-0 md:pt-0">
        {navItems.map((item) => {
          const isActive = location === item.href || 
                          (item.href !== '/' && location.startsWith(item.href));
                          
          return (
            <Link 
              key={item.href} 
              href={item.href}
              aria-current={isActive ? "page" : undefined}
              className={cn(
                "group flex min-h-12 min-w-0 flex-1 flex-col items-center justify-center gap-1 rounded-xl px-1 py-1.5 text-[9px] leading-tight transition-colors md:flex-row md:justify-start md:gap-3 md:px-3 md:py-3 md:text-sm",
                isActive 
                  ? "bg-primary/12 font-semibold text-primary md:shadow-[inset_3px_0_0_hsl(var(--primary))]"
                  : "text-muted-foreground hover:bg-white/[0.05] hover:text-foreground"
              )}
              title={item.label}
            >
              <item.icon className={cn(
                "h-[18px] w-[18px] flex-shrink-0 transition-transform duration-200 group-hover:-translate-y-0.5 md:h-5 md:w-5 md:group-hover:translate-x-0.5",
                isActive && "text-primary"
              )} />
              <span className="max-w-full truncate">{item.label}</span>
            </Link>
          )
        })}
      </nav>
      <div className="mt-auto hidden border-t border-white/[0.08] px-3 pt-5 md:block">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Radio className="h-3.5 w-3.5 text-accent" />
          <span>စတူဒီယို အွန်လိုင်း</span>
          <span className="ml-auto h-1.5 w-1.5 rounded-full bg-accent shadow-[0_0_8px_hsl(var(--accent)/.8)]" />
        </div>
      </div>
    </aside>
  )
}
