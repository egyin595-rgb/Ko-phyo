import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Sidebar } from '@/components/layout/sidebar';

import NotFound from '@/pages/not-found';
import Dashboard from '@/pages/dashboard';
import Projects from '@/pages/projects';
import ProjectDetail from '@/pages/project-detail';
import Scheduler from '@/pages/scheduler';
import Exports from '@/pages/exports';
import Settings from '@/pages/settings';
import ViralFinder from '@/pages/viral-finder';

import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-[100dvh] bg-background studio-grid">
      <Sidebar />
      <main className="min-h-[100dvh] pl-0 transition-all duration-300 md:pl-64">
        <div className="mx-auto max-w-[1440px] px-3 pb-24 pt-3 sm:px-6 sm:pb-12 sm:pt-5 md:px-10 md:pt-8">
          {children}
        </div>
      </main>
    </div>
  )
}

function Router() {
  return (
    <Layout>
      <RoutedErrorBoundary>
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/projects" component={Projects} />
          <Route path="/projects/:id" component={ProjectDetail} />
          <Route path="/viral-finder" component={ViralFinder} />
          <Route path="/scheduler" component={Scheduler} />
          <Route path="/exports" component={Exports} />
          <Route path="/settings" component={Settings} />
          <Route component={NotFound} />
        </Switch>
      </RoutedErrorBoundary>
    </Layout>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider delayDuration={200}>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
