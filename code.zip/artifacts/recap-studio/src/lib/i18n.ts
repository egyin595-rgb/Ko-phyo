const statusLabels: Record<string, string> = {
  draft: "မူကြမ်း",
  processing: "လုပ်ဆောင်နေသည်",
  queued: "တန်းစီထားသည်",
  completed: "ပြီးစီးပြီ",
  failed: "မအောင်မြင်ပါ",
  scheduled: "အချိန်ဇယားသတ်မှတ်ထားသည်",
  cancelled: "ပယ်ဖျက်ပြီး",
}

const stageLabels: Record<string, string> = {
  "Not started": "မစတင်ရသေးပါ",
  Scheduled: "အချိန်ဇယားထဲသို့ ထည့်ပြီး",
  Queued: "တန်းစီထားသည်",
  Starting: "စတင်နေသည်",
  "Preparing uploaded source video": "တင်ထားသော မူရင်းဗီဒီယိုကို ပြင်ဆင်နေသည်",
  "Downloading source video": "မူရင်းဗီဒီယိုကို ဒေါင်းလုဒ်လုပ်နေသည်",
  "Source video ready": "မူရင်းဗီဒီယို အဆင်သင့်ဖြစ်ပြီ",
  "Transcribing Chinese audio": "တရုတ်အသံကို စာသားပြောင်းနေသည်",
  "Speaker dialogue ready": "ဇာတ်ကောင်အလိုက် စကားပြောစာသား ရရှိပြီ",
  "Chinese transcript ready": "တရုတ်စာသား ရရှိပြီ",
  "Translating character dialogue": "ဇာတ်ကောင်စကားပြောများကို တိုက်ရိုက်ဘာသာပြန်နေသည်",
  "Character dialogue ready": "ဇာတ်ကောင်စကားပြော ဘာသာပြန်ပြီးပြီ",
  "Writing recap scripts": "အနှစ်ချုပ်စာသားများ ရေးနေသည်",
  "Recap scripts ready": "အနှစ်ချုပ်စာသားများ အဆင်သင့်ဖြစ်ပြီ",
  "Generating narration": "နောက်ခံအသံ ဖန်တီးနေသည်",
  "Generating character voices": "ဇာတ်ကောင်အလိုက် အသံများ ဖန်တီးနေသည်",
  "Narration and subtitles ready": "နောက်ခံအသံနှင့် စာတန်းထိုး အဆင်သင့်ဖြစ်ပြီ",
  "Character voices and subtitles ready": "ဇာတ်ကောင်အသံနှင့် စာတန်းထိုး အဆင်သင့်ဖြစ်ပြီ",
  "Rendering both videos": "ဗီဒီယိုနှစ်ခုကို ဖန်တီးနေသည်",
  "Uploading completed exports": "ပြီးစီးသောဗီဒီယိုများကို သိမ်းဆည်းနေသည်",
  "Gemini temporarily rate-limited. Retrying…": "Gemini ကို ယာယီကန့်သတ်ထားသဖြင့် ပြန်လည်ကြိုးစားနေသည်",
  "Gemini unavailable temporarily. Continuing with fallback translation…": "Gemini ယာယီမရသဖြင့် အစားထိုးဘာသာပြန်ဖြင့် ဆက်လုပ်နေသည်",
  "Fallback translation ready; continuing with narration and export.": "အစားထိုးဘာသာပြန် အဆင်သင့်ဖြစ်ပြီ၊ အသံနှင့်ဗီဒီယိုထုတ်ယူမှု ဆက်လုပ်နေသည်",
  "Export complete": "ဗီဒီယိုထုတ်ယူမှု ပြီးစီးပြီ",
  Ready: "အဆင်သင့်ဖြစ်ပြီ",
  Failed: "မအောင်မြင်ပါ",
  Cancelled: "ပယ်ဖျက်ပြီး",
  Interrupted: "ရပ်တန့်သွားသည်",
}

const messageLabels: Record<string, string> = {
  "Project created": "ပရောဂျက် ဖန်တီးပြီးပါပြီ",
  "Processing complete": "လုပ်ဆောင်မှု ပြီးစီးပါပြီ",
  "Project changes saved": "ပရောဂျက်ပြောင်းလဲမှုများကို သိမ်းဆည်းပြီးပါပြီ",
  "Scheduled job cancelled": "အချိန်ဇယားသတ်မှတ်ထားသော လုပ်ဆောင်မှုကို ပယ်ဖျက်ပြီးပါပြီ",
}

export function localizeLanguage(language: string) {
  return language === "myanmar" ? "မြန်မာ" : language === "english" ? "အင်္ဂလိပ်" : language
}

export function localizeMode(mode: string) {
  const labels: Record<string, string> = {
    instant: "ချက်ချင်း",
    smart: "စမတ်",
    manual: "ကိုယ်တိုင်",
  }
  return labels[mode] || mode
}

export function localizeStatus(status: string, progress?: number) {
  const label = statusLabels[status] || status
  return status === "processing" || status === "queued"
    ? `${label} ${Math.round(progress || 0)}%`
    : label
}

export function localizeStage(stage: string) {
  if (!stage) return "";
  if (stageLabels[stage]) return stageLabels[stage];
  
  const s = stage.toLowerCase();
  if (s.includes("rendering myanmar")) return "မြန်မာဗီဒီယို ဖန်တီးနေသည်";
  if (s.includes("rendering english")) return "အင်္ဂလိပ်ဗီဒီယို ဖန်တီးနေသည်";
  if (s.includes("rendering")) return "ဗီဒီယို ဖန်တီးနေသည်";
  if (s.includes("self-heal") || s.includes("self heal")) return "အမှားများကို အလိုအလျောက် ပြင်ဆင်နေသည်";
  if (s.includes("uploading export") || s.includes("uploading completed")) return "ပြီးစီးသောဗီဒီယိုများကို သိမ်းဆည်းနေသည်";
  if (s.includes("gemini temporarily rate-limited")) return "Gemini ကို ယာယီကန့်သတ်ထားသဖြင့် ပြန်လည်ကြိုးစားနေသည်";
  if (s.includes("continuing with fallback translation")) return "Gemini ယာယီမရသဖြင့် အစားထိုးဘာသာပြန်ဖြင့် ဆက်လုပ်နေသည်";
  if (s.includes("fallback translation ready")) return "အစားထိုးဘာသာပြန် အဆင်သင့်ဖြစ်ပြီ၊ ဆက်လုပ်နေသည်";
  if (s.includes("uploading")) return "ဖိုင်သိမ်းဆည်းနေသည်";
  if (s.includes("downloading")) return "ဒေါင်းလုဒ်လုပ်နေသည်";
  
  return stage.replaceAll("_", " ");
}

export function localizeMessage(message: string) {
  if (messageLabels[message]) return messageLabels[message]
  if (message.endsWith(" job queued")) {
    const action = message.replace(/ job queued$/, "").toLowerCase()
    const actionLabels: Record<string, string> = {
      full: "အစအဆုံး",
      transcribe: "စာသားပြောင်း",
      translate: "ဘာသာပြန်",
      export: "ထုတ်ယူ",
    }
    return `${actionLabels[action] || "လုပ်ဆောင်မှု"} ကို တန်းစီထားပါပြီ`
  }
  return localizeStage(message)
}

export function localizeError(value: unknown) {
  const message = String(value || "")
  if (!message) return "တစ်စုံတစ်ရာ မှားယွင်းသွားပါသည်။ ထပ်မံကြိုးစားပါ။"
  if (message.includes("Disk storage full") || message.includes("disk space")) {
    return "Disk နေရာ မလုံလောက်ပါ။ အနည်းဆုံး ၂၅၀ MB နေရာလွတ်ထားပြီး ထပ်မံကြိုးစားပါ။"
  }
  if (message.includes("Network timeout") || message.includes("timed out during upload")) {
    return "ကွန်ယက် upload ချိန်ကုန်သွားပါသည်။ အင်တာနက်ကို စစ်ဆေးပြီး ၅ မိနစ်အတွင်း ထပ်မံကြိုးစားပါ။"
  }
  if (message.includes("Unsupported video codec") || message.includes("corrupt video")) {
    return "ဗီဒီယို codec ကို မထောက်ပံ့ပါ သို့မဟုတ် ဖိုင်ပျက်နေပါသည်။ MP4/MOV/MKV/WebM ဖိုင်ကို ပြန်ရွေးပါ။"
  }
  if (message.includes("normalization timed out")) {
    return "ဗီဒီယိုဖော်မတ်ပြောင်းချိန် ၁၅ မိနစ်ကျော်သွားပါသည်။ ပိုတိုသောဗီဒီယိုကို စမ်းပါ။"
  }
  if (message.includes("Upload cancelled")) {
    return "ဗီဒီယိုတင်ခြင်းကို ပယ်ဖျက်ပြီးပါပြီ။"
  }
  if (message.includes("Project not found")) return "ပရောဂျက်ကို ရှာမတွေ့ပါ။"
  if (
    message.includes("rate limited by Gemini") ||
    message.includes("Gemini") && message.includes("429") ||
    message.includes("quota")
  ) {
    return "Gemini ဘာသာပြန်ဝန်ဆောင်မှုကို ယာယီကန့်သတ်ထားပါသည်။ ခဏအကြာတွင် ထပ်မံကြိုးစားပါ။"
  }
  if (
    message.includes("temporarily unavailable in Gemini") ||
    message.includes("Gemini") && message.includes("503")
  ) {
    return "Gemini ဝန်ဆောင်မှုမှာ လက်ရှိအသုံးများနေပါသည်။ ခဏအကြာတွင် ထပ်မံကြိုးစားပါ။"
  }
  if (
    message.includes("no fallback translation provider") ||
    message.includes("fallback translation provider could not")
  ) {
    return "Gemini ကို ယာယီကန့်သတ်ထားပြီး အစားထိုးဘာသာပြန်ဝန်ဆောင်မှု မအောင်မြင်ပါ။ Manual Script ထည့်ပြီး ထပ်မံကြိုးစားပါ။"
  }
  if (
    message.includes("Gemini rejected the configured API key") ||
    message.includes("Gemini API key")
  ) {
    return "Gemini API key ကို အသုံးပြု၍ မရပါ။ API key နှင့် provider setting ကို စစ်ဆေးပြီး ထပ်မံကြိုးစားပါ။"
  }
  if (
    message.includes("AssemblyAI rejected") ||
    message.includes("ASSEMBLYAI_AUTH_ERROR")
  ) {
    return "Speech transcription ဝန်ဆောင်မှု၏ အထောက်အထားကို အသုံးပြု၍ မရပါ။ ခဏအကြာတွင် ထပ်မံကြိုးစားပါ။"
  }
  if (
    message.includes("AssemblyAI") ||
    message.includes("ASSEMBLYAI_") ||
    message.includes("Speech transcription service is temporarily unavailable")
  ) {
    return "အသံစာသားပြောင်းဝန်ဆောင်မှု ယာယီမရနိုင်ပါ။ ခဏအကြာတွင် ထပ်မံကြိုးစားပါ။"
  }
  if (message.includes("endpoint") || message.includes("database")) {
    return "ဆာဗာဒေတာဘေ့စ်ကို ချိတ်ဆက်၍ မရပါ။ ခဏအကြာတွင် ထပ်မံကြိုးစားပါ။"
  }
  if (message.includes("API server")) return "API ဆာဗာကို မတွေ့ပါ။ ဆာဗာအခြေအနေကို စစ်ဆေးပါ။"
  if (message.includes("Save")) return "သိမ်းဆည်း၍ မရပါ။ ထပ်မံကြိုးစားပါ။"
  if (message.includes("Download")) return "ဒေါင်းလုဒ်လုပ်၍ မရပါ။ ထပ်မံကြိုးစားပါ။"
  if (
    message.includes("upload") || message.includes("Upload") ||
    message.includes("video file") || message.includes("video files") ||
    message.includes("normalized") || message.includes("Choose an MP4")
  ) {
    return "ဗီဒီယိုတင်၍ မရပါ။ MP4၊ MOV၊ MKV သို့မဟုတ် WebM ဖိုင်ဖြစ်ပြီး ၅၀၀ MB မကျော်ကြောင်း စစ်ဆေးပါ။"
  }
  if (message.includes("transcri") || message.includes("Transcri")) return "စာသားပြောင်း၍ မရပါ။ အသံဖိုင်နှင့် ဝန်ဆောင်မှုဆက်သွယ်မှုကို စစ်ဆေးပါ။"
  if (message.includes("required") || message.includes("required")) return "လိုအပ်သောအချက်အလက်များကို ဖြည့်စွက်ပါ။"
  return "လုပ်ဆောင်မှု မအောင်မြင်ပါ။ အသေးစိတ်ကို စစ်ဆေးပြီး ထပ်မံကြိုးစားပါ။"
}

export function formatMyanmarDate(dateString: string) {
  return new Date(dateString).toLocaleDateString("my-MM", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  })
}