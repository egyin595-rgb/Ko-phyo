import { 
  useListSchedules, 
  useCreateSchedule, 
  useCancelSchedule,
  useListProjects,
  getListSchedulesQueryKey,
  getListProjectsQueryKey,
  getGetProjectQueryKey
} from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { Calendar, Clock, Loader2, XCircle, CheckCircle2, PlayCircle, Zap } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { DialogDescription } from "@radix-ui/react-dialog"
import { formatMyanmarDate, localizeError, localizeMode } from "@/lib/i18n"

function formatScheduledTime(dateString: string, timezone: string) {
  try {
    return new Intl.DateTimeFormat("my-MM", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      timeZone: timezone,
    }).format(new Date(dateString))
  } catch {
    return formatMyanmarDate(dateString)
  }
}

export default function Scheduler() {
  const { data: schedules, isLoading } = useListSchedules({
    query: { refetchInterval: 5000, queryKey: getListSchedulesQueryKey() }
  })
  
  const { toast } = useToast()
  const queryClient = useQueryClient()
  
  const cancelSchedule = useCancelSchedule({
    mutation: {
      onSuccess: (_data, variables) => {
        toast({ title: "အချိန်ဇယားကို ပယ်ဖျက်ပြီးပါပြီ" })
        queryClient.invalidateQueries({ queryKey: getListSchedulesQueryKey() })
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() })
        const projectId = schedules?.find(schedule => schedule.id === variables.id)?.projectId
        if (projectId) queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(projectId) })
      },
      onError: (error: any) => {
        toast({
          variant: "destructive",
          title: "ပယ်ဖျက်၍ မရပါ",
          description: localizeError(error.message),
        })
      }
    }
  })

  return (
    <div className="space-y-6 animate-studio-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <p className="studio-kicker mb-2 text-primary">လုပ်ဆောင်မှု / တန်းစီမှု</p>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">လုပ်ဆောင်မှု အချိန်ဇယား</h1>
          <p className="mt-1 text-sm text-muted-foreground">အစအဆုံးလုပ်ငန်းစဉ်ကို ယခု၊ နောက်မှ သို့မဟုတ် ပရိသတ်အချိန်နှင့် ကိုက်ညီသည့်အချိန်တွင် တန်းစီပါ။</p>
        </div>
        <CreateScheduleDialog />
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="glass-card border-0 col-span-1 border-primary/20 bg-primary/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Zap className="w-4 h-4 text-primary" /> စမတ်အချိန်ဇယား
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              စမတ်အချိန်ဇယားသည် ဆက်တင်များတွင် သတ်မှတ်ထားသော လူကြည့်အများဆုံးအချိန်များအတွင်း လုပ်ဆောင်မှုများကို အလိုအလျောက်စတင်ပေးပြီး လုပ်ငန်းစဉ်ရင်းမြစ်များကို ထိရောက်စွာ အသုံးချပါသည်။
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="glass-card border-0 overflow-hidden border-card-border/80">
        <CardHeader>
            <CardTitle>လုပ်ဆောင်မှုတန်းစီစာရင်း</CardTitle>
            <CardDescription>အချိန်ဇယားသတ်မှတ်ထားပြီး လုပ်ဆောင်နေသော လုပ်ငန်းစဉ်များ။</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin text-muted" /></div>
          ) : !schedules || schedules.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground flex flex-col items-center">
              <Calendar className="w-12 h-12 mb-3 opacity-20" />
              <p>တန်းစီထားသော လုပ်ဆောင်မှု မရှိသေးပါ။</p>
            </div>
          ) : (
            <Table className="min-w-[680px]">
              <TableHeader>
                <TableRow>
                  <TableHead>ပရောဂျက်</TableHead>
                  <TableHead>နည်းလမ်း</TableHead>
                  <TableHead>အချိန်ဇယား</TableHead>
                  <TableHead>အခြေအနေ</TableHead>
                  <TableHead className="text-right">လုပ်ဆောင်ချက်များ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {schedules.map((schedule) => (
                  <TableRow key={schedule.id}>
                    <TableCell className="font-medium">{schedule.projectTitle}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {schedule.mode === 'smart' && <Zap className="w-3 h-3 mr-1 text-amber-500" />}
                         {localizeMode(schedule.mode)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                       {schedule.scheduledAt ? formatScheduledTime(schedule.scheduledAt, schedule.timezone) : 'အချိန်သတ်မှတ်ရန် စောင့်နေသည်'}
                      {schedule.timezone && <span className="text-xs ml-2 opacity-50">{schedule.timezone}</span>}
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={schedule.status} />
                    </TableCell>
                    <TableCell className="text-right">
                      {schedule.status === 'scheduled' && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => cancelSchedule.mutate({ id: schedule.id })}
                          disabled={cancelSchedule.isPending}
                        >
                           <XCircle className="w-4 h-4 mr-1.5" /> ပယ်ဖျက်ရန်
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'processing':
      return <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/20"><PlayCircle className="w-3 h-3 mr-1 animate-pulse" /> လုပ်ဆောင်နေသည်</Badge>
    case 'completed':
      return <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20"><CheckCircle2 className="w-3 h-3 mr-1" /> ပြီးစီးပြီ</Badge>
    case 'cancelled':
      return <Badge variant="secondary" className="opacity-50 text-xs">ပယ်ဖျက်ပြီး</Badge>
    case 'failed':
      return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" /> မအောင်မြင်ပါ</Badge>
    case 'scheduled':
    default:
      return <Badge variant="outline" className="text-amber-500 border-amber-500/30 bg-amber-500/5"><Clock className="w-3 h-3 mr-1" /> အချိန်ဇယားသတ်မှတ်ထားသည်</Badge>
  }
}

function CreateScheduleDialog() {
  const [open, setOpen] = useState(false)
  const [projectId, setProjectId] = useState("")
  const [mode, setMode] = useState<"instant" | "smart" | "manual">("instant")
  const [scheduledDate, setScheduledDate] = useState("")
  const [scheduledTime, setScheduledTime] = useState("")
  
  const { data: projects } = useListProjects()
  const availableProjects = projects?.filter(p => p.status !== 'processing' && p.status !== 'queued') || []
  
  const queryClient = useQueryClient()
  const { toast } = useToast()
  
  const createSchedule = useCreateSchedule({
    mutation: {
      onSuccess: (_data, variables) => {
        queryClient.invalidateQueries({ queryKey: getListSchedulesQueryKey() })
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() })
        queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(variables.data.projectId) })
        setOpen(false)
         toast({ title: "အချိန်ဇယား သတ်မှတ်ပြီးပါပြီ", description: "ပရောဂျက်ကို တန်းစီစာရင်းထဲသို့ ထည့်ပြီးပါပြီ။" })
      },
      onError: (error: any) => {
        toast({
          variant: "destructive",
          title: "အချိန်ဇယား သတ်မှတ်၍ မရပါ",
          description: localizeError(error.message)
        })
      }
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!projectId) return
    
    let scheduledAt = undefined
    if (mode === 'manual' && scheduledDate && scheduledTime) {
      scheduledAt = `${scheduledDate}T${scheduledTime}:00`
    }
    
    createSchedule.mutate({
      data: {
        projectId,
        mode,
        scheduledAt,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
      }
    })
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
         <Button className="gap-2 shadow-lg shadow-primary/20"><Calendar className="w-4 h-4" /> လုပ်ဆောင်မှု အချိန်ဇယားသတ်မှတ်ရန်</Button>
      </DialogTrigger>
      <DialogContent>
        <form onSubmit={handleSubmit}>
          <DialogHeader>
             <DialogTitle>ပရောဂျက်လုပ်ဆောင်မှု အချိန်ဇယားသတ်မှတ်ရန်</DialogTitle>
             <DialogDescription>ရှိပြီးသားပရောဂျက်အတွက် အစအဆုံးလုပ်ငန်းစဉ်ကို တန်းစီပါ။</DialogDescription>
          </DialogHeader>
          <div className="grid gap-6 py-6">
            <div className="space-y-2">
               <Label htmlFor="project">ပရောဂျက်</Label>
              <Select value={projectId} onValueChange={setProjectId}>
                 <SelectTrigger id="project" aria-label="ပရောဂျက်">
                   <SelectValue placeholder="ပရောဂျက်ကို ရွေးပါ" />
                </SelectTrigger>
                <SelectContent>
                  {availableProjects.length === 0 ? (
                     <SelectItem value="none" disabled>ရွေးချယ်နိုင်သော ပရောဂျက် မရှိပါ</SelectItem>
                  ) : (
                    availableProjects.map(p => (
                      <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
               <Label htmlFor="mode">အချိန်ဇယားနည်းလမ်း</Label>
              <Select value={mode} onValueChange={(v: any) => setMode(v)}>
                    <SelectTrigger id="mode" aria-label="အချိန်ဇယားနည်းလမ်း">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                   <SelectItem value="instant">ချက်ချင်း (အမြန်ဆုံးလုပ်ဆောင်ရန်)</SelectItem>
                   <SelectItem value="smart">စမတ် (လူကြည့်အများဆုံးအချိန်အနီး)</SelectItem>
                   <SelectItem value="manual">ကိုယ်တိုင် (သတ်မှတ်ထားသောအချိန်)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {mode === 'manual' && (
              <div className="grid grid-cols-2 gap-4 border border-border/50 p-4 rounded-md bg-muted/30">
                <div className="space-y-2">
                   <Label htmlFor="date">ရက်စွဲ</Label>
                  <Input 
                    id="date" 
                    type="date" 
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    required={mode === 'manual'}
                  />
                </div>
                <div className="space-y-2">
                   <Label htmlFor="time">အချိန်</Label>
                  <Input 
                    id="time" 
                    type="time" 
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    required={mode === 'manual'}
                  />
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
             <Button type="button" variant="outline" onClick={() => setOpen(false)}>မလုပ်တော့ပါ</Button>
            <Button type="submit" disabled={!projectId || createSchedule.isPending || (mode === 'manual' && (!scheduledDate || !scheduledTime))}>
              {createSchedule.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              တန်းစီရန်
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
