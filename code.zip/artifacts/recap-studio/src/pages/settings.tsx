import { useGetSettings, useUpdateSettings, getGetSettingsQueryKey } from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { CheckCircle2, XCircle, Save, Loader2, KeyRound, HardDrive, Languages, Video } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { localizeError } from "@/lib/i18n"

export default function Settings() {
  const { data: settings, isLoading } = useGetSettings()
  const { toast } = useToast()
  const queryClient = useQueryClient()
  
  const updateSettings = useUpdateSettings({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "ဆက်တင်များ ပြင်ဆင်ပြီးပါပြီ", description: "နှစ်သက်ရာဆက်တင်များကို အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ။" })
        queryClient.setQueryData(getGetSettingsQueryKey(), (old: any) => 
          old ? { ...old, ...data } : old
        )
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "သိမ်းဆည်း၍ မရပါ", description: localizeError(err.message) })
      }
    }
  })

  // Local state for editing form
  const [myanmarVoice, setMyanmarVoice] = useState("my-MM-ThihaNeural")
  const [myanmarRate, setMyanmarRate] = useState(15)
  const [englishVoice, setEnglishVoice] = useState("en-US-JennyNeural")
  const [timezone, setTimezone] = useState("UTC")
  const [peakHours, setPeakHours] = useState<number[]>([18, 19, 20, 21]) // Default evening
  
  useEffect(() => {
    if (settings) {
      setMyanmarVoice(settings.myanmarVoice)
      const savedMyanmarRate = Number(settings.myanmarRate)
      setMyanmarRate(
        Number.isInteger(savedMyanmarRate) && savedMyanmarRate >= 0 && savedMyanmarRate <= 15
          ? savedMyanmarRate
          : 15
      )
      setEnglishVoice(settings.englishVoice)
      setTimezone(settings.timezone)
      setPeakHours(settings.peakHours)
    }
  }, [settings])

  const handleSave = () => {
    updateSettings.mutate({
      data: {
        myanmarVoice: myanmarVoice as any,
        myanmarRate,
        englishVoice: englishVoice as any,
        timezone,
        peakHours
      }
    })
  }

  const togglePeakHour = (hour: number) => {
    setPeakHours(prev => 
      prev.includes(hour) 
        ? prev.filter(h => h !== hour)
        : [...prev, hour].sort((a,b) => a-b)
    )
  }

  if (isLoading) {
    return <div className="flex justify-center p-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
  }

  if (!settings) return null

  return (
    <div className="mx-auto max-w-5xl space-y-6 animate-studio-in pb-20">
      <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <p className="studio-kicker mb-2 text-primary">အလုပ်ခွင် / နှစ်သက်ရာများ</p>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">စတူဒီယို ဆက်တင်များ</h1>
          <p className="mt-1 text-sm text-muted-foreground">ဗီဒီယိုတိုင်းအတွက် အသံ၊ အချိန်နှင့် ဝန်ဆောင်မှုအဆင်သင့်ဖြစ်မှုကို ချိန်ညှိပါ။</p>
        </div>
        <Button onClick={handleSave} disabled={updateSettings.isPending} className="w-full sm:w-auto">
          {updateSettings.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
          ပြောင်းလဲမှုများ သိမ်းရန်
        </Button>
      </div>

      <div className="grid gap-8">
         <Card className="glass-card border-0">
          <CardHeader>
            <CardTitle className="text-xl">ဝန်ဆောင်မှုချိတ်ဆက်မှု အခြေအနေ</CardTitle>
            <CardDescription>နောက်ကွယ် API သော့များနှင့် ချိတ်ဆက်မှုများ၏ အခြေအနေ။ ပတ်ဝန်းကျင်ကိန်းရှင်များမှ သတ်မှတ်ထားပါသည်။</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 gap-4">
              <StatusItem 
                icon={KeyRound}
                 title="Gemini / Local (စာသားပြောင်းခြင်း)" 
                ready={settings.translationProviderReady} 
                 missingMessage="Gemini key မရှိသေးပါ။ မြန်မာ recap ထုတ်ရန် Gemini ကို configure လုပ်ပါ။"
              />
              <StatusItem 
                icon={Languages}
                 title="ဘာသာပြန်ခြင်းနှင့် အသံဖန်တီးခြင်း" 
                ready={settings.translationReady} 
                 missingMessage="ဘာသာပြန်ဝန်ဆောင်မှု အထောက်အထား မရှိပါ။"
              />
              <StatusItem 
                icon={HardDrive}
                 title="ဖိုင်သိမ်းဆည်းရာ" 
                ready={settings.storageReady} 
                 missingMessage="ဖိုင်သိမ်းဆည်းရာ bucket ဆက်တင် မရှိပါ။"
              />
              <StatusItem 
                icon={Video}
                 title="TikTok ထုတ်ဝေခြင်း" 
                ready={settings.tiktokConnected} 
                 missingMessage="ဤအလုပ်ခွင်ဗားရှင်းအတွက် ရည်ရွယ်ချက်ရှိရှိ ချိတ်ဆက်မထားပါ။"
              />
            </div>
            
               {!settings.translationProviderReady && (
               <div className="mt-6 p-4 rounded-md bg-muted/50 border border-border text-sm text-muted-foreground leading-relaxed">
                    <strong>မှတ်ချက် -</strong> Gemini သော့မရှိပါက မြန်မာ recap
                    ဇာတ်ညွှန်းနှင့် narration ကို မဖန်တီးဘဲ ရှင်းလင်းသော error ဖြင့်
                    ရပ်တန့်ပါမည်။ အတုစာသား သို့မဟုတ် dummy အသံ fallback မသုံးပါ။
               </div>
            )}
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="glass-card border-0">
            <CardHeader>
              <CardTitle>အသံဆက်တင်</CardTitle>
              <CardDescription>ဘာသာပြန်ထားသော အသံဖန်တီးရန် TTS အသံကို ရွေးပါ။</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2.5">
                <Label>Narrator Voice / မြန်မာအသံ</Label>
                <Select value={myanmarVoice} onValueChange={setMyanmarVoice}>
                  <SelectTrigger className="bg-card">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                  <SelectItem value="my-MM-NilarNeural">နီလာ — မိန်းကလေးအသံ (Neural)</SelectItem>
                  <SelectItem value="my-MM-ThihaNeural">သီဟ — ယောက်ျားလေးအသံ (Neural)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

                <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-3">
                  <Label htmlFor="myanmar-rate">မြန်မာအသံ အမြန်နှုန်း</Label>
                  <span className="text-sm font-semibold text-primary">
                     +{myanmarRate}%
                  </span>
                </div>
                <input
                  id="myanmar-rate"
                  type="range"
                  min={0}
                  max={15}
                  step={1}
                  value={myanmarRate}
                  onChange={(event) => setMyanmarRate(Number(event.target.value))}
                  className="h-2 w-full accent-primary"
                  aria-label="မြန်မာအသံ အမြန်နှုန်း"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>0% (ပုံမှန်)</span>
                  <span>+15% (ပိုမြန်)</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Edge-TTS မြန်မာ narration ကို ရွေးထားသော အမြန်နှုန်းဖြင့် ထုတ်ပေးပါမည်။
                </p>
              </div>
              
              <div className="space-y-2.5">
                <Label>အင်္ဂလိပ်အသံ</Label>
                <Select value={englishVoice} onValueChange={setEnglishVoice}>
                  <SelectTrigger className="bg-card">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en-US-JennyNeural">ဂျန်နီ (အမေရိကန် အမျိုးသမီး၊ Neural)</SelectItem>
                    <SelectItem value="en-US-GuyNeural">ဂိုင် (အမေရိကန် အမျိုးသား၊ Neural)</SelectItem>
                    <SelectItem value="en-GB-SoniaNeural">ဆိုနီယာ (ဗြိတိန် အမျိုးသမီး၊ Neural)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
          
          <Card className="glass-card border-0">
            <CardHeader>
              <CardTitle>စမတ်အချိန်ဇယား စည်းမျဉ်းများ</CardTitle>
              <CardDescription>စမတ်အချိန်ဇယားအတွက် လူကြည့်အများဆုံးအချိန် ခန့်မှန်းချက်များကို သတ်မှတ်ပါ။</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2.5">
                <Label>ပစ်မှတ်အချိန်ဇုန်</Label>
                <Select value={timezone} onValueChange={setTimezone}>
                  <SelectTrigger className="bg-card">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UTC">UTC</SelectItem>
                    <SelectItem value="Asia/Rangoon">Asia/Rangoon (မြန်မာပစ်မှတ်)</SelectItem>
                    <SelectItem value="America/New_York">America/New_York (အမေရိကန်ပစ်မှတ်)</SelectItem>
                    <SelectItem value="Europe/London">Europe/London (ဗြိတိန်ပစ်မှတ်)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2.5">
                <div className="flex justify-between items-center">
                  <Label>လူကြည့်အများဆုံးအချိန်များ (၂၄ နာရီ)</Label>
                  <span className="text-xs text-muted-foreground">{peakHours.length} ခု ရွေးထားသည်</span>
                </div>
                <div className="grid grid-cols-6 gap-2">
                  {Array.from({length: 24}).map((_, i) => {
                    const isActive = peakHours.includes(i)
                    return (
                      <button
                        key={i}
                        type="button"
                        onClick={() => togglePeakHour(i)}
                        className={`text-xs h-8 rounded border transition-colors flex items-center justify-center font-mono
                          ${isActive 
                            ? 'bg-primary text-primary-foreground border-primary' 
                            : 'bg-card text-muted-foreground hover:border-primary/50'
                          }`}
                      >
                        {i.toString().padStart(2, '0')}
                      </button>
                    )
                  })}
                </div>
                <p className="text-[10px] text-muted-foreground mt-2 leading-tight">
                  ယနေ့တန်းစီထားသော စမတ်လုပ်ဆောင်မှုများသည် ရွေးချယ်ထားသောအချိန်ဇုန်၏ နောက်ထပ်ရရှိနိုင်သည့် လူကြည့်အများဆုံးအချိန်တွင် အလိုအလျောက် လုပ်ဆောင်ပါမည်။
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function StatusItem({ icon: Icon, title, ready, missingMessage }: { icon: any, title: string, ready: boolean, missingMessage: string }) {
  return (
    <div className={`p-4 rounded-lg border ${ready ? 'border-border/50 bg-card' : 'border-destructive/30 bg-destructive/5'} flex items-start gap-3 transition-colors`}>
      <div className={`mt-0.5 ${ready ? 'text-primary' : 'text-muted-foreground'}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="space-y-1 flex-1">
        <div className="flex items-center justify-between">
          <p className="font-medium text-sm leading-none">{title}</p>
          {ready ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          ) : (
            <XCircle className="w-4 h-4 text-destructive" />
          )}
        </div>
        {!ready && (
          <p className="text-xs text-muted-foreground leading-snug">{missingMessage}</p>
        )}
      </div>
    </div>
  )
}
