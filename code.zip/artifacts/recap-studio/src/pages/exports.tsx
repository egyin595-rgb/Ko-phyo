import { useListProjects, useDeleteProjectExport, getListProjectsQueryKey } from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, AlertCircle, Loader2 } from "lucide-react"
import { formatDate } from "@/lib/utils"
import { ExportMediaPanel } from "@/components/export-media-panel"
import { localizeError } from "@/lib/i18n"
import { useToast } from "@/components/ui/use-toast"

export default function Exports() {
  const { data: projects, isLoading, error, refetch, isFetching } = useListProjects({
    query: { refetchInterval: 10000, queryKey: getListProjectsQueryKey() }
  })
  const queryClient = useQueryClient()
  const { toast } = useToast()
  const deleteProjectExport = useDeleteProjectExport({
    mutation: {
      onSuccess: () => {
        void queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() })
        toast({ title: "Video ဖျက်ပြီးပါပြီ", description: "ရွေးထားသော completed export ကို ဖယ်ရှားပြီးပါပြီ။" })
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Video ဖျက်၍ မရပါ", description: localizeError(err.message) })
      },
    },
  })
  
  // Flatten all exports from all projects
  const allExports = projects?.flatMap(p =>
    p.exportsStale ? [] : (p.exports || []).map(exp => ({
      ...exp,
      projectId: p.id,
      projectNumber: p.projectNumber,
      projectTitle: p.title,
      projectDate: p.updatedAt
    }))
  ).sort((a, b) => new Date(b.projectDate).getTime() - new Date(a.projectDate).getTime()) || []

  return (
    <div className="space-y-5 animate-studio-in sm:space-y-6">
      <div className="rounded-2xl border border-card-border bg-card/70 p-4 shadow-lg shadow-black/10 sm:p-5">
        <p className="studio-kicker mb-2 text-primary">စာကြည့်တိုက် / ရလဒ်ဖိုင်များ</p>
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">ထုတ်ယူထားသော ဗီဒီယိုများ</h1>
        <p className="mt-1 text-sm text-muted-foreground">ပြီးစီးထားသော ဘာသာပြန်ဗီဒီယိုများ၊ အသံဖိုင်များနှင့် စာတန်းထိုးဖိုင်များ။</p>
      </div>

      <Card className="glass-card overflow-hidden border-card-border/80">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="space-y-3 p-5 sm:p-8">{[1,2,3].map((item) => <div key={item} className="h-16 animate-pulse rounded-xl bg-muted/60" />)}</div>
          ) : error ? (
            <div className="flex flex-col items-center py-20 text-center text-muted-foreground">
              <AlertCircle className="mb-4 h-16 w-16 opacity-20 text-destructive" />
              <h3 className="mb-1 text-lg font-medium text-foreground">ရလဒ်ဖိုင်များ ရယူ၍ မရပါ</h3>
              <p className="mb-5 max-w-md text-sm">{localizeError((error as any)?.message || "Exports could not be loaded.")}</p>
              <Button variant="outline" onClick={() => void refetch()} disabled={isFetching}>
                {isFetching && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                ထပ်မံကြိုးစားရန်
              </Button>
            </div>
          ) : allExports.length === 0 ? (
            <div className="text-center py-20 text-muted-foreground flex flex-col items-center">
              <Download className="w-16 h-16 mb-4 opacity-10" />
              <h3 className="text-lg font-medium text-foreground mb-1">ထုတ်ယူထားသောဖိုင် မရှိသေးပါ</h3>
              <p>ရလဒ်ဖိုင်များ ဖန်တီးရန် ပရောဂျက်များကို လုပ်ငန်းစဉ်မှတစ်ဆင့် လုပ်ဆောင်ပါ။</p>
            </div>
          ) : (
            <div className="divide-y divide-border/50">
              {allExports.map((exp, index) => (
                <div key={`${exp.projectId}-${exp.language}-${index}`} className="space-y-3 p-5 sm:p-6">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h3 className="font-semibold text-lg line-clamp-1">{exp.projectTitle}</h3>
                      <p className="mt-1 text-sm text-muted-foreground">
                        ပြီးစီးချိန် {formatDate(exp.projectDate)}
                      </p>
                    </div>
                  </div>
                  <ExportMediaPanel
                    exportItem={exp}
                    projectTitle={exp.projectTitle}
                    projectNumber={exp.projectNumber || 0}
                     onDelete={() => deleteProjectExport.mutate({
                       id: exp.projectId,
                       language: exp.language as "myanmar" | "english",
                     })}
                     isDeleting={
                       deleteProjectExport.isPending
                       && deleteProjectExport.variables?.id === exp.projectId
                       && deleteProjectExport.variables?.language === exp.language
                     }
                  />
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
