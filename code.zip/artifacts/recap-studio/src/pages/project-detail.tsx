import { 
  useGetProject, 
  useUpdateProject, 
  useRunProject, 
  useDeleteProject,
  useDeleteProjectExport,
  useGeneratePostMetadata,
  getGetProjectQueryKey,
  getListProjectsQueryKey,
} from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { useParams, useLocation } from "wouter"
import { useState, useEffect, useRef, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { 
  ArrowLeft, Save, Play, Pause, Volume2, VolumeX, Download, Trash2, Bold,
  AlertCircle, Loader2, Languages, Type,
  Video, Plus, Maximize2, ShieldCheck, ImagePlus, Film, RotateCcw, Move, ChevronDown,
  ChevronLeft, ChevronRight,
} from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { localizeError, localizeStatus } from "@/lib/i18n"
import { ExportMediaPanel } from "@/components/export-media-panel"
import { ReadyToPostSuite } from "@/components/ready-to-post-suite"
import { DownloadFileButton } from "@/components/download-file-button"
import { ProgressPipeline } from "@/components/progress-pipeline"
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

type BoxGeometry = {
  xPercent: number
  yPercent: number
  widthPercent: number
  heightPercent: number
}

type BlurBox = BoxGeometry & { id: string; strength: number }
type SubtitleBox = BoxGeometry
type MaskStyle = "dark-translucent" | "light-translucent" | "clean-boxblur"
type SubtitlePreset = "classic-yellow" | "clean-white" | "neon-green" | "cyan" | "custom"
type SubtitleAlignment = "left" | "center" | "right"
type SubtitleFontFamily = "Noto Sans Myanmar"
type SubtitleVerticalPosition = "top" | "center" | "bottom"
type ExportQuality = "720p" | "1080p" | "original"
type SubtitleStyle = {
  preset: SubtitlePreset
  primaryColor: string
  outlineColor: string
  outlineWidth: number
  shadowOpacity: number
}
type CameraMove = {
  startSeconds: number
  endSeconds: number
  zoom: number
  panX?: number
  panY?: number
  transitionSeconds?: number
}
type VideoTransform = {
  scale: number
  zoom: number
  x: number
  y: number
  mirrorHorizontal: boolean
  cameraMoves: CameraMove[]
}
type PreviewVideoCanvas = { left: number; top: number; width: number; height: number }
type DialogueLine = {
  id: string
  speaker: string
  start: number
  end: number
  sourceText: string
  reviewRequired: boolean
  timingWarning: string[]
  myanmarText?: string | null
  englishText?: string | null
  translationFallback: boolean
}

const SUBTITLE_PRESET_STYLES: Record<Exclude<SubtitlePreset, "custom">, SubtitleStyle> = {
  "classic-yellow": {
    preset: "classic-yellow",
    primaryColor: "#FFEB3B",
    outlineColor: "#000000",
    outlineWidth: 4,
    shadowOpacity: 75,
  },
  "clean-white": {
    preset: "clean-white",
    primaryColor: "#FFFFFF",
    outlineColor: "#000000",
    outlineWidth: 4,
    shadowOpacity: 75,
  },
  "neon-green": {
    preset: "neon-green",
    primaryColor: "#39FF14",
    outlineColor: "#000000",
    outlineWidth: 3,
    shadowOpacity: 75,
  },
  cyan: {
    preset: "cyan",
    primaryColor: "#00FFFF",
    outlineColor: "#000000",
    outlineWidth: 3,
    shadowOpacity: 75,
  },
}

const DEFAULT_SUBTITLE_STYLE: SubtitleStyle = {
  ...SUBTITLE_PRESET_STYLES["clean-white"],
}
const DEFAULT_VIDEO_TRANSFORM: VideoTransform = {
  scale: 1,
  zoom: 1,
  x: 0,
  y: 0,
  mirrorHorizontal: false,
  cameraMoves: [],
}
const ACTIVE_PROJECT_STORAGE_KEY = "recap-studio.active-project-id"
const SCRIPT_DRAFT_STORAGE_PREFIX = "recap-studio.script-draft:"
const SETTINGS_DRAFT_STORAGE_PREFIX = "recap-studio.settings-draft:"
const MIN_SUBTITLE_FONT_SIZE = 12
const MAX_SUBTITLE_FONT_SIZE = 120
const DEFAULT_SUBTITLE_FONT_SIZE = 32
const MIN_SUBTITLE_MARGIN_V = 80
const MAX_SUBTITLE_MARGIN_V = 240
const DEFAULT_SUBTITLE_MARGIN_V = 160
const DEFAULT_SUBTITLE_FONT_FAMILY: SubtitleFontFamily = "Noto Sans Myanmar"
const DEFAULT_SUBTITLE_BOLD = true
const MIN_TIMING_OFFSET = -30
const MAX_TIMING_OFFSET = 30
const TIMING_OFFSET_STEP = 0.5
const SUBTITLE_VERTICAL_POSITIONS: Record<SubtitleVerticalPosition, number> = {
  top: 8,
  center: 39,
  bottom: 78,
}

type ScriptDraft = {
  transcript: string
  dialogue?: DialogueLine[]
  myanmarScript: string
  englishScript: string
  updatedAt: number
}

type ProjectSettingsDraft = {
  updatedAt: number
  settings: Record<string, unknown>
}

const PERSISTED_SETTING_FIELDS = [
  "globalEdit",
  "blurBoxes",
  "subtitleBox",
  "logoPosition",
  "maskStyle",
  "subtitleStyle",
  "originalAudioVolume",
  "narrationTiming",
  "subtitleFontSize",
  "subtitleMarginV",
  "subtitleFontFamily",
  "subtitleBold",
  "timingOffset",
  "narrationSpeed",
  "subtitleAlignment",
  "logoCoordinates",
  "logoScale",
  "watermarkText",
  "videoTransform",
  "exportQuality",
] as const

type PersistedSettingField = typeof PERSISTED_SETTING_FIELDS[number]

const readStoredProjectId = () => {
  if (typeof window === "undefined") return ""
  return window.localStorage.getItem(ACTIVE_PROJECT_STORAGE_KEY)?.trim() || ""
}

const projectErrorStatus = (error: unknown): number | null => {
  if (!error || typeof error !== "object" || !("status" in error)) return null
  const status = Number((error as { status?: unknown }).status)
  return Number.isFinite(status) ? status : null
}

const isPermanentProjectRetrievalError = (error: unknown): boolean => {
  const status = projectErrorStatus(error)
  return status !== null && status >= 400 && status < 500 && status !== 408 && status !== 429
}

const scriptDraftKey = (projectId: string) => `${SCRIPT_DRAFT_STORAGE_PREFIX}${projectId}`
const settingsDraftKey = (projectId: string) => `${SETTINGS_DRAFT_STORAGE_PREFIX}${projectId}`

const readScriptDraft = (projectId: string): ScriptDraft | null => {
  if (typeof window === "undefined") return null
  try {
    const raw = window.localStorage.getItem(scriptDraftKey(projectId))
    if (!raw) return null
    const draft = JSON.parse(raw) as Partial<ScriptDraft>
    if (
      typeof draft.updatedAt !== "number"
      || !Number.isFinite(draft.updatedAt)
      || typeof draft.transcript !== "string"
      || typeof draft.myanmarScript !== "string"
      || typeof draft.englishScript !== "string"
    ) return null
    return draft as ScriptDraft
  } catch {
    return null
  }
}

const readSettingsDraft = (projectId: string): ProjectSettingsDraft | null => {
  if (typeof window === "undefined") return null
  try {
    const raw = window.localStorage.getItem(settingsDraftKey(projectId))
    if (!raw) return null
    const draft = JSON.parse(raw) as Partial<ProjectSettingsDraft>
    if (
      typeof draft.updatedAt !== "number"
      || !Number.isFinite(draft.updatedAt)
      || !draft.settings
      || typeof draft.settings !== "object"
      || Array.isArray(draft.settings)
    ) return null
    return {
      updatedAt: draft.updatedAt,
      settings: draft.settings as Record<string, unknown>,
    }
  } catch {
    return null
  }
}

const isHexColor = (value: unknown): value is string =>
  typeof value === "string" && /^#[0-9A-Fa-f]{6}$/.test(value)

const normalizeSubtitleStyle = (style: unknown): SubtitleStyle => {
  if (!style || typeof style !== "object") return { ...DEFAULT_SUBTITLE_STYLE }
  const candidate = style as Partial<SubtitleStyle>
  const preset = candidate.preset
  if (preset && preset !== "custom" && preset in SUBTITLE_PRESET_STYLES) {
    return { ...SUBTITLE_PRESET_STYLES[preset as Exclude<SubtitlePreset, "custom">] }
  }
  return {
    preset: "custom",
    primaryColor: isHexColor(candidate.primaryColor) ? candidate.primaryColor.toUpperCase() : "#FFFFFF",
    outlineColor: isHexColor(candidate.outlineColor) ? candidate.outlineColor.toUpperCase() : "#000000",
    outlineWidth: Number.isFinite(Number(candidate.outlineWidth))
      ? Math.max(0, Math.min(8, Number(candidate.outlineWidth)))
      : 2.5,
    shadowOpacity: Number.isFinite(Number(candidate.shadowOpacity))
      ? Math.max(0, Math.min(100, Number(candidate.shadowOpacity)))
      : 75,
  }
}

const normalizeBox = (box: unknown): BoxGeometry | null => {
  if (!box || typeof box !== "object") return null
  const candidate = box as Partial<BoxGeometry> & {
    x?: number
    y?: number
    width?: number
    height?: number
  }
  const percent = (current: number | undefined, legacy: number | undefined) => {
    const currentValue = Number(current)
    if (Number.isFinite(currentValue)) return currentValue
    const legacyValue = Number(legacy)
    return Number.isFinite(legacyValue) ? legacyValue * 100 : Number.NaN
  }
  const xPercent = percent(candidate.xPercent, candidate.x)
  const yPercent = percent(candidate.yPercent, candidate.y)
  const widthPercent = percent(candidate.widthPercent, candidate.width)
  const heightPercent = percent(candidate.heightPercent, candidate.height)
  if (![xPercent, yPercent, widthPercent, heightPercent].every(Number.isFinite)) return null
  if (
    widthPercent <= 0
    || heightPercent <= 0
    || xPercent < 0
    || yPercent < 0
    || xPercent + widthPercent > 100
    || yPercent + heightPercent > 100
  ) return null
  return { xPercent, yPercent, widthPercent, heightPercent }
}

const normalizeBlurBoxes = (boxes: unknown): BlurBox[] => {
  if (!Array.isArray(boxes)) return []
  return boxes.flatMap((box, index) => {
    const geometry = normalizeBox(box)
    if (!geometry) return []
    const candidate = box as Partial<BlurBox>
    return [{
      id: String(candidate.id || `blur-${index + 1}`),
      ...geometry,
      strength: Math.max(5, Math.min(50, Number.isFinite(Number(candidate.strength)) ? Number(candidate.strength) : 20)),
    }]
  })
}

const normalizeCameraMoves = (value: unknown): CameraMove[] => {
  if (!Array.isArray(value)) return []
  return value.slice(0, 32).flatMap((raw) => {
    if (!raw || typeof raw !== "object") return []
    const candidate = raw as Partial<CameraMove>
    const startSeconds = Number(candidate.startSeconds)
    const endSeconds = Number(candidate.endSeconds)
    if (!Number.isFinite(startSeconds) || !Number.isFinite(endSeconds)) return []
    const zoom = Number(candidate.zoom)
    const panX = candidate.panX == null ? undefined : Number(candidate.panX)
    const panY = candidate.panY == null ? undefined : Number(candidate.panY)
    const transitionSeconds = candidate.transitionSeconds == null
      ? undefined
      : Number(candidate.transitionSeconds)
    return [{
      startSeconds: Math.max(0, Math.min(900, startSeconds)),
      endSeconds: Math.max(0.01, Math.min(900, endSeconds)),
      zoom: Math.max(1, Math.min(2.5, Number.isFinite(zoom) ? zoom : 1.15)),
      ...(Number.isFinite(panX) ? { panX: Math.max(-1, Math.min(1, panX!)) } : {}),
      ...(Number.isFinite(panY) ? { panY: Math.max(-1, Math.min(1, panY!)) } : {}),
      ...(Number.isFinite(transitionSeconds)
        ? { transitionSeconds: Math.max(0.01, Math.min(2, transitionSeconds!)) }
        : {}),
    }]
  })
}

const normalizeVideoTransform = (transform: unknown): VideoTransform => {
  if (!transform || typeof transform !== "object") return { ...DEFAULT_VIDEO_TRANSFORM }
  const candidate = transform as Partial<VideoTransform>
  return {
    scale: Math.max(1, Math.min(2, Number.isFinite(Number(candidate.scale)) ? Number(candidate.scale) : 1)),
    zoom: Math.max(1, Math.min(2, Number.isFinite(Number(candidate.zoom)) ? Number(candidate.zoom) : 1)),
    x: Math.max(-1, Math.min(1, Number.isFinite(Number(candidate.x)) ? Number(candidate.x) : 0)),
    y: Math.max(-1, Math.min(1, Number.isFinite(Number(candidate.y)) ? Number(candidate.y) : 0)),
    mirrorHorizontal: candidate.mirrorHorizontal === true,
    cameraMoves: normalizeCameraMoves(candidate.cameraMoves),
  }
}

const videoTransformTravel = (factor: number) => Math.max(0.05, (factor - 1) * 0.5)

const cameraMoveAtTime = (cameraMoves: CameraMove[], currentTime: number) => {
  const move = cameraMoves.find(
    (candidate) => currentTime >= candidate.startSeconds && currentTime <= candidate.endSeconds,
  )
  if (!move || move.endSeconds <= move.startSeconds) {
    return { zoom: 1, panX: 0, panY: 0 }
  }
  const segmentDuration = move.endSeconds - move.startSeconds
  const transition = move.transitionSeconds ?? Math.min(0.4, segmentDuration / 2)
  if (!Number.isFinite(transition) || transition <= 0) {
    return { zoom: 1, panX: 0, panY: 0 }
  }
  const progress = Math.max(
    0,
    Math.min(
      1,
      Math.min(
        (currentTime - move.startSeconds) / transition,
        (move.endSeconds - currentTime) / transition,
      ),
    ),
  )
  return {
    zoom: 1 + (move.zoom - 1) * progress,
    panX: (move.panX ?? 0) * progress,
    panY: (move.panY ?? 0) * progress,
  }
}

const previewTransformAtTime = (transform: VideoTransform, currentTime: number) => {
  const camera = cameraMoveAtTime(transform.cameraMoves, currentTime)
  const staticFactor = transform.scale * transform.zoom
  const factor = staticFactor * camera.zoom
  const offsetX = (
    transform.x * videoTransformTravel(staticFactor)
    - camera.panX * videoTransformTravel(camera.zoom)
  ) * 100
  const offsetY = (
    transform.y * videoTransformTravel(staticFactor)
    - camera.panY * videoTransformTravel(camera.zoom)
  ) * 100
  return {
    camera,
    factor,
    offsetX,
    offsetY,
    css: `translate(${offsetX}%, ${offsetY}%) scale(${factor})`,
  }
}

const validateCameraMoves = (cameraMoves: CameraMove[], duration: number): string | null => {
  if (cameraMoves.length > 32) return "A project can have up to 32 camera moves."
  const sorted = [...cameraMoves].sort((a, b) => a.startSeconds - b.startSeconds)
  for (let index = 0; index < sorted.length; index += 1) {
    const move = sorted[index]
    const segmentDuration = move.endSeconds - move.startSeconds
    const transition = move.transitionSeconds ?? Math.min(0.4, segmentDuration / 2)
    const panX = move.panX ?? 0
    const panY = move.panY ?? 0
    if (
      !Number.isFinite(move.startSeconds)
      || !Number.isFinite(move.endSeconds)
      || !Number.isFinite(move.zoom)
      || !Number.isFinite(panX)
      || !Number.isFinite(panY)
      || !Number.isFinite(transition)
      || move.startSeconds < 0
      || move.endSeconds <= move.startSeconds
      || (duration > 0 && move.endSeconds > duration)
      || move.zoom < 1
      || move.zoom > 2.5
      || panX < -1
      || panX > 1
      || panY < -1
      || panY > 1
      || transition <= 0
      || transition > 2
      || transition * 2 > segmentDuration
      || (move.zoom === 1 && (panX !== 0 || panY !== 0))
    ) {
      return `Camera move ${index + 1} has values outside the allowed range.`
    }
    if (index > 0 && move.startSeconds < sorted[index - 1].endSeconds) {
      return "Camera move segments cannot overlap."
    }
  }
  return null
}

const createCameraMove = (
  currentTime: number,
  duration: number,
  cameraMoves: CameraMove[],
): CameraMove | null => {
  const length = duration > 0 ? Math.min(2, duration) : 2
  if (length < 0.2) return null
  const sorted = [...cameraMoves].sort((a, b) => a.startSeconds - b.startSeconds)
  const origins = [Math.max(0, Math.min(currentTime, duration || currentTime)), 0]
  for (const origin of origins) {
    let startSeconds = origin
    for (let attempt = 0; attempt <= sorted.length; attempt += 1) {
      const endSeconds = Math.min(startSeconds + length, duration > 0 ? duration : Infinity)
      if (endSeconds - startSeconds < 0.2) break
      const overlap = sorted.find(
        (move) => move.startSeconds < endSeconds && move.endSeconds > startSeconds,
      )
      if (!overlap) {
        const segmentDuration = endSeconds - startSeconds
        return {
          startSeconds,
          endSeconds,
          zoom: 1.15,
          panX: 0,
          panY: 0,
          transitionSeconds: Math.min(0.4, segmentDuration / 2),
        }
      }
      startSeconds = overlap.endSeconds
    }
  }
  return null
}

const normalizeDialogue = (value: unknown): DialogueLine[] => {
  if (!Array.isArray(value)) return []
  return value.flatMap((raw, index) => {
    if (!raw || typeof raw !== "object") return []
    const candidate = raw as Partial<DialogueLine>
    const start = Number(candidate.start)
    const end = Number(candidate.end)
    const sourceText = String(candidate.sourceText || "").trim()
    if (!sourceText || !Number.isFinite(start) || !Number.isFinite(end) || end <= start) return []
    return [{
      id: String(candidate.id || `line_${String(index + 1).padStart(3, "0")}`),
      speaker: String(candidate.speaker || "A"),
      start: Math.max(0, start),
      end: Math.max(0, end),
      sourceText,
      reviewRequired: sourceText.includes("[听不清]"),
      timingWarning: Array.isArray(candidate.timingWarning)
        ? candidate.timingWarning.map(String)
        : [],
      myanmarText: candidate.myanmarText || null,
      englishText: candidate.englishText || null,
      translationFallback: Boolean(candidate.translationFallback),
    }]
  })
}

const dialogueToTranscript = (lines: DialogueLine[]) =>
  lines.map((line) => `[${line.speaker}] ${line.sourceText}`).join("\n")

const measurePreviewVideoCanvas = (
  frame: HTMLElement | null,
  video: HTMLVideoElement | null,
): PreviewVideoCanvas => {
  if (!frame) return { left: 0, top: 0, width: 0, height: 0 }
  const frameWidth = frame.clientWidth
  const frameHeight = frame.clientHeight
  if (!frameWidth || !frameHeight) return { left: 0, top: 0, width: 0, height: 0 }

  const videoWidth = video?.videoWidth || frameWidth
  const videoHeight = video?.videoHeight || frameHeight
  const scale = Math.min(frameWidth / videoWidth, frameHeight / videoHeight)
  const width = videoWidth * scale
  const height = videoHeight * scale
  return {
    left: (frameWidth - width) / 2,
    top: (frameHeight - height) / 2,
    width,
    height,
  }
}

const DEFAULT_PREVIEW_SUBTITLE_BOX: SubtitleBox = {
  xPercent: 6,
  yPercent: 78,
  widthPercent: 88,
  heightPercent: 22,
}

const PREVIEW_WORKFLOW_STEPS = [
  { id: 1, label: "Preview", description: "ဗီဒီယိုနေရာနှင့် blur" },
  { id: 2, label: "Story / Script", description: "Transcript နှင့် narration စာသား" },
  { id: 3, label: "Render / Export", description: "Settings၊ processing နှင့် download" },
] as const

const subtitleVerticalPositionForBox = (box: SubtitleBox | null): SubtitleVerticalPosition => {
  const y = box?.yPercent ?? DEFAULT_PREVIEW_SUBTITLE_BOX.yPercent
  if (y < 25) return "top"
  if (y < 60) return "center"
  return "bottom"
}

type PreviewSubtitleCue = {
  start: number
  end: number
  text: string
}

const isMyanmarSyllableExtender = (character: string) => {
  const code = character.codePointAt(0) || 0
  return (
    /\p{M}/u.test(character)
    || (code >= 0x102b && code <= 0x103e)
    || (code >= 0x1056 && code <= 0x1059)
    || (code >= 0x105e && code <= 0x106d)
    || (code >= 0x1071 && code <= 0x1096)
    || (code >= 0xa9b0 && code <= 0xa9c0)
    || (code >= 0xaa29 && code <= 0xaa36)
    || character === "\u200b"
    || character === "\u200c"
    || character === "\u200d"
  )
}

const splitMyanmarSyllables = (value: string): string[] => {
  if (typeof Intl !== "undefined" && "Segmenter" in Intl) {
    const segmenter = new Intl.Segmenter("my", { granularity: "grapheme" })
    return Array.from(segmenter.segment(value), ({ segment }) => segment)
  }
  const syllables: string[] = []
  let current = ""
  let joinNextBase = false
  for (const character of value) {
    if (current && (isMyanmarSyllableExtender(character) || joinNextBase)) {
      current += character
      joinNextBase = character === "\u1039"
      continue
    }
    if (current) syllables.push(current)
    current = character
    joinNextBase = character === "\u1039"
  }
  if (current) syllables.push(current)
  return syllables
}

const previewPhraseUnits = (phrase: string): string[] =>
  phrase.includes(" ") ? phrase.split(/\s+/).filter(Boolean) : splitMyanmarSyllables(phrase)

const splitPreviewSubtitleCues = (script: string): string[] => {
  const normalized = script.normalize("NFC").replace(/[ \t]+/g, " ").trim()
  if (!normalized) return []

  const sentences = normalized
    .split(/(?<=[။၊!?])\s*|(?<=[.!?])\s+|\n+/u)
    .map((value) => value.trim())
    .filter(Boolean)
  const phrases: string[] = []

  for (const sentence of sentences) {
    const hasSpaces = /\s/.test(sentence)
    const tokens = hasSpaces ? sentence.split(/\s+/).filter(Boolean) : [sentence]
    let current: string[] = []
    let currentLength = 0
    for (const token of tokens) {
      const separator = current.length && hasSpaces ? " " : ""
      const candidateLength = currentLength + separator.length + token.length
      if (current.length && (current.length >= 6 || candidateLength > 26)) {
        phrases.push(current.join(hasSpaces ? " " : ""))
        current = []
        currentLength = 0
      }
      current.push(token)
      currentLength = current.join(hasSpaces ? " " : "").length
      if (
        current.length >= 3
        && /[။၊!?.,]$/u.test(token)
      ) {
        phrases.push(current.join(hasSpaces ? " " : ""))
        current = []
        currentLength = 0
      }
    }
    if (current.length) phrases.push(current.join(hasSpaces ? " " : ""))
  }

  // Match the renderer's short-tail behavior without inventing a second
  // subtitle source: keep a tiny punctuation tail attached to the previous
  // phrase when it still fits the caption-sized limit.
  const merged: string[] = []
  for (const phrase of phrases) {
    const units = previewPhraseUnits(phrase)
    const previous = merged.at(-1)
    if (previous && units.length < 3) {
      const previousUnits = previewPhraseUnits(previous)
      if (previousUnits.length > 3 && previousUnits.length + units.length <= 6) {
        merged[merged.length - 1] = `${previous}${previous.includes(" ") || phrase.includes(" ") ? " " : ""}${phrase}`
        continue
      }
    }
    merged.push(phrase)
  }
  return merged
}

const wrapPreviewSubtitleText = (
  value: string,
  canvasWidth: number,
  canvasHeight: number,
  fontSize: number,
): string => {
  const scale = canvasHeight / 1920
  const scaledFontSize = Math.max(1, fontSize * scale)
  const width = Math.max(1, Math.floor(canvasWidth / Math.max(1, scaledFontSize * 0.95)))
  const lines: string[] = []
  for (const paragraph of value.normalize("NFC").replace(/\r\n?/gu, "\n").split("\n")) {
    const words = paragraph.trim().split(/\s+/u).filter(Boolean)
    let current = ""
    for (const word of words) {
      const candidate = `${current}${current ? " " : ""}${word}`
      if (current && splitMyanmarSyllables(candidate).length > width) {
        lines.push(current)
        current = word
      } else {
        current = candidate
      }
    }
    if (current) lines.push(current)
  }
  return lines.join("\n").trim()
}

const splitPreviewCueAtPhraseBoundaries = (
  value: string,
  canvasWidth: number,
  canvasHeight: number,
  fontSize: number,
): string[] => {
  const words = value.normalize("NFC").replace(/\s+/gu, " ").trim().split(" ").filter(Boolean)
  if (!words.length) return []
  const phrases: string[] = []
  let current = ""
  for (const word of words) {
    const candidate = `${current}${current ? " " : ""}${word}`
    const lineCount = wrapPreviewSubtitleText(
      candidate,
      canvasWidth,
      canvasHeight,
      fontSize,
    ).split("\n").filter(Boolean).length
    if (current && lineCount > 2) {
      phrases.push(wrapPreviewSubtitleText(current, canvasWidth, canvasHeight, fontSize))
      current = word
    } else {
      current = candidate
    }
  }
  if (current) {
    phrases.push(wrapPreviewSubtitleText(current, canvasWidth, canvasHeight, fontSize))
  }
  return phrases
}

const distributePreviewCueTime = (
  cue: PreviewSubtitleCue,
  phrases: string[],
): PreviewSubtitleCue[] => {
  if (phrases.length <= 1) return [{ ...cue, text: phrases[0] || cue.text }]
  const weights = phrases.map((phrase) => Math.max(1, Array.from(phrase).length))
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0)
  const duration = Math.max(0.01, cue.end - cue.start)
  let cursor = cue.start
  return phrases.map((text, index) => {
    const end = index === phrases.length - 1
      ? cue.end
      : cursor + duration * weights[index] / totalWeight
    const segment = { ...cue, start: cursor, end: Math.max(cursor + 0.01, end), text }
    cursor = segment.end
    return segment
  })
}

const parseSrtTime = (value: string): number => {
  const match = value.trim().match(/^(\d+):(\d{2}):(\d{2}),(\d{3})$/u)
  if (!match) return 0
  return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]) + Number(match[4]) / 1000
}

const parsePreviewSrt = (value: string): PreviewSubtitleCue[] =>
  value
    .replace(/\r\n?/gu, "\n")
    .trim()
    .split(/\n{2,}/u)
    .flatMap((block): PreviewSubtitleCue[] => {
      const lines = block.split("\n")
      const timingIndex = lines.findIndex((line) => line.includes("-->"))
      if (timingIndex < 0) return []
      const [start, end] = lines[timingIndex].split("-->").map((part) => parseSrtTime(part.split(/\s+/u)[0] || ""))
      const text = lines.slice(timingIndex + 1).join("\n").trim()
      return end > start && text ? [{ start, end, text }] : []
    })

export default function ProjectDetail() {
  const params = useParams<{ id: string }>()
  const routeProjectId = params.id?.trim() || ""
  const [storedProjectId] = useState(readStoredProjectId)
  const id = routeProjectId || storedProjectId
  const [, setLocation] = useLocation()
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const preserveEditorStateAfterLogoUploadRef = useRef(false)

  useEffect(() => {
    if (routeProjectId) {
      window.localStorage.setItem(ACTIVE_PROJECT_STORAGE_KEY, routeProjectId)
    } else if (storedProjectId) {
      setLocation(`/projects/${storedProjectId}`)
    }
  }, [routeProjectId, storedProjectId, setLocation])
  
  const { data: project, isLoading, error, refetch, isFetching } = useGetProject(id, {
    query: {
      enabled: Boolean(id),
      retry: (failureCount, queryError) =>
        !isPermanentProjectRetrievalError(queryError) && failureCount < 2,
      refetchInterval: (query) =>
        isPermanentProjectRetrievalError(query.state.error) ? false : 3000,
      queryKey: getGetProjectQueryKey(id),
    }
  })

  const latestScriptRevisionRef = useRef(0)
  const autosaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const settingsAutosaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const settingsRetryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const settingsDraftHydratedForId = useRef<string | null>(null)
  const settingsAutosaveRevisionRef = useRef(0)
  const settingsAutosavePendingRef = useRef<{
    revision: number
    payload: Record<string, unknown>
  } | null>(null)
  const settingsAutosaveActiveRef = useRef<{
    revision: number
    payload: Record<string, unknown>
  } | null>(null)
  const settingsRetryAttemptRef = useRef(0)
  const scriptDraftHydratedForId = useRef<string | null>(null)
  const skipNextDraftWriteRef = useRef(false)
  
  const updateProject = useUpdateProject({
    mutation: {
      retry: 2,
      retryDelay: (attemptIndex) => Math.min(1000 * (2 ** attemptIndex), 4000),
      onSuccess: (data, variables: any) => {
        const preserveEditorState = preserveEditorStateAfterLogoUploadRef.current
        preserveEditorStateAfterLogoUploadRef.current = false
        toast({ title: "သိမ်းဆည်းပြီးပါပြီ", description: "ပရောဂျက်တည်းဖြတ်မှုများကို အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ။" })
        if (preserveEditorState) {
          queryClient.setQueryData(getGetProjectQueryKey(id), (old: any) =>
            old ? { ...old, ...data } : data
          )
          return
        }
        const savedScripts = ["transcript", "myanmarScript", "englishScript"].some(
          (field) => Object.prototype.hasOwnProperty.call(variables?.data || {}, field),
        )
        const savedRevision = Number(variables?.data?.scriptUpdatedAt || 0)
        const currentScriptSave = !savedScripts || savedRevision >= latestScriptRevisionRef.current
        if (!savedScripts) {
          queryClient.setQueryData(getGetProjectQueryKey(id), (old: any) =>
            old ? { ...old, ...data } : data
          )
          return
        }
        if (!currentScriptSave) {
          queryClient.setQueryData(getGetProjectQueryKey(id), (old: any) =>
            old
              ? {
                  ...old,
                  ...data,
                  transcript: old.transcript,
                  dialogue: old.dialogue,
                  myanmarScript: old.myanmarScript,
                  englishScript: old.englishScript,
                }
              : data
          )
          return
        }
        if (savedScripts) {
          window.localStorage.removeItem(scriptDraftKey(id))
          setScriptSaveStatus("saved")
        }
        const cleanFields = {
          transcript: false,
          dialogue: false,
          myanmarScript: false,
          englishScript: false,
          globalEdit: false,
          blurBoxes: false,
          subtitleBox: false,
          logoPosition: false,
          maskStyle: false,
          subtitleStyle: false,
          originalAudioVolume: false,
           narrationTiming: false,
          subtitleFontSize: false,
          subtitleMarginV: false,
           subtitleFontFamily: false,
           subtitleBold: false,
           timingOffset: false,
          narrationSpeed: false,
          subtitleAlignment: false,
          logoCoordinates: false,
          logoScale: false,
          watermarkText: false,
          videoTransform: false,
           exportQuality: false,
        }
        dirtyFieldsRef.current = cleanFields
        setDirtyFields(cleanFields)
        setTranscript(data.transcript || "")
        setDialogue(normalizeDialogue(data.dialogue))
        setMyanmarScript(data.myanmarScript || "")
        setEnglishScript(data.englishScript || "")
        setGlobalEdit(data.globalEdit || "none")
        setBlurBoxes(normalizeBlurBoxes(data.blurBoxes))
        setSubtitleBox(normalizeBox(data.subtitleBox))
        setLogoPosition(data.logoPosition || "top-right")
        setMaskStyle((data.maskStyle || "clean-boxblur") as MaskStyle)
        setSubtitleStyle(normalizeSubtitleStyle(data.subtitleStyle))
        setOriginalAudioVolume(0)
        setSubtitleFontSize(Math.max(MIN_SUBTITLE_FONT_SIZE, Math.min(MAX_SUBTITLE_FONT_SIZE, Number(data.subtitleFontSize ?? DEFAULT_SUBTITLE_FONT_SIZE))))
        setSubtitleMarginV(Math.max(MIN_SUBTITLE_MARGIN_V, Math.min(MAX_SUBTITLE_MARGIN_V, Number(data.subtitleMarginV ?? DEFAULT_SUBTITLE_MARGIN_V))))
          setSubtitleFontFamily((data.subtitleFontFamily || DEFAULT_SUBTITLE_FONT_FAMILY) as SubtitleFontFamily)
         setSubtitleBold(Boolean(data.subtitleBold ?? DEFAULT_SUBTITLE_BOLD))
         setTimingOffset(Math.max(MIN_TIMING_OFFSET, Math.min(MAX_TIMING_OFFSET, Number(data.timingOffset ?? 0))))
          setNarrationSpeed(Math.max(0.8, Math.min(1.5, Number(data.narrationSpeed ?? 1.0))))
         setNarrationStartSeconds(Math.max(0.5, Number(data.narrationStartSeconds ?? 0.5)))
         setNarrationDurationSeconds(
           data.narrationDurationSeconds == null ? null : Number(data.narrationDurationSeconds),
         )
          setStoryEndSeconds(
            data.storyEndSeconds == null ? null : Number(data.storyEndSeconds),
          )
        setSubtitleAlignment((data.subtitleAlignment || "center") as SubtitleAlignment)
        setLogoCoordinates({
          x: Number.isFinite(Number(data.logoX)) ? Number(data.logoX) : 0.75,
          y: Number.isFinite(Number(data.logoY)) ? Number(data.logoY) : 0.05,
        })
        setLogoScale(Math.max(0.05, Math.min(0.5, Number(data.logoScale ?? 0.22))))
        setWatermarkText(data.watermarkText || "")
        setVideoTransform(normalizeVideoTransform(data.videoTransform))
         setExportQuality(
           data.lastRequestedQuality === "720p"
             || data.lastRequestedQuality === "1080p"
             || data.lastRequestedQuality === "original"
             ? data.lastRequestedQuality
             : "1080p",
         )
         window.localStorage.removeItem(settingsDraftKey(id))
        queryClient.setQueryData(getGetProjectQueryKey(id), (old: any) => 
          old ? { ...old, ...data } : old
        )
      },
      onError: (err: any) => {
        preserveEditorStateAfterLogoUploadRef.current = false
        if (readScriptDraft(id)) {
          setScriptSaveStatus("local")
          toast({
            title: "စာသားကို စက်ထဲတွင် သိမ်းထားပါသည်",
            description: "Server save မအောင်မြင်သေးပါ။ လက်ရှိစာသားနဲ့ Step 3 ကို ဆက်လုပ်နိုင်ပြီး server ကို နောက်မှ ပြန်သိမ်းပါမည်။",
          })
          return
        }
        toast({ variant: "destructive", title: "သိမ်းဆည်း၍ မရပါ", description: localizeError(err.message) })
      }
    }
  })
  const autosaveProject = useUpdateProject({
    mutation: {
      retry: 2,
      retryDelay: (attemptIndex) => Math.min(1000 * (2 ** attemptIndex), 4000),
      onSuccess: (_data, variables: any) => {
        const revision = Number(variables?.data?.scriptUpdatedAt || 0)
        if (revision !== latestScriptRevisionRef.current) return
        setScriptSaveStatus("saved")
        window.localStorage.removeItem(scriptDraftKey(id))
      },
      onError: (_error, variables: any) => {
        const revision = Number(variables?.data?.scriptUpdatedAt || 0)
        if (revision === latestScriptRevisionRef.current) setScriptSaveStatus("local")
      },
    },
  })
  const autosaveScripts = autosaveProject.mutate
  const autosaveSettings = useUpdateProject({
    mutation: {
      retry: 2,
      retryDelay: (attemptIndex) => Math.min(1000 * (2 ** attemptIndex), 8000),
    },
  })
  const generatePostMetadata = useGeneratePostMetadata({
    mutation: {
      onSuccess: (data) => {
        queryClient.setQueryData(getGetProjectQueryKey(id), data)
        toast({ title: "Post metadata အသင့်ဖြစ်ပါပြီ", description: "Viral titles နှင့် hashtags များကို ထုတ်ပေးပြီးပါပြီ။" })
      },
      onError: (error: any) => {
        toast({ variant: "destructive", title: "Metadata ထုတ်၍ မရပါ", description: localizeError(error.message) })
      },
    },
  })
  const metadataRequestRef = useRef("")
  useEffect(() => {
    if (
      project?.status === "completed"
      && project.exports?.length
      && !project.exportsStale
      && project.myanmarScript
      && !project.viralTitles?.length
      && metadataRequestRef.current !== project.id
    ) {
      metadataRequestRef.current = project.id
      generatePostMetadata.mutate({ id: project.id })
    }
  }, [
    project?.id,
    project?.status,
    project?.myanmarScript,
    project?.exports?.length,
    project?.exportsStale,
    project?.viralTitles?.length,
    generatePostMetadata,
  ])
  
  const runProject = useRunProject({
    mutation: {
      onSuccess: () => {
        toast({ title: "လုပ်ဆောင်မှု စတင်ပါပြီ", description: "လုပ်ငန်းစဉ်လုပ်ဆောင်ချက်ကို တန်းစီထားပါပြီ။" })
        queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(id) })
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "လုပ်ဆောင်၍ မရပါ", description: localizeError(err.message) })
      }
    }
  })
  
  const deleteProject = useDeleteProject({
    mutation: {
      onSuccess: () => {
        toast({ title: "ဖျက်ပြီးပါပြီ", description: "ပရောဂျက်ကို ဖယ်ရှားပြီးပါပြီ။" })
         queryClient.setQueryData(
           getListProjectsQueryKey(),
           (currentProjects: any[] | undefined) =>
             (currentProjects || []).filter((item) => item.id !== id),
         )
         void queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() })
        window.localStorage.removeItem(ACTIVE_PROJECT_STORAGE_KEY)
        setLocation("/projects")
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "ဖျက်၍ မရပါ", description: localizeError(err.message) })
      }
    }
  })
  const deleteProjectExport = useDeleteProjectExport({
    mutation: {
      onSuccess: (data) => {
        queryClient.setQueryData(getGetProjectQueryKey(id), data)
        void queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() })
        toast({ title: "Video ဖျက်ပြီးပါပြီ", description: "ရွေးထားသော completed export ကို ဖယ်ရှားပြီးပါပြီ။" })
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Video ဖျက်၍ မရပါ", description: localizeError(err.message) })
      },
    },
  })

  // Local state for editing
  const [transcript, setTranscript] = useState("")
  const [dialogue, setDialogue] = useState<DialogueLine[]>([])
  const [myanmarScript, setMyanmarScript] = useState("")
  const [englishScript, setEnglishScript] = useState("")
  const [globalEdit, setGlobalEdit] = useState("none")
  const [blurBoxes, setBlurBoxes] = useState<BlurBox[]>([])
  const [subtitleBox, setSubtitleBox] = useState<SubtitleBox | null>(null)
  const [logoPosition, setLogoPosition] = useState("top-right")
  const [maskStyle, setMaskStyle] = useState<MaskStyle>("clean-boxblur")
  const [subtitleStyle, setSubtitleStyle] = useState<SubtitleStyle>({ ...DEFAULT_SUBTITLE_STYLE })
   const [originalAudioVolume, setOriginalAudioVolume] = useState(0)
  const [subtitleFontSize, setSubtitleFontSize] = useState(DEFAULT_SUBTITLE_FONT_SIZE)
  const [subtitleMarginV, setSubtitleMarginV] = useState(DEFAULT_SUBTITLE_MARGIN_V)
  const [subtitleFontFamily, setSubtitleFontFamily] = useState<SubtitleFontFamily>(DEFAULT_SUBTITLE_FONT_FAMILY)
  const [subtitleBold, setSubtitleBold] = useState(DEFAULT_SUBTITLE_BOLD)
  const [timingOffset, setTimingOffset] = useState(0)
  const [narrationSpeed, setNarrationSpeed] = useState(1.0)
  const [narrationStartSeconds, setNarrationStartSeconds] = useState(0.5)
   const [narrationDurationSeconds, setNarrationDurationSeconds] = useState<number | null>(null)
  const [storyEndSeconds, setStoryEndSeconds] = useState<number | null>(null)
  const [subtitleAlignment, setSubtitleAlignment] = useState<SubtitleAlignment>("center")
  const [videoTransform, setVideoTransform] = useState<VideoTransform>({ ...DEFAULT_VIDEO_TRANSFORM })
  const [exportQuality, setExportQuality] = useState<ExportQuality>("1080p")
  const [logoCoordinates, setLogoCoordinates] = useState({ x: 0.75, y: 0.05 })
  const [logoScale, setLogoScale] = useState(0.22)
  const [watermarkText, setWatermarkText] = useState("")
  const [isUploadingLogo, setIsUploadingLogo] = useState(false)
  const [previewStep, setPreviewStep] = useState<1 | 2 | 3>(1)
  const [scriptSaveStatus, setScriptSaveStatus] = useState<"idle" | "local" | "saving" | "saved">("idle")
  const [dirtyFields, setDirtyFields] = useState({
    transcript: false,
    dialogue: false,
    myanmarScript: false,
    englishScript: false,
    globalEdit: false,
    blurBoxes: false,
    subtitleBox: false,
    logoPosition: false,
    maskStyle: false,
    subtitleStyle: false,
    originalAudioVolume: false,
    narrationTiming: false,
    subtitleFontSize: false,
    subtitleMarginV: false,
    subtitleFontFamily: false,
    subtitleBold: false,
    timingOffset: false,
    narrationSpeed: false,
    subtitleAlignment: false,
    logoCoordinates: false,
    logoScale: false,
    watermarkText: false,
    videoTransform: false,
    exportQuality: false,
  })
  
  const initializedForId = useRef<string | null>(null)
  const dirtyFieldsRef = useRef(dirtyFields)
  const previewFrameRef = useRef<HTMLDivElement>(null)
  const previewVideoRef = useRef<HTMLVideoElement>(null)
  const previewBackgroundVideoRef = useRef<HTMLVideoElement>(null)
  const logoInputRef = useRef<HTMLInputElement>(null)
  const [previewVideoCanvas, setPreviewVideoCanvas] = useState<PreviewVideoCanvas>({
    left: 0,
    top: 0,
    width: 0,
    height: 0,
  })
  const [previewPlayback, setPreviewPlayback] = useState({
    currentTime: 0,
    duration: 0,
    isPlaying: false,
    isMuted: true,
    volume: 1,
  })
  const [isPreviewReady, setIsPreviewReady] = useState(false)
  const [authoritativeSubtitleCues, setAuthoritativeSubtitleCues] = useState<PreviewSubtitleCue[]>([])
  const authoritativeSubtitleUrl = useMemo(() => {
    if (project?.exportsStale) return ""
    const exports = (project?.exports || []) as Array<{ language?: string; subtitleUrl?: string }>
    return exports.find((item) => item.language === "myanmar")?.subtitleUrl?.trim() || ""
  }, [project?.exports, project?.exportsStale])
  const dragRef = useRef<{
    mode: "move" | "resize"
    target: "subtitle" | "overlay" | string
    pointerId: number
    startClientX: number
    startClientY: number
    startBox: BoxGeometry
    startCoordinates?: { x: number; y: number }
  } | null>(null)
  const [activeBoxId, setActiveBoxId] = useState<string | null>(null)
  useEffect(() => {
    if (!authoritativeSubtitleUrl) {
      setAuthoritativeSubtitleCues([])
      return
    }
    let cancelled = false
    fetch(authoritativeSubtitleUrl, { credentials: "include" })
      .then((response) => response.ok ? response.text() : "")
      .then((content) => {
        if (!cancelled) setAuthoritativeSubtitleCues(parsePreviewSrt(content))
      })
      .catch(() => {
        if (!cancelled) setAuthoritativeSubtitleCues([])
      })
    return () => {
      cancelled = true
    }
  }, [authoritativeSubtitleUrl])

  useEffect(() => {
    // A downloaded SRT is authoritative only for the script that produced it.
    // Editing the script immediately returns the preview to the deterministic
    // pre-export cue generator until the next export completes.
    setAuthoritativeSubtitleCues([])
  }, [myanmarScript])

  const previewSubtitleBoxWidthPercent =
    subtitleBox?.widthPercent ?? DEFAULT_PREVIEW_SUBTITLE_BOX.widthPercent
  const previewSubtitleCues = useMemo(() => {
     if (authoritativeSubtitleCues.length) {
       return authoritativeSubtitleCues.flatMap((cue) => {
         const start = Math.max(0, cue.start + timingOffset)
         const end = Math.max(
           start + 0.01,
           Math.min(
             previewPlayback.duration || Number.POSITIVE_INFINITY,
             cue.end + timingOffset,
           ),
         )
         const previewCue = {
           ...cue,
           start,
           end,
         }
         const width =
           ((previewVideoCanvas.width || 1080) * previewSubtitleBoxWidthPercent) / 100
         const phrases = splitPreviewCueAtPhraseBoundaries(
           cue.text,
           width,
           previewVideoCanvas.height || 1920,
           subtitleFontSize,
         )
         return distributePreviewCueTime(previewCue, phrases)
       })
     }
    const fallback = splitPreviewSubtitleCues(myanmarScript)
    const duration = previewPlayback.duration
    const width =
      ((previewVideoCanvas.width || 1080) * previewSubtitleBoxWidthPercent) / 100
    return fallback.flatMap((text, index) => {
      const cue = {
        start: duration
          ? Math.max(0, (duration * index) / fallback.length + timingOffset)
          : 0,
        end: duration
          ? Math.min(duration, (duration * (index + 1)) / fallback.length + timingOffset)
          : 0,
        text,
      }
      const phrases = splitPreviewCueAtPhraseBoundaries(
        text,
        width,
        previewVideoCanvas.height || 1920,
        subtitleFontSize,
      )
      return distributePreviewCueTime(cue, phrases)
    })
  }, [
    authoritativeSubtitleCues,
    myanmarScript,
    previewPlayback.duration,
    previewVideoCanvas.width,
    previewVideoCanvas.height,
    previewSubtitleBoxWidthPercent,
    subtitleFontSize,
    timingOffset,
  ])
  const previewSubtitleText = useMemo(() => {
    if (!previewSubtitleCues.length) return ""
    const current = previewSubtitleCues.find((cue) =>
      previewPlayback.currentTime >= cue.start
      && previewPlayback.currentTime < cue.end,
    )
    return current?.text || ""
  }, [previewSubtitleCues, previewPlayback.currentTime, previewPlayback.duration])
  const subtitleVerticalPosition = useMemo(
    () => subtitleVerticalPositionForBox(subtitleBox),
    [subtitleBox],
  )
  const subtitleConfig = useMemo(() => ({
    subtitleBox,
    subtitleStyle,
    subtitleFontFamily,
    subtitleBold,
    subtitleFontSize,
    subtitleMarginV,
    subtitleAlignment,
    timingOffset,
  }), [
    subtitleBox,
    subtitleStyle,
    subtitleFontFamily,
    subtitleBold,
    subtitleFontSize,
    subtitleMarginV,
    subtitleAlignment,
    timingOffset,
  ])
  const settingsSnapshot = useMemo(() => ({
    globalEdit,
    blurBoxes,
    subtitleBox,
    logoPosition,
    maskStyle,
    subtitleStyle,
    originalAudioVolume,
    subtitleFontSize,
    subtitleMarginV,
    subtitleFontFamily,
    subtitleBold,
    timingOffset,
    narrationSpeed,
    narrationStartSeconds,
    narrationDurationSeconds,
    storyEndSeconds,
    subtitleAlignment,
    logoX: logoCoordinates.x,
    logoY: logoCoordinates.y,
    logoScale,
    watermarkText: watermarkText.trim(),
    videoTransform,
    lastRequestedQuality: exportQuality,
  }), [
    globalEdit,
    blurBoxes,
    subtitleBox,
    logoPosition,
    maskStyle,
    subtitleStyle,
    originalAudioVolume,
    subtitleFontSize,
    subtitleMarginV,
    subtitleFontFamily,
    subtitleBold,
    timingOffset,
    narrationSpeed,
    narrationStartSeconds,
    narrationDurationSeconds,
    storyEndSeconds,
    subtitleAlignment,
    logoCoordinates.x,
    logoCoordinates.y,
    logoScale,
    watermarkText,
    videoTransform,
    exportQuality,
  ])

  const persistSettingsDraft = (revision: number) => {
    try {
      window.localStorage.setItem(settingsDraftKey(id), JSON.stringify({
        updatedAt: revision,
        settings: settingsSnapshot,
      }))
    } catch {
      // The server remains authoritative when browser storage is unavailable.
    }
  }

  const clearSettingsDirty = () => {
    const next = { ...dirtyFieldsRef.current }
    for (const field of PERSISTED_SETTING_FIELDS) next[field] = false
    dirtyFieldsRef.current = next
    setDirtyFields(next)
  }

  const markDirty = (field: keyof typeof dirtyFields) => {
    const next = { ...dirtyFieldsRef.current, [field]: true }
    dirtyFieldsRef.current = next
    setDirtyFields(next)
  }

  const dialogueValidation = useMemo(() => {
    const sourceDuration = Number(project?.sourceDuration || 0)
    const errors: string[] = []
    const warnings: string[] = []
    let previousEnd: number | null = null
    dialogue.forEach((line, index) => {
      const label = `Line ${String(index + 1).padStart(2, "0")}`
      if (line.end <= line.start) errors.push(`${label}: end time must be greater than start time.`)
      if (sourceDuration > 0 && line.end > sourceDuration + 0.01) {
        errors.push(`${label}: end time is outside the source video.`)
      }
      if (line.reviewRequired) warnings.push(`${label}: [听不清] needs review.`)
      if (line.end - line.start < 0.25 || line.end - line.start > 30) {
        warnings.push(`${label}: suspicious duration.`)
      }
      if (previousEnd !== null && line.start < previousEnd - 0.01) {
        warnings.push(`${label}: overlaps the previous cue.`)
      }
      if (previousEnd !== null && line.start - previousEnd > 8) {
        warnings.push(`${label}: large gap before this cue.`)
      }
      previousEnd = line.end
    })
    return {
      errors,
      warnings,
      hasDialogue: dialogue.length > 0,
      ready: errors.length === 0 && !warnings.some((warning) => warning.includes("[听不清]")),
    }
  }, [dialogue, project?.sourceDuration])

  const updateDialogueLine = (lineId: string, patch: Partial<DialogueLine>) => {
    const next = dialogue.map((line) => {
      if (line.id !== lineId) return line
      const updated = { ...line, ...patch }
      const sourceTextChanged = (
        typeof patch.sourceText === "string"
        && patch.sourceText.trim() !== line.sourceText
      )
      return {
        ...updated,
        reviewRequired: updated.sourceText.includes("[听不清]"),
        timingWarning: [],
        ...(sourceTextChanged
          ? {
              myanmarText: null,
              englishText: null,
              translationFallback: false,
            }
          : {}),
      }
    })
    setDialogue(next)
    setTranscript(dialogueToTranscript(next))
    markDirty("dialogue")
    markDirty("transcript")
  }

  const updateTranscript = (value: string) => {
    setTranscript(value)
    setDialogue((current) => current.length ? [] : current)
    markDirty("transcript")
    markDirty("dialogue")
  }

  const previewDialogueLine = (line: DialogueLine) => {
    const video = previewVideoRef.current
    if (!video) return
    video.currentTime = Math.max(0, line.start)
    video.muted = false
    setPreviewPlayback((current) => ({ ...current, currentTime: line.start, isMuted: false }))
    void video.play().catch(() => {
      toast({
        variant: "destructive",
        title: "အပိုင်းကို ဖွင့်၍မရပါ",
        description: "Browser မှ video playback ခွင့်ပြုချက် လိုအပ်နိုင်ပါသည်။",
      })
    })
  }

  const nextScriptRevision = () => {
    const revision = Math.max(Date.now(), latestScriptRevisionRef.current + 1)
    latestScriptRevisionRef.current = revision
    return revision
  }

  const persistScriptDraft = (revision: number) => {
    const draft: ScriptDraft = {
      transcript,
      dialogue,
      myanmarScript,
      englishScript,
      updatedAt: revision,
    }
    try {
      window.localStorage.setItem(scriptDraftKey(id), JSON.stringify(draft))
    } catch {
      // The in-memory editor state remains available for Step 3 when storage is unavailable.
    }
  }

  useEffect(() => {
    if (!id || initializedForId.current !== id || scriptDraftHydratedForId.current !== id) return
    if (skipNextDraftWriteRef.current) {
      skipNextDraftWriteRef.current = false
      return
    }

    const revision = nextScriptRevision()
    persistScriptDraft(revision)
    setScriptSaveStatus("local")
    if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current)
    if (project?.status === "queued" || project?.status === "processing") return
    autosaveTimerRef.current = setTimeout(() => {
      setScriptSaveStatus("saving")
      autosaveScripts({
        id,
        data: {
          transcript,
          dialogue,
          myanmarScript,
          englishScript,
          scriptUpdatedAt: revision,
        },
      })
    }, 800)

    return () => {
      if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current)
    }
  }, [id, transcript, dialogue, myanmarScript, englishScript, project?.status, autosaveScripts])
  
  useEffect(() => {
    if (!project) return

    if (initializedForId.current !== project.id) {
      initializedForId.current = project.id
      const settingsDraft = readSettingsDraft(project.id)
      const projectUpdatedAt = Date.parse(String(project.updatedAt || "")) || 0
      const useSettingsDraft = Boolean(
        settingsDraft && settingsDraft.updatedAt > projectUpdatedAt,
      )
      const restoredSettings = useSettingsDraft ? settingsDraft!.settings : project
      settingsDraftHydratedForId.current = project.id
      setGlobalEdit((restoredSettings.globalEdit || "none") as string)
      setBlurBoxes(normalizeBlurBoxes(restoredSettings.blurBoxes))
      setSubtitleBox(normalizeBox(restoredSettings.subtitleBox))
      setLogoPosition((restoredSettings.logoPosition || "top-right") as string)
       setMaskStyle((restoredSettings.maskStyle || "clean-boxblur") as MaskStyle)
       setSubtitleStyle(normalizeSubtitleStyle(restoredSettings.subtitleStyle))
         setOriginalAudioVolume(0)
          const savedTranscript = project.transcript || ""
          const savedMyanmarScript = project.myanmarScript || ""
          const savedEnglishScript = project.englishScript || ""
          const draft = readScriptDraft(project.id)
          const useDraft = Boolean(draft && draft.updatedAt > projectUpdatedAt)
           const projectScriptRevision = Number(project.scriptUpdatedAt || 0)
          setTranscript(useDraft ? draft!.transcript : savedTranscript)
           setDialogue(normalizeDialogue(useDraft && draft?.dialogue ? draft.dialogue : project.dialogue))
          setMyanmarScript(useDraft ? draft!.myanmarScript : savedMyanmarScript)
          setEnglishScript(useDraft ? draft!.englishScript : savedEnglishScript)
           latestScriptRevisionRef.current = useDraft
             ? draft!.updatedAt
             : projectScriptRevision
           if (useDraft) {
            setScriptSaveStatus("local")
          }
          scriptDraftHydratedForId.current = project.id
          skipNextDraftWriteRef.current = true
           setSubtitleFontSize(Math.max(MIN_SUBTITLE_FONT_SIZE, Math.min(MAX_SUBTITLE_FONT_SIZE, Number(restoredSettings.subtitleFontSize ?? DEFAULT_SUBTITLE_FONT_SIZE))))
           setSubtitleMarginV(Math.max(MIN_SUBTITLE_MARGIN_V, Math.min(MAX_SUBTITLE_MARGIN_V, Number(restoredSettings.subtitleMarginV ?? DEFAULT_SUBTITLE_MARGIN_V))))
            setSubtitleFontFamily((restoredSettings.subtitleFontFamily || DEFAULT_SUBTITLE_FONT_FAMILY) as SubtitleFontFamily)
            setSubtitleBold(Boolean(restoredSettings.subtitleBold ?? DEFAULT_SUBTITLE_BOLD))
            setTimingOffset(Math.max(MIN_TIMING_OFFSET, Math.min(MAX_TIMING_OFFSET, Number(restoredSettings.timingOffset ?? 0))))
           setNarrationSpeed(Math.max(0.8, Math.min(1.5, Number(restoredSettings.narrationSpeed ?? 1.0))))
           setNarrationStartSeconds(Math.max(0.5, Number(restoredSettings.narrationStartSeconds ?? 0.5)))
          setNarrationDurationSeconds(
             restoredSettings.narrationDurationSeconds == null ? null : Number(restoredSettings.narrationDurationSeconds),
          )
           setStoryEndSeconds(
             restoredSettings.storyEndSeconds == null ? null : Number(restoredSettings.storyEndSeconds),
           )
           setExportQuality(
             restoredSettings.lastRequestedQuality === "720p"
               || restoredSettings.lastRequestedQuality === "1080p"
               || restoredSettings.lastRequestedQuality === "original"
               ? restoredSettings.lastRequestedQuality
               : "1080p",
           )
        setSubtitleAlignment((restoredSettings.subtitleAlignment || "center") as SubtitleAlignment)
       setLogoCoordinates({
          x: Number.isFinite(Number(restoredSettings.logoX)) ? Number(restoredSettings.logoX) : 0.75,
          y: Number.isFinite(Number(restoredSettings.logoY)) ? Number(restoredSettings.logoY) : 0.05,
       })
         setLogoScale(Math.max(0.05, Math.min(0.5, Number(restoredSettings.logoScale ?? 0.22))))
        setWatermarkText(String(restoredSettings.watermarkText || ""))
        setVideoTransform(normalizeVideoTransform(restoredSettings.videoTransform))
      const cleanFields = {
        transcript: false,
        dialogue: false,
        myanmarScript: false,
        englishScript: false,
        globalEdit: false,
        blurBoxes: false,
        subtitleBox: false,
        logoPosition: false,
         maskStyle: false,
         subtitleStyle: false,
         originalAudioVolume: false,
          narrationTiming: false,
         subtitleFontSize: false,
         subtitleMarginV: false,
          subtitleFontFamily: false,
          subtitleBold: false,
          timingOffset: false,
          narrationSpeed: false,
          subtitleAlignment: false,
         logoCoordinates: false,
          logoScale: false,
         watermarkText: false,
         videoTransform: false,
          exportQuality: false,
      }
      const hydratedDirtyFields = { ...cleanFields }
      if (useSettingsDraft) {
        for (const field of PERSISTED_SETTING_FIELDS) hydratedDirtyFields[field] = true
      }
      dirtyFieldsRef.current = hydratedDirtyFields
      setDirtyFields(hydratedDirtyFields)
      return
    }

    if (!dirtyFieldsRef.current.transcript) setTranscript(project.transcript || "")
    if (!dirtyFieldsRef.current.dialogue) setDialogue(normalizeDialogue(project.dialogue))
    if (!dirtyFieldsRef.current.myanmarScript) setMyanmarScript(project.myanmarScript || "")
    if (!dirtyFieldsRef.current.englishScript) setEnglishScript(project.englishScript || "")
    if (!dirtyFieldsRef.current.globalEdit) setGlobalEdit(project.globalEdit || "none")
    if (!dirtyFieldsRef.current.blurBoxes) setBlurBoxes(normalizeBlurBoxes(project.blurBoxes))
    if (!dirtyFieldsRef.current.subtitleBox) setSubtitleBox(normalizeBox(project.subtitleBox))
    if (!dirtyFieldsRef.current.logoPosition) setLogoPosition(project.logoPosition || "top-right")
     if (!dirtyFieldsRef.current.maskStyle) setMaskStyle((project.maskStyle || "clean-boxblur") as MaskStyle)
     if (!dirtyFieldsRef.current.subtitleStyle) setSubtitleStyle(normalizeSubtitleStyle(project.subtitleStyle))
       if (!dirtyFieldsRef.current.originalAudioVolume) setOriginalAudioVolume(0)
    if (!dirtyFieldsRef.current.subtitleFontSize) {
      setSubtitleFontSize(Math.max(MIN_SUBTITLE_FONT_SIZE, Math.min(MAX_SUBTITLE_FONT_SIZE, Number(project.subtitleFontSize ?? DEFAULT_SUBTITLE_FONT_SIZE))))
      setSubtitleMarginV(Math.max(MIN_SUBTITLE_MARGIN_V, Math.min(MAX_SUBTITLE_MARGIN_V, Number(project.subtitleMarginV ?? DEFAULT_SUBTITLE_MARGIN_V))))
    }
     if (!dirtyFieldsRef.current.subtitleFontFamily) {
       setSubtitleFontFamily((project.subtitleFontFamily || DEFAULT_SUBTITLE_FONT_FAMILY) as SubtitleFontFamily)
     }
     if (!dirtyFieldsRef.current.subtitleBold) {
       setSubtitleBold(Boolean(project.subtitleBold ?? DEFAULT_SUBTITLE_BOLD))
     }
     if (!dirtyFieldsRef.current.timingOffset) {
       setTimingOffset(Math.max(MIN_TIMING_OFFSET, Math.min(MAX_TIMING_OFFSET, Number(project.timingOffset ?? 0))))
     }
    if (!dirtyFieldsRef.current.narrationSpeed) {
      setNarrationSpeed(Math.max(0.8, Math.min(1.5, Number(project.narrationSpeed ?? 1.0))))
    }
     if (!dirtyFieldsRef.current.narrationTiming) {
      setNarrationStartSeconds(Math.max(0.5, Number(project.narrationStartSeconds ?? 0.5)))
       setNarrationDurationSeconds(
         project.narrationDurationSeconds == null ? null : Number(project.narrationDurationSeconds),
       )
        setStoryEndSeconds(
          project.storyEndSeconds == null ? null : Number(project.storyEndSeconds),
        )
     }
     if (!dirtyFieldsRef.current.subtitleAlignment) {
       setSubtitleAlignment((project.subtitleAlignment || "center") as SubtitleAlignment)
     }
     if (!dirtyFieldsRef.current.logoCoordinates) {
       setLogoCoordinates({
         x: Number.isFinite(Number(project.logoX)) ? Number(project.logoX) : 0.75,
          y: Number.isFinite(Number(project.logoY)) ? Number(project.logoY) : 0.05,
       })
     }
     if (!dirtyFieldsRef.current.watermarkText) setWatermarkText(project.watermarkText || "")
     if (!dirtyFieldsRef.current.videoTransform) {
       setVideoTransform(normalizeVideoTransform(project.videoTransform))
     }
     if (!dirtyFieldsRef.current.exportQuality) {
       setExportQuality(
         project.lastRequestedQuality === "720p"
           || project.lastRequestedQuality === "1080p"
           || project.lastRequestedQuality === "original"
           ? project.lastRequestedQuality
           : "1080p",
       )
     }
  }, [project])

  const flushSettingsAutosave = async () => {
    if (!id || settingsAutosaveActiveRef.current) return
    const pending = settingsAutosavePendingRef.current
    if (!pending) return
    settingsAutosavePendingRef.current = null
    settingsAutosaveActiveRef.current = pending
    try {
      const data = await autosaveSettings.mutateAsync({
        id,
        data: pending.payload as any,
      })
      const isLatest = settingsAutosaveActiveRef.current?.revision === pending.revision
        && settingsAutosaveRevisionRef.current === pending.revision
      if (isLatest) {
        settingsRetryAttemptRef.current = 0
        clearSettingsDirty()
        window.localStorage.removeItem(settingsDraftKey(id))
        queryClient.setQueryData(getGetProjectQueryKey(id), (old: any) =>
          old ? { ...old, ...data } : data,
        )
      }
    } catch {
      // Keep the latest settings draft and dirty flags; retry without resetting the editor.
      if (!settingsAutosavePendingRef.current) settingsAutosavePendingRef.current = pending
      settingsRetryAttemptRef.current += 1
      const delay = Math.min(30000, 1000 * (2 ** Math.min(settingsRetryAttemptRef.current, 5)))
      if (settingsRetryTimerRef.current) clearTimeout(settingsRetryTimerRef.current)
      settingsRetryTimerRef.current = setTimeout(() => {
        settingsRetryTimerRef.current = null
        void flushSettingsAutosave()
      }, delay)
    } finally {
      if (settingsAutosaveActiveRef.current?.revision === pending.revision) {
        settingsAutosaveActiveRef.current = null
      }
      if (settingsAutosavePendingRef.current && !settingsRetryTimerRef.current) {
        settingsAutosaveTimerRef.current = setTimeout(() => {
          settingsAutosaveTimerRef.current = null
          void flushSettingsAutosave()
        }, 0)
      }
    }
  }

  useEffect(() => {
    if (
      !id
      || initializedForId.current !== id
      || settingsDraftHydratedForId.current !== id
    ) return
    const hasDirtySettings = PERSISTED_SETTING_FIELDS.some((field) => dirtyFields[field])
    if (!hasDirtySettings) return

    const revision = Math.max(Date.now(), settingsAutosaveRevisionRef.current + 1)
    settingsAutosaveRevisionRef.current = revision
    persistSettingsDraft(revision)
    settingsAutosavePendingRef.current = {
      revision,
      payload: { ...settingsSnapshot },
    }
    if (settingsAutosaveTimerRef.current) clearTimeout(settingsAutosaveTimerRef.current)
    if (settingsRetryTimerRef.current) {
      clearTimeout(settingsRetryTimerRef.current)
      settingsRetryTimerRef.current = null
    }
    if (project?.status === "queued" || project?.status === "processing") return
    settingsAutosaveTimerRef.current = setTimeout(() => {
      settingsAutosaveTimerRef.current = null
      void flushSettingsAutosave()
    }, 800)

    return () => {
      if (settingsAutosaveTimerRef.current) {
        clearTimeout(settingsAutosaveTimerRef.current)
        settingsAutosaveTimerRef.current = null
      }
    }
  }, [id, dirtyFields, settingsSnapshot, project?.status, autosaveSettings])

  useEffect(() => {
    const retryWhenOnline = () => {
      if (settingsAutosavePendingRef.current && !settingsAutosaveActiveRef.current) {
        void flushSettingsAutosave()
      }
    }
    window.addEventListener("online", retryWhenOnline)
    return () => {
      window.removeEventListener("online", retryWhenOnline)
      if (settingsAutosaveTimerRef.current) clearTimeout(settingsAutosaveTimerRef.current)
      if (settingsRetryTimerRef.current) clearTimeout(settingsRetryTimerRef.current)
    }
  }, [id, autosaveSettings])

  useEffect(() => {
    const handlePointerMove = (event: PointerEvent) => {
      const drag = dragRef.current
      const frame = previewFrameRef.current
      if (!drag || drag.pointerId !== event.pointerId || !frame) return
      const rect = frame.getBoundingClientRect()
      if (!rect.width || !rect.height) return
      const videoCanvas = measurePreviewVideoCanvas(frame, previewVideoRef.current)
      const interactionWidth = videoCanvas?.width || rect.width
      const interactionHeight = videoCanvas?.height || rect.height
      const dx = (event.clientX - drag.startClientX) / interactionWidth
      const dy = (event.clientY - drag.startClientY) / interactionHeight
      const dxPercent = dx * 100
      const dyPercent = dy * 100
      const nextGeometry = (box: BoxGeometry): BoxGeometry => {
        if (drag.target === "subtitle" && drag.mode === "move") {
          return {
            ...box,
            yPercent: Math.max(
              0,
              Math.min(100 - box.heightPercent, drag.startBox.yPercent + dyPercent),
            ),
          }
        }
        if (drag.mode === "move") {
          return {
            ...box,
            xPercent: Math.max(
              0,
              Math.min(100 - box.widthPercent, drag.startBox.xPercent + dxPercent),
            ),
            yPercent: Math.max(
              0,
              Math.min(100 - box.heightPercent, drag.startBox.yPercent + dyPercent),
            ),
          }
        }
        return {
          ...box,
          widthPercent: Math.max(
            1,
            Math.min(100 - drag.startBox.xPercent, drag.startBox.widthPercent + dxPercent),
          ),
          heightPercent: Math.max(
            1,
            Math.min(100 - drag.startBox.yPercent, drag.startBox.heightPercent + dyPercent),
          ),
        }
      }
      if (drag.target === "overlay" && drag.startCoordinates) {
         setLogoCoordinates({
           x: Math.max(0, Math.min(0.78, drag.startCoordinates.x + dx)),
           y: Math.max(0, Math.min(0.81, drag.startCoordinates.y + dy)),
         })
         markDirty("logoCoordinates")
      } else if (drag.target === "subtitle") {
        setSubtitleBox((current) => {
          const base = current || DEFAULT_PREVIEW_SUBTITLE_BOX
          return nextGeometry(base)
        })
        markDirty("subtitleBox")
      } else {
        setBlurBoxes((current) => current.map((box) =>
          box.id === drag.target ? { ...box, ...nextGeometry(box) } : box
        ))
        markDirty("blurBoxes")
      }
    }
    const stopDragging = () => {
      dragRef.current = null
      setActiveBoxId(null)
    }
    const handlePointerUp = (event: PointerEvent) => {
      if (dragRef.current?.pointerId === event.pointerId) stopDragging()
    }
    window.addEventListener("pointermove", handlePointerMove)
    window.addEventListener("pointerup", handlePointerUp)
    window.addEventListener("pointercancel", handlePointerUp)
    return () => {
      window.removeEventListener("pointermove", handlePointerMove)
      window.removeEventListener("pointerup", handlePointerUp)
      window.removeEventListener("pointercancel", handlePointerUp)
    }
  }, [])

  useEffect(() => {
    setIsPreviewReady(false)
    setPreviewVideoCanvas({ left: 0, top: 0, width: 0, height: 0 })
    setPreviewPlayback((current) => ({
      ...current,
      currentTime: 0,
      duration: 0,
      isPlaying: false,
    }))

    return () => {
      const video = previewVideoRef.current
      if (!video) return
      video.pause()
      previewBackgroundVideoRef.current?.pause()
    }
  }, [project?.id, project?.sourceUrl])

  useEffect(() => {
    const refreshPreviewVideoCanvas = () => {
      setPreviewVideoCanvas(
        measurePreviewVideoCanvas(previewFrameRef.current, previewVideoRef.current),
      )
    }
    refreshPreviewVideoCanvas()
    const frame = previewFrameRef.current
    const observer = typeof ResizeObserver === "undefined" || !frame
      ? null
      : new ResizeObserver(refreshPreviewVideoCanvas)
    if (observer && frame) observer.observe(frame)
    window.addEventListener("resize", refreshPreviewVideoCanvas)
    return () => {
      observer?.disconnect()
      window.removeEventListener("resize", refreshPreviewVideoCanvas)
    }
  }, [project?.id, project?.sourceUrl])

  useEffect(() => {
    const video = previewVideoRef.current
    if (!video) return

    const applyTransform = () => {
      const currentTime = Number.isFinite(video.currentTime)
        ? Math.max(0, video.currentTime)
        : 0
      video.style.transform = previewTransformAtTime(videoTransform, currentTime).css
    }

    applyTransform()
    if (!previewPlayback.isPlaying || !isPreviewReady) return

    video.style.willChange = "transform"
    let animationFrame = 0
    const updateOnFrame = () => {
      applyTransform()
      animationFrame = window.requestAnimationFrame(updateOnFrame)
    }
    animationFrame = window.requestAnimationFrame(updateOnFrame)

    return () => {
      window.cancelAnimationFrame(animationFrame)
      video.style.willChange = ""
    }
  }, [videoTransform, previewPlayback.isPlaying, isPreviewReady])

  const startBoxInteraction = (
    mode: "move" | "resize",
    target: string,
    event: React.PointerEvent<HTMLElement>,
  ) => {
    if (isBusy || !isPreviewReady) return
    const box = target === "subtitle"
      ? (subtitleBox || DEFAULT_PREVIEW_SUBTITLE_BOX)
      : blurBoxes.find((candidate) => candidate.id === target)
    if (!box) return
    event.preventDefault()
    event.stopPropagation()
     event.currentTarget.setPointerCapture(event.pointerId)
    dragRef.current = {
      mode,
      target,
      pointerId: event.pointerId,
      startClientX: event.clientX,
      startClientY: event.clientY,
      startBox: box,
    }
    setActiveBoxId(target)
  }

  const startOverlayInteraction = (event: React.PointerEvent<HTMLElement>) => {
    if (isBusy || !isPreviewReady || (!project?.hasLogo && !watermarkText.trim())) return
    event.preventDefault()
    event.stopPropagation()
     event.currentTarget.setPointerCapture(event.pointerId)
    dragRef.current = {
      mode: "move",
      target: "overlay",
      pointerId: event.pointerId,
      startClientX: event.clientX,
      startClientY: event.clientY,
       startBox: {
         xPercent: 0,
         yPercent: 0,
         widthPercent: 22,
         heightPercent: 19,
       },
      startCoordinates: logoCoordinates,
    }
    setActiveBoxId("overlay")
  }

  const addBlurBox = () => {
    if (isBusy || !isPreviewReady || blurBoxes.length >= 20) return
    const index = blurBoxes.length
    const next: BlurBox = {
      id: `blur-${Date.now()}-${index + 1}`,
      xPercent: Math.min(72, 14 + (index % 4) * 4),
      yPercent: Math.min(85, 82 + (index % 3) * 1.5),
      widthPercent: 70,
      heightPercent: 11,
      strength: 20,
    }
    setBlurBoxes((current) => [...current, next])
    setActiveBoxId(next.id)
    markDirty("blurBoxes")
  }

  const setBlurPreset = (preset: "standard" | "wide" | "reset") => {
    if (isBusy || isStarting || !isPreviewReady) return
    if (preset === "reset") {
      setBlurBoxes([])
      setActiveBoxId(null)
      markDirty("blurBoxes")
      return
    }
    const next: BlurBox = preset === "standard"
      ? {
          id: `blur-preset-${Date.now()}`,
          xPercent: 5,
          yPercent: 85,
          widthPercent: 90,
          heightPercent: 11,
          strength: 20,
        }
      : {
          id: `blur-preset-${Date.now()}`,
          xPercent: 2,
          yPercent: 84,
          widthPercent: 96,
          heightPercent: 12,
          strength: 20,
        }
    setBlurBoxes([next])
    setActiveBoxId(next.id)
    markDirty("blurBoxes")
  }

  const deleteBlurBox = (boxId: string) => {
    if (isBusy) return
    setBlurBoxes((current) => current.filter((box) => box.id !== boxId))
    setActiveBoxId((current) => current === boxId ? null : current)
    markDirty("blurBoxes")
  }

  const updateBlurStrength = (boxId: string, strength: number) => {
    const boundedStrength = Math.max(5, Math.min(50, strength))
    setBlurBoxes((current) => current.map((box) =>
      box.id === boxId ? { ...box, strength: boundedStrength } : box
    ))
    markDirty("blurBoxes")
  }

  const handleSave = () => {
    settingsAutosaveRevisionRef.current = Math.max(
      settingsAutosaveRevisionRef.current + 1,
      Date.now(),
    )
    settingsAutosavePendingRef.current = null
    if (settingsAutosaveTimerRef.current) {
      clearTimeout(settingsAutosaveTimerRef.current)
      settingsAutosaveTimerRef.current = null
    }
    const scriptRevision = nextScriptRevision()
    persistScriptDraft(scriptRevision)
    setScriptSaveStatus("local")
    updateProject.mutate({
      id,
      data: {
        ...subtitleConfig,
        transcript,
        dialogue,
        myanmarScript,
        englishScript,
        scriptUpdatedAt: scriptRevision,
        globalEdit: globalEdit as any,
        blurBoxes,
        subtitleBox,
        logoPosition: logoPosition as any,
         maskStyle,
         subtitleStyle,
         originalAudioVolume,
         subtitleFontSize,
          subtitleMarginV,
          subtitleFontFamily,
          subtitleBold,
          timingOffset,
          narrationSpeed,
          narrationStartSeconds,
          narrationDurationSeconds,
           storyEndSeconds,
          subtitleAlignment,
         logoX: logoCoordinates.x,
         logoY: logoCoordinates.y,
          logoScale,
         watermarkText: watermarkText.trim(),
         videoTransform,
         lastRequestedQuality: exportQuality,
      }
    })
  }

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    event.target.value = ""
    if (!file) return
    if (file.type !== "image/png" && !file.name.toLowerCase().endsWith(".png")) {
      toast({ variant: "destructive", title: "PNG ဖိုင်သာ အသုံးပြုပါ", description: "Channel Logo အတွက် PNG ပုံတစ်ခု ရွေးပါ။" })
      return
    }
    if (file.size > 5 * 1024 * 1024) {
      toast({ variant: "destructive", title: "Logo ဖိုင်ကြီးလွန်းပါသည်", description: "PNG logo သည် 5 MB သို့မဟုတ် ထိုထက်ငယ်ရပါမည်။" })
      return
    }
    setIsUploadingLogo(true)
    preserveEditorStateAfterLogoUploadRef.current = true
    try {
      const form = new FormData()
      form.append("file", file)
      const response = await fetch("/api/studio/logos", {
        method: "POST",
        body: form,
        credentials: "include",
      })
      const body = await response.json().catch(() => ({}))
      if (!response.ok || !body.logoObjectPath) {
        throw new Error(body.detail || "Channel logo upload failed.")
      }
      await updateProject.mutateAsync({
        id,
        data: {
          logoObjectPath: body.logoObjectPath,
          logoPosition: logoPosition as any,
           logoX: logoCoordinates.x,
           logoY: logoCoordinates.y,
           watermarkText: watermarkText.trim(),
        },
      })
      toast({ title: "Channel Logo သိမ်းပြီးပါပြီ", description: "Logo ကို export video များတွင် ထည့်သွင်းပေးမည်။" })
    } catch (uploadError: any) {
      preserveEditorStateAfterLogoUploadRef.current = false
      toast({ variant: "destructive", title: "Logo တင်၍ မရပါ", description: localizeError(uploadError.message || "Channel logo upload failed.") })
    } finally {
      preserveEditorStateAfterLogoUploadRef.current = false
      setIsUploadingLogo(false)
    }
  }

  const handleRemoveLogo = () => {
    if (isBusy || updateProject.isPending) return
    updateProject.mutate({ id, data: { logoObjectPath: null } })
  }

  const updateVideoTransform = (patch: Partial<VideoTransform>) => {
    setVideoTransform((current) => normalizeVideoTransform({ ...current, ...patch }))
    markDirty("videoTransform")
  }

  const updateCameraMove = (index: number, patch: Partial<CameraMove>) => {
    updateVideoTransform({
      cameraMoves: videoTransform.cameraMoves.map((move, moveIndex) =>
        moveIndex === index ? { ...move, ...patch } : move,
      ),
    })
  }

  const addCameraMove = () => {
    if (videoTransform.cameraMoves.length >= 32) return
    const move = createCameraMove(
      previewPlayback.currentTime,
      previewPlayback.duration,
      videoTransform.cameraMoves,
    )
    if (!move) {
      toast({
        variant: "destructive",
        title: "No free camera-move time",
        description: "There is no non-overlapping segment long enough for another camera move.",
      })
      return
    }
    updateVideoTransform({ cameraMoves: [...videoTransform.cameraMoves, move] })
  }
  
  const handleRun = (
    action: 'full' | 'transcribe' | 'translate' | 'export' | 'export_english' | 'export_capcut' | 'test_export',
    quality: ExportQuality = exportQuality,
  ) => {
    if (["full", "export", "export_english", "export_capcut", "test_export"].includes(action)) {
      const cameraMoveError = validateCameraMoves(
        videoTransform.cameraMoves,
        previewPlayback.duration,
      )
      if (cameraMoveError) {
        toast({
          variant: "destructive",
          title: "Review camera moves before exporting",
          description: cameraMoveError,
        })
        return
      }
    }
    if (
      dialogueValidation.hasDialogue
      && ["translate", "full", "export", "export_english"].includes(action)
      && !dialogueValidation.ready
    ) {
      toast({
        variant: "destructive",
        title: "Transcript timing ကို အရင်ပြင်ပါ",
        description: dialogueValidation.errors[0]
          || dialogueValidation.warnings.find((warning) => warning.includes("[听不清]"))
          || "Transcript line များတွင် review လိုအပ်နေပါသည်။",
      })
      return
    }
    const video = previewVideoRef.current
    const previewWidth = Math.round(previewVideoCanvas.width || video?.clientWidth || 0)
    const previewHeight = Math.round(previewVideoCanvas.height || video?.clientHeight || 0)
    const sourceWidth = video?.videoWidth || 0
    const sourceHeight = video?.videoHeight || 0
    const shortEdge = quality === "1080p" ? 1080 : quality === "720p" ? 720 : 0
    const isPortrait = sourceHeight >= sourceWidth
    const exportWidth = quality === "original"
      ? sourceWidth
      : shortEdge
        ? (isPortrait ? shortEdge : Math.round(shortEdge * 16 / 9))
        : 0
    const exportHeight = quality === "original"
      ? sourceHeight
      : shortEdge
        ? (isPortrait ? Math.round(shortEdge * 16 / 9) : shortEdge)
        : 0
    runProject.mutate({
      id,
      data: {
        action,
        quality,
        ...subtitleConfig,
        transcript,
        dialogue,
        myanmarScript,
        englishScript,
        globalEdit: globalEdit as any,
        ...(latestScriptRevisionRef.current > 0
          ? { scriptUpdatedAt: latestScriptRevisionRef.current }
          : {}),
        ...(previewWidth > 0 ? { previewWidth } : {}),
        ...(previewHeight > 0 ? { previewHeight } : {}),
        ...(exportWidth > 0 ? { exportWidth } : {}),
        ...(exportHeight > 0 ? { exportHeight } : {}),
        blurBoxes,
        subtitleBox,
        maskStyle,
        subtitleStyle,
        originalAudioVolume,
        subtitleFontSize,
        subtitleMarginV,
        subtitleFontFamily,
        subtitleBold,
        timingOffset,
         narrationSpeed,
         narrationStartSeconds,
         narrationDurationSeconds,
          storyEndSeconds,
        subtitleAlignment,
        logoPosition: logoPosition as any,
        logoX: logoCoordinates.x,
        logoY: logoCoordinates.y,
        logoScale,
        watermarkText: watermarkText.trim(),
        videoTransform,
      }
    })
  }

  const retryAction = (() => {
    const failedStage = String(project?.errorStage || project?.stage || "").toLowerCase()
    const errorCode = String(project?.errorCode || "").toLowerCase()
    if (failedStage.includes("transcrib") || failedStage.includes("speech-to-text")) {
      return "transcribe" as const
    }
    if (failedStage.includes("translat") || failedStage.includes("script")) {
      return "translate" as const
    }
    if (failedStage.includes("capcut") || errorCode.includes("capcut")) {
      return "export_capcut" as const
    }
    if (myanmarScript.trim()) return "export" as const
    if (englishScript.trim()) return "export_english" as const
    return "full" as const
  })()
  const projectNotFound = projectErrorStatus(error) === 404

  if (isLoading) {
    return (
      <div className="mx-auto max-w-5xl space-y-5 animate-pulse">
        <div className="h-10 w-40 rounded-xl bg-card" />
        <div className="grid gap-5 md:grid-cols-[minmax(0,1.4fr)_minmax(280px,.6fr)]">
          <div className="h-[520px] rounded-2xl bg-card" />
          <div className="h-[360px] rounded-2xl bg-card" />
        </div>
      </div>
    )
  }

  if (error || !project) {
    return (
      <div className="text-center py-20">
        <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
        <h2 className="text-xl font-semibold mb-2">
          {projectNotFound || !error ? "ပရောဂျက်ကို ရှာမတွေ့ပါ" : "ပရောဂျက်အချက်အလက် ရယူ၍ မရပါ"}
        </h2>
        {error && (
          <p className="mx-auto mb-5 max-w-md text-sm text-muted-foreground">
            {projectNotFound
              ? "ဤ project ID သည် မရှိတော့ပါ သို့မဟုတ် ဖျက်ပြီးဖြစ်နိုင်ပါသည်။"
              : localizeError((error as any)?.message || "Project details could not be loaded.")}
          </p>
        )}
        <div className="flex justify-center gap-2">
          {error && !projectNotFound && (
            <Button variant="outline" onClick={() => void refetch()} disabled={isFetching}>
              {isFetching && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              ထပ်မံကြိုးစားရန်
            </Button>
          )}
          <Button variant="outline" onClick={() => setLocation("/projects")}>ပရောဂျက်များသို့ ပြန်ရန်</Button>
        </div>
      </div>
    )
  }

  const isBusy = project.status === 'processing' || project.status === 'queued'
  const isStarting = runProject.isPending || updateProject.isPending || isUploadingLogo
  const sourcePreviewUrl = project.sourceUrl?.trim() || `/api/studio/projects/${project.id}/source`
  const previewTransform = previewTransformAtTime(videoTransform, previewPlayback.currentTime)
  const activeCameraMove = previewTransform.camera
  const previewTransformFactor = previewTransform.factor
  const needsPreviewTransformBackground = previewTransformFactor < 1.1
    && (
      Math.abs(previewTransform.offsetX) > 0.01
      || Math.abs(previewTransform.offsetY) > 0.01
      || Math.abs(activeCameraMove.panX) > 0.0001
      || Math.abs(activeCameraMove.panY) > 0.0001
    )
  const cameraMoveValidationError = validateCameraMoves(
    videoTransform.cameraMoves,
    previewPlayback.duration,
  )
  const readyToPost = !isBusy
    && project.status === "completed"
    && !project.exportsStale
    && Boolean(project.exports?.length)
  const reusableMyanmarExport = readyToPost
    ? project.exports?.find((item) => item.language === "myanmar") || project.exports?.[0]
    : undefined
  const canDownloadExistingExport = Boolean(
    reusableMyanmarExport?.downloadUrl || reusableMyanmarExport?.videoUrl,
  )
  const formatPreviewTime = (seconds: number) => {
    const safeSeconds = Math.max(0, Math.floor(seconds || 0))
    const minutes = Math.floor(safeSeconds / 60)
    const remainder = safeSeconds % 60
    return `${minutes}:${String(remainder).padStart(2, "0")}`
  }
  const togglePreviewPlayback = () => {
    const video = previewVideoRef.current
    if (!video || !isPreviewReady) return
    if (video.paused) {
      void video.play().catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") return
        if (error && typeof error === "object" && "name" in error && error.name === "AbortError") return
        console.error(error)
      })
    } else {
      video.pause()
    }
  }
  const togglePreviewMute = () => {
    const video = previewVideoRef.current
    if (!video || !isPreviewReady) return
    video.muted = !video.muted
    setPreviewPlayback((current) => ({ ...current, isMuted: video.muted }))
  }
  const updatePreviewVolume = (value: number) => {
    const video = previewVideoRef.current
    if (!video || !isPreviewReady) return
    const nextVolume = Math.max(0, Math.min(1, value))
    video.volume = nextVolume
    if (value > 0 && video.muted) video.muted = false
    setPreviewPlayback((current) => ({
      ...current,
      volume: nextVolume,
      isMuted: video.muted,
    }))
  }

  const handlePreviewLoadedMetadata = (event: React.SyntheticEvent<HTMLVideoElement>) => {
    const video = previewVideoRef.current ?? event.currentTarget
    if (!video) return
    const duration = Number.isFinite(video.duration) ? Math.max(0, video.duration) : 0
    const currentTime = Number.isFinite(video.currentTime) ? Math.max(0, video.currentTime) : 0
    setPreviewPlayback((current) => ({ ...current, duration, currentTime }))
    setPreviewVideoCanvas(measurePreviewVideoCanvas(previewFrameRef.current, video))
    setIsPreviewReady(true)
    syncPreviewBackground(true)
  }

  const syncPreviewBackground = (forceSeek = false) => {
    const video = previewVideoRef.current
    const background = previewBackgroundVideoRef.current
    if (!video || !background || background.readyState < 1) return
    if (forceSeek || Math.abs(background.currentTime - video.currentTime) > 0.3) {
      try {
        background.currentTime = video.currentTime
      } catch {
        // The background layer is decorative; the foreground preview remains authoritative.
      }
    }
    if (!video.paused && background.paused && background.readyState >= 2) {
      void background.play().catch(() => undefined)
    } else if (video.paused && !background.paused) {
      background.pause()
    }
  }

  const handlePreviewTimeUpdate = (event: React.SyntheticEvent<HTMLVideoElement>) => {
    const video = previewVideoRef.current ?? event.currentTarget
    if (!video || video.readyState < 1) return
    const currentTime = Number.isFinite(video.currentTime) ? Math.max(0, video.currentTime) : 0
    setPreviewPlayback((current) => ({ ...current, currentTime }))
    syncPreviewBackground()
  }

  return (
    <div className="mx-auto max-w-6xl space-y-4 pb-20 animate-studio-in sm:space-y-5">
        <div className="rounded-2xl border border-card-border bg-card/70 p-2.5 shadow-lg shadow-black/10 backdrop-blur-xl sm:p-3">
          <div className="flex flex-wrap items-center gap-2.5">
          <Button variant="outline" onClick={() => setLocation("/projects")} className="h-10 shrink-0 border-white/10 bg-background/50 px-3 text-foreground hover:bg-white/10 hover:text-white" aria-label="ပရောဂျက်များသို့ ပြန်ရန်">
          <ArrowLeft className="mr-1.5 h-4 w-4" /> <span className="hidden sm:inline">Back</span>
        </Button>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="max-w-full truncate text-xl font-bold tracking-tight sm:text-2xl text-foreground">
              {project.title}
            </h1>
            <Badge variant={
              project.status === 'completed' ? 'default' : 
              project.status === 'failed' ? 'destructive' : 'secondary'
            } className="capitalize glass-panel border-0">
              {isBusy && <Loader2 className="w-3 h-3 mr-1 animate-spin inline" />}
              {localizeStatus(project.status, project.progress)}
            </Badge>
          </div>
          <p className="mt-1 truncate text-xs text-muted-foreground sm:text-sm">
            {project.sourceUrl || "စက်ထဲမှ တင်ထားသောဖိုင်"}
          </p>
        </div>
        
        <div className="flex w-full gap-2 sm:w-auto">
          <Button variant="secondary" onClick={handleSave} disabled={isBusy || updateProject.isPending} className="h-10 flex-1 border-white/10 bg-white/[0.06] text-foreground hover:bg-white/10 sm:flex-none">
            {updateProject.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            <span className="sm:hidden">သိမ်းရန်</span><span className="hidden sm:inline">တည်းဖြတ်မှုများ သိမ်းရန်</span>
          </Button>
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="icon" aria-label="ပရောဂျက်ဖျက်ရန်" className="h-10 w-10 bg-destructive/80 text-white hover:bg-destructive"><Trash2 className="w-4 h-4" /></Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="glass-panel border-0">
              <AlertDialogHeader>
              <AlertDialogTitle>ပရောဂျက်ကို ဖျက်မည်လား။</AlertDialogTitle>
                <AlertDialogDescription className="text-muted-foreground">
                ပရောဂျက်နှင့် ဖန်တီးထားသောဖိုင်များအားလုံးကို အပြီးတိုင် ဖျက်မည်ဖြစ်ပါသည်။ ပြန်လည်ပြင်ဆင်၍ မရပါ။
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
              <AlertDialogCancel className="bg-card border-0 hover:bg-white/10 text-foreground">မလုပ်တော့ပါ</AlertDialogCancel>
              <AlertDialogAction onClick={() => deleteProject.mutate({ id })} className="bg-destructive hover:bg-destructive/90 text-white">ဖျက်ရန်</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
      </div>

      <nav
        className="rounded-2xl border border-card-border bg-card/70 p-3 shadow-lg shadow-black/10 backdrop-blur-xl"
        aria-label="Preview workflow"
      >
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
            {PREVIEW_WORKFLOW_STEPS.map((step) => {
              const active = previewStep === step.id
              const complete = previewStep > step.id
              return (
                <button
                  key={step.id}
                  type="button"
                  onClick={() => setPreviewStep(step.id)}
                  aria-current={active ? "step" : undefined}
                  className={`min-w-0 rounded-xl border px-2.5 py-2 text-left transition-colors sm:px-3 ${
                    active
                      ? "border-primary/50 bg-primary/12 text-foreground shadow-[0_0_20px_hsl(var(--primary)/.12)]"
                      : complete
                        ? "border-emerald-400/25 bg-emerald-400/5 text-emerald-200"
                        : "border-white/10 bg-background/30 text-muted-foreground hover:bg-white/[0.06] hover:text-foreground"
                  }`}
                >
                  <span className="flex items-center gap-1.5 text-[11px] font-semibold sm:text-xs">
                    <span className="font-mono text-[10px] opacity-70">{step.id}</span>
                    <span className="truncate">{step.label}</span>
                  </span>
                  <span className="mt-0.5 hidden truncate text-[10px] text-muted-foreground sm:block">
                    {step.description}
                  </span>
                </button>
              )
            })}
          </div>
          <div className="flex items-center justify-between gap-3 lg:min-w-[260px] lg:justify-end">
            <p className="text-xs text-muted-foreground" aria-live="polite">
              Step {previewStep} of {PREVIEW_WORKFLOW_STEPS.length}
            </p>
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setPreviewStep((current) => Math.max(1, current - 1) as 1 | 2 | 3)}
                disabled={previewStep === 1}
                className="gap-1 border-white/10 bg-background/40"
              >
                <ChevronLeft className="h-4 w-4" />
                Back
              </Button>
              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={() => setPreviewStep((current) => Math.min(3, current + 1) as 1 | 2 | 3)}
                disabled={previewStep === 3}
                className="gap-1 border-white/10 bg-white/[0.08]"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3 md:gap-5">
        <div
          className={previewStep === 1 || previewStep === 2
            ? "space-y-4 md:col-span-3 md:space-y-6"
            : "hidden"}
          aria-hidden={previewStep === 3}
        >
          <section hidden={previewStep !== 1} aria-label="Preview step">
          <Card className="glass-card border-primary/20 shadow-[0_18px_60px_rgba(0,0,0,.24)]">
            <CardHeader className="pb-3 border-b border-white/5">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2 text-lg text-foreground">
                    <ShieldCheck className="h-5 w-5 text-primary" />
                    တရုတ်စာတန်း ဖုံးကွယ်မှု
                  </CardTitle>
                  <CardDescription className="mt-1 text-muted-foreground">
                    ဗီဒီယိုပေါ်တွင် စာတန်းတစ်ခုချင်းစီကို ဖုံးရန် လွတ်လပ်သော box များထည့်ပါ။
                  </CardDescription>
                </div>
                   <div className="flex flex-wrap gap-2">
                     <Button
                       type="button"
                       size="sm"
                       variant="outline"
                       onClick={() => setBlurPreset("standard")}
                       disabled={isBusy || isStarting || !isPreviewReady}
                       className="border-primary/30 bg-primary/5 hover:bg-primary/10"
                     >
                       Standard Bottom
                     </Button>
                     <Button
                       type="button"
                       size="sm"
                       variant="outline"
                       onClick={() => setBlurPreset("wide")}
                       disabled={isBusy || isStarting || !isPreviewReady}
                       className="border-primary/30 bg-primary/5 hover:bg-primary/10"
                     >
                       Wide Subtitle
                     </Button>
                     <Button
                       type="button"
                       size="sm"
                       variant="ghost"
                       onClick={() => setBlurPreset("reset")}
                       disabled={isBusy || isStarting || !isPreviewReady}
                       className="hover:bg-white/10"
                     >
                       Reset
                     </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="secondary"
                    onClick={addBlurBox}
                    disabled={isBusy || isStarting || !isPreviewReady || blurBoxes.length >= 20}
                    className="bg-card border border-white/5 hover:bg-white/10"
                  >
                    <Plus className="mr-1.5 h-4 w-4 text-primary" />
                    Add Blur Box
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full gap-2 border-accent/40 text-accent hover:bg-accent/10"
                    onClick={() => handleRun("test_export", exportQuality)}
                    disabled={isBusy || isStarting}
                  >
                    {isBusy || isStarting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                    Test Export (Bypass AI)
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="grid gap-4 p-3 sm:p-5 lg:grid-cols-[minmax(240px,360px)_1fr]">
              <div className="mx-auto w-full max-w-[320px]">
                <div
                  ref={previewFrameRef}
                  className="preview-canvas-locked overlay-interaction relative aspect-[9/16] w-full overflow-hidden rounded-2xl border border-white/10 bg-black shadow-2xl shadow-black/60"
                >
                <div
                  className="absolute inset-0 h-full w-full"
                  style={{
                    transform: videoTransform.mirrorHorizontal ? "scaleX(-1)" : undefined,
                    transformOrigin: "center center",
                  }}
                >
                {needsPreviewTransformBackground && (
                  <video
                    ref={previewBackgroundVideoRef}
                    key={`transform-background-${sourcePreviewUrl}`}
                    src={sourcePreviewUrl}
                    className="pointer-events-none absolute inset-0 h-full w-full object-cover"
                    style={{ filter: "blur(8px)", transform: "scale(1.08)" }}
                    muted
                    playsInline
                    preload="metadata"
                    tabIndex={-1}
                    aria-hidden="true"
                    onLoadedMetadata={() => syncPreviewBackground(true)}
                  />
                )}
                <video
                  ref={previewVideoRef}
                  key={sourcePreviewUrl}
                  src={sourcePreviewUrl}
                    className="preview-canvas-locked overlay-interaction h-full w-full select-none object-contain"
                    draggable={false}
                  style={{
                    transformOrigin: "center center",
                    transform: previewTransform.css,
                  }}
                  muted={previewPlayback.isMuted}
                  playsInline
                  preload="metadata"
                  onLoadStart={() => {
                    previewBackgroundVideoRef.current?.pause()
                    setIsPreviewReady(false)
                    setPreviewPlayback((current) => ({
                      ...current,
                      currentTime: 0,
                      duration: 0,
                      isPlaying: false,
                    }))
                  }}
                  onLoadedMetadata={handlePreviewLoadedMetadata}
                  onTimeUpdate={handlePreviewTimeUpdate}
                  onError={() => {
                    previewBackgroundVideoRef.current?.pause()
                    setIsPreviewReady(false)
                    setPreviewPlayback((current) => ({ ...current, isPlaying: false }))
                  }}
                  onPlay={() => {
                    setPreviewPlayback((current) => ({ ...current, isPlaying: true }))
                    syncPreviewBackground(true)
                  }}
                  onPause={() => {
                    setPreviewPlayback((current) => ({ ...current, isPlaying: false }))
                    syncPreviewBackground(true)
                  }}
                  onEnded={() => {
                    setPreviewPlayback((current) => ({ ...current, isPlaying: false }))
                    syncPreviewBackground(true)
                  }}
                  aria-label="မူရင်းဗီဒီယို အစမ်းကြည့်ရန်"
                />
                </div>
                {!isPreviewReady && (
                  <div className="pointer-events-none absolute inset-0 z-40 flex items-center justify-center bg-black/45 text-xs text-white/80">
                    ဗီဒီယိုကို ပြင်ဆင်နေသည်…
                  </div>
                )}
                  {isPreviewReady && previewSubtitleText && previewVideoCanvas.width > 0 && previewVideoCanvas.height > 0 && (() => {
                    const box = subtitleBox || DEFAULT_PREVIEW_SUBTITLE_BOX
                    const previewScale = previewVideoCanvas.height / 1920
                    const previewFontSize = Math.max(1, subtitleFontSize * previewScale)
                    const boxTop = previewVideoCanvas.top + (box.yPercent / 100) * previewVideoCanvas.height
                    return (
                      <div
                        aria-label="မြန်မာစာတန်း preview"
                        onPointerDown={(event) => startBoxInteraction("move", "subtitle", event)}
                        className="overlay-interaction pointer-events-auto absolute z-20 cursor-grab overflow-hidden"
                        style={{
                          left: `${previewVideoCanvas.left + (box.xPercent / 100) * previewVideoCanvas.width}px`,
                          top: `${boxTop}px`,
                          width: `${(box.widthPercent / 100) * previewVideoCanvas.width}px`,
                          height: `${(box.heightPercent / 100) * previewVideoCanvas.height}px`,
                        }}
                      >
                        <div
                          className="absolute inset-0"
                          role="group"
                          aria-label="မြန်မာစာတန်း နေရာနှင့်အရွယ်အစား"
                        >
                          <button
                            type="button"
                            aria-label="မြန်မာစာတန်း နေရာရွှေ့ရန်"
                            onPointerDown={(event) => startBoxInteraction("move", "subtitle", event)}
                            className={`pointer-events-auto absolute left-1/2 top-1 z-10 -translate-x-1/2 rounded bg-black/80 p-1 text-white shadow-sm ${activeBoxId === "subtitle" ? "ring-2 ring-accent" : ""}`}
                          >
                            <Move className="h-3 w-3" />
                          </button>
                          <button
                            type="button"
                            aria-label="မြန်မာစာတန်း အရွယ်အစားပြောင်းရန်"
                            onPointerDown={(event) => startBoxInteraction("resize", "subtitle", event)}
                            className="pointer-events-auto absolute bottom-1 right-1 z-10 cursor-nwse-resize rounded-full border border-accent bg-background/90 p-1 text-accent shadow-lg"
                          >
                            <Maximize2 className="h-2 w-2" />
                          </button>
                          <div
                            className="absolute left-0 right-0 whitespace-pre-wrap px-1"
                          style={{
                            top: 0,
                            color: subtitleStyle.primaryColor,
                             fontFamily: `'${subtitleFontFamily}', sans-serif`,
                            fontSize: `${previewFontSize}px`,
                             fontWeight: subtitleBold ? 700 : 400,
                            lineHeight: 1.16,
                            wordBreak: "keep-all",
                            overflowWrap: "normal",
                            textAlign: subtitleAlignment,
                            WebkitTextStroke: `${Math.max(0.5, subtitleStyle.outlineWidth * previewScale)}px ${subtitleStyle.outlineColor}`,
                             textShadow: `0 ${Math.max(1, previewScale * 2)}px ${Math.max(1, previewScale * 2)}px rgba(0,0,0,${Math.max(0, Math.min(1, subtitleStyle.shadowOpacity / 100))})`,
                          }}
                          >
                            {previewSubtitleText}
                          </div>
                        </div>
                      </div>
                    )
                  })()}
                 {(project.hasLogo || watermarkText.trim()) && (
                   <div
                     role="group"
                     aria-label="Hook Title Banner နှင့် Logo နေရာ"
                       className="overlay-interaction absolute z-30 flex flex-col items-start gap-1 rounded-md border border-accent/80 bg-black/20 p-1.5 text-white shadow-lg shadow-black/30"
                     style={{
                        left: `${previewVideoCanvas.left + logoCoordinates.x * previewVideoCanvas.width}px`,
                        top: `${previewVideoCanvas.top + logoCoordinates.y * previewVideoCanvas.height}px`,
                        width: `${logoScale * previewVideoCanvas.width}px`,
                        maxWidth: `${previewVideoCanvas.width * 0.5}px`,
                        minWidth: `${previewVideoCanvas.width * 0.05}px`,
                     }}
                   >
                      <button
                        type="button"
                        aria-label="Logo နှင့် watermark နေရာရွှေ့ရန်"
                        onPointerDown={startOverlayInteraction}
                        className="drag-handle absolute left-1/2 top-1 z-10 -translate-x-1/2 rounded bg-black/80 p-1 text-white shadow-sm"
                      >
                        <Move className="h-3 w-3" />
                      </button>
                     {project.hasLogo && (
                       <img
                         src={`/api/studio/projects/${project.id}/logo`}
                         alt="Channel logo"
                          className={`max-h-[19vh] w-full object-contain object-left-top ${activeBoxId === "overlay" ? "ring-2 ring-accent ring-offset-1 ring-offset-black/50" : ""}`}
                         draggable={false}
                       />
                     )}
                      {watermarkText.trim() && (
                        <span className="max-w-full break-words rounded-md bg-[#7C3AED]/90 px-2 py-1 text-[10px] font-semibold leading-tight text-white shadow-lg [text-shadow:0_1px_3px_rgba(0,0,0,.9)]">
                         {watermarkText}
                       </span>
                     )}
                   </div>
                 )}
                {blurBoxes.map((box, index) => (
                  <div
                    key={box.id}
                    role="group"
                    aria-label={`Blur ${index + 1}`}
                        className={`overlay-interaction absolute z-10 border-2 border-dashed border-primary bg-black/25 shadow-lg shadow-black/30 transition-all ${activeBoxId === box.id ? "ring-2 ring-primary/80 ring-offset-1 ring-offset-black/50" : ""}`}
                    style={{
                       left: `${previewVideoCanvas.left + (box.xPercent / 100) * previewVideoCanvas.width}px`,
                       top: `${previewVideoCanvas.top + (box.yPercent / 100) * previewVideoCanvas.height}px`,
                       width: `${(box.widthPercent / 100) * previewVideoCanvas.width}px`,
                       height: `${(box.heightPercent / 100) * previewVideoCanvas.height}px`,
                       backgroundColor: `rgba(20, 20, 28, ${Math.min(0.52, 0.12 + box.strength / 100)})`,
                       backdropFilter: `blur(${Math.max(1, box.strength * previewVideoCanvas.height / 1920)}px)`,
                       WebkitBackdropFilter: `blur(${Math.max(1, box.strength * previewVideoCanvas.height / 1920)}px)`,
                    }}
                  >
                    <button
                      type="button"
                      aria-label={`Blur ${index + 1} နေရာရွှေ့ရန်`}
                      onPointerDown={(event) => startBoxInteraction("move", box.id, event)}
                      className="drag-handle absolute left-1/2 top-1 z-10 -translate-x-1/2 rounded bg-black/80 p-1 text-white shadow-sm"
                    >
                      <Move className="h-3 w-3" />
                    </button>
                    <span className="absolute left-1 top-1 rounded bg-black/80 px-1.5 py-0.5 font-mono text-[10px] text-white shadow-sm border border-white/10">
                      Blur {index + 1}
                    </span>
                    <button
                      type="button"
                      aria-label={`Blur ${index + 1} ဖျက်ရန်`}
                      onPointerDown={(event) => event.stopPropagation()}
                      onClick={() => deleteBlurBox(box.id)}
                      className="absolute right-1 top-1 rounded bg-destructive/90 p-1 text-white hover:bg-destructive shadow-sm"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                    <button
                      type="button"
                      aria-label={`Blur ${index + 1} အရွယ်အစားပြောင်းရန်`}
                      onPointerDown={(event) => startBoxInteraction("resize", box.id, event)}
                       className="drag-handle absolute bottom-[-7px] right-[-7px] cursor-nwse-resize rounded-full border-2 border-primary bg-background p-1 text-primary shadow-lg"
                    >
                      <Maximize2 className="h-2 w-2" />
                    </button>
                  </div>
                ))}
                </div>
               <div className="mx-auto flex w-full max-w-[320px] items-center gap-2 rounded-b-xl border border-t-0 border-white/10 bg-card/80 px-3 py-2 shadow-lg" aria-label="ဗီဒီယိုထိန်းချုပ်မှု">
                 <Button
                   type="button"
                   variant="ghost"
                   size="icon"
                   className="h-8 w-8 shrink-0"
                   onClick={togglePreviewPlayback}
                   disabled={!isPreviewReady}
                   aria-label={previewPlayback.isPlaying ? "Pause preview" : "Play preview"}
                 >
                   {previewPlayback.isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                 </Button>
                 <span className="w-[68px] shrink-0 text-center font-mono text-[11px] text-muted-foreground">
                   {formatPreviewTime(previewPlayback.currentTime)} / {formatPreviewTime(previewPlayback.duration)}
                 </span>
                  <input
                    type="range"
                    min={0}
                   max={previewPlayback.duration || 0}
                   step={0.01}
                   value={Math.min(previewPlayback.currentTime, previewPlayback.duration || 0)}
                   onChange={(event) => {
                     const value = Number(event.target.value)
                     const video = previewVideoRef.current
                     if (!video || !isPreviewReady) return
                     const nextTime = Math.max(0, Math.min(value, previewPlayback.duration || 0))
                     video.currentTime = nextTime
                     setPreviewPlayback((current) => ({ ...current, currentTime: nextTime }))
                   }}
                   disabled={!isPreviewReady}
                   className="min-w-0 flex-1 accent-primary"
                   aria-label="ဗီဒီယို timeline"
                 />
                 <Button
                   type="button"
                   variant="ghost"
                   size="icon"
                   className="h-8 w-8 shrink-0"
                   onClick={togglePreviewMute}
                   disabled={!isPreviewReady}
                   aria-label={previewPlayback.isMuted ? "Unmute preview" : "Mute preview"}
                 >
                   {previewPlayback.isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                 </Button>
                 <input
                   type="range"
                   min={0}
                   max={1}
                   step={0.05}
                   value={previewPlayback.volume}
                   onChange={(event) => updatePreviewVolume(Number(event.target.value))}
                   disabled={!isPreviewReady}
                   className="hidden w-16 accent-primary sm:block"
                   aria-label="ဗီဒီယိုအသံအတိုးအကျယ်"
                 />
               </div>
                 <div className="mt-3 rounded-xl border border-accent/25 bg-accent/5 p-3 shadow-inner">
                    <p className="text-xs font-semibold text-foreground">Final audio mix</p>
                   <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
                      Export သည် ရွေးထားသော Edge-TTS ဇာတ်ကြောင်းအသံကို master timeline အဖြစ်သုံးပြီး
                      configured background music နှင့် sound effects ကို volume/ducking setting အတိုင်း mix လုပ်မည်။
                      မူရင်းဗီဒီယိုအသံကို မထည့်ပါ။
                   </p>
                 </div>
                <div className="mt-3 space-y-3 rounded-xl border border-white/10 bg-card/60 p-3">
                  <div>
                    <p className="text-xs font-semibold text-foreground">Video framing</p>
                    <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
                      Preview နှင့် export နှစ်ခုလုံးတွင် တူညီသော scale, zoom, X/Y transform ကို အသုံးပြုမည်။
                    </p>
                  </div>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div className="space-y-1.5">
                        <Label htmlFor="subtitle-font-family" className="text-xs">Font family</Label>
                        <Select
                          value={subtitleFontFamily}
                          onValueChange={(value) => {
                            setSubtitleFontFamily(value as SubtitleFontFamily)
                            markDirty("subtitleFontFamily")
                          }}
                          disabled={isBusy || isStarting}
                        >
                          <SelectTrigger id="subtitle-font-family" className="h-9 bg-card border-white/10">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-card border-white/10">
                            <SelectItem value="Noto Sans Myanmar">Noto Sans Myanmar</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">Weight</Label>
                        <Button
                          type="button"
                          variant={subtitleBold ? "secondary" : "outline"}
                          className="h-9 w-full justify-start gap-2 border-white/10"
                          onClick={() => {
                            setSubtitleBold((value) => !value)
                            markDirty("subtitleBold")
                          }}
                          disabled={isBusy || isStarting}
                          aria-pressed={subtitleBold}
                        >
                          <Bold className="h-4 w-4" />
                          {subtitleBold ? "Bold" : "Regular"}
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-xs">Subtitle timing offset</Label>
                        <span className="font-mono text-xs text-muted-foreground">
                          {timingOffset >= 0 ? "+" : ""}{timingOffset.toFixed(1)}s
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          className="h-9 px-2"
                          onClick={() => {
                            setTimingOffset((value) => Math.max(MIN_TIMING_OFFSET, Number((value - TIMING_OFFSET_STEP).toFixed(1))))
                            markDirty("timingOffset")
                          }}
                          disabled={isBusy || isStarting || timingOffset <= MIN_TIMING_OFFSET}
                          aria-label="စာတန်းကို 0.5 စက္ကန့် စောရန်"
                        >
                          −0.5s
                        </Button>
                        <input
                          type="range"
                          min={MIN_TIMING_OFFSET}
                          max={MAX_TIMING_OFFSET}
                          step={TIMING_OFFSET_STEP}
                          value={timingOffset}
                          onChange={(event) => {
                            setTimingOffset(Number(event.target.value))
                            markDirty("timingOffset")
                          }}
                          disabled={isBusy || isStarting}
                          className="w-full accent-accent"
                          aria-label="စာတန်း timing offset"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          className="h-9 px-2"
                          onClick={() => {
                            setTimingOffset((value) => Math.min(MAX_TIMING_OFFSET, Number((value + TIMING_OFFSET_STEP).toFixed(1))))
                            markDirty("timingOffset")
                          }}
                          disabled={isBusy || isStarting || timingOffset >= MAX_TIMING_OFFSET}
                          aria-label="စာတန်းကို 0.5 စက္ကန့် နောက်ကျရန်"
                        >
                          +0.5s
                        </Button>
                      </div>
                      <p className="text-[11px] text-muted-foreground">
                        Preview နှင့် export SRT/MP4 တို့တွင် cue အားလုံးကို တစ်ပြိုင်နက်ရွှေ့မည်။ အနုတ်တန်ဖိုးသည် 0:00 တွင် ဖြတ်တောက်မည်။
                      </p>
                    </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {([
                      ["scale", "Scale", 1, 2, 1],
                      ["zoom", "Zoom", 1, 2, 1],
                    ] as const).map(([key, label, min, max, step]) => (
                      <div key={key} className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <Label htmlFor={`video-${key}`} className="text-xs">{label}</Label>
                          <span className="text-xs font-mono text-muted-foreground">{videoTransform[key].toFixed(2)}x</span>
                        </div>
                        <input id={`video-${key}`} type="range" min={min} max={max} step={step} value={videoTransform[key]} onChange={(event) => updateVideoTransform({ [key]: Number(event.target.value) })} disabled={isBusy || isStarting} className="w-full accent-primary" aria-label={`${label} video transform`} />
                      </div>
                    ))}
                    {([
                      ["x", "X position"],
                      ["y", "Y position"],
                    ] as const).map(([key, label]) => (
                      <div key={key} className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <Label htmlFor={`video-${key}`} className="text-xs">{label}</Label>
                          <span className="text-xs font-mono text-muted-foreground">{videoTransform[key].toFixed(2)}</span>
                        </div>
                        <input id={`video-${key}`} type="range" min={-1} max={1} step={0.01} value={videoTransform[key]} onChange={(event) => updateVideoTransform({ [key]: Number(event.target.value) })} disabled={isBusy || isStarting} className="w-full accent-accent" aria-label={`${label} video transform`} />
                      </div>
                    ))}
                  </div>
                  <Button type="button" variant="ghost" size="sm" className="h-7 px-2 text-xs" disabled={isBusy || isStarting} onClick={() => { setVideoTransform({ ...DEFAULT_VIDEO_TRANSFORM }); markDirty("videoTransform") }}>
                    <RotateCcw className="mr-1.5 h-3 w-3" /> Reset framing
                  </Button>
                </div>
                <div className="mt-3 space-y-4 rounded-xl border border-white/10 bg-background/50 p-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="space-y-1">
                      <Label htmlFor="mirror-horizontal" className="text-xs font-semibold">
                        Mirror video horizontally
                      </Label>
                      <p className="text-[11px] text-muted-foreground">
                        Mirrors the picture in preview and the final export.
                      </p>
                    </div>
                    <Switch
                      id="mirror-horizontal"
                      checked={videoTransform.mirrorHorizontal}
                      onCheckedChange={(checked) => updateVideoTransform({ mirrorHorizontal: checked })}
                      disabled={isBusy || isStarting}
                      aria-label="Mirror video horizontally"
                    />
                  </div>

                  <div className="space-y-3 border-t border-white/10 pt-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <h3 className="text-xs font-semibold">Camera moves</h3>
                        <p className="text-[11px] text-muted-foreground">
                          Add eased zoom and pan segments on the source timeline.
                        </p>
                      </div>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="h-8 shrink-0 px-2"
                        onClick={addCameraMove}
                        disabled={isBusy || isStarting || videoTransform.cameraMoves.length >= 32}
                      >
                        <Plus className="mr-1 h-3.5 w-3.5" />
                        Add move
                      </Button>
                    </div>

                    {videoTransform.cameraMoves.length === 0 ? (
                      <div className="rounded-lg border border-dashed border-white/10 px-3 py-4 text-center text-[11px] text-muted-foreground">
                        No camera moves yet. Add one at the current preview time.
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {videoTransform.cameraMoves.map((move, index) => (
                          <div
                            key={`camera-move-${index}`}
                            className="space-y-3 rounded-lg border border-white/10 bg-card/60 p-3"
                          >
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-xs font-medium">Move {index + 1}</p>
                              <Button
                                type="button"
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 text-muted-foreground hover:text-destructive"
                                onClick={() => updateVideoTransform({
                                  cameraMoves: videoTransform.cameraMoves.filter((_, moveIndex) => moveIndex !== index),
                                })}
                                disabled={isBusy || isStarting}
                                aria-label={`Remove camera move ${index + 1}`}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                              <div className="space-y-1">
                                <Label htmlFor={`camera-start-${index}`} className="text-[11px]">
                                  Start time (s)
                                </Label>
                                <Input
                                  id={`camera-start-${index}`}
                                  type="number"
                                  min={0}
                                  max={900}
                                  step={0.1}
                                  value={move.startSeconds}
                                  onChange={(event) => updateCameraMove(index, {
                                    startSeconds: Number(event.currentTarget.value || 0),
                                  })}
                                  disabled={isBusy || isStarting}
                                  className="h-8"
                                />
                              </div>
                              <div className="space-y-1">
                                <Label htmlFor={`camera-end-${index}`} className="text-[11px]">
                                  End time (s)
                                </Label>
                                <Input
                                  id={`camera-end-${index}`}
                                  type="number"
                                  min={0.01}
                                  max={900}
                                  step={0.1}
                                  value={move.endSeconds}
                                  onChange={(event) => updateCameraMove(index, {
                                    endSeconds: Math.max(0.01, Number(event.currentTarget.value || 0)),
                                  })}
                                  disabled={isBusy || isStarting}
                                  className="h-8"
                                />
                              </div>
                              <div className="space-y-1">
                                <Label htmlFor={`camera-zoom-${index}`} className="text-[11px]">
                                  Zoom (1–2.5×)
                                </Label>
                                <Input
                                  id={`camera-zoom-${index}`}
                                  type="number"
                                  min={1}
                                  max={2.5}
                                  step={0.05}
                                  value={move.zoom}
                                  onChange={(event) => updateCameraMove(index, {
                                    zoom: Number(event.currentTarget.value || 1),
                                  })}
                                  disabled={isBusy || isStarting}
                                  className="h-8"
                                />
                              </div>
                              <div className="space-y-1">
                                <Label htmlFor={`camera-transition-${index}`} className="text-[11px]">
                                  Transition duration (s)
                                </Label>
                                <Input
                                  id={`camera-transition-${index}`}
                                  type="number"
                                  min={0.01}
                                  max={2}
                                  step={0.05}
                                  value={move.transitionSeconds ?? ""}
                                  onChange={(event) => updateCameraMove(index, {
                                    transitionSeconds: event.currentTarget.value === ""
                                      ? undefined
                                      : Number(event.currentTarget.value),
                                  })}
                                  disabled={isBusy || isStarting}
                                  className="h-8"
                                />
                              </div>
                              <div className="space-y-1">
                                <Label htmlFor={`camera-pan-x-${index}`} className="text-[11px]">
                                  Pan X (−1 to 1)
                                </Label>
                                <Input
                                  id={`camera-pan-x-${index}`}
                                  type="number"
                                  min={-1}
                                  max={1}
                                  step={0.05}
                                  value={move.panX ?? ""}
                                  onChange={(event) => updateCameraMove(index, {
                                    panX: event.currentTarget.value === ""
                                      ? undefined
                                      : Number(event.currentTarget.value),
                                  })}
                                  disabled={isBusy || isStarting}
                                  className="h-8"
                                />
                              </div>
                              <div className="space-y-1">
                                <Label htmlFor={`camera-pan-y-${index}`} className="text-[11px]">
                                  Pan Y (−1 to 1)
                                </Label>
                                <Input
                                  id={`camera-pan-y-${index}`}
                                  type="number"
                                  min={-1}
                                  max={1}
                                  step={0.05}
                                  value={move.panY ?? ""}
                                  onChange={(event) => updateCameraMove(index, {
                                    panY: event.currentTarget.value === ""
                                      ? undefined
                                      : Number(event.currentTarget.value),
                                  })}
                                  disabled={isBusy || isStarting}
                                  className="h-8"
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    {cameraMoveValidationError && (
                      <p role="alert" className="text-[11px] text-destructive">
                        {cameraMoveValidationError}
                      </p>
                    )}
                    <p className="text-[10px] text-muted-foreground">
                      Segments must be within the video, cannot overlap, and need an ease duration no longer than half the segment.
                    </p>
                  </div>
                </div>
                <div className="mt-3 space-y-3 rounded-xl border border-primary/25 bg-primary/5 p-3 shadow-inner">
                  <div className="space-y-1.5">
                    <Label htmlFor="export-quality" className="text-xs font-semibold text-foreground">
                      Video Export Quality
                    </Label>
                    <Select
                      value={exportQuality}
                      onValueChange={(value) => {
                        setExportQuality(value as ExportQuality)
                        markDirty("exportQuality")
                      }}
                      disabled={isBusy || isStarting}
                    >
                      <SelectTrigger id="export-quality" className="h-9 bg-card border-white/10">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-white/10">
                        <SelectItem value="720p">720p canvas — Fastest export</SelectItem>
                        <SelectItem value="1080p">1080p canvas — Full detail</SelectItem>
                        <SelectItem value="original">Auto / native source canvas</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="original-audio-volume" className="text-xs font-semibold text-foreground">
                          မူရင်းအသံ (အမြဲပိတ်ထားသည်)
                        </Label>
                        <span className="text-xs font-mono text-muted-foreground">
                          {Math.round(originalAudioVolume * 100)}%
                        </span>
                      </div>
                        <input
                        id="original-audio-volume"
                        type="range"
                        min={0}
                          max={0}
                        step={0.01}
                          value={0}
                          disabled
                        className="w-full accent-primary"
                          aria-label="မူရင်းဗီဒီယိုအသံ ပိတ်ထားသည်"
                      />
                    </div>
                      <div className="space-y-1.5">
                       <div className="flex items-center justify-between">
                        <Label htmlFor="narration-speed" className="text-xs font-semibold text-foreground">
                          ဇာတ်ကြောင်းအသံမြန်နှုန်း
                        </Label>
                        <span className="text-xs font-mono text-muted-foreground">
                           {narrationSpeed.toFixed(2)}x
                        </span>
                      </div>
                       <input
                        id="narration-speed"
                        type="range"
                         min={0.8}
                          max={1.5}
                          step={0.01}
                          value={narrationSpeed}
                          onChange={(event) => {
                            setNarrationSpeed(Number(event.target.value))
                           markDirty("narrationSpeed")
                         }}
                          disabled={isBusy || isStarting}
                        className="w-full accent-accent"
                          aria-label="ဇာတ်ကြောင်းအသံမြန်နှုန်း"
                      />
                         <p className="text-[11px] text-muted-foreground">FFmpeg သည် ဤ speed အတိုင်း voiceover နှင့် subtitle timeline ကိုညှိပေးမည်။</p>
                    </div>
                   </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="narration-start" className="text-xs font-semibold text-foreground">
                          Voiceover စတင်ချိန် (စက္ကန့်)
                        </Label>
                        <span className="text-xs font-mono text-muted-foreground">
                          {narrationStartSeconds.toFixed(1)}s
                        </span>
                      </div>
                      <input
                        id="narration-start"
                        type="number"
        min={0.5}
                        max={900}
                        step={0.1}
                        value={narrationStartSeconds}
                        onChange={(event) => {
                           setNarrationStartSeconds(Math.max(0.5, Math.min(900, Number(event.target.value) || 0.5)))
                          markDirty("narrationTiming")
                        }}
                        disabled={isBusy || isStarting}
                        className="h-9 w-full rounded-md border border-white/10 bg-card px-3 text-sm"
                        aria-label="Voiceover စတင်ချိန် စက္ကန့်"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="narration-duration" className="text-xs font-semibold text-foreground">
                          Voiceover အများဆုံးအချိန် (စက္ကန့်)
                        </Label>
                        <span className="text-xs font-mono text-muted-foreground">
                          {narrationDurationSeconds == null ? "Auto" : `${narrationDurationSeconds.toFixed(1)}s`}
                        </span>
                      </div>
                      <input
                        id="narration-duration"
                        type="number"
                        min={0.1}
                        max={900}
                        step={0.1}
                        value={narrationDurationSeconds ?? ""}
                        placeholder="Auto — story end သို့မဟုတ် video အဆုံး"
                        onChange={(event) => {
                          const raw = event.target.value.trim()
                          setNarrationDurationSeconds(raw === "" ? null : Math.max(0.1, Math.min(900, Number(raw) || 0.1)))
                          markDirty("narrationTiming")
                        }}
                        disabled={isBusy || isStarting}
                        className="h-9 w-full rounded-md border border-white/10 bg-card px-3 text-sm"
                        aria-label="Voiceover အများဆုံးအချိန် စက္ကန့်"
                      />
                    </div>
                  </div>
                  <details className="rounded-lg border border-white/10 bg-card/40 p-3">
                    <summary className="cursor-pointer text-xs font-semibold text-foreground">
                      ဇာတ်လမ်းအဆုံးကို သတ်မှတ်ရန် (ရွေးချယ်နိုင်သည်)
                    </summary>
                    <div className="mt-3 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="story-end-seconds" className="text-xs text-muted-foreground">
                          မူရင်းဗီဒီယိုပေါ်ရှိ အဆုံးချိန် (စက္ကန့်)
                        </Label>
                        <span className="text-xs font-mono text-muted-foreground">
                          {storyEndSeconds == null ? "Auto" : `${storyEndSeconds.toFixed(1)}s`}
                        </span>
                      </div>
                      <input
                        id="story-end-seconds"
                        type="number"
                        min={0.1}
                        max={project.sourceDuration || 900}
                        step={0.1}
                        value={storyEndSeconds ?? ""}
                        placeholder={`Auto — source end (${Number(project.sourceDuration || 0).toFixed(1)}s)`}
                        onChange={(event) => {
                          const raw = event.target.value.trim()
                          const sourceDuration = Number(project.sourceDuration || 0)
                          setStoryEndSeconds(
                            raw === ""
                              ? null
                              : Math.max(
                                  0.1,
                                  Math.min(
                                    sourceDuration || 900,
                                    Number(raw) || 0.1,
                                  ),
                                ),
                          )
                          markDirty("narrationTiming")
                        }}
                        disabled={isBusy || isStarting || !project.sourceDuration}
                        className="h-9 w-full rounded-md border border-white/10 bg-card px-3 text-sm"
                        aria-label="Story end in source video seconds"
                      />
                      <p className="text-[11px] leading-relaxed text-muted-foreground">
                        အလွတ်ထားပါက မူရင်းဗီဒီယိုအဆုံးကို သုံးမည်။ ဤအချိန်သည် narration window ကိုသာ ကန့်သတ်ပြီး export ဗီဒီယိုကို မဖြတ်ပါ။
                      </p>
                    </div>
                  </details>
                  <p className="text-[11px] leading-relaxed text-muted-foreground">
                    Auto narration window သည် story end ကို သတ်မှတ်ထားပါက ထိုနေရာအထိ၊ မဟုတ်ပါက source video အဆုံးအထိ ဖြစ်သည်။ စကားပြောသံသည် သဘာဝအတိုင်း စောပြီးဆုံးနိုင်ပြီး၊ export ဗီဒီယိုနှင့် ၎င်း၏ အဆုံးပိုင်းကို မဖြတ်ပါ။ Standalone SRT သည် တကယ်ပြောထားသော narration အချိန်နှင့် ကိုက်ညီသည်။
                  </p>
                  {reusableMyanmarExport && canDownloadExistingExport ? (
                    <DownloadFileButton
                      url={reusableMyanmarExport.downloadUrl || reusableMyanmarExport.videoUrl}
                      filename={`Project_${project.projectNumber || 0}_Final.mp4`}
                      icon={<Download className="h-4 w-4" />}
                      disabled={isBusy || isStarting}
                      className="flex h-10 w-full items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-[0_0_20px_rgba(var(--primary),0.3)] transition-colors hover:bg-primary/90"
                    >
                      Download Existing Export
                    </DownloadFileButton>
                  ) : (
                    <Button
                      type="button"
                      className="w-full gap-2 bg-primary text-primary-foreground shadow-[0_0_20px_rgba(var(--primary),0.3)] hover:bg-primary/90"
                      onClick={() => handleRun("full", exportQuality)}
                      disabled={isBusy || isStarting}
                    >
                      {isBusy || isStarting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                      Start Export / Download
                    </Button>
                  )}
                  <p className="text-center text-[11px] leading-relaxed text-muted-foreground">
                    {canDownloadExistingExport
                      ? "ဒီ project ကို မပြောင်းလဲသေးသောကြောင့် ရှိပြီးသား Final MP4 ကို ပြန်ထုတ်စရာမလိုဘဲ download လုပ်နိုင်ပါသည်။"
                      : "Upload သည် draft သာဖန်တီးပါသည်။ ဤခလုတ်နှိပ်ပြီးမှ TTS နှင့် FFmpeg render စတင်မည်။"}
                  </p>
                </div>
              </div>
              <div className="flex flex-col justify-center gap-5">
                <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 shadow-inner">
                  <p className="text-sm font-semibold text-primary">လွတ်လပ်သော ဖုံးကွယ် box များ</p>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    + Add Blur Box ကိုနှိပ်ပြီး စာတန်းတစ်ခုချင်းစီပေါ်တွင် box တစ်ခုထည့်ပါ။ Box ကို ဆွဲ၍ရွှေ့နိုင်ပြီး အောက်ညာဘက်ထောင့်ကို ဆွဲ၍ အကျယ်/အမြင့် ပြောင်းနိုင်သည်။
                  </p>
                </div>
                <div className="space-y-2 bg-card/40 p-4 rounded-xl border border-white/5 shadow-inner">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium text-foreground">ရွေးထားသော box များ</span>
                    <Badge variant="secondary" className="bg-background/80 text-primary border border-primary/20">{blurBoxes.length}/20</Badge>
                  </div>
                  {blurBoxes.length === 0 ? (
                    <p className="text-xs text-muted-foreground italic">
                      မူရင်းတရုတ်စာတန်းရှိသည့်နေရာများကို ဖုံးရန် box ထည့်ပါ။
                    </p>
                  ) : (
                    <div className="space-y-2 max-h-32 overflow-y-auto pr-2 custom-scrollbar">
                      {blurBoxes.map((box, index) => (
                        <div key={box.id} className="flex items-center justify-between rounded-lg border border-white/10 bg-background/50 px-3 py-2 text-xs transition-colors hover:bg-background">
                          <button
                            type="button"
                            className="flex items-center gap-2 text-left text-foreground"
                            onClick={() => setActiveBoxId(box.id)}
                          >
                            <span className="h-2 w-2 rounded-full bg-primary shadow-[0_0_8px_rgba(var(--primary),0.8)]" />
                            <span>Blur {index + 1}</span>
                          </button>
                           <span className="font-mono text-[10px] text-muted-foreground">{box.strength}</span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-muted-foreground hover:text-destructive hover:bg-destructive/20"
                            onClick={() => deleteBlurBox(box.id)}
                            disabled={isBusy}
                            aria-label={`Blur ${index + 1} ဖျက်ရန်`}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                        {activeBoxId && (() => {
                         const activeBlurBox = blurBoxes.find((box) => box.id === activeBoxId)
                         if (!activeBlurBox) return null
                         return (
                           <div className="space-y-1.5 rounded-lg border border-primary/20 bg-primary/5 p-2.5">
                             <div className="flex items-center justify-between">
                               <Label htmlFor="active-blur-strength" className="text-xs">Blur strength</Label>
                               <span className="font-mono text-xs text-primary">{activeBlurBox.strength}</span>
                             </div>
                             <input
                               id="active-blur-strength"
                               type="range"
                               min={5}
                               max={50}
                               step={1}
                               value={activeBlurBox.strength}
                               onChange={(event) => updateBlurStrength(activeBlurBox.id, Number(event.target.value))}
                               disabled={isBusy || isStarting}
                               className="w-full accent-primary"
                               aria-label={`Blur ${blurBoxes.findIndex((box) => box.id === activeBlurBox.id) + 1} strength`}
                             />
                           </div>
                         )
                       })()}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
          </section>
          <section hidden={previewStep !== 2} aria-label="Story and script step">
          <Card className="glass-card border-card-border">
            <CardHeader className="pb-4 border-b border-white/5">
                <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
                <CardTitle className="text-lg text-foreground flex items-center gap-2">
                  <Languages className="w-5 h-5 text-accent" />
                   ဇာတ်လမ်းအနှစ်ချုပ် အသံနှင့် standalone SRT
                </CardTitle>
                 <div className="flex w-full gap-2 sm:w-auto">
                    <Button variant="secondary" size="sm" onClick={() => handleRun('transcribe')} disabled={isBusy || isStarting} className="flex-1 sm:flex-none bg-card border border-white/5 hover:bg-white/10">
                     <Type className="w-3 h-3 mr-1.5 text-primary" /> မူရင်းအသံစာသားပြောင်းရန်
                  </Button>
                <Button variant="secondary" size="sm" onClick={() => handleRun('translate')} disabled={isBusy || isStarting || !transcript.trim()} className="flex-1 sm:flex-none bg-card border border-white/5 hover:bg-white/10">
                     <Languages className="w-3 h-3 mr-1.5 text-accent" /> ဇာတ်လမ်းအနှစ်ချုပ်ဖန်တီးရန်
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-5">
              <div className="mb-3 flex items-center justify-between text-xs text-muted-foreground" aria-live="polite">
                <span>စာသားပြင်ဆင်မှုများသည် အလိုအလျောက် သိမ်းဆည်းပါသည်။</span>
                <span className={scriptSaveStatus === "local" ? "text-amber-300" : scriptSaveStatus === "saving" ? "text-primary" : scriptSaveStatus === "saved" ? "text-emerald-300" : ""}>
                  {scriptSaveStatus === "local" ? "စက်ထဲတွင် သိမ်းထားသည်" : scriptSaveStatus === "saving" ? "သိမ်းဆည်းနေသည်…" : scriptSaveStatus === "saved" ? "သိမ်းပြီးပါပြီ" : ""}
                </span>
              </div>
              <Tabs defaultValue="myanmar" className="w-full">
                <TabsList className="mb-4 flex w-full justify-start overflow-x-auto bg-background/50 border border-white/5 rounded-lg p-1">
                   <TabsTrigger value="transcript" className="min-w-[132px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary data-[state=active]:shadow-none rounded-md">မူရင်းမှတ်တမ်း</TabsTrigger>
                   <TabsTrigger value="myanmar" className="min-w-[132px] data-[state=active]:bg-accent/20 data-[state=active]:text-accent data-[state=active]:shadow-none rounded-md">မြန်မာဇာတ်လမ်းအနှစ်ချုပ်</TabsTrigger>
                   <TabsTrigger value="english" className="min-w-[132px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary data-[state=active]:shadow-none rounded-md">အင်္ဂလိပ်ဇာတ်လမ်းအနှစ်ချုပ်</TabsTrigger>
                </TabsList>
                
                <TabsContent value="transcript" className="m-0 focus-visible:outline-none">
                   {dialogue.length > 0 && (
                     <div className="mb-4 space-y-3 rounded-xl border border-primary/20 bg-primary/5 p-3">
                       <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                         <div>
                           <p className="text-sm font-medium text-primary">Chinese Transcript Review</p>
                           <p className="text-xs text-muted-foreground">
                             စာကြောင်း၊ အချိန်နဲ့ မသေချာတဲ့နေရာကို ပြင်ပြီး Save လုပ်ပါ။
                           </p>
                         </div>
                         <div className="flex flex-wrap items-center gap-2 text-xs">
                           <span className="text-muted-foreground">
                             {dialogue.length} lines{Number(project.sourceDuration || 0) > 0
                               ? ` · source ${Number(project.sourceDuration).toFixed(2)}s`
                               : ""}
                           </span>
                           <span className={`rounded-full border px-2 py-1 ${
                             dialogueValidation.ready
                               ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300"
                               : "border-amber-400/30 bg-amber-400/10 text-amber-300"
                           }`}>
                             {dialogueValidation.ready ? "✓ Timing valid" : "⚠ Needs review"}
                           </span>
                         </div>
                       </div>
                       {(dialogueValidation.errors.length > 0 || dialogueValidation.warnings.length > 0) && (
                         <div className="rounded-lg border border-amber-400/20 bg-amber-400/5 px-3 py-2 text-xs text-amber-200">
                           {dialogueValidation.errors.slice(0, 2).map((message) => (
                             <p key={message}>⚠ {message}</p>
                           ))}
                           {dialogueValidation.warnings.slice(0, 2).map((message) => (
                             <p key={message}>⚠ {message}</p>
                           ))}
                         </div>
                       )}
                       <div className="max-h-[620px] space-y-3 overflow-y-auto pr-1">
                         {dialogue.map((line, index) => (
                           <div
                             key={line.id}
                             className={`space-y-2 rounded-lg border p-3 ${
                               line.reviewRequired
                                 ? "border-amber-400/40 bg-amber-400/5"
                                 : "border-white/10 bg-background/40"
                             }`}
                           >
                             <div className="flex flex-wrap items-center justify-between gap-2">
                               <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                 <span className="font-mono text-primary">{String(index + 1).padStart(2, "0")}</span>
                                 <span>{line.id}</span>
                                 <span>Speaker {line.speaker}</span>
                               </div>
                               <div className="flex items-center gap-2">
                                 {line.reviewRequired && (
                                   <span className="inline-flex items-center gap-1 text-xs text-amber-300">
                                     <AlertCircle className="h-3.5 w-3.5" /> Needs Review
                                   </span>
                                 )}
                                 {!line.myanmarText && (
                                   <span className="text-xs text-sky-300">
                                     Translation pending
                                   </span>
                                 )}
                                 {line.timingWarning.length > 0 && (
                                   <span className="text-xs text-amber-300">
                                     Timing: {line.timingWarning.join(", ")}
                                   </span>
                                 )}
                                 <Button
                                   type="button"
                                   size="sm"
                                   variant="outline"
                                   className="h-7 border-primary/30 px-2 text-xs"
                                   onClick={() => previewDialogueLine(line)}
                                   disabled={isBusy || !isPreviewReady}
                                 >
                                   <Play className="mr-1 h-3 w-3" /> Play
                                 </Button>
                               </div>
                             </div>
                             <Textarea
                               value={line.sourceText}
                               onChange={(event) => updateDialogueLine(line.id, { sourceText: event.target.value })}
                               disabled={isBusy}
                               className="min-h-[58px] resize-y bg-background/50 text-sm"
                               aria-label={`Chinese transcript line ${index + 1}`}
                             />
                             <div className="grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
                               <label className="space-y-1">
                                 <span className="text-[11px] text-muted-foreground">Start (seconds)</span>
                                 <Input
                                   type="number"
                                   min={0}
                                   max={Number(project.sourceDuration || 86400)}
                                   step="0.001"
                                   value={line.start.toFixed(3)}
                                   onChange={(event) => updateDialogueLine(line.id, {
                                     start: Math.max(0, Number(event.target.value) || 0),
                                   })}
                                   disabled={isBusy}
                                   className="h-8 bg-background/50 font-mono text-xs"
                                 />
                               </label>
                               <label className="space-y-1">
                                 <span className="text-[11px] text-muted-foreground">End (seconds)</span>
                                 <Input
                                   type="number"
                                   min={0}
                                   max={Number(project.sourceDuration || 86400)}
                                   step="0.001"
                                   value={line.end.toFixed(3)}
                                   onChange={(event) => updateDialogueLine(line.id, {
                                     end: Math.max(0, Number(event.target.value) || 0),
                                   })}
                                   disabled={isBusy}
                                   className="h-8 bg-background/50 font-mono text-xs"
                                 />
                               </label>
                               <div className="flex items-end text-[11px] text-muted-foreground">
                                 Duration {(line.end - line.start).toFixed(3)}s
                               </div>
                             </div>
                           </div>
                         ))}
                       </div>
                     </div>
                   )}
                  <Textarea 
                    className="min-h-[400px] font-mono text-sm leading-relaxed bg-background/50 border-white/10 focus-visible:ring-primary/50 resize-none shadow-inner" 
                     placeholder="မူရင်းတရုတ်အသံမှတ်တမ်းကို ဤနေရာတွင် ပြသပါမည်..."
                    value={transcript}
                    onChange={(e) => {
                       updateTranscript(e.target.value)
                    }}
                    disabled={isBusy}
                     aria-label="မူရင်းမှတ်တမ်း"
                  />
                   <p className="text-xs text-muted-foreground mt-3 text-right">Gemini ဇာတ်လမ်းအနှစ်ချုပ် မဖန်တီးမီ မူရင်းတရုတ်အသံမှတ်တမ်းကို စစ်ဆေးနိုင်ပါသည်။</p>
                </TabsContent>
                
                <TabsContent value="myanmar" className="m-0 focus-visible:outline-none">
                  <Textarea 
                    className="min-h-[400px] font-mono text-sm leading-relaxed bg-background/50 border-white/10 focus-visible:ring-accent/50 resize-none shadow-inner" 
                     placeholder="သဘာဝကျသော တတိယပုဂ္ဂိုလ် မြန်မာဇာတ်လမ်းအနှစ်ချုပ်ကို ဤနေရာတွင် ပြသပါမည်..."
                    value={myanmarScript}
                    onChange={(e) => {
                      setMyanmarScript(e.target.value)
                      markDirty("myanmarScript")
                    }}
                    disabled={isBusy}
                     aria-label="မြန်မာဇာတ်လမ်းအနှစ်ချုပ်"
                  />
                    <p className="text-xs text-muted-foreground mt-3 text-right">ဤစာသားကို ဗီဒီယိုတစ်လျှောက် ဆက်တိုက် မြန်မာဇာတ်လမ်းပြောအသံနှင့် synchronized standalone SRT အတွက် အသုံးပြုပါမည်။</p>
                </TabsContent>
                
                <TabsContent value="english" className="m-0 focus-visible:outline-none">
                  <Textarea 
                    className="min-h-[400px] font-mono text-sm leading-relaxed bg-background/50 border-white/10 focus-visible:ring-primary/50 resize-none shadow-inner" 
                     placeholder="သဘာဝကျသော တတိယပုဂ္ဂိုလ် အင်္ဂလိပ်ဇာတ်လမ်းအနှစ်ချုပ်ကို ဤနေရာတွင် ပြသပါမည်..."
                    value={englishScript}
                    onChange={(e) => {
                      setEnglishScript(e.target.value)
                      markDirty("englishScript")
                    }}
                    disabled={isBusy}
                     aria-label="အင်္ဂလိပ်ဇာတ်လမ်းအနှစ်ချုပ်"
                  />
                    <p className="text-xs text-muted-foreground mt-3 text-right">ဤစာသားကို ဗီဒီယိုတစ်လျှောက် ဆက်တိုက် အင်္ဂလိပ်ဇာတ်လမ်းပြောအသံနှင့် synchronized standalone SRT အတွက် အသုံးပြုပါမည်။</p>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
          </section>
        </div>

        <div
          className={previewStep === 3
            ? "space-y-6 md:col-span-3 md:mx-auto md:w-full md:max-w-5xl"
            : "hidden"}
          aria-hidden={previewStep !== 3}
        >
          <Card className="glass-card border-card-border md:sticky md:top-6">
            <CardHeader className="pb-2 border-b border-white/5">
              <CardTitle className="text-lg text-foreground flex items-center justify-between">
                လုပ်ငန်းစဉ်အခြေအနေ
                {isBusy && <span className="flex h-2 w-2 rounded-full bg-primary animate-ping"></span>}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-5">
              
              <ProgressPipeline project={project} />

              {project.error && (
                <div className="p-3 bg-destructive/10 text-destructive text-sm rounded-lg flex items-start gap-2 border border-destructive/20 shadow-inner">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <div className="min-w-0 flex-1 space-y-3">
                    <p className="leading-tight break-words">{localizeError(project.error)}</p>
                    {project.status === "failed" && (
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="h-8 border-destructive/30 bg-destructive/10 text-destructive hover:bg-destructive/20"
                        onClick={() => handleRun(retryAction)}
                        disabled={isStarting}
                      >
                        <RotateCcw className="mr-2 h-3.5 w-3.5" />
                        အဆင့်ကို ပြန်စမ်းမည်
                      </Button>
                    )}
                  </div>
                </div>
              )}
              
              <details open className="group rounded-xl border border-white/5 bg-background/20">
                <summary className="flex min-h-12 cursor-pointer list-none items-center justify-between gap-3 px-4 py-3 text-sm font-semibold text-foreground [&::-webkit-details-marker]:hidden">
                  <span>Project settings</span>
                  <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform group-open:rotate-180" />
                </summary>
              <div className="space-y-4 border-t border-white/5 bg-background/40 p-4 shadow-inner">
                <div className="space-y-2">
                  <Label htmlFor="video-filter" className="text-muted-foreground">ဗီဒီယိုတည်းဖြတ်မှု</Label>
                  <Select value={globalEdit} onValueChange={(value) => {
                    setGlobalEdit(value)
                    markDirty("globalEdit")
                  }} disabled={isBusy || isStarting}>
                    <SelectTrigger id="video-filter" aria-label="ဗီဒီယိုတည်းဖြတ်မှု" className="bg-card border-white/10 focus:ring-primary/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-white/10">
                      <SelectItem value="none">မရှိ</SelectItem>
                      <SelectItem value="crop">၉:၁၆ ဖြတ်တောက်ခြင်း</SelectItem>
                      <SelectItem value="zoom">ချဲ့ခြင်း</SelectItem>
                      <SelectItem value="blur">ဝါးခြင်း</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3 pt-4 border-t border-white/5">
                  <div className="flex items-center justify-between gap-2">
                    <Label className="text-muted-foreground">Channel Logo PNG</Label>
                    {project.hasLogo && <Badge variant="outline" className="text-[10px] text-accent border-accent/30 bg-accent/10">အသုံးပြုနေသည်</Badge>}
                  </div>
                  <input
                    ref={logoInputRef}
                    type="file"
                    accept="image/png,.png"
                    className="hidden"
                    onChange={handleLogoUpload}
                    disabled={isBusy || isStarting}
                  />
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="secondary"
                      className="flex-1 bg-card border border-white/10 hover:bg-white/10 text-xs"
                      onClick={(event) => {
                        event.preventDefault()
                        logoInputRef.current?.click()
                      }}
                      disabled={isBusy || isStarting}
                    >
                      {isUploadingLogo ? <Loader2 className="mr-2 h-3 w-3 animate-spin text-primary" /> : <ImagePlus className="mr-2 h-3 w-3 text-primary" />}
                      {project.hasLogo ? "Logo ပြောင်းရန်" : "PNG Logo တင်ရန်"}
                    </Button>
                    {project.hasLogo && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={handleRemoveLogo}
                        disabled={isBusy || isStarting}
                        aria-label="Channel Logo ဖျက်ရန်"
                        className="hover:bg-destructive/20 hover:text-destructive text-muted-foreground shrink-0"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  <Select
                    value={logoPosition}
                    onValueChange={(value) => {
                      setLogoPosition(value)
                      markDirty("logoPosition")
                    }}
                    disabled={isBusy || isStarting || !project.hasLogo}
                  >
                    <SelectTrigger aria-label="Channel Logo နေရာ" className="bg-card border-white/10 focus:ring-primary/50 text-xs h-9">
                      <SelectValue placeholder="Logo နေရာရွေးရန်" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-white/10 text-xs">
                      <SelectItem value="top-right">ညာဘက်အပေါ်</SelectItem>
                      <SelectItem value="top-left">ဘယ်ဘက်အပေါ်</SelectItem>
                      <SelectItem value="bottom-right">ညာဘက်အောက်</SelectItem>
                    </SelectContent>
                  </Select>
                   <p className="text-[11px] leading-relaxed text-muted-foreground">
                      Logo သို့မဟုတ် watermark ကို preview ပေါ်တွင် ဆွဲ၍ နေရာရွှေ့ပါ။ Letterbox အနက်ဘက်ကို မတွက်ဘဲ video canvas အတွင်းရှိ relative percentage ကို export တစ်လျှောက် ထိန်းသိမ်းပေးမည်။
                   </p>
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="logo-scale" className="text-xs text-muted-foreground">Logo အရွယ်</Label>
                        <span className="text-xs font-mono text-muted-foreground">{Math.round(logoScale * 100)}%</span>
                      </div>
                      <input
                        id="logo-scale"
                        type="range"
                        min={0.05}
                        max={0.5}
                        step={0.01}
                        value={logoScale}
                        onChange={(event) => {
                          setLogoScale(Number(event.target.value))
                          markDirty("logoScale")
                        }}
                        disabled={isBusy || isStarting || !project.hasLogo}
                        className="w-full accent-accent"
                        aria-label="Logo scale 5 မှ 50 ရာခိုင်နှုန်း"
                      />
                    </div>
                   <div className="space-y-2">
                     <Label htmlFor="watermark-text" className="text-muted-foreground">Hook Title Banner (ရွေးချယ်နိုင်သည်)</Label>
                     <Input
                       id="watermark-text"
                       value={watermarkText}
                       maxLength={80}
                       onChange={(event) => {
                         setWatermarkText(event.target.value)
                         markDirty("watermarkText")
                       }}
                       disabled={isBusy || isStarting}
                       placeholder="ဥပမာ - သူ့ရဲ့လျှို့ဝှက်ချက်က ဘာလဲ?"
                       className="bg-card border-white/10"
                     />
                   </div>
                 </div>

                 <div className="space-y-2 border-t border-white/5 pt-4">
                   <Label htmlFor="subtitle-mask-style" className="text-muted-foreground">မူရင်းတရုတ်စာတန်း ဖုံးသည့်ပုံစံ</Label>
                   <Select
                     value={maskStyle}
                     onValueChange={(value) => {
                       setMaskStyle(value as MaskStyle)
                       markDirty("maskStyle")
                     }}
                     disabled={isBusy || isStarting}
                   >
                     <SelectTrigger id="subtitle-mask-style" className="bg-card border-white/10 focus:ring-primary/50">
                       <SelectValue />
                     </SelectTrigger>
                     <SelectContent className="bg-card border-white/10">
                       <SelectItem value="dark-translucent">Dark Translucent</SelectItem>
                       <SelectItem value="light-translucent">Light Translucent</SelectItem>
                       <SelectItem value="clean-boxblur">Clean BoxBlur</SelectItem>
                     </SelectContent>
                   </Select>
                </div>

                 <div className="space-y-3 border-t border-white/5 pt-4">
                   <div>
                     <Label className="text-muted-foreground">မြန်မာစာတန်းပုံစံ</Label>
                     <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
                       Preview နှင့် MP4 နှစ်ခုလုံးသည် export canvas ပေါ်ရှိ တူညီသော font size, MarginV နှင့် alignment ကို အသုံးပြုမည်။
                     </p>
                   </div>
                   <div className="grid gap-3 sm:grid-cols-2">
                     <div className="space-y-1.5">
                       <div className="flex items-center justify-between">
                         <Label htmlFor="subtitle-font-size" className="text-xs">Font size</Label>
                         <span className="font-mono text-xs text-muted-foreground">{subtitleFontSize}px</span>
                       </div>
                       <input
                         id="subtitle-font-size"
                         type="range"
                         min={MIN_SUBTITLE_FONT_SIZE}
                         max={MAX_SUBTITLE_FONT_SIZE}
                         step={1}
                         value={subtitleFontSize}
                         onChange={(event) => {
                           setSubtitleFontSize(Number(event.target.value))
                           markDirty("subtitleFontSize")
                         }}
                         disabled={isBusy || isStarting}
                         className="w-full accent-accent"
                         aria-label="မြန်မာစာတန်း font size"
                       />
                     </div>
                     <div className="space-y-1.5">
                        <Label htmlFor="subtitle-vertical-position" className="text-xs">Vertical position</Label>
                        <Select
                          value={subtitleVerticalPosition}
                          onValueChange={(value) => {
                            const position = value as SubtitleVerticalPosition
                            const current = subtitleBox || DEFAULT_PREVIEW_SUBTITLE_BOX
                            setSubtitleBox({
                              ...current,
                              yPercent: SUBTITLE_VERTICAL_POSITIONS[position],
                            })
                            markDirty("subtitleBox")
                          }}
                         disabled={isBusy || isStarting}
                        >
                          <SelectTrigger id="subtitle-vertical-position" className="h-9 bg-card border-white/10">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-card border-white/10">
                            <SelectItem value="top">အပေါ်</SelectItem>
                            <SelectItem value="center">အလယ်</SelectItem>
                            <SelectItem value="bottom">အောက်</SelectItem>
                          </SelectContent>
                        </Select>
                     </div>
                   </div>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div className="space-y-1.5">
                       <Label htmlFor="subtitle-alignment" className="text-xs">Alignment</Label>
                       <Select
                         value={subtitleAlignment}
                         onValueChange={(value) => {
                           setSubtitleAlignment(value as SubtitleAlignment)
                           markDirty("subtitleAlignment")
                         }}
                         disabled={isBusy || isStarting}
                       >
                         <SelectTrigger id="subtitle-alignment" className="h-9 bg-card border-white/10">
                           <SelectValue />
                         </SelectTrigger>
                         <SelectContent className="bg-card border-white/10">
                           <SelectItem value="left">ဘယ်ဘက်</SelectItem>
                           <SelectItem value="center">အလယ်</SelectItem>
                           <SelectItem value="right">ညာဘက်</SelectItem>
                         </SelectContent>
                       </Select>
                    </div>
                     <div className="space-y-1.5">
                       <Label htmlFor="subtitle-preset" className="text-xs">Preset</Label>
                       <Select
                         value={subtitleStyle.preset}
                         onValueChange={(value) => {
                           const preset = value as SubtitlePreset
                           setSubtitleStyle(
                             preset === "custom"
                               ? { ...subtitleStyle, preset }
                               : { ...SUBTITLE_PRESET_STYLES[preset], outlineWidth: subtitleStyle.outlineWidth },
                           )
                           markDirty("subtitleStyle")
                         }}
                         disabled={isBusy || isStarting}
                       >
                         <SelectTrigger id="subtitle-preset" className="h-9 bg-card border-white/10">
                           <SelectValue />
                         </SelectTrigger>
                         <SelectContent className="bg-card border-white/10">
                           <SelectItem value="clean-white">Clean white</SelectItem>
                           <SelectItem value="classic-yellow">Classic yellow</SelectItem>
                           <SelectItem value="neon-green">Neon green</SelectItem>
                           <SelectItem value="cyan">Cyan</SelectItem>
                           <SelectItem value="custom">Custom</SelectItem>
                         </SelectContent>
                       </Select>
                     </div>
                   </div>
                   <div className="grid gap-3 sm:grid-cols-2">
                     <div className="space-y-1.5">
                       <div className="flex items-center justify-between">
                       <Label htmlFor="subtitle-outline-width" className="text-xs">Outline</Label>
                       <span className="font-mono text-xs text-muted-foreground">{subtitleStyle.outlineWidth.toFixed(1)}px</span>
                     </div>
                     <input
                       id="subtitle-outline-width"
                       type="range"
                       min={0}
                       max={8}
                       step={0.5}
                       value={subtitleStyle.outlineWidth}
                       onChange={(event) => {
                         setSubtitleStyle((current) => ({ ...current, preset: "custom", outlineWidth: Number(event.target.value) }))
                         markDirty("subtitleStyle")
                       }}
                       disabled={isBusy || isStarting}
                       className="w-full accent-accent"
                       aria-label="မြန်မာစာတန်း outline width"
                     />
                      </div>
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <Label htmlFor="subtitle-shadow-opacity" className="text-xs">Background shadow</Label>
                          <span className="font-mono text-xs text-muted-foreground">{Math.round(subtitleStyle.shadowOpacity)}%</span>
                        </div>
                        <input
                          id="subtitle-shadow-opacity"
                          type="range"
                          min={0}
                          max={100}
                          step={1}
                          value={subtitleStyle.shadowOpacity}
                          onChange={(event) => {
                            setSubtitleStyle((current) => ({
                              ...current,
                              preset: "custom",
                              shadowOpacity: Number(event.target.value),
                            }))
                            markDirty("subtitleStyle")
                          }}
                          disabled={isBusy || isStarting}
                          className="w-full accent-accent"
                          aria-label="မြန်မာစာတန်း background shadow opacity"
                        />
                     </div>
                      </div>
                   {subtitleStyle.preset === "custom" && (
                     <div className="grid gap-3 sm:grid-cols-2">
                       {([
                         ["primaryColor", "စာတန်းအရောင်"],
                         ["outlineColor", "Outline အရောင်"],
                       ] as const).map(([key, label]) => (
                         <label key={key} className="flex items-center justify-between gap-3 rounded-md border border-white/10 bg-card px-3 py-2 text-xs">
                           <span>{label}</span>
                           <input
                             type="color"
                             value={subtitleStyle[key]}
                             onChange={(event) => {
                               setSubtitleStyle((current) => ({ ...current, preset: "custom", [key]: event.target.value.toUpperCase() }))
                               markDirty("subtitleStyle")
                             }}
                             disabled={isBusy || isStarting}
                             aria-label={label}
                           />
                         </label>
                       ))}
                     </div>
                   )}
                 </div>

              </div>
              </details>
                
            </CardContent>
          </Card>
          
           {readyToPost && (
             <ReadyToPostSuite
               projectTitle={project.title}
              projectNumber={project.projectNumber || 0}
               exports={project.exports}
                hookTitle={project.viralHookTitle || ""}
                caption={project.viralCaption || ""}
               hashtags={project.viralHashtags || []}
               metadataLoading={generatePostMetadata.isPending}
               onGenerateMetadata={() => generatePostMetadata.mutate({ id: project.id })}
             />
           )}

           <Card className="glass-card border-0">
            <CardHeader className="pb-3 border-b border-white/5">
              <CardTitle className="text-base text-foreground flex items-center justify-between">
                ထုတ်ယူထားသော ဗီဒီယိုများ
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
               <div className="grid gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    className="w-full justify-start bg-card border border-white/5 hover:bg-white/10"
                    onClick={() => handleRun('export')}
                    disabled={isBusy || isStarting || !myanmarScript.trim()}
                  >
                    <Download className="w-3.5 h-3.5 mr-2 text-accent" /> မြန်မာဗီဒီယို ပြန်ထုတ်ရန်
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="w-full justify-start bg-card border border-white/5 hover:bg-white/10"
                    onClick={() => handleRun('export_english')}
                    disabled={isBusy || isStarting || !englishScript.trim()}
                  >
                    <Languages className="w-3.5 h-3.5 mr-2 text-primary" />
                    {project.exports?.some((item: any) => item.language === "english")
                      ? "အင်္ဂလိပ်ဗီဒီယို ပြန်ထုတ်ရန်"
                      : "အင်္ဂလိပ်ဗီဒီယို ထုတ်ယူမည်"}
                  </Button>
                </div>

              {!isBusy && project.status === "completed" && !project.exportsStale && project.exports && project.exports.length > 0 ? (
                <div className="space-y-4 pt-2">
                  {project.exports.map((exp, i) => (
                    <ExportMediaPanel
                      key={i}
                      exportItem={exp}
                      projectTitle={project.title}
                      projectNumber={project.projectNumber || 0}
                      compact
                      showVideoPreview={false}
                       onDelete={() => deleteProjectExport.mutate({
                         id: project.id,
                         language: exp.language as "myanmar" | "english",
                       })}
                       isDeleting={
                         deleteProjectExport.isPending
                         && deleteProjectExport.variables?.language === exp.language
                       }
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-sm text-muted-foreground bg-background/30 rounded-xl border border-white/5">
                  <Film className="w-8 h-8 mx-auto mb-2 opacity-20" />
                  {project.exportsStale
                    ? "စာသားပြင်ပြီးနောက် ဗီဒီယိုကို ပြန်ထုတ်ရန်လိုပါသည်။"
                    : "ထုတ်ယူထားသောဗီဒီယို မရှိသေးပါ။"}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
