import { useGetDashboard, useHealthCheck, getGetDashboardQueryKey, getHealthCheckQueryKey } from "@workspace/api-client-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Link } from "wouter"
import { Film, Activity, Server, Plus, Clock, CheckCircle2, PlayCircle, AlertCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { cn, formatDate } from "@/lib/utils"
import { localizeMessage, localizeStage, localizeStatus } from "@/lib/i18n"

export default function Dashboard() {
  const { data: dashboard, isLoading: isLoadingDashboard, error } = useGetDashboard({
    query: { refetchInterval: 3000, queryKey: getGetDashboardQueryKey() }
  })
  
  const { data: health, isLoading: isLoadingHealth } = useHealthCheck({
    query: { refetchInterval: 10000, queryKey: getHealthCheckQueryKey() }
  })

  if (error) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">အနှစ်ချုပ်</h1>
        <Card className="glass-card border-destructive bg-destructive/10">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-destructive">
              <AlertCircle className="w-5 h-5" />
              <p>အနှစ်ချုပ်ကို ဖွင့်၍ မရပါ။ API ဆာဗာ အလုပ်လုပ်နေကြောင်း စစ်ဆေးပါ။</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-5 animate-studio-in pb-20 sm:space-y-7">
      <div className="glass-card group overflow-hidden border-primary/20 p-5 sm:p-8">
        <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-primary/20 blur-[80px] transition-all duration-700 group-hover:bg-primary/30 group-hover:scale-110" />
        <div className="pointer-events-none absolute -left-20 -bottom-20 h-64 w-64 rounded-full bg-accent/20 blur-[80px] transition-all duration-700 group-hover:bg-accent/30 group-hover:scale-110" />
        
        <div className="relative z-10 flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
          <div>
            <p className="studio-kicker mb-3">အနှစ်ချုပ် / ထိန်းချုပ်ခန်း</p>
            <h1 className="mb-3 text-3xl font-bold leading-tight tracking-tight text-foreground sm:text-5xl">
              နောက်ထပ်ဗီဒီယိုကို<br/><span className="gradient-text">ဒီကနေ စတင်လိုက်ပါ။</span>
            </h1>
            <p className="max-w-lg text-sm text-muted-foreground leading-relaxed">
              ဇာတ်လမ်းအဓိပ္ပာယ် မပျောက်စေဘဲ ဒရာမာဗီဒီယိုများကို ရှင်းလင်းသော မြန်မာနှင့် အင်္ဂလိပ်အနှစ်ချုပ်များအဖြစ် ပြောင်းလဲပါ။
            </p>
          </div>
          <div className="flex w-full flex-col gap-3 sm:w-auto">
            <Link href="/projects" className="inline-flex h-12 items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-primary px-6 py-2 text-sm font-semibold text-primary-foreground shadow-[0_0_20px_rgba(var(--primary),0.4)] transition-all hover:scale-105 hover:shadow-[0_0_30px_rgba(var(--primary),0.6)]">
              <Plus className="w-5 h-5" /> ပရောဂျက်အသစ်
            </Link>
            <div className="flex items-center gap-2 rounded-xl border border-white/5 bg-black/40 backdrop-blur-md px-4 py-2.5 text-xs font-medium w-full justify-center">
              <Server className="w-4 h-4 text-muted-foreground" />
              <span className="text-muted-foreground">API အခြေအနေ:</span>
              {isLoadingHealth ? (
                <span className="w-2 h-2 rounded-full bg-muted animate-pulse" />
              ) : health?.status === 'ok' ? (
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)] animate-pulse" />
                  ချိတ်ဆက်ထားသည်
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-destructive">
                  <span className="w-2 h-2 rounded-full bg-destructive shadow-[0_0_10px_rgba(248,113,113,0.8)]" />
                  အော့ဖ်လိုင်း
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {isLoadingDashboard ? (
        <DashboardSkeleton />
      ) : dashboard ? (
        <>
           <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard 
              title="ပရောဂျက်စုစုပေါင်း" 
              value={dashboard.totalProjects} 
              icon={Film}
              description="အဆင့်အားလုံးမှ"
            />
            <StatCard 
              title="လုပ်ဆောင်နေသောအလုပ်များ" 
              value={dashboard.activeJobs} 
              icon={PlayCircle}
              description="လက်ရှိလုပ်ဆောင်နေသည်"
              className={dashboard.activeJobs > 0 ? "border-primary/30 shadow-[0_0_15px_rgba(var(--primary),0.1)] before:bg-primary/5" : ""}
              valueColor={dashboard.activeJobs > 0 ? "text-primary" : undefined}
            />
            <StatCard 
              title="အချိန်ဇယားသတ်မှတ်ထားသောအလုပ်များ" 
              value={dashboard.scheduledJobs} 
              icon={Clock}
              description="လုပ်ဆောင်ရန် စောင့်နေသည်"
            />
            <StatCard 
              title="ပြီးစီးသောဗီဒီယိုများ" 
              value={dashboard.completedExports} 
              icon={CheckCircle2}
              description="ဒေါင်းလုဒ်လုပ်ရန် အဆင်သင့်"
              className={dashboard.completedExports > 0 ? "border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.1)] before:bg-emerald-500/5" : ""}
              valueColor={dashboard.completedExports > 0 ? "text-emerald-400" : undefined}
            />
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="glass-card border-0 col-span-1 animate-studio-in stagger-2">
              <CardHeader className="border-b border-white/5 pb-4">
                <CardTitle className="flex items-center gap-2 text-lg text-foreground">
                  <Activity className="w-5 h-5 text-accent" /> လတ်တလောလုပ်ဆောင်ချက်များ
                </CardTitle>
                <CardDescription>လုပ်ငန်းစဉ်ထဲမှ နောက်ဆုံးဖြစ်ရပ်များ။</CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                {dashboard.recentActivity.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-10 text-center bg-background/30 rounded-xl border border-white/5">
                    <Activity className="w-12 h-12 text-muted mb-3 opacity-20" />
                    <p className="text-muted-foreground text-sm">လတ်တလောလုပ်ဆောင်ချက် မရှိသေးပါ။</p>
                  </div>
                ) : (
                  <div className="space-y-5">
                    {dashboard.recentActivity.map((activity, index) => (
                      <div key={activity.id} className="flex items-start gap-4 relative">
                        {index !== dashboard.recentActivity.length - 1 && (
                          <div className="absolute left-[3px] top-3 bottom-[-20px] w-px bg-white/10" />
                        )}
                        <div className="w-2 h-2 mt-1.5 rounded-full bg-accent flex-shrink-0 shadow-[0_0_8px_rgba(var(--accent),0.8)] relative z-10" />
                        <div className="space-y-1 bg-background/40 w-full p-3 rounded-lg border border-white/5 hover:bg-background/60 transition-colors">
                          <p className="text-sm font-medium leading-none text-foreground">{localizeMessage(activity.title)}</p>
                          <p className="text-xs text-muted-foreground leading-relaxed">{localizeMessage(activity.message)}</p>
                          <p className="text-[10px] text-muted-foreground/50 font-mono mt-2">{formatDate(activity.createdAt)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="glass-card border-0 col-span-1 animate-studio-in stagger-3">
              <CardHeader className="border-b border-white/5 pb-4">
                <CardTitle className="text-lg flex items-center justify-between text-foreground">
                  လက်ရှိပရောဂျက်များ
                  <Link href="/projects" className="text-xs font-medium text-muted-foreground hover:text-primary transition-colors bg-background/50 px-2.5 py-1.5 rounded-md border border-white/5">
                    အားလုံးကြည့်ရန်
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="space-y-3">
                  {dashboard.projects.filter(p => p.status !== 'failed').slice(0, 4).map(project => (
                    <Link key={project.id} href={`/projects/${project.id}`} className="flex items-center justify-between p-3.5 rounded-xl bg-background/40 border border-white/5 hover:border-primary/40 hover:bg-background/80 transition-all group/item hover:shadow-[0_4px_20px_rgba(var(--primary),0.1)]">
                      <div className="space-y-1.5 truncate pr-4">
                        <p className="font-semibold text-sm truncate text-foreground group-hover/item:text-primary transition-colors">{project.title}</p>
                        <div className="flex items-center gap-2.5">
                          <Badge variant={project.status === 'processing' ? 'default' : 'secondary'} className={`text-[10px] px-1.5 py-0 font-mono ${project.status === 'processing' ? 'bg-primary/20 text-primary hover:bg-primary/30 border-0' : 'bg-black/40 text-muted-foreground border-white/10'}`}>
                            {localizeStatus(project.status, project.progress)}
                          </Badge>
                          <span className="text-[11px] text-muted-foreground capitalize truncate max-w-[100px]">{localizeStage(project.stage)}</span>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                         <span className="text-xs font-mono font-medium bg-black/50 border border-white/5 px-2.5 py-1 rounded-md text-muted-foreground group-hover/item:text-foreground transition-colors">{Math.round(project.progress)}%</span>
                      </div>
                    </Link>
                  ))}
                  {dashboard.projects.filter(p => p.status !== 'failed').length === 0 && (
                    <div className="text-center py-10 bg-background/30 rounded-xl border border-white/5">
                       <Film className="w-10 h-10 mx-auto mb-3 opacity-20 text-muted" />
                       <p className="text-muted-foreground text-sm">လက်ရှိပရောဂျက် မရှိသေးပါ။</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      ) : null}
    </div>
  )
}

function StatCard({ title, value, icon: Icon, description, className, valueColor }: { title: string, value: number, icon: any, description: string, className?: string, valueColor?: string }) {
  return (
    <Card className={cn("glass-card border-0 overflow-hidden relative group", className)}>
      <div className="absolute top-0 right-0 p-4 opacity-10 transition-transform duration-500 group-hover:scale-110 group-hover:opacity-20">
        <Icon className="h-20 w-20" />
      </div>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent className="relative z-10">
        <div className={cn("text-4xl font-bold font-mono", valueColor || "text-foreground")}>{value}</div>
        <p className="text-[11px] text-muted-foreground mt-2 uppercase tracking-wider font-semibold">
          {description}
        </p>
      </CardContent>
    </Card>
  )
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map(i => (
          <Card key={i} className="glass-card border-0 p-6 animate-pulse">
            <div className="h-4 bg-white/5 rounded w-24 mb-4" />
            <div className="h-10 bg-white/5 rounded w-16 mb-3" />
            <div className="h-3 bg-white/5 rounded w-32" />
          </Card>
        ))}
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="glass-card border-0 h-96 animate-pulse" />
        <Card className="glass-card border-0 h-96 animate-pulse" />
      </div>
    </div>
  )
}
