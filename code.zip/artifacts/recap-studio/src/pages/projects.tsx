import { useListProjects, useCreateProject, useDeleteProject, getListProjectsQueryKey } from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { useState, useEffect, useRef } from "react"
import { Link, useLocation } from "wouter"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Film, Search, Plus, Loader2, AlertCircle, Clock, CheckCircle2,
  Download, Pencil, Trash2, ArrowLeft, Video, RefreshCw,
} from "lucide-react"
import { formatDate } from "@/lib/utils"
import { localizeError, localizeStage, localizeStatus } from "@/lib/i18n"
import { useToast } from "@/components/ui/use-toast"
import { DownloadFileButton } from "@/components/download-file-button"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export default function Projects() {
  const [search, setSearch] = useState("")
  const {
    data: projects = [],
    isLoading,
    isFetching,
    error,
    refetch,
  } = useListProjects({
    query: {
      refetchInterval: 3000,
      retry: 4,
      retryDelay: (attemptIndex) => Math.min(1000 * (2 ** attemptIndex), 8000),
      queryKey: getListProjectsQueryKey(),
    }
  })

  const filteredProjects = projects.filter(p =>
    String(p.title || "").toLowerCase().includes(search.toLowerCase())
  )
  const hasStaleProjects = projects.length > 0

  return (
    <div className="space-y-5 animate-studio-in sm:space-y-6">
      <div className="flex flex-col items-start justify-between gap-4 rounded-2xl border border-card-border bg-card/70 p-4 shadow-lg shadow-black/10 sm:flex-row sm:items-end sm:p-5">
        <div>
          <p className="studio-kicker mb-2 text-primary">စာကြည့်တိုက် / ဗီဒီယိုများ</p>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">ပရောဂျက်မှတ်တမ်း</h1>
          <p className="mt-1 text-sm text-muted-foreground">မူရင်းဗီဒီယို၊ စာသားနှင့် ထုတ်ယူမှုအားလုံးကို အလုပ်ခွင်တစ်ခုတည်းတွင် စုစည်းထားပါသည်။</p>
        </div>
        <CreateProjectDialog />
      </div>

      <div className="relative max-w-xl">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="ပရောဂျက်များကို ရှာဖွေရန်..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="h-12 rounded-xl border-card-border bg-card/80 pl-10 focus-visible:ring-primary/50"
        />
      </div>

      {error && hasStaleProjects ? (
        <Card className="glass-card border-0 border-destructive/40 bg-destructive/10">
          <CardContent className="flex flex-wrap items-center justify-between gap-3 pt-6 text-sm text-destructive">
            <span className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 shrink-0" />
              အသစ်ပြန်ဖတ်၍ မရသေးပါ။ ယခင် project list ကို ဆက်လက်ပြသထားပါသည်။
            </span>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => void refetch()}
              disabled={isFetching}
            >
              <RefreshCw className={`mr-2 h-4 w-4 ${isFetching ? "animate-spin" : ""}`} />
              ထပ်မံကြိုးစားရန်
            </Button>
          </CardContent>
        </Card>
      ) : null}

      {isLoading && !hasStaleProjects ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {[1,2,3,4,5,6].map(i => (
            <Card key={i} className="glass-card border-0 animate-pulse h-[200px]" />
          ))}
        </div>
      ) : error && !hasStaleProjects ? (
        <Card className="glass-card border-0 border-destructive bg-destructive/10">
          <CardContent className="flex flex-wrap items-center justify-between gap-3 pt-6 text-destructive">
            <span className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              ပရောဂျက်များကို ဖွင့်၍ မရပါ။
            </span>
            <Button type="button" variant="outline" size="sm" onClick={() => void refetch()} disabled={isFetching}>
              <RefreshCw className={`mr-2 h-4 w-4 ${isFetching ? "animate-spin" : ""}`} />
              ထပ်မံကြိုးစားရန်
            </Button>
          </CardContent>
        </Card>
      ) : filteredProjects.length === 0 ? (
        <div className="glass-card border-0 text-center py-20 bg-background/30">
          <Film className="w-12 h-12 text-muted mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-1">ပရောဂျက် မတွေ့ပါ</h3>
          <p className="text-muted-foreground mb-4">
            {search ? "အခြားရှာဖွေစကားလုံးဖြင့် ထပ်မံရှာပါ။" : "စတင်ရန် သင့်ပထမဆုံးပရောဂျက်ကို ဖန်တီးပါ။"}
          </p>
          {!search && <CreateProjectDialog />}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filteredProjects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      )}
    </div>
  )
}

function ProjectCard({ project }: { project: any }) {
  const [previewFailed, setPreviewFailed] = useState(false)
  const queryClient = useQueryClient()
  const { toast } = useToast()
  const projectsQueryKey = getListProjectsQueryKey()
  const deleteProject = useDeleteProject({
    mutation: {
      onMutate: async ({ id }) => {
        await queryClient.cancelQueries({ queryKey: projectsQueryKey })
        const previousProjects = queryClient.getQueryData<any[]>(projectsQueryKey)
        queryClient.setQueryData(
          projectsQueryKey,
          (currentProjects: any[] | undefined) =>
            (currentProjects || []).filter((item) => item.id !== id),
        )
        return { previousProjects }
      },
      onSuccess: () => {
        void queryClient.invalidateQueries({ queryKey: projectsQueryKey })
        toast({ title: "ပရောဂျက်ကို ဖျက်ပြီးပါပြီ", description: "ပရောဂျက်နှင့် သိမ်းဆည်းထားသောဖိုင်များကို ဖယ်ရှားပြီးပါပြီ။" })
      },
      onError: (error: any, _variables: { id: string }, context: { previousProjects?: any[] } | undefined) => {
        if (context?.previousProjects) {
          queryClient.setQueryData(projectsQueryKey, context.previousProjects)
        }
        void queryClient.invalidateQueries({ queryKey: projectsQueryKey })
        if (Number(error?.status) !== 404) {
          toast({
            variant: "destructive",
            title: "ဖျက်၍ မရပါ",
            description: localizeError(error.message),
          })
        }
      },
    },
  })

  const completedVideo = project.exportsStale
    ? undefined
    : (project.exports || []).find((item: any) => item.videoUrl)
  const isBusy = project.status === "processing" || project.status === "queued"
  const sourcePreviewUrl = `/api/studio/projects/${project.id}/source`
  const canPreviewUploadedSource = project.status !== "unavailable" && !project.sourceUrl

  return (
    <Card className="studio-surface group flex h-full flex-col overflow-hidden border-card-border/80 transition-all duration-300 hover:-translate-y-1 hover:border-primary/45">
      <Link href={`/projects/${project.id}`} className="block">
          <div className="relative aspect-video overflow-hidden bg-muted/50">
          {!previewFailed && canPreviewUploadedSource ? (
            <video
              src={sourcePreviewUrl}
              muted
              playsInline
              preload="metadata"
              onError={() => setPreviewFailed(true)}
              className="h-full w-full object-cover"
              aria-label={`${project.title} အစမ်းကြည့်ဗီဒီယို`}
            />
          ) : (
            <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-muted-foreground">
              <Film className="h-10 w-10 opacity-30" />
               <span className="text-xs">{project.sourceUrl ? "တိုက်ရိုက် URL မူရင်း" : "အစမ်းကြည့်၍ မရပါ"}</span>
            </div>
          )}
          <div className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-black/70 to-transparent px-4 pb-3 pt-8 text-xs text-white">
             <span className="flex items-center gap-1.5"><Video className="h-3.5 w-3.5" /> ဗီဒီယိုအစမ်းကြည့်ရန်</span>
            {project.duration > 0 && <span>{Math.round(project.duration / 60)} မိနစ် {project.duration % 60} စက္ကန့်</span>}
          </div>
        </div>
      </Link>

      <CardContent className="flex h-full flex-col p-4 sm:p-5">
        <div className="mb-4 flex items-start justify-between gap-2">
          <Link href={`/projects/${project.id}`} className="min-w-0">
             <p className="mb-1 text-xs font-semibold uppercase tracking-[0.18em] text-primary">
               Project No. {project.projectNumber || "—"}
             </p>
            <h3 className="font-semibold line-clamp-2 leading-snug group-hover:text-primary transition-colors">{project.title}</h3>
          </Link>
          <StatusBadge project={project} />
        </div>

        <div className="space-y-4 mt-auto">
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span className="capitalize">{isBusy ? localizeStage(project.stage) : localizeStatus(project.status)}</span>
              <span>{Math.round(project.progress)}%</span>
            </div>
            <Progress value={project.progress} className="h-1.5" />
          </div>

             <div className="flex items-center gap-1.5 border-t border-border/50 pt-3 text-xs text-muted-foreground">
             <Clock className="w-3 h-3" /> ဖန်တီးသည့်အချိန် {formatDate(project.createdAt)}
          </div>

          <div className="flex flex-wrap gap-2 pt-1">
            <Link href={`/projects/${project.id}`} className="flex-1 min-w-[110px]">
              <Button type="button" variant="outline" size="sm" className="w-full gap-1.5">
                 <Pencil className="w-3.5 h-3.5" /> ဖွင့်/တည်းဖြတ်
              </Button>
            </Link>
            <DownloadFileButton
              url={completedVideo?.downloadUrl || completedVideo?.videoUrl}
               filename={`Project_${project.projectNumber || 0}_Final${completedVideo?.language === "english" ? "_English" : ""}.mp4`}
              icon={<Download className="w-3.5 h-3.5" />}
              disabled={!completedVideo || isBusy}
              className="flex min-h-9 flex-1 min-w-[130px] items-center justify-center gap-1.5 rounded-md border border-input bg-background px-3 text-sm font-medium shadow-sm hover:bg-accent hover:text-accent-foreground"
            >
              ဗီဒီယိုဒေါင်းလုဒ်
            </DownloadFileButton>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button type="button" variant="outline" size="sm" className="gap-1.5 text-destructive hover:text-destructive" disabled={isBusy || deleteProject.isPending}>
                  {deleteProject.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                  ဖျက်ရန်
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                 <AlertDialogTitle>ပရောဂျက်ကို ဖျက်မည်လား။</AlertDialogTitle>
                  <AlertDialogDescription>
                   “{project.title}” နှင့် တင်ထားသောမူရင်း၊ ပြီးစီးထားသောဗီဒီယိုများကို အပြီးတိုင် ဖျက်မည်ဖြစ်ပါသည်။
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                 <AlertDialogCancel>မလုပ်တော့ပါ</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => deleteProject.mutate({ id: project.id })}
                    className="bg-destructive hover:bg-destructive/90"
                  >
                     ပရောဂျက်ဖျက်ရန်
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function StatusBadge({ project }: { project: any }) {
  switch (project.status) {
    case 'processing':
    case 'queued':
       return <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/20 hover:bg-blue-500/20 flex gap-1 items-center px-2 py-0.5"><Loader2 className="w-3 h-3 animate-spin" /> {localizeStatus(project.status, project.progress)}</Badge>
    case 'completed':
       return <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 hover:bg-emerald-500/20 flex gap-1 items-center px-2 py-0.5"><CheckCircle2 className="w-3 h-3" /> ပြီးစီးပြီ</Badge>
    case 'failed':
       return <Badge variant="destructive" className="flex gap-1 items-center px-2 py-0.5"><AlertCircle className="w-3 h-3" /> မအောင်မြင်ပါ</Badge>
    case 'draft':
       return <Badge variant="secondary">မူကြမ်း</Badge>
    default:
       return <Badge variant="secondary">{localizeStatus(project.status)}</Badge>
  }
}

function CreateProjectDialog() {
  const [open, setOpen] = useState(false)
  const [sourceFile, setSourceFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(-1)
  const [uploadError, setUploadError] = useState("")
  const [uploadPreviewUrl, setUploadPreviewUrl] = useState<string | null>(null)
  const [globalEdit, setGlobalEdit] = useState("none")
  const [targetDuration, setTargetDuration] = useState<"original" | "3" | "5" | "8" | "10">("original")
  const [rightsConfirmed, setRightsConfirmed] = useState(false)
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const uploadXhrRef = useRef<XMLHttpRequest | null>(null)
  const cancelRequestedRef = useRef(false)
  useEffect(() => {
    if (!sourceFile) {
      setUploadPreviewUrl(null)
      return
    }
    const url = URL.createObjectURL(sourceFile)
    setUploadPreviewUrl(url)
    return () => URL.revokeObjectURL(url)
  }, [sourceFile])
  
  const queryClient = useQueryClient()
  const { toast } = useToast()
  const [, setLocation] = useLocation()

  const resetFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const resetUploadState = () => {
    resetFileInput()
    setSourceFile(null)
    setUploadProgress(-1)
    setUploadError("")
  }

  const handleDialogOpenChange = (nextOpen: boolean) => {
    if (!nextOpen) {
      cancelRequestedRef.current = true
      uploadXhrRef.current?.abort()
      resetUploadState()
    }
    setOpen(nextOpen)
  }
  
  const createProject = useCreateProject({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() })
      }
    }
  })

  const autoProjectTitle = (file: File) => {
    const stem = file.name.replace(/\.[^/.]+$/, "").trim().replace(/\s+/g, " ")
    if (stem) return stem.slice(0, 160)
    const now = new Date()
    const pad = (value: number) => String(value).padStart(2, "0")
    return `Recap_${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}`
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!sourceFile || !rightsConfirmed) return

    const selectedFile = sourceFile
    let uploadedSourceObjectPath: string | undefined
    cancelRequestedRef.current = false
    setUploadError("")
    // Clear the DOM file-input value at the start of a creation attempt. The
    // captured File remains available to this request, and the same file can
    // be selected again after a failed or cancelled attempt.
    resetFileInput()

    try {
      setIsUploading(Boolean(sourceFile))
      if (sourceFile) {
        const formData = new FormData()
        formData.append("file", sourceFile)
        
        uploadedSourceObjectPath = await new Promise((resolve, reject) => {
          const xhr = new XMLHttpRequest()
          xhr.open("POST", "/api/studio/uploads")
          xhr.withCredentials = true
          xhr.timeout = 300000
          uploadXhrRef.current = xhr
          
          xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) {
              setUploadProgress(Math.round((e.loaded / e.total) * 100))
            }
          }
          
          xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
              try {
                const payload = JSON.parse(xhr.responseText)
                if (typeof payload.sourceObjectPath !== "string") {
                  reject(new Error("Invalid upload response."))
                  return
                }
                resolve(payload.sourceObjectPath)
              } catch (err) {
                reject(new Error("Could not upload the video file."))
              }
            } else {
              try {
                const payload = JSON.parse(xhr.responseText)
                reject(new Error(payload.error || payload.detail || "Could not upload the video file."))
              } catch {
                reject(new Error(`Upload failed with HTTP ${xhr.status}.`))
              }
            }
          }
          
          xhr.onerror = () => reject(new Error("Network error during upload."))
          xhr.ontimeout = () => reject(new Error("Network timeout during upload after 5 minutes."))
          xhr.onabort = () => reject(new Error("Upload cancelled."))
          
          setUploadProgress(0)
          xhr.send(formData)
          uploadXhrRef.current = xhr
        })
      }

      const created = await createProject.mutateAsync({
        data: {
          title: autoProjectTitle(selectedFile),
          sourceObjectPath: uploadedSourceObjectPath,
          rightsConfirmed,
          globalEdit: globalEdit as any,
          targetDurationMinutes: targetDuration === "original"
            ? null
            : Number(targetDuration) as 3 | 5 | 8 | 10,
        }
      })
      setOpen(false)
      resetUploadState()
      setRightsConfirmed(false)
      toast({ title: "မူကြမ်းပရောဂျက် ဖန်တီးပြီးပါပြီ", description: "Preview တွင် Blur Box နှင့် Subtitle Area ကို ပြင်ပြီး Export Video ကိုနှိပ်ပါ။" })
      setLocation(`/projects/${created.id}`)
    } catch (error: any) {
      if (uploadedSourceObjectPath) {
        try {
          const cleanupResponse = await fetch("/api/studio/uploads", {
            method: "DELETE",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ sourceObjectPath: uploadedSourceObjectPath }),
          })
          if (!cleanupResponse.ok && cleanupResponse.status !== 409) {
            console.warn("Uploaded source cleanup failed", cleanupResponse.status)
          }
        } catch (cleanupError) {
          console.warn("Uploaded source cleanup request failed", cleanupError)
        }
      }
      const message = error.body?.detail || error.message
      if (cancelRequestedRef.current || message === "Upload cancelled.") {
        return
      }
      const preciseError = localizeError(message)
      setUploadError(preciseError)
      toast({
        variant: "destructive",
           title: "ပရောဂျက်ဖန်တီး၍ မရပါ",
           description: preciseError,
      })
    } finally {
      uploadXhrRef.current = null
      setIsUploading(false)
      setUploadProgress(-1)
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleDialogOpenChange}>
      <DialogTrigger asChild>
         <Button className="gap-2 shadow-lg shadow-primary/20"><Plus className="w-4 h-4" /> ပရောဂျက်အသစ်</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] max-h-[90dvh] overflow-y-auto">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
             <DialogTitle>ပရောဂျက်အသစ် ဖန်တီးရန်</DialogTitle>
          </DialogHeader>
          <div className="grid gap-6 py-6">
            <div className="space-y-2">
               <Label htmlFor="video-file">ဗီဒီယိုဖိုင်</Label>
              <Input
                id="video-file"
                ref={fileInputRef}
                type="file"
                accept="video/*,.mp4,.mov,.mkv,.webm"
                onChange={(e) => {
                  const file = e.target.files?.[0] || null
                  if (!file) {
                    setSourceFile(null)
                    return
                  }
                  const hasAllowedExtension = /\.(mp4|mov|mkv|webm)$/i.test(file.name)
                  const hasVideoMime = (file.type || "").toLowerCase().startsWith("video/")
                  if (!hasAllowedExtension && !hasVideoMime) {
                     toast({ variant: "destructive", title: "မထောက်ပံ့သောဖိုင်", description: "MP4၊ MOV၊ MKV သို့မဟုတ် WebM ဗီဒီယိုကို ရွေးပါ။" })
                    e.currentTarget.value = ""
                    setSourceFile(null)
                    setUploadError("")
                    return
                  }
                  if (file.size > 500 * 1024 * 1024) {
                     toast({ variant: "destructive", title: "ဖိုင်အရွယ်အစား ကြီးလွန်းပါသည်", description: "ဗီဒီယိုဖိုင်သည် ၅၀၀ MB ထက် မပိုရပါ။" })
                    e.currentTarget.value = ""
                    setSourceFile(null)
                    setUploadError("")
                    return
                  }
                  setUploadError("")
                  setUploadProgress(-1)
                  setSourceFile(file)
                }}
                className="cursor-pointer file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-primary-foreground hover:file:bg-primary/90"
              />
              <p className="text-xs text-muted-foreground">
                  သင့်စက်ထဲမှ MP4၊ MOV၊ MKV သို့မဟုတ် WebM ဖိုင်ကို ရွေးပါ (အများဆုံး ၅၀၀ MB၊ ၁၅ မိနစ်အထိ)။
              </p>
              {uploadError && (
                <div className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive" role="alert">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{uploadError}</span>
                </div>
              )}
              {uploadPreviewUrl && (
                <div className="mt-3 rounded-md overflow-hidden relative bg-black max-w-[200px]">
                  <video src={uploadPreviewUrl} className="w-full max-h-56" muted playsInline aria-label="ရွေးထားသောဗီဒီယို အစမ်းကြည့်ရန်" />
                  {uploadProgress >= 0 && (
                    <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center">
                      <span className="text-sm font-medium text-white">{uploadProgress}%</span>
                      {uploadProgress === 100 && <span className="text-[10px] text-white/80 mt-1 px-2 text-center">ဖိုင်တင်ပြီးပါပြီ။ ဗီဒီယိုဖော်မတ် ပြောင်း၍ သိမ်းဆည်းနေသည်…</span>}
                    </div>
                  )}
                </div>
              )}
            </div>
            
            <div className="space-y-2">
               <Label htmlFor="globalEdit">ဗီဒီယိုတည်းဖြတ်မှု</Label>
              <Select value={globalEdit} onValueChange={setGlobalEdit}>
                <SelectTrigger id="globalEdit">
                 <SelectValue placeholder="တည်းဖြတ်မှုကို ရွေးပါ" />
                </SelectTrigger>
                <SelectContent>
                   <SelectItem value="none">မရှိ (မူရင်းအတိုင်း)</SelectItem>
                   <SelectItem value="crop">၉:၁၆ အလိုအလျောက်ဖြတ်တောက်မှု (TikTok/Shorts)</SelectItem>
                   <SelectItem value="zoom">အနည်းငယ်ချဲ့ခြင်း</SelectItem>
                   <SelectItem value="blur">နောက်ခံဝါးခြင်း (၁၆:၉ ကို ၉:၁၆ အဖြစ်)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="target-duration">Recap ရည်မှန်းချိန်</Label>
              <Select value={targetDuration} onValueChange={(value) => setTargetDuration(value as typeof targetDuration)}>
                <SelectTrigger id="target-duration">
                  <SelectValue placeholder="ရည်မှန်းချိန်ကို ရွေးပါ" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="original">မူရင်းကြာချိန်အတိုင်းထားမည်</SelectItem>
                  <SelectItem value="3">၃ မိနစ်</SelectItem>
                  <SelectItem value="5">၅ မိနစ်</SelectItem>
                  <SelectItem value="8">၈ မိနစ်</SelectItem>
                  <SelectItem value="10">၁၀ မိနစ်</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                ဤရွေးချယ်မှုသည် export ဗီဒီယိုအရှည်ကို သတ်မှတ်သည်။ Narration သည် ဇာတ်လမ်းကို သဘာဝအတိုင်း ပြောပြီး အစောဆုံးနိုင်ပါသည်။
              </p>
            </div>
            
            <div className="flex items-center space-x-2 bg-muted/50 p-3 rounded-md border border-border/50">
              <Checkbox 
                id="rights" 
                checked={rightsConfirmed} 
                onCheckedChange={(c) => setRightsConfirmed(c as boolean)}
                required
              />
              <Label htmlFor="rights" className="text-sm font-normal leading-snug cursor-pointer">
                 ဤဗီဒီယိုအကြောင်းအရာကို အသုံးပြု၍ လုပ်ဆောင်ခွင့်ရှိကြောင်း အတည်ပြုပါသည်။
              </Label>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => { setOpen(false); setLocation("/projects") }}>
               <ArrowLeft className="w-4 h-4 mr-2" /> ပရောဂျက်များသို့ ပြန်ရန်
            </Button>
            <Button type="submit" disabled={!sourceFile || !rightsConfirmed || createProject.isPending || isUploading}>
              {(createProject.isPending || isUploading) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {isUploading ? "ဗီဒီယိုတင်နေသည်..." : "မူကြမ်းပရောဂျက် ဖန်တီးရန်"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
