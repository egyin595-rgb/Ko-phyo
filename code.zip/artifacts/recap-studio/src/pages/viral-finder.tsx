import { useMemo, useState } from "react"
import { useQueryClient } from "@tanstack/react-query"
import { useLocation } from "wouter"
import {
  AlertCircle,
  ArrowUpRight,
  BarChart3,
  ChevronDown,
  ExternalLink,
  Flame,
  Languages,
  Loader2,
  Radar,
  Search,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Youtube,
} from "lucide-react"
import {
  ViralSearchInputPlatform,
  type ViralSearchInputPlatform as ViralSearchInputPlatformType,
  type ViralSource,
  getListProjectsQueryKey,
  useIngestViralSource,
  useListProjects,
  useSearchViralSources,
} from "@workspace/api-client-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"
import { localizeError } from "@/lib/i18n"

type Platform = ViralSearchInputPlatformType

const platformOptions: Array<{
  value: Platform
  label: string
  shortLabel: string
  color: string
}> = [
  { value: ViralSearchInputPlatform.youtube, label: "YouTube", shortLabel: "YT", color: "text-red-400" },
  { value: ViralSearchInputPlatform.bilibili, label: "Bilibili", shortLabel: "BL", color: "text-cyan-300" },
  { value: ViralSearchInputPlatform.rednote, label: "Rednote", shortLabel: "RN", color: "text-rose-300" },
]

const numberFormatter = new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 })

function formatMetric(value: number) {
  return numberFormatter.format(value || 0)
}

function formatDuration(seconds: number | null) {
  if (!seconds || seconds < 1) return "—"
  const minutes = Math.floor(seconds / 60)
  const remainder = Math.round(seconds % 60).toString().padStart(2, "0")
  return `${minutes}:${remainder}`
}

function formatDate(value: string | null) {
  if (!value) return "နေ့ရက် မသိရသေး"
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat("my-MM", { month: "short", day: "numeric", year: "numeric" }).format(date)
}

function platformLabel(platform: Platform) {
  return platformOptions.find((item) => item.value === platform)?.label ?? platform
}

export default function ViralFinder() {
  const [query, setQuery] = useState("")
  const [platform, setPlatform] = useState<Platform>(ViralSearchInputPlatform.youtube)
  const [limit, setLimit] = useState("8")
  const [rightsConfirmed, setRightsConfirmed] = useState(false)
  const [response, setResponse] = useState<{
    originalQuery: string
    translatedQuery: string
    platform: Platform
    results: ViralSource[]
    filteredCount: number
  } | null>(null)
  const [activeIngestId, setActiveIngestId] = useState<string | null>(null)
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [, setLocation] = useLocation()

  const { data: projects } = useListProjects({
    query: { queryKey: getListProjectsQueryKey(), refetchInterval: 3000 },
  })

  const searchMutation = useSearchViralSources({
    mutation: {
      onSuccess: (data) => {
        setResponse(data)
        setRightsConfirmed(false)
      },
      onError: (error) => {
        setResponse(null)
        toast({
          variant: "destructive",
          title: "ရှာဖွေ၍ မရပါ",
          description: localizeError(error),
        })
      },
    },
  })

  const ingestMutation = useIngestViralSource({
    mutation: {
      onSuccess: (project) => {
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() })
        toast({
          title: "မူကြမ်း ပရောဂျက်ဖန်တီးပြီးပါပြီ",
          description: "အကြောင်းအရာတည်းဖြတ်ခန်းသို့ သွားနေပါသည်...",
        })
        setLocation(`/projects/${project.id}`)
      },
      onError: (error) => {
        setActiveIngestId(null)
        toast({
          variant: "destructive",
          title: "ဗီဒီယိုကို ထည့်၍ မရပါ",
          description: localizeError(error),
        })
      },
    },
  })

  const results = response?.results ?? []
  const trendingCount = useMemo(() => results.filter((result) => result.isTrending).length, [results])
  const topScore = useMemo(
    () => results.reduce((highest, result) => Math.max(highest, result.viralScore), 0),
    [results],
  )

  const handleSearch = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const cleanQuery = query.trim()
    if (!cleanQuery || searchMutation.isPending) return
    searchMutation.mutate({
      data: {
        query: cleanQuery,
        platform,
        limit: Number(limit),
      },
    })
  }

  const handleIngest = (source: ViralSource) => {
    if (!rightsConfirmed || ingestMutation.isPending) return
    setActiveIngestId(source.id)
    ingestMutation.mutate({
      data: {
        url: source.url,
        title: source.title,
        platform: source.platform,
        rightsConfirmed,
      },
    })
  }

  return (
    <div className="animate-studio-in space-y-6 pb-4">
      <header className="relative overflow-hidden rounded-[1.75rem] border border-card-border/80 bg-card/75 p-5 shadow-[0_18px_48px_hsl(222_35%_3%/.22)] sm:p-7">
        <div className="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
        <div className="relative flex flex-col gap-7">
          <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
            <div className="max-w-3xl">
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <span className="studio-kicker text-primary">RESEARCH DESK / VIRAL SOURCE FINDER</span>
                <Badge variant="outline" className="gap-1 border-primary/30 bg-primary/10 text-primary">
                  <Radar className="h-3 w-3" /> LIVE SIGNALS
                </Badge>
              </div>
              <h1 className="text-3xl font-bold tracking-tight sm:text-5xl">နောက်တစ်ပုဒ်ကို မတက်ခင် ရှာပါ</h1>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground sm:text-base">
                လူတွေမပြောခင် ဇာတ်လမ်းကို တွေ့ပါ။ YouTube၊ Bilibili နှင့် Rednote မှ အရှိန်တက်နေသော
                အကြောင်းအရာများကို စုစည်းပြီး recap အတွက် အလားအလာအမြင့်ဆုံးကို အရင်ရွေးပါ။
              </p>
            </div>
            <div className="grid grid-cols-3 gap-2 sm:min-w-[310px]">
              <SignalStat label="စစ်ထုတ်ပြီး" value={response ? response.filteredCount : "—"} />
              <SignalStat label="Trending" value={response ? trendingCount : "—"} accent />
              <SignalStat label="Projects" value={projects?.length ?? "—"} />
            </div>
          </div>

          <form onSubmit={handleSearch} className="rounded-2xl border border-border/70 bg-background/55 p-2.5 sm:p-3" data-testid="form-viral-search">
            <div className="flex flex-col gap-2 lg:flex-row">
              <div className="relative min-w-0 flex-1">
                <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-primary" />
                <Input
                  data-testid="input-viral-query"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="ဇာတ်လမ်း၊ keyword သို့မဟုတ် ဗီဒီယို URL ထည့်ပါ..."
                  className="h-12 border-0 bg-transparent pl-11 text-base shadow-none focus-visible:ring-0"
                  maxLength={256}
                />
              </div>
              <div className="flex gap-2">
                <PlatformSelect value={platform} onChange={setPlatform} />
                <select
                  data-testid="select-viral-limit"
                  value={limit}
                  onChange={(event) => setLimit(event.target.value)}
                  className="h-12 rounded-xl border border-input bg-card px-3 text-sm font-medium text-foreground outline-none focus:ring-2 focus:ring-ring"
                  aria-label="ရလဒ်အရေအတွက်"
                >
                  <option value="4">4 results</option>
                  <option value="8">8 results</option>
                  <option value="12">12 results</option>
                </select>
                <Button data-testid="button-search-viral" type="submit" size="lg" disabled={!query.trim() || searchMutation.isPending} className="h-12 gap-2 px-5">
                  {searchMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                  <span className="hidden sm:inline">ရှာဖွေမည်</span>
                  <span className="sm:hidden">ရှာမည်</span>
                </Button>
              </div>
            </div>
          </form>
        </div>
      </header>

      {response && (
        <section className="grid gap-3 md:grid-cols-[1fr_auto] md:items-center" data-testid="section-search-context">
          <div className="flex min-w-0 items-center gap-3 rounded-xl border border-border/70 bg-card/45 px-4 py-3">
            <Languages className="h-4 w-4 shrink-0 text-accent" />
            <div className="min-w-0 text-sm">
              <span className="text-muted-foreground">ရှာဖွေမှု </span>
              <strong className="font-medium">“{response.originalQuery}”</strong>
              {response.translatedQuery && response.translatedQuery !== response.originalQuery && (
                <span className="text-muted-foreground"> · ဘာသာပြန် keyword “{response.translatedQuery}”</span>
              )}
            </div>
            <Badge variant="secondary" className="ml-auto shrink-0">{platformLabel(response.platform)}</Badge>
          </div>
          <div className="flex items-center gap-2 rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-xs text-primary">
            <Sparkles className="h-4 w-4" />
            <span>{topScore > 0 ? `အမြင့်ဆုံး viral score ${Math.round(topScore)}` : "Signal analysis complete"}</span>
          </div>
        </section>
      )}

      {!response && !searchMutation.isPending && (
        <EmptyResearchState onExample={(example) => setQuery(example)} />
      )}

      {searchMutation.isPending && <SearchSkeleton />}

      {searchMutation.isError && !response && (
        <Card className="border-destructive/40 bg-destructive/10" data-testid="state-viral-error">
          <CardContent className="flex flex-col items-center gap-3 py-14 text-center">
            <div className="rounded-full bg-destructive/15 p-3 text-destructive"><AlertCircle className="h-6 w-6" /></div>
            <div>
              <h2 className="font-semibold">Signal မရရှိသေးပါ</h2>
              <p className="mt-1 text-sm text-muted-foreground">Platform သို့မဟုတ် keyword ကို ပြောင်းပြီး ထပ်ကြိုးစားပါ။</p>
            </div>
            <Button data-testid="button-retry-viral" variant="outline" onClick={() => handleSearch({ preventDefault: () => {} } as React.FormEvent<HTMLFormElement>)} disabled={!query.trim()}>
              ထပ်မံရှာဖွေမည်
            </Button>
          </CardContent>
        </Card>
      )}

      {response && !searchMutation.isPending && results.length === 0 && <NoResultsState query={response.originalQuery} />}

      {response && results.length > 0 && (
        <section className="space-y-3" data-testid="section-viral-results">
          <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-end">
            <div>
              <p className="studio-kicker mb-1 text-primary">RANKED SOURCES / {results.length} FOUND</p>
              <h2 className="text-xl font-semibold tracking-tight">Recap အတွက် အရင်စစ်သင့်သောဗီဒီယိုများ</h2>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" /> viral score နှင့် velocity အလိုက် စီထားသည်
            </div>
          </div>
          <div className="grid gap-4 xl:grid-cols-2">
            {results.map((source, index) => (
              <SourceCard
                key={source.id}
                source={source}
                rank={index + 1}
                rightsConfirmed={rightsConfirmed}
                isIngesting={activeIngestId === source.id && ingestMutation.isPending}
                onIngest={() => handleIngest(source)}
              />
            ))}
          </div>
        </section>
      )}

      {response && results.length > 0 && (
        <div className="flex flex-col gap-3 rounded-2xl border border-primary/20 bg-primary/[.04] p-4 sm:flex-row sm:items-center sm:justify-between sm:px-5">
          <div className="flex items-start gap-3">
            <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
            <div>
              <Label htmlFor="rights-confirmed" className="cursor-pointer text-sm font-semibold">အသုံးပြုခွင့်ကို အတည်ပြုပါ</Label>
              <p className="mt-1 text-xs leading-5 text-muted-foreground">Download & Recap မပြုလုပ်မီ အကြောင်းအရာအသုံးပြုခွင့်ရှိကြောင်း အတည်ပြုပါ။</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Checkbox
              data-testid="checkbox-rights-confirmed"
              id="rights-confirmed"
              checked={rightsConfirmed}
              onCheckedChange={(checked) => setRightsConfirmed(checked === true)}
            />
            <Label htmlFor="rights-confirmed" className="cursor-pointer text-xs text-muted-foreground">အတည်ပြုပြီးပါပြီ</Label>
          </div>
        </div>
      )}
    </div>
  )
}

function SignalStat({ label, value, accent = false }: { label: string; value: number | string; accent?: boolean }) {
  return (
    <div className="rounded-xl border border-border/70 bg-background/35 px-3 py-3 text-center">
      <p className="studio-kicker text-[8px]">{label}</p>
      <p className={cn("mt-1 font-mono text-lg font-semibold", accent && "text-primary")} data-testid={`stat-${label.toLowerCase().replace(/\s+/g, "-")}`}>{value}</p>
    </div>
  )
}

function PlatformSelect({ value, onChange }: { value: Platform; onChange: (value: Platform) => void }) {
  return (
    <div className="relative shrink-0">
      <select
        data-testid="select-viral-platform"
        value={value}
        onChange={(event) => onChange(event.target.value as Platform)}
        className="h-12 w-[116px] appearance-none rounded-xl border border-input bg-card pl-3 pr-8 text-sm font-medium text-foreground outline-none focus:ring-2 focus:ring-ring sm:w-[132px]"
        aria-label="Platform ရွေးချယ်ရန်"
      >
        {platformOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
      </select>
      <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
    </div>
  )
}

function SourceCard({
  source,
  rank,
  rightsConfirmed,
  isIngesting,
  onIngest,
}: {
  source: ViralSource
  rank: number
  rightsConfirmed: boolean
  isIngesting: boolean
  onIngest: () => void
}) {
  const [thumbnailFailed, setThumbnailFailed] = useState(false)
  const option = platformOptions.find((item) => item.value === source.platform)
  return (
    <Card className="glass-card border-0 transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40" data-testid={`card-viral-source-${source.id}`}>
      <CardContent className="p-0">
        <div className="flex flex-col sm:flex-row">
          <div className="relative aspect-video shrink-0 overflow-hidden bg-muted sm:aspect-auto sm:h-auto sm:w-[220px]">
            {source.thumbnailUrl && !thumbnailFailed ? (
              <img data-testid={`img-viral-thumbnail-${source.id}`} src={source.thumbnailUrl} alt="" onError={() => setThumbnailFailed(true)} className="h-full min-h-[150px] w-full object-cover transition-transform duration-500 group-hover:scale-105" />
            ) : (
              <div className="flex min-h-[150px] h-full items-center justify-center bg-secondary text-muted-foreground">
                <Youtube className="h-9 w-9 opacity-30" />
              </div>
            )}
            <div className="absolute left-3 top-3 flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-background/85 font-mono text-xs font-bold text-primary backdrop-blur">{String(rank).padStart(2, "0")}</span>
              {source.isTrending && <Badge data-testid={`badge-trending-${source.id}`} className="gap-1 border-0 bg-primary text-primary-foreground"><Flame className="h-3 w-3" /> Trending</Badge>}
            </div>
            <span className="absolute bottom-3 right-3 rounded-md bg-background/85 px-2 py-1 font-mono text-[10px] text-foreground backdrop-blur">{formatDuration(source.duration)}</span>
          </div>
          <div className="flex min-w-0 flex-1 flex-col p-4 sm:p-5">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="mb-2 flex flex-wrap items-center gap-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                  <span className={cn("flex items-center gap-1", option?.color)}><span className="h-1.5 w-1.5 rounded-full bg-current" />{option?.label ?? source.platform}</span>
                  <span>•</span>
                  <span>{source.genre || "Unclassified"}</span>
                </div>
                <h3 data-testid={`text-viral-title-${source.id}`} className="line-clamp-2 text-base font-semibold leading-snug">{source.title}</h3>
                <p className="mt-1 truncate text-xs text-muted-foreground">{source.uploader} · {formatDate(source.uploadDate)}</p>
              </div>
              <div className="shrink-0 text-right">
                <p className="studio-kicker text-[8px]">VIRAL SCORE</p>
                <p data-testid={`text-viral-score-${source.id}`} className="font-mono text-2xl font-bold text-primary">{Math.round(source.viralScore)}</p>
              </div>
            </div>

            <p className="mt-4 line-clamp-2 text-sm leading-5 text-muted-foreground">{source.storyline || "ဇာတ်လမ်းအကျဉ်းချုပ် မရရှိသေးပါ။"}</p>

            <div className="mt-4 grid grid-cols-3 gap-2 border-y border-border/60 py-3">
              <Metric icon={<BarChart3 className="h-3.5 w-3.5" />} label="Views" value={formatMetric(source.viewCount)} />
              <Metric icon={<TrendingUp className="h-3.5 w-3.5" />} label="/ day" value={formatMetric(source.velocityPerDay)} />
               <Metric icon={<Sparkles className="h-3.5 w-3.5" />} label="Engage" value={`${(source.engagementRate * 100).toFixed(1)}%`} />
            </div>

            <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center">
              <Button data-testid={`button-ingest-viral-${source.id}`} onClick={onIngest} disabled={!rightsConfirmed || isIngesting} className="h-10 flex-1 gap-2 text-xs">
                {isIngesting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ArrowUpRight className="h-3.5 w-3.5" />}
                {isIngesting ? "မူကြမ်းဖန်တီးနေသည်..." : "Download & Recap"}
              </Button>
              <a data-testid={`link-open-source-${source.id}`} href={source.url} target="_blank" rel="noreferrer" className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl border border-input px-3 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground">
                <ExternalLink className="h-3.5 w-3.5" /> မူရင်းဖွင့်ရန်
              </a>
            </div>
            {!rightsConfirmed && <p className="mt-2 flex items-center gap-1.5 text-[10px] text-muted-foreground"><ShieldCheck className="h-3 w-3" /> အောက်တွင် အသုံးပြုခွင့်အတည်ပြုပါ</p>}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function Metric({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="min-w-0">
      <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">{icon}<span>{label}</span></div>
      <p className="mt-1 truncate font-mono text-sm font-semibold text-foreground">{value}</p>
    </div>
  )
}

function EmptyResearchState({ onExample }: { onExample: (value: string) => void }) {
  return (
    <Card className="border-dashed border-border/80 bg-card/35" data-testid="state-viral-empty">
      <CardContent className="flex flex-col items-center justify-center px-5 py-16 text-center">
        <div className="relative mb-5">
          <div className="absolute inset-0 animate-pulse rounded-2xl bg-primary/10 blur-xl" />
          <div className="relative rounded-2xl border border-primary/20 bg-primary/10 p-4 text-primary"><Radar className="h-8 w-8" /></div>
        </div>
        <p className="studio-kicker mb-2 text-primary">WAITING FOR A SIGNAL</p>
        <h2 className="text-xl font-semibold">ပထမဆုံး အကြောင်းအရာကို ရှာကြည့်ပါ</h2>
        <p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">Keyword တစ်ခု၊ ဇာတ်လမ်းနာမည် သို့မဟုတ် video URL ဖြင့် စတင်ပါ။ ရလဒ်များကို viral score အလိုက် စီပေးပါမည်။</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {["Celebrity fallout", "မိသားစုအရှုပ်တော်ပုံ", "unexpected confession"].map((example) => (
            <button key={example} data-testid={`button-example-${example}`} type="button" onClick={() => onExample(example)} className="rounded-full border border-border/80 bg-background/45 px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary">{example}</button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

function NoResultsState({ query }: { query: string }) {
  return (
    <Card className="border-dashed border-border/80 bg-card/35" data-testid="state-viral-no-results">
      <CardContent className="flex flex-col items-center py-16 text-center">
        <Search className="mb-4 h-9 w-9 text-muted-foreground/50" />
        <h2 className="font-semibold">“{query}” အတွက် ရလဒ်မတွေ့ပါ</h2>
        <p className="mt-2 text-sm text-muted-foreground">Keyword ကို တိုအောင်ပြောင်းပါ၊ ဒါမှမဟုတ် platform တစ်ခုကို ပြောင်းပြီး ထပ်ရှာပါ။</p>
      </CardContent>
    </Card>
  )
}

function SearchSkeleton() {
  return (
    <section className="grid gap-4 xl:grid-cols-2" data-testid="state-viral-loading">
      {[1, 2, 3, 4].map((item) => (
        <div key={item} className="h-[360px] animate-pulse rounded-2xl border border-border/60 bg-card/50 sm:h-[270px]" />
      ))}
    </section>
  )
}