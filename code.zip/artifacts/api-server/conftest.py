"""Keep pytest runs offline and isolate Studio's local test files."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path


API_ROOT = Path(__file__).resolve().parent
if str(API_ROOT) not in sys.path:
    sys.path.insert(0, str(API_ROOT))

from studio.offline_test_support import (  # noqa: E402
    blocked_network_operations,
    install_network_guard,
)


install_network_guard()
_TEST_STORAGE = tempfile.TemporaryDirectory(prefix="studio-pytest-")
_ROOT = Path(_TEST_STORAGE.name)
os.environ["STUDIO_DATA_ROOT"] = str(_ROOT / "data")
os.environ["STUDIO_DATABASE_PATH"] = str(_ROOT / "data" / "studio.sqlite3")
os.environ["STUDIO_MEDIA_ROOT"] = str(_ROOT / "media")
os.environ["STUDIO_CHECKPOINT_ROOT"] = str(_ROOT / "checkpoints")


def pytest_sessionfinish(session, exitstatus):
    attempts = blocked_network_operations()
    if attempts:
        reporter = session.config.pluginmanager.get_plugin("terminalreporter")
        message = (
            f"Offline isolation blocked {len(attempts)} network operation(s): "
            + ", ".join(attempts)
        )
        if reporter is not None:
            reporter.write_sep("=", message, red=True)
        session.exitstatus = 1
    _TEST_STORAGE.cleanup()