"""Focused byte-range and ownership tests for studio media endpoints."""
import asyncio
import tempfile
import unittest
from contextlib import nullcontext
from pathlib import Path
from unittest.mock import MagicMock, Mock, patch

from .offline_test_support import install_network_guard

install_network_guard()

from fastapi import HTTPException
from starlette.requests import Request

from . import engine, main, storage
from .models import ProjectInput, ProjectUpdate


def request(method="GET", range_header=None, owner="a" * 64):
    headers = []
    if range_header is not None:
        headers.append((b"range", range_header.encode("ascii")))
    value = Request({
        "type": "http",
        "http_version": "1.1",
        "method": method,
        "scheme": "https",
        "path": "/media",
        "raw_path": b"/media",
        "query_string": b"",
        "headers": headers,
        "client": ("test", 1),
        "server": ("test", 443),
    })
    value.state.owner = owner
    return value


def media_file(content=b"0123456789"):
    descriptor, name = tempfile.mkstemp(suffix=".mp4")
    Path(name).write_bytes(content)
    return Path(name)


async def response_body(response):
    return b"".join([chunk async for chunk in response.body_iterator])


class MediaStreamingTests(unittest.TestCase):
    def test_old_thumbnail_refreshes_cleanly_without_rerunning_export(self):
        project = {
            "id": "thumbnail-refresh-project",
            "sourceObjectPath": "studio/" + "a" * 64 + "/sources/source.mp4",
            "sourceDuration": 42.7,
            "exports": [{
                "language": "myanmar",
                "thumbnailFilename": "old-thumbnail.jpg",
                "thumbnailProcessingVersion": 0,
            }],
        }
        current = {
            **project,
            "exports": [dict(project["exports"][0])],
        }
        conn = Mock()
        storage = MagicMock()
        destination = media_file(content=b"old")

        def download_source(_object_name, filename):
            Path(filename).write_bytes(b"source")

        storage.download_to_filename.side_effect = download_source

        with patch.object(main, "storage_client", return_value=storage), \
                patch.object(main.store, "connection", return_value=nullcontext(conn)), \
                patch.object(main, "project_or_404", return_value=current), \
                patch.object(main.store, "save") as save, \
                patch.object(
                    engine,
                    "_probe_video_dimensions",
                    return_value=(720, 1280),
                ), \
                patch.object(
                    engine,
                    "_extract_thumbnail",
                    side_effect=lambda _source, _duration, output, **_kwargs: (
                        Path(output).write_bytes(b"clean-thumbnail")
                    ),
                ) as extract:
            main._refresh_clean_thumbnail(
                project,
                "a" * 64,
                "myanmar",
                "studio/project-exports",
                "old-thumbnail.jpg",
                destination,
            )

        self.assertEqual(destination.read_bytes(), b"clean-thumbnail")
        self.assertEqual(
            storage.upload_from_filename.call_args.args[0],
            "studio/project-exports/old-thumbnail.jpg",
        )
        self.assertTrue(extract.call_args.kwargs["clean_publish_thumbnail"])
        self.assertEqual(
            current["exports"][0]["thumbnailProcessingVersion"],
            main.CLEAN_THUMBNAIL_VERSION,
        )
        save.assert_called_once()
        destination.unlink(missing_ok=True)

    def test_full_response_is_mp4_and_cleans_up(self):
        path = media_file()
        response = main.local_media_response(path, request(), "video/mp4", "source.mp4", "inline")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers["content-type"], "video/mp4")
        self.assertEqual(response.headers["accept-ranges"], "bytes")
        self.assertEqual(response.headers["content-length"], "10")
        self.assertIn('filename="drama_recap.mp4"', response.headers["content-disposition"])
        self.assertIn("filename*=UTF-8''source.mp4", response.headers["content-disposition"])
        self.assertEqual(asyncio.run(response_body(response)), b"0123456789")
        self.assertFalse(path.exists())

    def test_closed_and_open_ranges_return_valid_206(self):
        for header, expected, content_range in (
            ("bytes=2-5", b"2345", "bytes 2-5/10"),
            ("bytes=7-", b"789", "bytes 7-9/10"),
        ):
            with self.subTest(header=header):
                path = media_file()
                response = main.local_media_response(
                    path, request(range_header=header), "video/mp4", "source.mp4", "inline",
                )
                self.assertEqual(response.status_code, 206)
                self.assertEqual(response.headers["content-range"], content_range)
                self.assertEqual(response.headers["content-length"], str(len(expected)))
                self.assertEqual(asyncio.run(response_body(response)), expected)
                self.assertFalse(path.exists())

    def test_suffix_range(self):
        path = media_file()
        response = main.local_media_response(
            path, request(range_header="bytes=-4"), "video/mp4", "source.mp4", "inline",
        )

        self.assertEqual(response.status_code, 206)
        self.assertEqual(response.headers["content-range"], "bytes 6-9/10")
        self.assertEqual(asyncio.run(response_body(response)), b"6789")

    def test_unsatisfiable_and_multiple_ranges_return_416_and_cleanup(self):
        for header in ("bytes=10-", "bytes=-0", "bytes=+1-2", "bytes=0-1,4-5", "items=0-1"):
            with self.subTest(header=header):
                path = media_file()
                response = main.local_media_response(
                    path, request(range_header=header), "video/mp4", "source.mp4", "inline",
                )
                self.assertEqual(response.status_code, 416)
                self.assertEqual(response.headers["content-range"], "bytes */10")
                self.assertEqual(response.headers["content-length"], "0")
                self.assertFalse(path.exists())

    def test_head_has_range_headers_no_body_and_background_cleanup(self):
        path = media_file()
        response = main.local_media_response(
            path, request("HEAD", "bytes=1-3"), "video/mp4", "source.mp4", "inline",
        )

        self.assertEqual(response.status_code, 206)
        self.assertEqual(response.headers["content-range"], "bytes 1-3/10")
        self.assertEqual(response.headers["content-length"], "3")
        self.assertEqual(response.body, b"")
        self.assertTrue(path.exists())
        asyncio.run(response.background())
        self.assertFalse(path.exists())

    def test_authoritative_file_stream_does_not_delete_source(self):
        path = media_file()
        response = main.local_media_response(
            path,
            request(range_header="bytes=0-3"),
            "video/mp4",
            "source.mp4",
            "attachment",
            cleanup_after_response=False,
        )

        self.assertEqual(asyncio.run(response_body(response)), b"0123")
        self.assertTrue(path.exists())
        path.unlink(missing_ok=True)

    def test_source_checks_workspace_ownership_before_storage(self):
        denied = HTTPException(404, "Project not found.")
        with patch.object(main.store, "connection", return_value=nullcontext(Mock())), \
                patch.object(main, "project_or_404", side_effect=denied) as lookup, \
                patch.object(main, "storage_client") as storage:
            with self.assertRaises(HTTPException):
                main.get_source_preview("other-project", request(owner="b" * 64))

        lookup.assert_called_once()
        self.assertEqual(lookup.call_args.args[1:3], ("b" * 64, "other-project"))
        storage.assert_not_called()

    def test_export_checks_workspace_ownership_before_storage(self):
        connection = Mock()
        with patch.object(main.store, "connection", return_value=nullcontext(connection)), \
                patch.object(main.store, "get", return_value=None), \
                patch.object(main.store, "get_any_owner", return_value=(
                    {"id": "other-project"}, "a" * 64
                )) as get_any_owner, \
                patch.object(main.store, "reassign_project_owner") as reassign, \
                patch.object(main, "storage_client") as storage:
            with self.assertRaises(HTTPException):
                main.get_file("other-project", "myanmar.mp4", request(owner="b" * 64))
        get_any_owner.assert_not_called()
        reassign.assert_not_called()
        storage.assert_not_called()

    def test_head_does_not_report_success_when_export_storage_fails(self):
        project = {
            "id": "storage-failure-project",
            "status": "completed",
            "progress": 100,
            "objectPrefix": "studio/storage-failure-project",
            "exports": [{
                "language": "myanmar",
                "videoFilename": "final.mp4",
            }],
        }
        with patch.object(main.store, "connection", return_value=nullcontext(Mock())), \
                patch.object(main, "project_or_404", return_value=project), \
                patch.object(
                    main,
                    "storage_client",
                    side_effect=OSError("injected storage retrieval failure"),
                ):
            with self.assertRaises(HTTPException) as raised:
                main.get_file(
                    project["id"],
                    "myanmar.mp4",
                    request(method="HEAD"),
                )

        self.assertEqual(raised.exception.status_code, 503)
        self.assertEqual(
            raised.exception.detail,
            "Export storage is unavailable. Try again shortly.",
        )

    def test_app_storage_head_checks_object_without_downloading_it(self):
        project = {
            "id": "lightweight-head-project",
            "status": "completed",
            "progress": 100,
            "objectPrefix": "studio/lightweight-head-project",
            "exports": [{
                "language": "myanmar",
                "videoFilename": "final.mp4",
            }],
        }
        sdk_client = Mock()
        sdk_client.exists.return_value = True
        media = storage.AppStorageClient(client=sdk_client)
        with patch.object(main.store, "connection", return_value=nullcontext(Mock())), \
                patch.object(main, "project_or_404", return_value=project), \
                patch.object(main, "storage_client", return_value=media):
            response = main.get_file(
                project["id"],
                "myanmar.mp4",
                request(method="HEAD"),
            )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers["content-type"], "video/mp4")
        self.assertEqual(response.headers["accept-ranges"], "bytes")
        self.assertNotIn("content-length", response.headers)
        sdk_client.exists.assert_called_once_with(
            "studio/lightweight-head-project/final.mp4"
        )
        sdk_client.download_to_filename.assert_not_called()

    def test_export_get_surfaces_app_storage_read_failure_after_head_check(self):
        project = {
            "id": "storage-read-failure-project",
            "status": "completed",
            "progress": 100,
            "objectPrefix": "studio/storage-read-failure-project",
            "exports": [{
                "language": "myanmar",
                "videoFilename": "final.mp4",
            }],
        }
        sdk_client = Mock()
        sdk_client.exists.return_value = True
        sdk_client.download_to_filename.side_effect = OSError(
            "injected object retrieval failure"
        )
        with tempfile.TemporaryDirectory() as temporary_root:
            media = storage.AppStorageClient(
                client=sdk_client,
                temporary_root=Path(temporary_root),
            )
            with patch.object(main.store, "connection", return_value=nullcontext(Mock())), \
                    patch.object(main, "project_or_404", return_value=project), \
                    patch.object(main, "storage_client", return_value=media):
                with self.assertRaises(HTTPException) as raised:
                    main.get_file(
                        project["id"],
                        "myanmar.mp4",
                        request(method="GET"),
                    )

        self.assertEqual(raised.exception.status_code, 503)
        sdk_client.exists.assert_called_once_with(
            "studio/storage-read-failure-project/final.mp4"
        )
        sdk_client.download_to_filename.assert_called_once()

    def test_project_rejects_another_workspaces_uploaded_source(self):
        data = ProjectInput(
            title="Private source",
            sourceObjectPath=f"studio/{'a' * 64}/sources/source.mp4",
            rightsConfirmed=True,
        )
        with patch.object(main.store, "connection") as connection:
            with self.assertRaises(HTTPException) as raised:
                main.create_project(data, request(owner="b" * 64))
        self.assertEqual(raised.exception.status_code, 403)
        connection.assert_not_called()

    def test_partial_project_update_preserves_persistent_and_editor_state(self):
        project = {
            "id": "persistent-project",
            "title": "Persistent project",
            "status": "draft",
            "sourceObjectPath": "",
            "sourceUrl": "",
            "logoObjectPath": "studio/" + "a" * 64 + "/logos/logo.png",
            "transcript": "original transcript",
            "myanmarScript": "မူရင်းစာသား",
            "englishScript": "Original script",
            "blurBoxes": [],
            "subtitleBox": None,
            "events": [],
        }
        project["sourceObjectPath"] = "studio/" + "a" * 64 + "/sources/source.mp4"
        conn = Mock()
        with patch.object(main.store, "connection", return_value=nullcontext(conn)), \
                patch.object(main, "project_or_404", return_value=project), \
                patch.object(main.store, "save") as save:
            result = main.update_project(
                project["id"],
                ProjectUpdate(logoObjectPath=project["logoObjectPath"]),
                request(owner="a" * 64),
            )

        self.assertEqual(result["id"], project["id"])
        self.assertEqual(project["sourceObjectPath"], "studio/" + "a" * 64 + "/sources/source.mp4")
        self.assertEqual(project["myanmarScript"], "မူရင်းစာသား")
        self.assertEqual(project["englishScript"], "Original script")
        self.assertEqual(project["logoObjectPath"], "studio/" + "a" * 64 + "/logos/logo.png")
        save.assert_called_once()

    def test_stale_script_revision_cannot_overwrite_dialogue(self):
        dialogue = [{
            "id": "line-1",
            "speaker": "A",
            "start": 0.0,
            "end": 1.0,
            "sourceText": "Original line",
        }]
        project = {
            "id": "revision-project",
            "title": "Revision project",
            "status": "draft",
            "sourceUrl": "",
            "transcript": "Original line",
            "dialogue": dialogue,
            "myanmarScript": "မြန်မာစာသား",
            "englishScript": "English script",
            "_scriptUpdatedAt": 200,
            "events": [],
            "exports": [],
        }
        stale_dialogue = [{
            "id": "line-1",
            "speaker": "A",
            "start": 0.0,
            "end": 1.0,
            "sourceText": "Stale line",
        }]
        conn = Mock()
        with patch.object(main.store, "connection", return_value=nullcontext(conn)), \
                patch.object(main, "project_or_404", return_value=project), \
                patch.object(main.store, "save"):
            main.update_project(
                project["id"],
                ProjectUpdate(
                    transcript="Stale transcript",
                    dialogue=stale_dialogue,
                    scriptUpdatedAt=100,
                ),
                request(owner="a" * 64),
            )

        self.assertEqual(project["transcript"], "Original line")
        self.assertEqual(project["dialogue"][0]["sourceText"], "Original line")

    def test_transcript_dialogue_mismatch_clears_timing_and_marks_exports_stale(self):
        dialogue = [{
            "id": "line-1",
            "speaker": "A",
            "start": 0.0,
            "end": 1.0,
            "sourceText": "Old line",
        }]
        project = {
            "id": "mismatch-project",
            "title": "Mismatch project",
            "status": "completed",
            "sourceUrl": "",
            "transcript": "Old line",
            "dialogue": dialogue,
            "myanmarScript": "Old Burmese",
            "englishScript": "Old English",
            "_scriptUpdatedAt": 10,
            "exports": [{"language": "myanmar"}],
            "viralHookTitle": "Old title",
            "viralCaption": "Old caption",
            "viralTitles": ["Old title"],
            "viralHashtags": ["#old"],
            "events": [],
        }
        conn = Mock()
        with patch.object(main.store, "connection", return_value=nullcontext(conn)), \
                patch.object(main, "project_or_404", return_value=project), \
                patch.object(main.store, "save"):
            main.update_project(
                project["id"],
                ProjectUpdate(
                    transcript="New line",
                    dialogue=dialogue,
                    myanmarScript="New Burmese",
                    englishScript="New English",
                    scriptUpdatedAt=20,
                ),
                request(owner="a" * 64),
            )

        self.assertEqual(project["dialogue"], [])
        self.assertTrue(project["exportsStale"])
        self.assertEqual(project["viralHookTitle"], "")
        self.assertEqual(project["viralHashtags"], [])

    def test_speaker_labelled_transcript_preserves_edited_dialogue_timing(self):
        dialogue = [{
            "id": "line-1",
            "speaker": "A",
            "start": 0.0,
            "end": 1.0,
            "sourceText": "Edited line",
        }]
        project = {
            "id": "labelled-transcript-project",
            "title": "Labelled transcript project",
            "status": "completed",
            "sourceUrl": "",
            "transcript": "[A] Original line",
            "dialogue": [{
                **dialogue[0],
                "sourceText": "Original line",
            }],
            "myanmarScript": "Old Burmese",
            "englishScript": "Old English",
            "_scriptUpdatedAt": 10,
            "exports": [{"language": "myanmar"}],
            "events": [],
        }
        conn = Mock()
        with patch.object(main.store, "connection", return_value=nullcontext(conn)), \
                patch.object(main, "project_or_404", return_value=project), \
                patch.object(main.store, "save"):
            main.update_project(
                project["id"],
                ProjectUpdate(
                    transcript="[A] Edited line",
                    dialogue=dialogue,
                    scriptUpdatedAt=20,
                ),
                request(owner="a" * 64),
            )

        self.assertEqual(project["transcript"], "[A] Edited line")
        self.assertEqual(project["dialogue"][0]["sourceText"], "Edited line")
        self.assertEqual(project["dialogue"][0]["start"], 0.0)
        self.assertEqual(project["dialogue"][0]["end"], 1.0)


if __name__ == "__main__":
    unittest.main()