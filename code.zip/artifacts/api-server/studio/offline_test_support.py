"""Fail-closed network guard shared by the Studio's offline tests."""
from __future__ import annotations

import socket
from threading import Lock


_lock = Lock()
_blocked_operations: list[str] = []
_guard_installed = False


class OfflineNetworkAttempt(RuntimeError):
    """Raised when a test reaches an unmocked network boundary."""


def _blocked(operation: str):
    def deny(*_args, **_kwargs):
        with _lock:
            _blocked_operations.append(operation)
        raise OfflineNetworkAttempt(
            f"External network access is disabled in Studio tests ({operation})."
        )

    return deny


def install_network_guard() -> None:
    """Block network sockets, DNS, and PostgreSQL connections in offline tests."""
    global _guard_installed
    if _guard_installed:
        return

    for method in ("connect", "connect_ex", "sendto", "sendmsg"):
        setattr(socket.socket, method, _blocked(f"socket.{method}"))
    for method in (
        "create_connection",
        "getaddrinfo",
        "gethostbyname",
        "gethostbyname_ex",
        "gethostbyaddr",
    ):
        setattr(socket, method, _blocked(f"socket.{method}"))
    try:
        import psycopg
    except ImportError:
        pass
    else:
        # libpq may use native sockets rather than Python's socket methods, so
        # block the connector itself while preserving the selected backend.
        psycopg.connect = _blocked("psycopg.connect")
    _guard_installed = True


def blocked_network_operations() -> tuple[str, ...]:
    """Return operation names only; never retain hosts, URLs, or credentials."""
    with _lock:
        return tuple(_blocked_operations)