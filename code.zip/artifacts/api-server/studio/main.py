"""FastAPI studio API and a single-process, persistent APScheduler work queue."""
import asyncio
import errno
import logging
import math
import os
import re
import secrets
import socket
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from apscheduler.schedulers.background import BackgroundScheduler
from fastapi import FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response, StreamingResponse
from starlette.background import BackgroundTask

from . import store
from .storage import storage_client
from .models import (
    ProjectInput,
    ProjectUpdate,
    RunInput,
    ScheduleInput,
    UploadCleanupInput,
    SettingsInput,
    ViralIngestInput,
    ViralSearchInput,
)
from .viral_finder import ViralFinderError, download_source, search_sources

log = logging.getLogger("studio")
logging.basicConfig(level=logging.INFO)
scheduler = BackgroundScheduler(timezone="UTC")
pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="video-engine")
busy = threading.Lock()
ACTIVE = {"queued", "processing"}
CLEAN_THUMBNAIL_VERSION = 2
SCRIPT_FIELDS = {"transcript", "dialogue", "myanmarScript", "englishScript"}
EXPORT_INVALIDATING_FIELDS = SCRIPT_FIELDS | {
    "globalEdit",
    "blurBoxes",
    "subtitleBox",
    "maskStyle",
    "subtitleStyle",
    "originalAudioVolume",
    "subtitleFontSize",
    "subtitleMarginV",
    "subtitleFontFamily",
    "subtitleBold",
    "timingOffset",
    "narrationStartSeconds",
    "narrationDurationSeconds",
    "storyEndSeconds",
    "narrationSpeed",
    "subtitleAlignment",
    "logoObjectPath",
    "logoPosition",
    "logoX",
    "logoY",
    "logoScale",
    "watermarkText",
    "backgroundMusicObjectPath",
    "backgroundMusicVolume",
    "sfxObjectPath",
    "sfxVolume",
    "narrationDucking",
    "videoTransform",
    "targetDurationMinutes",
}


def _validate_story_end_boundary(values, project):
    if "storyEndSeconds" not in values or values["storyEndSeconds"] is None:
        return
    try:
        story_end = float(values["storyEndSeconds"])
        source_duration = float(
            project.get("sourceDuration") or project.get("duration") or 0
        )
    except (TypeError, ValueError) as exc:
        raise HTTPException(422, "The story-end boundary is invalid.") from exc
    if not math.isfinite(story_end) or not math.isfinite(source_duration):
        raise HTTPException(422, "The story-end boundary is invalid.")
    if source_duration <= 0:
        raise HTTPException(
            409,
            "Process the source video before setting a story-end boundary.",
        )
    if story_end <= 0 or story_end > source_duration + 0.01:
        raise HTTPException(
            422,
            "The story-end boundary must fall within the source video.",
        )


def _invalidate_generated_assets(project):
    project["exportsStale"] = True
    project["storyTimeline"] = []
    project["viralHookTitle"] = ""
    project["viralCaption"] = ""
    project["viralTitles"] = []
    project["viralHashtags"] = []


def _integer_version(project, key):
    try:
        return max(0, int(project.get(key) or 0))
    except (TypeError, ValueError):
        return 0


def _ensure_project_number(conn, project, owner):
    """Backfill legacy projects while keeping the number durable after reopen."""
    try:
        project_number = int(project.get("projectNumber") or 0)
    except (TypeError, ValueError):
        project_number = 0
    if project_number > 0:
        return project
    project["projectNumber"] = store.next_sequence(conn, "project")
    store.save(conn, owner, "project", project)
    return project


def _assign_export_sequences(conn, owner, project):
    """Assign persistent SRT numbers only after the export assets exist."""
    exports = project.get("exports")
    if not isinstance(exports, list):
        return
    changed = False
    for export in exports:
        if not isinstance(export, dict):
            continue
        if not any(
            str(export.get(field) or "").strip()
            for field in ("videoUrl", "downloadUrl", "subtitleUrl")
        ):
            continue
        try:
            sequence = int(export.get("srtSequence") or 0)
        except (TypeError, ValueError):
            sequence = 0
        if sequence <= 0:
            export["srtSequence"] = store.next_sequence(conn, "srt")
            changed = True
    if changed:
        store.save(conn, owner, "project", project)


def _changed_fields(project, values, fields):
    return {
        field
        for field in fields
        if field in values and values[field] != project.get(field)
    }


def _exports_match_current_script(project):
    exports = project.get("exports")
    if not isinstance(exports, list) or not exports:
        return False
    current_script_version = _integer_version(project, "scriptVersion")
    for export in exports:
        if not isinstance(export, dict):
            return False
        if "scriptVersion" not in export:
            # Legacy exports predate version metadata. Preserve their existing
            # usability until the user changes the script/settings. If this
            # project is already stale, however, a legacy entry cannot prove
            # that it was regenerated for the current version.
            if project.get("exportsStale"):
                return False
            continue
        if _integer_version(export, "scriptVersion") != current_script_version:
            return False
    return True


def _script_fields_changed(project, values):
    return any(
        field in values and values[field] != project.get(field)
        for field in SCRIPT_FIELDS
    )


def project_or_404(conn, owner, id, lock=False):
    project = store.get(conn, owner, "project", id, lock=lock)
    if not project:
        raise HTTPException(404, "Project not found.")
    _ensure_project_number(conn, project, owner)
    _assign_export_sequences(conn, owner, project)
    return project


def _public_percent_box(raw_box, include_strength=False):
    if not isinstance(raw_box, dict):
        return None
    try:
        values = {}
        for current, legacy in (
            ("xPercent", "x"),
            ("yPercent", "y"),
            ("widthPercent", "width"),
            ("heightPercent", "height"),
        ):
            raw_value = raw_box.get(current)
            if raw_value is None:
                raw_value = float(raw_box.get(legacy, 0.0) or 0.0) * 100.0
            values[current] = float(raw_value)
        if not all(math.isfinite(value) for value in values.values()):
            return None
        values["id"] = str(raw_box.get("id") or "")
        if include_strength:
            try:
                values["strength"] = min(50, max(5, int(raw_box.get("strength", 20))))
            except (TypeError, ValueError):
                values["strength"] = 20
        return values
    except (TypeError, ValueError):
        return None


def _normalize_dialogue_records(raw_dialogue, source_duration=0.0):
    """Normalize provider/legacy dialogue and expose review/timing warnings."""
    if not isinstance(raw_dialogue, list):
        return []
    try:
        duration = max(0.0, float(source_duration or 0))
    except (TypeError, ValueError):
        duration = 0.0
    result = []
    previous_end = None
    for index, raw in enumerate(raw_dialogue):
        if not isinstance(raw, dict):
            continue
        try:
            start = max(0.0, float(raw.get("start", 0) or 0))
            end = max(0.0, float(raw.get("end", 0) or 0))
        except (TypeError, ValueError):
            continue
        source_text = str(raw.get("sourceText") or raw.get("text") or "").strip()
        if not source_text or end <= start:
            continue
        warnings = []
        if end - start < 0.25:
            warnings.append("short")
        if end - start > 30:
            warnings.append("long")
        if previous_end is not None and start < previous_end - 0.01:
            warnings.append("overlap")
        if duration > 0 and end > duration + 0.01:
            warnings.append("outside-source")
        if previous_end is not None and start - previous_end > 8:
            warnings.append("large-gap")
        line_id = str(raw.get("id") or f"line_{index + 1:03d}")
        line_id = re.sub(r"[^A-Za-z0-9_-]", "_", line_id)[:64] or f"line_{index + 1:03d}"
        item = {
            "id": line_id,
            "speaker": re.sub(r"[^A-Za-z0-9_-]", "", str(raw.get("speaker") or "A"))[:32] or "A",
            "start": round(start, 3),
            "end": round(end, 3),
            "sourceText": source_text,
            "reviewRequired": "[听不清]" in source_text,
            "timingWarning": warnings,
            "translationFallback": bool(raw.get("translationFallback", False)),
        }
        for key in ("myanmarText", "englishText"):
            value = str(raw.get(key) or "").strip()
            if value:
                item[key] = value
        result.append(item)
        previous_end = end
    return result


def _validate_dialogue_records(raw_dialogue, source_duration=0.0):
    normalized = _normalize_dialogue_records(raw_dialogue, source_duration)
    if len(normalized) != len(raw_dialogue or []):
        raise HTTPException(400, "Each transcript line needs text and a valid start/end time.")
    ids = [line["id"] for line in normalized]
    if len(ids) != len(set(ids)):
        raise HTTPException(400, "Transcript line IDs must be unique.")
    if source_duration and any(
        line["end"] > float(source_duration) + 0.01 for line in normalized
    ):
        raise HTTPException(400, "A transcript end time cannot exceed the source video duration.")
    return normalized


def public_project(project):
    public = {
        k: v for k, v in project.items()
        if not k.startswith("_") and k not in {
            "objectPrefix", "exportObjectPrefixes", "sourceObjectPath", "logoObjectPath",
            "backgroundMusicObjectPath", "sfxObjectPath",
        }
    }
    public["id"] = str(public.get("id") or "")
    public["title"] = str(public.get("title") or "Untitled project")[:160]
    try:
        public["projectNumber"] = max(0, int(project.get("projectNumber") or 0))
    except (TypeError, ValueError):
        public["projectNumber"] = 0
    public["sourceUrl"] = str(public.get("sourceUrl") or "")
    public["status"] = str(public.get("status") or "draft")
    public["stage"] = str(public.get("stage") or "Not started")
    public["createdAt"] = str(public.get("createdAt") or "")
    public["updatedAt"] = str(public.get("updatedAt") or "")
    public["scriptUpdatedAt"] = int(project.get("_scriptUpdatedAt") or 0)
    public["exportsStale"] = bool(project.get("exportsStale", False))
    public["scriptVersion"] = _integer_version(project, "scriptVersion")
    public["processingVersion"] = _integer_version(project, "processingVersion")
    public["outputVersion"] = _integer_version(project, "outputVersion")
    public["lastSuccessfulProcessingVersion"] = _integer_version(
        project,
        "lastSuccessfulProcessingVersion",
    )
    public["lastRequestedQuality"] = (
        project.get("lastRequestedQuality")
        if project.get("lastRequestedQuality") in {"720p", "1080p", "original"}
        else "1080p"
    )
    public["transcript"] = str(public.get("transcript") or "")
    try:
        public["sourceDuration"] = max(0.0, float(project.get("sourceDuration", 0) or 0))
    except (TypeError, ValueError):
        public["sourceDuration"] = 0.0
    public["dialogue"] = _normalize_dialogue_records(
        project.get("dialogue"),
        public["sourceDuration"],
    )
    public["myanmarScript"] = str(public.get("myanmarScript") or "")
    public["englishScript"] = str(public.get("englishScript") or "")
    public["storyTimeline"] = (
        public["storyTimeline"] if isinstance(public.get("storyTimeline"), list) else []
    )
    public["globalEdit"] = str(public.get("globalEdit") or "none")
    public["error"] = str(public.get("error") or "")
    public["errorDetails"] = str(public.get("errorDetails") or "")
    public["errorStage"] = str(public.get("errorStage") or "")
    public["errorCode"] = str(public.get("errorCode") or "")
    try:
        public["progress"] = min(100, max(0, float(public.get("progress", 0) or 0)))
    except (TypeError, ValueError):
        public["progress"] = 0
    if not isinstance(public.get("exports"), list):
        public["exports"] = []
    if not isinstance(public.get("events"), list):
        public["events"] = []
    if not isinstance(public.get("blurBoxes"), list):
        legacy_boxes = []
        try:
            top = float(public.get("blurTop", 0.0) or 0.0)
            bottom = float(public.get("blurBottom", 0.0) or 0.0)
        except (TypeError, ValueError):
            top, bottom = 0.0, 0.0
        if top > 0:
            legacy_boxes.append({
                "id": "legacy-top", "x": 0.0, "y": 0.0, "width": 1.0, "height": top,
            })
        if bottom > 0:
            legacy_boxes.append({
                "id": "legacy-bottom", "x": 0.0, "y": 1.0 - bottom, "width": 1.0, "height": bottom,
            })
        public["blurBoxes"] = legacy_boxes
    public.pop("blurTop", None)
    public.pop("blurBottom", None)
    public["blurBoxes"] = [
        normalized
        for box in public.get("blurBoxes", [])
        if (normalized := _public_percent_box(box, include_strength=True)) is not None
    ]
    # Keep the normalized subtitle geometry visible to the editor so the
    # preview, persisted project, and export use the same coordinates.
    if public.get("subtitleBox") is not None and not isinstance(public["subtitleBox"], dict):
        public["subtitleBox"] = None
    elif public.get("subtitleBox") is not None:
        public["subtitleBox"] = _public_percent_box(public["subtitleBox"])
    if not isinstance(public.get("subtitleStyle"), dict):
        public["subtitleStyle"] = {
            "preset": "clean-white",
            "primaryColor": "#FFFFFF",
            "outlineColor": "#000000",
            "outlineWidth": 4,
            "shadowOpacity": 75,
        }
    elif "shadowOpacity" not in public["subtitleStyle"]:
        public["subtitleStyle"]["shadowOpacity"] = 75
    if (
        isinstance(public.get("subtitleStyle"), dict)
        and public["subtitleStyle"].get("preset") == "clean-white"
    ):
        public["subtitleStyle"]["outlineWidth"] = 4
    public.setdefault("originalAudioVolume", 0.0)
    try:
        public["originalAudioVolume"] = min(
            0.05,
            max(0.0, float(public["originalAudioVolume"])),
        )
    except (TypeError, ValueError):
        public["originalAudioVolume"] = 0.0
    try:
        raw_font_size = int(public.get("subtitleFontSize", 32))
        public["subtitleFontSize"] = min(120, max(12, raw_font_size))
    except (TypeError, ValueError):
        public["subtitleFontSize"] = 32
    try:
        raw_margin_v = int(public.get("subtitleMarginV", 160))
        # Migrate the former 45–60px output-space setting to the new
        # 1080x1920 reference-space MarginV contract.
        public["subtitleMarginV"] = (
            160 if raw_margin_v < 80 else min(240, max(80, raw_margin_v))
        )
    except (TypeError, ValueError):
        public["subtitleMarginV"] = 160
    public["subtitleAlignment"] = (
        project.get("subtitleAlignment")
        if project.get("subtitleAlignment") in {"left", "center", "right"}
        else "center"
    )
    public["subtitleFontFamily"] = "Noto Sans Myanmar"
    public["subtitleBold"] = bool(project.get("subtitleBold", True))
    try:
        public["timingOffset"] = min(
            30.0,
            max(-30.0, float(project.get("timingOffset", 0.0) or 0.0)),
        )
    except (TypeError, ValueError):
        public["timingOffset"] = 0.0
    public["viralTitles"] = (
        public["viralTitles"] if isinstance(public.get("viralTitles"), list) else []
    )
    public["viralHookTitle"] = str(public.get("viralHookTitle") or "")
    public["viralCaption"] = str(public.get("viralCaption") or "")
    public["viralHashtags"] = (
        public["viralHashtags"] if isinstance(public.get("viralHashtags"), list) else []
    )
    checkpoint = project.get("pipelineCheckpoint")
    public["pipelineCheckpoint"] = (
        checkpoint if isinstance(checkpoint, dict) else {"version": 1, "stages": {}}
    )
    public["pipelineCheckpoint"].setdefault("version", 1)
    public["pipelineCheckpoint"].setdefault("stages", {})
    if isinstance(public.get("exports"), list):
        for export in public["exports"]:
            if isinstance(export, dict):
                language = str(export.get("language") or "")
                export.setdefault(
                    "thumbnailUrl",
                    f"/api/studio/projects/{project.get('id', '')}/files/{language}.jpg",
                )
                export.setdefault(
                    "downloadUrl",
                    f"/api/download/video?projectId={project.get('id', '')}&language={language}",
                )
                export.setdefault(
                    "capcutVideoUrl",
                    (
                        f"/api/download/capcut-video?projectId={project.get('id', '')}"
                        f"&language={language}"
                        if export.get("capcutVideoFilename")
                        else ""
                    ),
                )
                export.setdefault(
                    "thumbnailDownloadUrl",
                    f"/api/download/thumbnail?projectId={project.get('id', '')}&language={language}",
                )
                if export.get("metadataFilename"):
                    export.setdefault(
                        "metadataUrl",
                        f"/api/studio/projects/{project.get('id', '')}/files/{language}-metadata.json",
                    )
                if export.get("packageFilename"):
                    export.setdefault(
                        "packageUrl",
                        f"/api/studio/projects/{project.get('id', '')}/files/{language}-export.zip",
                    )
    public["maskStyle"] = (
        project.get("maskStyle")
        if project.get("maskStyle") in {"dark-translucent", "light-translucent", "clean-boxblur"}
        else "clean-boxblur"
    )
    public["hasLogo"] = bool(project.get("logoObjectPath"))
    position = project.get("logoPosition")
    public["logoPosition"] = position if position in {"top-right", "top-left", "bottom-right"} else "top-right"
    def bounded_float(key, default, minimum=None, maximum=None):
        try:
            value = float(project.get(key, default) or default)
        except (TypeError, ValueError):
            value = default
        if not math.isfinite(value):
            value = default
        if minimum is not None:
            value = max(minimum, value)
        if maximum is not None:
            value = min(maximum, value)
        return value

    public["logoX"] = bounded_float("logoX", 0.75, 0.0, 1.0)
    public["logoY"] = bounded_float("logoY", 0.05, 0.0, 1.0)
    public["logoScale"] = bounded_float("logoScale", 0.22, 0.05, 0.5)
    public["watermarkText"] = str(project.get("watermarkText") or "")
    public["narrationStartSeconds"] = max(
        0.5,
        float(public.get("narrationStartSeconds", 0.5) or 0.5),
    )
    public.setdefault("narrationDurationSeconds", None)
    public.setdefault("storyEndSeconds", None)
    try:
        public["narrationSpeed"] = min(
            1.5,
            max(0.8, float(public.get("narrationSpeed", 1.0))),
        )
    except (TypeError, ValueError):
        public["narrationSpeed"] = 1.0
    if not isinstance(public.get("videoTransform"), dict):
        public["videoTransform"] = {"scale": 1.0, "zoom": 1.0, "x": 0.0, "y": 0.0}
    target_duration = project.get("targetDurationMinutes")
    public["targetDurationMinutes"] = (
        int(target_duration) if target_duration in {3, 5, 8, 10} else None
    )
    return public


def _unavailable_public_project(project, record_id=None):
    """Return a schema-shaped card for a corrupt snapshot record."""
    raw_id = record_id or (project.get("id") if isinstance(project, dict) else None)
    project_id = str(raw_id or f"unavailable-{uuid.uuid4().hex}")
    title = (
        str(project.get("title") or "Unavailable project")[:160]
        if isinstance(project, dict)
        else "Unavailable project"
    )
    return {
        "id": project_id,
        "title": title,
        "sourceUrl": "",
        "status": "unavailable",
        "stage": "Project metadata unavailable",
        "progress": 0,
        "createdAt": "",
        "updatedAt": "",
        "scriptUpdatedAt": 0,
        "exportsStale": False,
        "scriptVersion": 0,
        "processingVersion": 0,
        "outputVersion": 0,
        "lastSuccessfulProcessingVersion": 0,
        "lastRequestedQuality": "1080p",
        "transcript": "",
        "myanmarScript": "",
        "englishScript": "",
        "globalEdit": "none",
        "blurBoxes": [],
        "subtitleBox": None,
        "maskStyle": "clean-boxblur",
        "subtitleStyle": {
            "preset": "clean-white",
            "primaryColor": "#FFFFFF",
            "outlineColor": "#000000",
            "outlineWidth": 4,
            "shadowOpacity": 75,
        },
        "originalAudioVolume": 0,
        "subtitleFontSize": 32,
        "subtitleMarginV": 160,
        "subtitleFontFamily": "Noto Sans Myanmar",
        "subtitleBold": True,
        "timingOffset": 0.0,
        "narrationStartSeconds": 0.5,
        "narrationDurationSeconds": None,
        "storyEndSeconds": None,
        "narrationSpeed": 1.0,
        "subtitleAlignment": "center",
        "targetDurationMinutes": None,
        "hasLogo": False,
        "logoPosition": "top-right",
        "logoX": 0.75,
        "logoY": 0.05,
        "logoScale": 0.22,
        "watermarkText": "",
        "hasBackgroundMusic": False,
        "hasSfx": False,
        "backgroundMusicVolume": 0,
        "sfxVolume": 0,
        "narrationDucking": 0.8,
        "videoTransform": {"scale": 1, "zoom": 1, "x": 0, "y": 0},
        "viralHookTitle": "",
        "viralCaption": "",
        "viralTitles": [],
        "viralHashtags": [],
        "duration": 0,
        "error": "Project metadata is unavailable. Try again later.",
        "errorDetails": "Project metadata is unavailable. Try again later.",
        "errorStage": "",
        "errorCode": "PROJECT_UNAVAILABLE",
        "pipelineCheckpoint": {"version": 1, "stages": {}},
        "exports": [],
        "events": [],
    }


def safe_public_project(project, record_id=None):
    """Normalize one record without allowing it to break the whole library."""
    try:
        if not isinstance(project, dict) or not project.get("id"):
            raise ValueError("record has no project id")
        return public_project(project)
    except Exception:
        log.warning(
            "Project record normalization failed project_id=%s type=%s",
            record_id,
            type(project).__name__,
        )
        return _unavailable_public_project(project, record_id)


def _disk_project_records(owner):
    """Read only projects owned by this workspace from the recovery snapshot."""
    return [
        project
        for project, _record_owner in store.disk_records(kind="project", owner=owner)
    ]


def _cleanup_unpublished_export_prefixes(result):
    """Remove media uploaded by a worker that could not publish its result."""
    if not isinstance(result, dict):
        return
    prefixes = result.get("exportObjectPrefixes") or {}
    if not isinstance(prefixes, dict):
        return
    try:
        storage = storage_client()
    except Exception:
        return
    for raw_prefix in set(prefixes.values()):
        prefix = str(raw_prefix or "").strip()
        if not prefix:
            continue
        try:
            storage.delete_prefix(prefix)
        except FileNotFoundError:
            continue
        except Exception:
            log.warning(
                "Unpublished export cleanup failed prefix=%s",
                prefix,
                exc_info=True,
            )


def _public_project_list(records):
    return [
        safe_public_project(
            project,
            project.get("id") if isinstance(project, dict) else None,
        )
        for project in records
    ]


def readiness(conn, owner):
    values = {k: v for k, v in store.settings(conn, owner).items() if k != "id"}
    ai_provider_ready = bool(
        os.environ.get("GEMINI_API_KEY") or os.environ.get("GEMINI_API_KEY2")
    )
    return {**values,
            # Transcription can use local timing cues, but Burmese recap
            # generation remains explicitly blocked until Gemini is configured.
            "assemblyAiReady": True,
            "translationReady": ai_provider_ready,
            "translationProviderReady": ai_provider_ready,
            "translationMode": (
                "Gemini audio + Burmese recap"
                if ai_provider_ready
                else "Gemini key required for Burmese recap"
            ),
            "storageReady": True,
            "tiktokConnected": False, "schedulerRunning": scheduler.running}


def check_requirements(project, action):
    # Provider readiness is checked by the engine so each job receives a
    # specific, fail-closed error instead of writing fabricated content.
    if action in {
        "full", "transcribe", "export", "export_english", "export_capcut", "test_export"
    }:
        if not str(project.get("sourceObjectPath") or "").strip() and not str(project.get("sourceUrl") or "").strip():
            raise HTTPException(400, "Upload a video or provide a direct HTTPS source URL before exporting.")
    if action == "translate" and not project["transcript"].strip():
        raise HTTPException(400, "Transcribe the video or save a transcript first.")
    if action in {"export", "export_capcut"} and not project["myanmarScript"].strip():
        raise HTTPException(400, "Save the Burmese script before exporting the Burmese video.")
    if action == "export_english" and not project["englishScript"].strip():
        raise HTTPException(400, "Save the English script before exporting the English video.")


MAX_UPLOAD_BYTES = 500 * 1024 * 1024
MIN_FREE_DISK_BYTES = 250 * 1024 * 1024
UPLOAD_CHUNK_BYTES = 1024 * 1024
MAX_LOGO_BYTES = 5 * 1024 * 1024
MAX_AUDIO_BYTES = 50 * 1024 * 1024
ALLOWED_UPLOAD_SUFFIXES = {".mp4", ".mov", ".mkv", ".webm"}
ALLOWED_AUDIO_SUFFIXES = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"}
TEMP_MEDIA_PREFIXES = (
    "recap-upload-",
    "recap-logo-",
    "recap-audio-",
    "recap-viral-",
    "recap-source-preview-",
    "recap-logo-preview-",
    "recap-download-",
    "recap-storage-download-",
)
TEMP_JOB_ROOT = Path(tempfile.gettempdir()) / "recap-studio-jobs"
TEMP_CLEANUP_MAX_AGE_SECONDS = 24 * 60 * 60
_temporary_media_lock = threading.RLock()
_active_temporary_paths: set[Path] = set()


def _track_temporary_path(path: Path) -> None:
    with _temporary_media_lock:
        _active_temporary_paths.add(path.resolve())


def _untrack_temporary_path(path: Path) -> None:
    with _temporary_media_lock:
        _active_temporary_paths.discard(path.resolve())


def _temporary_path_is_active(path: Path) -> bool:
    resolved = path.resolve()
    with _temporary_media_lock:
        return any(
            resolved == active
            or active in resolved.parents
            or resolved in active.parents
            for active in _active_temporary_paths
        )


def _free_disk_bytes(path: Path | None = None) -> int:
    return int(shutil.disk_usage(str(path or tempfile.gettempdir())).free)


def _disk_full_error(additional_bytes: int = 0) -> HTTPException:
    if additional_bytes:
        return HTTPException(
            507,
            "Disk storage full. Keep at least 250 MB free before uploading another video.",
        )
    return HTTPException(
        507,
        "Disk storage full. Free at least 250 MB and try again.",
    )


def _ensure_free_disk_space(additional_bytes: int = 0) -> None:
    try:
        free = _free_disk_bytes()
    except OSError as exc:
        raise HTTPException(507, "Disk storage could not be checked. Try again.") from exc
    if free < MIN_FREE_DISK_BYTES + max(0, int(additional_bytes)):
        raise _disk_full_error(additional_bytes)


def _prune_temporary_media() -> int:
    """Delete only old app-owned temporary media and never active paths."""
    candidates: list[Path] = []
    temporary_root = Path(tempfile.gettempdir())
    for prefix in TEMP_MEDIA_PREFIXES:
        candidates.extend(temporary_root.glob(f"{prefix}*"))
    if TEMP_JOB_ROOT.exists():
        candidates.extend(
            path for path in TEMP_JOB_ROOT.iterdir() if path.is_dir()
        )

    deleted = 0
    with _temporary_media_lock:
        for candidate in candidates:
            if _temporary_path_is_active(candidate):
                continue
            try:
                if time.time() - candidate.stat().st_mtime < TEMP_CLEANUP_MAX_AGE_SECONDS:
                    continue
            except FileNotFoundError:
                continue
            try:
                if candidate.is_dir():
                    shutil.rmtree(candidate, ignore_errors=False)
                else:
                    candidate.unlink(missing_ok=True)
                deleted += 1
            except FileNotFoundError:
                continue
            except OSError as exc:
                log.warning(
                    "Temporary media cleanup skipped path=%s errno=%s",
                    candidate.name,
                    getattr(exc, "errno", None),
                )
    if deleted:
        log.info("Temporary media cleanup deleted=%d", deleted)
    return deleted


def upload_suffix(filename, content_type: str = ""):
    suffix = Path(filename or "").suffix.lower()
    normalized = (content_type or "").split(";", 1)[0].strip().lower()
    if suffix not in ALLOWED_UPLOAD_SUFFIXES and not normalized.startswith("video/"):
        raise HTTPException(400, "Choose an MP4, MOV, MKV, or WebM video file.")
    # FFmpeg detects the actual container from the bytes. A neutral suffix lets
    # mobile browsers with a video MIME and a non-standard filename continue.
    return suffix if suffix in ALLOWED_UPLOAD_SUFFIXES else ".upload"


def upload_content_type_allowed(content_type: str, filename: str = "") -> bool:
    """Accept video/* or a supported extension when mobile MIME is blank/octet."""
    normalized = (content_type or "").split(";", 1)[0].strip().lower()
    suffix = Path(filename or "").suffix.lower()
    return normalized.startswith("video/") or suffix in ALLOWED_UPLOAD_SUFFIXES


def _storage_upload_error(exc: Exception) -> HTTPException:
    detail = str(exc).lower()
    if (
        isinstance(exc, (TimeoutError, socket.timeout, asyncio.TimeoutError))
        or "timeout" in detail
        or "timed out" in detail
        or "connection reset" in detail
    ):
        return HTTPException(
            504,
            "Network timeout while storing the uploaded video. Try again.",
        )
    if (
        isinstance(exc, OSError) and exc.errno == errno.ENOSPC
    ) or "no space left" in detail or "disk storage" in detail:
        return _disk_full_error()
    return HTTPException(503, "Could not store the uploaded video. Try again.")


def normalize_uploaded_video(source: Path, destination: Path) -> None:
    try:
        completed = subprocess.run(
            [
                "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
                "-i", str(source),
                "-map", "0:v:0", "-map", "0:a:0?", "-sn", "-dn",
                "-threads", "2",
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-ar", "48000",
                "-movflags", "+faststart", str(destination),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=900,
            check=False,
        )
    except OSError as exc:
        if exc.errno == errno.ENOSPC:
            raise _disk_full_error() from exc
        raise HTTPException(422, "The uploaded video could not be normalized.") from exc
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(
            504,
            "Video normalization timed out after 15 minutes. Try a shorter video.",
        ) from exc
    if completed.returncode or not destination.is_file() or destination.stat().st_size == 0:
        detail = (completed.stderr or "").lower()
        log.warning(
            "Uploaded video normalization failed returncode=%s stderr=%s",
            completed.returncode,
            detail[:300],
        )
        if (
            "no space left" in detail
            or "error while writing" in detail and "space" in detail
        ):
            raise _disk_full_error()
        if any(
            marker in detail
            for marker in (
                "unknown decoder",
                "unknown encoder",
                "unsupported codec",
                "could not find codec parameters",
                "invalid data found",
                "moov atom not found",
            )
        ):
            raise HTTPException(
                422,
                "Unsupported video codec or corrupt video file.",
            )
        raise HTTPException(
            422,
            "The uploaded video could not be normalized. Check the video codec and file integrity.",
        )


def _requested_byte_range(header: str | None, size: int) -> tuple[int, int] | None:
    """Parse one RFC 7233 byte range, including open and suffix forms."""
    if not header:
        return None
    value = header.strip()
    if not value.startswith("bytes=") or "," in value:
        raise HTTPException(416, "Requested range is not satisfiable.")
    bounds = value[6:].strip()
    if bounds.count("-") != 1:
        raise HTTPException(416, "Requested range is not satisfiable.")
    first, last = (part.strip() for part in bounds.split("-", 1))
    if not first and not last:
        raise HTTPException(416, "Requested range is not satisfiable.")
    if (first and not first.isdecimal()) or (last and not last.isdecimal()):
        raise HTTPException(416, "Requested range is not satisfiable.")
    try:
        if first:
            start = int(first)
            end = int(last) if last else size - 1
            if start < 0 or end < start or start >= size:
                raise ValueError
            return start, min(end, size - 1)
        suffix_length = int(last)
        if suffix_length <= 0 or size <= 0:
            raise ValueError
        return max(0, size - suffix_length), size - 1
    except ValueError as exc:
        raise HTTPException(416, "Requested range is not satisfiable.") from exc


def _iter_file_range(path: Path, start: int, length: int, cleanup_after_response: bool):
    try:
        with path.open("rb") as source:
            source.seek(start)
            remaining = length
            while remaining:
                chunk = source.read(min(1024 * 1024, remaining))
                if not chunk:
                    break
                remaining -= len(chunk)
                yield chunk
    finally:
        if cleanup_after_response:
            path.unlink(missing_ok=True)


def local_media_response(
    path: Path,
    request: Request,
    media_type: str,
    filename: str,
    disposition: str,
    cleanup_after_response: bool = True,
):
    """Serve a temporary local object with browser-compatible byte ranges."""
    size = path.stat().st_size
    safe_filename = Path(filename).name
    ascii_filename = (
        "drama_recap.mp4"
        if media_type == "video/mp4" and disposition == "inline"
        else (
            safe_filename
            if safe_filename.isascii()
            else "download" + Path(safe_filename).suffix
        )
    )
    headers = {
        "Accept-Ranges": "bytes",
        "Content-Disposition": (
            f'{disposition}; filename="{ascii_filename}"; '
            f"filename*=UTF-8''{quote(safe_filename)}"
        ),
    }
    try:
        selected = _requested_byte_range(request.headers.get("range"), size)
    except HTTPException:
        if cleanup_after_response:
            path.unlink(missing_ok=True)
        return Response(
            status_code=416,
            media_type=media_type,
            headers={**headers, "Content-Range": f"bytes */{size}", "Content-Length": "0"},
        )

    start, end, status_code = (0, size - 1, 200) if selected is None else (*selected, 206)
    length = max(0, end - start + 1)
    headers["Content-Length"] = str(length)
    if status_code == 206:
        headers["Content-Range"] = f"bytes {start}-{end}/{size}"
    cleanup = (
        BackgroundTask(path.unlink, missing_ok=True)
        if cleanup_after_response
        else None
    )
    if request.method == "HEAD":
        return Response(
            status_code=status_code,
            media_type=media_type,
            headers=headers,
            background=cleanup,
        )
    return StreamingResponse(
        _iter_file_range(path, start, length, cleanup_after_response),
        status_code=status_code,
        media_type=media_type,
        headers=headers,
        background=cleanup,
    )


def lightweight_head_response(
    media_type: str,
    filename: str,
    disposition: str,
):
    """Return download metadata without staging a large App Storage object."""
    safe_filename = Path(filename).name
    ascii_filename = (
        safe_filename if safe_filename.isascii() else "download" + Path(safe_filename).suffix
    )
    response = Response(
        status_code=200,
        media_type=media_type,
        headers={
            "Accept-Ranges": "bytes",
            "Content-Disposition": (
                f'{disposition}; filename="{ascii_filename}"; '
                f"filename*=UTF-8''{quote(safe_filename)}"
            ),
        },
    )
    # The object length is not available from the App Storage SDK's list/exists
    # response. Do not claim the empty HEAD body is the asset's real length.
    if "content-length" in response.headers:
        del response.headers["content-length"]
    return response


def enqueue(conn, owner, project, action, when, mode, tz, quality="1080p", overrides=None):
    try:
        conn.execute("BEGIN IMMEDIATE")
        current = store.get(
            conn,
            owner,
            "project",
            str(project.get("id") or ""),
            lock=True,
        )
        if not current:
            raise HTTPException(404, "Project not found.")
        if current.get("status") in ACTIVE:
            raise HTTPException(409, "This project already has a queued or running job.")

        # The project may have been loaded before another tab queued a job.
        # Refresh it while holding SQLite's write reservation, then apply this
        # request's explicit editor snapshot.
        submitted_revision = _integer_version(project, "_scriptUpdatedAt")
        project.clear()
        project.update(current)
        if submitted_revision > _integer_version(project, "_scriptUpdatedAt"):
            project["_scriptUpdatedAt"] = submitted_revision

        # Legacy records may predate this editor field. Keep queued snapshots
        # aligned with the public project schema and newly-created projects.
        project["globalEdit"] = str(project.get("globalEdit") or "none")
        overrides = dict(overrides or {})
        effective_project = dict(project)
        effective_project.update(overrides)
        script_changed = _script_fields_changed(project, overrides)
        export_changed = bool(
            _changed_fields(project, overrides, EXPORT_INVALIDATING_FIELDS)
        )
        check_requirements(effective_project, action)
        # Bound total paid/background work even if new anonymous browser sessions are created.
        count = store.count_since(
            conn,
            "schedule",
            datetime.now(timezone.utc) - timedelta(days=1),
        )
        if count >= 30:
            raise HTTPException(429, "Daily processing limit reached (30 jobs). Try again tomorrow.")
        # Persist the exact state used by this job before it is queued. This is
        # atomic with the active-status check and schedule insert.
        project.update(overrides)
        if script_changed:
            project["_scriptUpdatedAt"] = max(
                _integer_version(project, "_scriptUpdatedAt"),
                int(datetime.now(timezone.utc).timestamp() * 1000),
            )
            project["scriptVersion"] = _integer_version(project, "scriptVersion") + 1
        if export_changed:
            _invalidate_generated_assets(project)
        processing_version = _integer_version(project, "processingVersion") + 1
        project["processingVersion"] = processing_version
        project["lastRequestedQuality"] = quality
        schedule = {
            "id": store.uid(), "projectId": project["id"], "projectTitle": project["title"],
            "mode": mode, "scheduledAt": when.isoformat(), "timezone": tz,
            "quality": quality, "attempts": 0,
            "processingVersion": processing_version,
            "scriptVersion": _integer_version(project, "scriptVersion"),
            "status": "scheduled", "_action": action,
            "_projectOverrides": dict(overrides),
        }
        project.update(
            status="queued",
            stage="Scheduled" if when > datetime.now(timezone.utc) else "Queued",
            progress=0,
            error="",
        )
        for field in ("errorDetails", "errorStage", "errorCode"):
            project.pop(field, None)
        store.event(project, f"{action.capitalize()} job queued")
        store.save(conn, owner, "project", project)
        store.save(conn, owner, "schedule", schedule)
        conn.commit()
        try:
            store.persist_committed_records([
                (owner, "project", project),
                (owner, "schedule", schedule),
            ])
        except (OSError, store.SnapshotReadError, RuntimeError):
            log.exception(
                "Recovery snapshot write failed for queued job project_id=%s",
                project["id"],
            )
        return schedule
    except Exception:
        conn.rollback()
        raise


def _provider_operation_callbacks(owner, project_id, job_id):
    def load(operation_key):
        with store.connection() as conn:
            return store.get_provider_operation(conn, owner, operation_key)

    def claim_create(operation_key, record):
        payload = dict(record or {})
        payload.update(
            provider="assemblyai",
            projectId=str(project_id),
            jobId=str(job_id),
        )
        try:
            with store.connection() as conn:
                return store.claim_provider_operation(
                    conn,
                    owner,
                    project_id,
                    operation_key,
                    payload,
                )
        except store.ProviderOperationBlockedError as exc:
            from .engine import EngineError

            raise EngineError(
                "An unresolved AssemblyAI operation already exists for this project.",
                stage="transcription",
                code="ASSEMBLYAI_AMBIGUOUS_CREATE",
                client_message=(
                    "A previous speech transcription may still be running. "
                    "Resolve that provider job before submitting another one."
                ),
            ) from exc

    def save(operation_key, record):
        payload = dict(record or {})
        payload.update(
            provider="assemblyai",
            projectId=str(project_id),
            jobId=str(job_id),
        )
        with store.connection() as conn:
            return store.save_provider_operation(
                conn,
                owner,
                operation_key,
                payload,
            )

    return {
        "load": load,
        "claim_create": claim_create,
        "save": save,
    }


def work(owner, schedule):
    result = None
    try:
        from .engine import process_project
        with store.connection() as conn:
            project = project_or_404(conn, owner, schedule["projectId"])
            settings = store.settings(conn, owner)
        project_overrides = schedule.get("_projectOverrides")
        if not isinstance(project_overrides, dict):
            # Keep older queued jobs compatible with the script-only override
            # format used before the full preview configuration was forwarded.
            project_overrides = schedule.get("_scriptOverrides")
        if isinstance(project_overrides, dict):
            project.update({
                key: value
                for key, value in project_overrides.items()
            })

        def report(stage, progress, patch=None):
            try:
                with store.connection() as conn:
                    current = project_or_404(conn, owner, project["id"], lock=True)
                    current.update(patch or {})
                    if current["stage"] != stage:
                        store.event(current, stage)
                    current.update(stage=stage, progress=progress, status="processing")
                    store.save(conn, owner, "project", current)
            except Exception:
                # A transient progress-save failure must not discard a completed
                # transcription. The worker keeps the result in its local patch
                # and the final save below retries the durable project update.
                log.exception(
                    "Progress state persistence failed; continuing project_id=%s stage=%s",
                    project["id"],
                    stage,
                )

        cache_id = "".join(
            character
            if character.isalnum() or character in "-_"
            else "-"
            for character in str(project["id"])
        )
        export_id = uuid.uuid4().hex
        workdir = TEMP_JOB_ROOT / f"{cache_id}-{export_id}"
        workdir.mkdir(parents=True, exist_ok=True)
        _track_temporary_path(workdir)
        try:
            result = process_project(
                project,
                settings,
                schedule["_action"],
                report,
                workdir,
                quality=str(schedule.get("quality") or "1080p"),
                provider_operations=_provider_operation_callbacks(
                    owner,
                    project["id"],
                    schedule["id"],
                ),
                operation_key_prefix=str(schedule["id"]),
            )
        finally:
            # process_project uploads the final MP4, subtitle, audio, and
            # thumbnail before returning. Always remove the local job
            # directory, including failed jobs, so source videos, TTS files,
            # slices, ASS files, and render passes cannot accumulate.
            shutil.rmtree(workdir, ignore_errors=True)
            _untrack_temporary_path(workdir)
        with store.connection() as conn:
            current = project_or_404(conn, owner, project["id"], lock=True)
            expected_processing_version = int(schedule.get("processingVersion") or 0)
            current_processing_version = _integer_version(current, "processingVersion")
            if (
                expected_processing_version
                and current_processing_version != expected_processing_version
            ):
                _cleanup_unpublished_export_prefixes(result)
                raise RuntimeError(
                    "This processing job is stale and cannot replace a newer project version."
                )
            current.update(result or {})
            _assign_export_sequences(conn, owner, current)
            current.update(status="completed", stage="Ready", progress=100, error="")
            if isinstance(result, dict) and result.get("exports"):
                current["exportsStale"] = not _exports_match_current_script(current)
                current["outputVersion"] = expected_processing_version
                current["lastSuccessfulProcessingVersion"] = expected_processing_version
            for field in ("errorDetails", "errorStage", "errorCode"):
                current.pop(field, None)
            store.event(current, "Processing complete")
            store.save(conn, owner, "project", current)
            schedule["status"] = "completed"
            store.save(conn, owner, "schedule", schedule)
    except Exception as exc:
        _cleanup_unpublished_export_prefixes(result)
        # Engine errors are sanitized; never log provider headers, keys, or source URLs.
        log.exception(
            "Video processing failed type=%s error=%s",
            type(exc).__name__,
            str(exc)[:500],
        )
        message = str(exc)[:500] if isinstance(exc, (ValueError, RuntimeError)) else (
            "Processing failed. Check service credentials and source format, then retry.")
        with store.connection() as conn:
            current = store.get(conn, owner, "project", schedule["projectId"], lock=True)
            if current:
                expected_processing_version = int(schedule.get("processingVersion") or 0)
                if (
                    expected_processing_version
                    and _integer_version(current, "processingVersion")
                    != expected_processing_version
                ):
                    log.warning(
                        "Ignoring stale job failure project_id=%s processing_version=%s",
                        schedule["projectId"],
                        expected_processing_version,
                    )
                    schedule["status"] = "superseded"
                    store.save(conn, owner, "schedule", schedule)
                    return
                error_code = str(getattr(exc, "code", "") or "EXPORT_ERROR")
                error_stage = str(getattr(exc, "stage", "") or "processing")
                client_message = str(
                    getattr(exc, "client_message", "") or message
                )
                current.update(
                    status="failed",
                    stage="Failed",
                    error=client_message,
                    errorDetails=client_message,
                    errorStage=error_stage,
                    errorCode=error_code,
                )
                store.event(current, client_message)
                store.save(conn, owner, "project", current)
            schedule["status"] = "failed"
            store.save(conn, owner, "schedule", schedule)
    finally:
        busy.release()


def dispatch():
    if not busy.acquire(blocking=False):
        return
    try:
        with store.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                due = store.claim_due_schedule(conn)
                if not due:
                    conn.rollback()
                    busy.release()
                    return
                owner, schedule = due
                project = project_or_404(conn, owner, schedule["projectId"], lock=True)
                schedule = store.get(conn, owner, "schedule", schedule["id"], lock=True)
                if not schedule or schedule["status"] != "scheduled":
                    conn.rollback()
                    busy.release()
                    return
                attempts = int(schedule.get("attempts") or 0) + 1
                schedule["attempts"] = attempts
                if attempts > 3:
                    schedule["status"] = "failed"
                    project.update(
                        status="failed",
                        stage="Failed",
                        error="This job was retried three times after worker interruptions.",
                    )
                    store.save(conn, owner, "schedule", schedule)
                    store.save(conn, owner, "project", project)
                    conn.commit()
                    store.persist_committed_records(
                        [(owner, "schedule", schedule), (owner, "project", project)]
                    )
                    busy.release()
                    return
                schedule["status"] = "processing"
                store.save(conn, owner, "schedule", schedule)
                project.update(status="processing", stage="Starting")
                store.save(conn, owner, "project", project)
                conn.commit()
                store.persist_committed_records(
                    [(owner, "schedule", schedule), (owner, "project", project)]
                )
            except Exception:
                if conn.in_transaction:
                    conn.rollback()
                raise
        pool.submit(work, owner, schedule)
    except Exception:
        busy.release()
        log.exception("Background dispatch failed")


def requeue_interrupted_jobs(conn):
    """Make jobs interrupted by a process restart eligible for dispatch again."""
    conn.execute("BEGIN IMMEDIATE")
    rows = store.records_with_status(conn, "schedule", "processing")
    changed = []
    for schedule, owner in rows:
        current_schedule = store.get(
            conn,
            owner,
            "schedule",
            schedule["id"],
            lock=True,
        )
        if not current_schedule or current_schedule.get("status") != "processing":
            continue
        current_schedule["status"] = "scheduled"
        current_schedule["scheduledAt"] = datetime.now(timezone.utc).isoformat()
        current_schedule["attempts"] = int(current_schedule.get("attempts") or 0)
        store.save(conn, owner, "schedule", current_schedule)
        changed.append((owner, "schedule", current_schedule))
        project = store.get(
            conn,
            owner,
            "project",
            current_schedule["projectId"],
            lock=True,
        )
        if project:
            project.update(
                status="queued",
                stage="Queued after server restart",
                error="",
            )
            store.event(project, "Queued after server restart")
            store.save(conn, owner, "project", project)
            changed.append((owner, "project", project))
    conn.commit()
    store.persist_committed_records(changed)


database_degraded = False


@asynccontextmanager
async def lifespan(app):
    # Startup recovery is protected by the selected database transaction. SQLite
    # remains the isolated/local backend; Postgres is authoritative when selected.
    global database_degraded
    guard = None
    _prune_temporary_media()
    try:
        with store.connection() as conn:
            store.initialize_postgres_schema(conn)
            requeue_interrupted_jobs(conn)
        scheduler.add_job(dispatch, "interval", seconds=3, id="dispatch", max_instances=1)
        scheduler.start()
        database_degraded = False
    except store.StoreUnavailableError as exc:
        # Do not substitute the local SQLite snapshot when Postgres is selected:
        # that would expose stale records from a second source of truth.
        database_degraded = True
        log.exception(
            "Project database unavailable during startup; worker remains stopped: %s",
            type(exc).__name__,
        )
    yield
    if scheduler.running:
        scheduler.shutdown(wait=False)
    pool.shutdown(wait=True)


app = FastAPI(title="Drama Recap Studio", lifespan=lifespan, docs_url="/api/docs", openapi_url="/api/openapi.json")


@app.middleware("http")
async def browser_workspace(request: Request, call_next):
    """Opaque browser workspace, not a user login or shared account system."""
    owner = request.cookies.get("recap_workspace", "")
    fresh = len(owner) != 64 or any(c not in "0123456789abcdef" for c in owner)
    if fresh:
        owner = secrets.token_hex(32)
    request.state.owner = owner
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        origin = request.headers.get("origin")
        if origin and urlsplit(origin).netloc != request.headers.get("host"):
            return JSONResponse({"error": "Cross-site requests are not allowed."}, status_code=403)
    response = await call_next(request)
    if fresh:
        secure = request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https"
        response.set_cookie("recap_workspace", owner, httponly=True,
                            samesite="none" if secure else "lax", secure=secure,
                            max_age=60 * 60 * 24 * 365, path="/")
        # CHIPS keeps the workspace cookie usable in embedded HTTPS previews
        # even when the browser blocks ordinary third-party cookies.
        if secure:
            response.headers["set-cookie"] += "; Partitioned"
    response.headers["Cache-Control"] = "no-store"
    return response


@app.exception_handler(HTTPException)
async def http_error(request, exc):
    return JSONResponse({"error": exc.detail}, status_code=exc.status_code)


@app.exception_handler(store.StoreUnavailableError)
async def store_unavailable_error(request, exc):
    log.warning(
        "Database unavailable method=%s path=%s",
        request.method,
        request.url.path,
    )
    return JSONResponse(
        {
            "The project database is temporarily unavailable. Retry shortly."
        },
        status_code=503,
    )


@app.exception_handler(RequestValidationError)
async def invalid_request(request, exc):
    log.warning(
        "Request validation failed method=%s path=%s errors=%s",
        request.method,
        request.url.path,
        exc.errors(),
    )
    return JSONResponse({"error": "; ".join(e["msg"] for e in exc.errors())}, status_code=422)


@app.get("/api/healthz")
def health():
    degraded = database_degraded
    return JSONResponse(
        {
            "status": "degraded" if degraded else "ok",
            "database": "unavailable" if degraded else "ok",
        },
        status_code=503 if degraded else 200,
    )


@app.get("/api")
def api_root():
    """Return a lightweight deployment health response for the artifact probe."""
    return health()


@app.get("/api/studio/settings")
def get_settings(request: Request):
    with store.connection() as conn:
        return readiness(conn, request.state.owner)


@app.put("/api/studio/settings")
def update_settings(data: SettingsInput, request: Request):
    with store.connection() as conn:
        store.save(conn, request.state.owner, "settings",
                   {"id": f"settings:{request.state.owner}", **data.model_dump()})
        return readiness(conn, request.state.owner)


@app.get("/api/studio/projects")
def projects(request: Request):
    try:
        with store.connection() as conn:
            records = store.all_records(conn, request.state.owner, "project")
            records = [
                _ensure_project_number(conn, project, request.state.owner)
                if isinstance(project, dict) and project.get("id")
                else project
                for project in records
            ]
            for project in records:
                if isinstance(project, dict) and project.get("id"):
                    _assign_export_sequences(conn, request.state.owner, project)
            return _public_project_list(records)
    except store.StoreUnavailableError:
        if store.database_backend() == "postgres":
            raise
        records = _disk_project_records(request.state.owner)
        log.warning("Serving project library from recovery snapshot count=%d", len(records))
        return _public_project_list(records)


@app.post("/api/studio/viral-finder/search")
def search_viral_sources(data: ViralSearchInput):
    try:
        translated, results, filtered_count = search_sources(
            data.query, data.platform, data.limit
        )
    except ViralFinderError as exc:
        raise HTTPException(502, str(exc)) from exc
    return {
        "platform": data.platform,
        "originalQuery": data.query,
        "translatedQuery": translated,
        "results": results,
        "filteredCount": filtered_count,
    }


@app.post("/api/studio/viral-finder/ingest", status_code=201)
def ingest_viral_source(data: ViralIngestInput, request: Request):
    if not data.rightsConfirmed:
        raise HTTPException(400, "Confirm you own or have permission to process this video.")
    with store.connection() as conn:
        if len(store.all_records(conn, request.state.owner, "project")) >= 50:
            raise HTTPException(429, "This workspace supports up to 50 projects.")

    temporary_directory = Path(tempfile.mkdtemp(prefix="recap-viral-"))
    _track_temporary_path(temporary_directory)
    object_name = ""
    project_saved = False
    try:
        source_path = download_source(data.url, temporary_directory)
        object_name = f"studio/{request.state.owner}/sources/{store.uid()}{source_path.suffix.lower()}"
        try:
            storage_client().upload_from_filename(object_name, str(source_path))
        except Exception as exc:
            log.error("Viral source upload failed (%s)", type(exc).__name__)
            raise HTTPException(503, "Could not store the downloaded source. Try again.") from exc

        with store.connection() as conn:
            project = {
                "id": store.uid(),
                "projectNumber": store.next_sequence(conn, "project"),
                "title": data.title,
                "sourceUrl": "",
                "sourceObjectPath": object_name,
                "rightsConfirmed": True,
                "globalEdit": "crop",
                "blurBoxes": [],
                "subtitleBox": None,
                "maskStyle": "dark-translucent",
                "subtitleStyle": {
                    "preset": "clean-white",
                    "primaryColor": "#FFFFFF",
                    "outlineColor": "#000000",
                    "outlineWidth": 3,
                    "shadowOpacity": 75,
                },
                "logoObjectPath": None,
                "logoPosition": "top-right",
                "logoX": 0.75,
                "logoY": 0.05,
                "watermarkText": "",
                "status": "draft",
                "stage": "Not started",
                "progress": 0,
                "createdAt": store.now(),
                "updatedAt": store.now(),
                "transcript": "",
                "dialogue": [],
                "myanmarScript": "",
                "englishScript": "",
        "storyTimeline": [],
                "exports": [],
                "events": [],
                "scriptVersion": 0,
                "processingVersion": 0,
                "outputVersion": 0,
                "lastSuccessfulProcessingVersion": 0,
                "duration": 0,
                "error": "",
                "sourcePlatform": data.platform,
                "sourceOriginalUrl": data.url,
            }
            store.event(project, "Viral source downloaded and ready for recap")
            store.save(conn, request.state.owner, "project", project)
            project_saved = True
            return public_project(project)
    except ViralFinderError as exc:
        raise HTTPException(502, str(exc)) from exc
    except HTTPException:
        raise
    except Exception as exc:
        log.error("Viral project creation failed (%s)", type(exc).__name__)
        raise HTTPException(503, "The downloaded source could not be added to the project library.") from exc
    finally:
        if object_name and not project_saved:
            try:
                storage_client().delete(object_name, ignore_not_found=True)
            except Exception:
                log.warning("Could not clean up an unowned viral source object.")
        shutil.rmtree(temporary_directory, ignore_errors=True)
        _untrack_temporary_path(temporary_directory)


@app.post("/api/studio/uploads", status_code=201)
async def upload_source(request: Request, file: UploadFile = File(...)):
    content_type = (file.content_type or "").lower()
    original_suffix = upload_suffix(file.filename or "", content_type)
    if not upload_content_type_allowed(content_type, file.filename or ""):
        raise HTTPException(400, "Choose an MP4, MOV, MKV, or WebM video file.")

    # Create and register both paths before pruning so a consecutive upload
    # cannot mistake this request's files for stale media.
    descriptor, temporary_name = tempfile.mkstemp(prefix="recap-upload-", suffix=original_suffix)
    os.close(descriptor)
    temporary_path = Path(temporary_name)
    normalized_path = temporary_path.with_name(f"{temporary_path.stem}-normalized.mp4")
    _track_temporary_path(temporary_path)
    _track_temporary_path(normalized_path)
    size = 0
    try:
        _prune_temporary_media()
        _ensure_free_disk_space()
        with temporary_path.open("wb") as destination:
            while True:
                chunk = await file.read(UPLOAD_CHUNK_BYTES)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_UPLOAD_BYTES:
                    raise HTTPException(413, "Video files must be 500 MB or smaller.")
                try:
                    destination.write(chunk)
                except OSError as exc:
                    if exc.errno == errno.ENOSPC:
                        raise _disk_full_error() from exc
                    raise HTTPException(507, "The uploaded video could not be written to disk.") from exc
                _ensure_free_disk_space()

        # FFmpeg and local media file operations are synchronous and may take
        # minutes for the supported 500 MB input. Keep them off the ASGI event
        # loop while this request remains in progress.
        # Keep the input and normalized output on disk without retaining video
        # bytes in Python memory. Reserve room for the second file plus the
        # minimum free-space guard before starting FFmpeg.
        _ensure_free_disk_space(size)
        await asyncio.to_thread(normalize_uploaded_video, temporary_path, normalized_path)
        normalized_size = normalized_path.stat().st_size
        if normalized_size > MAX_UPLOAD_BYTES:
            raise HTTPException(413, "The normalized video is larger than 500 MB.")
        _ensure_free_disk_space()

        object_name = f"studio/{request.state.owner}/sources/{store.uid()}.mp4"
        try:
            client = await asyncio.to_thread(storage_client)
            await asyncio.to_thread(
                client.upload_from_filename, object_name, str(normalized_path),
            )
        except Exception as exc:
            log.error("Source upload failed (%s)", type(exc).__name__)
            raise _storage_upload_error(exc) from exc
        return {
            "sourceObjectPath": object_name,
            "sourceOriginalName": Path(file.filename or "uploaded.mp4").name[:160],
            "size": normalized_size,
        }
    finally:
        temporary_path.unlink(missing_ok=True)
        normalized_path.unlink(missing_ok=True)
        _untrack_temporary_path(temporary_path)
        _untrack_temporary_path(normalized_path)
        await file.close()


@app.delete("/api/studio/uploads", status_code=204)
def discard_uploaded_source(data: UploadCleanupInput, request: Request):
    owner_prefix = f"studio/{request.state.owner}/sources/"
    if not data.sourceObjectPath.startswith(owner_prefix):
        raise HTTPException(403, "The uploaded source does not belong to this workspace.")

    try:
        with store.connection() as conn:
            projects = store.all_records(conn, request.state.owner, "project")
            if any(
                isinstance(project, dict)
                and project.get("sourceObjectPath") == data.sourceObjectPath
                for project in projects
            ):
                raise HTTPException(409, "The uploaded source is already attached to a project.")
        storage_client().delete(data.sourceObjectPath, ignore_not_found=True)
    except HTTPException:
        raise
    except store.StoreUnavailableError as exc:
        log.warning("Upload cleanup skipped because project storage is unavailable.")
        raise HTTPException(503, "The uploaded source could not be safely cleaned up.") from exc
    except Exception as exc:
        log.warning("Could not clean up unclaimed uploaded source (%s)", type(exc).__name__)
        raise HTTPException(503, "The uploaded source could not be cleaned up.") from exc


@app.post("/api/studio/logos", status_code=201)
async def upload_logo(request: Request, file: UploadFile = File(...)):
    filename = Path(file.filename or "").name
    if Path(filename).suffix.lower() != ".png":
        raise HTTPException(400, "Choose a PNG channel logo file.")
    content_type = (file.content_type or "").lower()
    if content_type and content_type not in {"image/png", "application/octet-stream"}:
        raise HTTPException(400, "Channel logos must be PNG files.")

    descriptor, temporary_name = tempfile.mkstemp(prefix="recap-logo-", suffix=".png")
    os.close(descriptor)
    temporary_path = Path(temporary_name)
    _track_temporary_path(temporary_path)
    size = 0
    try:
        with temporary_path.open("wb") as destination:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                if size == 0 and not chunk.startswith(b"\x89PNG\r\n\x1a\n"):
                    raise HTTPException(400, "The channel logo is not a valid PNG file.")
                size += len(chunk)
                if size > MAX_LOGO_BYTES:
                    raise HTTPException(413, "Channel logo files must be 5 MB or smaller.")
                destination.write(chunk)

        object_name = f"studio/{request.state.owner}/logos/{store.uid()}.png"
        try:
            storage_client().upload_from_filename(object_name, str(temporary_path))
        except Exception as exc:
            log.error("Channel logo upload failed (%s)", type(exc).__name__)
            raise HTTPException(503, "Could not store the channel logo. Try again.") from exc
        return {
            "logoObjectPath": object_name,
            "logoOriginalName": filename[:160] or "channel-logo.png",
            "size": size,
        }
    finally:
        temporary_path.unlink(missing_ok=True)
        _untrack_temporary_path(temporary_path)
        await file.close()


@app.post("/api/studio/audio", status_code=201)
async def upload_audio(request: Request, file: UploadFile = File(...)):
    """Store a reusable background-music or sound-effects track locally."""
    filename = Path(file.filename or "").name
    suffix = Path(filename).suffix.lower()
    if suffix not in ALLOWED_AUDIO_SUFFIXES:
        raise HTTPException(400, "Choose an MP3, WAV, M4A, AAC, OGG, or FLAC audio file.")
    content_type = (file.content_type or "").split(";", 1)[0].strip().lower()
    if content_type and not (content_type.startswith("audio/") or content_type == "application/octet-stream"):
        raise HTTPException(400, "Audio tracks must be audio files.")

    descriptor, temporary_name = tempfile.mkstemp(prefix="recap-audio-", suffix=suffix)
    os.close(descriptor)
    temporary_path = Path(temporary_name)
    _track_temporary_path(temporary_path)
    size = 0
    object_name = f"studio/{request.state.owner}/audio/{store.uid()}{suffix}"
    try:
        with temporary_path.open("wb") as destination:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_AUDIO_BYTES:
                    raise HTTPException(413, "Audio tracks must be 50 MB or smaller.")
                destination.write(chunk)
        try:
            client = await asyncio.to_thread(storage_client)
            await asyncio.to_thread(client.upload_from_filename, object_name, str(temporary_path))
        except Exception as exc:
            log.error("Audio upload failed (%s)", type(exc).__name__)
            raise HTTPException(503, "Could not store the audio track. Try again.") from exc
        return {
            "audioObjectPath": object_name,
            "audioOriginalName": filename[:160] or f"audio{suffix}",
            "size": size,
        }
    finally:
        temporary_path.unlink(missing_ok=True)
        _untrack_temporary_path(temporary_path)
        await file.close()


@app.post("/api/studio/projects", status_code=201)
def create_project(data: ProjectInput, request: Request):
    if not data.rightsConfirmed:
        raise HTTPException(400, "Confirm you own or have permission to process this video.")
    if bool(data.sourceUrl.strip()) == bool(data.sourceObjectPath):
        raise HTTPException(400, "Provide either a direct HTTPS URL or an uploaded video file.")
    if data.sourceObjectPath and not data.sourceObjectPath.startswith(
        f"studio/{request.state.owner}/sources/"
    ):
        raise HTTPException(403, "The uploaded source does not belong to this workspace.")
    with store.connection() as conn:
        if len(store.all_records(conn, request.state.owner, "project")) >= 50:
            raise HTTPException(429, "This workspace supports up to 50 projects.")
        project = {
                "id": store.uid(), "projectNumber": store.next_sequence(conn, "project"),
                **data.model_dump(), "status": "draft", "stage": "Not started",
            "progress": 0, "createdAt": store.now(), "updatedAt": store.now(), "transcript": "",
            "sourceDuration": 0.0,
            "dialogue": [], "myanmarScript": "", "englishScript": "", "exports": [], "events": [],
            "storyTimeline": [],
            "exportsStale": False,
            "scriptVersion": 0,
            "processingVersion": 0,
            "outputVersion": 0,
            "lastSuccessfulProcessingVersion": 0,
            "duration": 0, "error": "",
            "logoObjectPath": None, "logoPosition": "top-right",
            "logoX": 0.75, "logoY": 0.05,
            "logoScale": 0.22,
            "backgroundMusicObjectPath": None,
            "sfxObjectPath": None,
            "backgroundMusicVolume": 0.15,
            "sfxVolume": 0.25,
            "narrationDucking": 0.8,
            "narrationStartSeconds": 0.5,
            "narrationDurationSeconds": None,
            "storyEndSeconds": None,
            "videoTransform": {"scale": 1.0, "zoom": 1.0, "x": 0.0, "y": 0.0},
            "subtitleAlignment": "center",
            "watermarkText": "",
            "subtitleStyle": {
                "preset": "clean-white",
                "primaryColor": "#FFFFFF",
                "outlineColor": "#000000",
                "outlineWidth": 4,
                "shadowOpacity": 75,
            },
            "narrationSpeed": 1.0,
            "subtitleFontFamily": "Noto Sans Myanmar",
            "subtitleBold": True,
            "timingOffset": 0.0,
            "viralHookTitle": "",
            "viralCaption": "",
        }
        store.event(project, "Project created")
        store.save(conn, request.state.owner, "project", project)
        return public_project(project)


@app.get("/api/studio/projects/{id}")
def get_project(id: str, request: Request):
    try:
        with store.connection() as conn:
            project = project_or_404(conn, request.state.owner, id)
            project = _ensure_project_number(conn, project, request.state.owner)
            return safe_public_project(project, id)
    except store.StoreUnavailableError:
        if store.database_backend() == "postgres":
            raise
        records = _disk_project_records(request.state.owner)
        for project in records:
            if isinstance(project, dict) and str(project.get("id")) == id:
                return safe_public_project(project, id)
        raise HTTPException(404, "Project not found.")


@app.patch("/api/studio/projects/{id}")
def update_project(id: str, data: ProjectUpdate, request: Request):
    if data.logoObjectPath and not data.logoObjectPath.startswith(
        f"studio/{request.state.owner}/logos/"
    ):
        raise HTTPException(403, "The uploaded channel logo does not belong to this workspace.")
    for field_name, prefix in (
        ("backgroundMusicObjectPath", "audio"),
        ("sfxObjectPath", "audio"),
    ):
        object_path = getattr(data, field_name)
        if object_path and not object_path.startswith(
            f"studio/{request.state.owner}/{prefix}/"
        ):
            raise HTTPException(403, "The uploaded audio track does not belong to this workspace.")
    with store.connection() as conn:
        project = project_or_404(conn, request.state.owner, id, lock=True)
        if project["status"] in ACTIVE:
            log.warning(
                "Project save rejected while job is active project_id=%s status=%s",
                id,
                project["status"],
            )
            raise HTTPException(409, "Wait for processing or cancel the pending schedule before editing.")
        # Keep explicitly submitted nulls so the UI can remove an optional
        # subtitle area. Omitted fields remain untouched.
        values = data.model_dump(exclude_unset=True)
        script_fields = SCRIPT_FIELDS
        incoming_revision = values.pop("scriptUpdatedAt", None)
        submitted_script_fields = script_fields.intersection(values)
        if "dialogue" in values:
            values["dialogue"] = _validate_dialogue_records(
                values["dialogue"],
                project.get("sourceDuration") or project.get("duration") or 0,
            )
        _validate_story_end_boundary(values, project)
        if submitted_script_fields:
            current_revision = int(project.get("_scriptUpdatedAt") or 0)
            if incoming_revision is not None and int(incoming_revision) < current_revision:
                for field_name in submitted_script_fields:
                    values.pop(field_name, None)
            else:
                project["_scriptUpdatedAt"] = int(
                    incoming_revision
                    if incoming_revision is not None
                    else datetime.now(timezone.utc).timestamp() * 1000
                )
        if "transcript" in values and "dialogue" in values:
            dialogue_lines = [
                line for line in values["dialogue"]
                if str(line.get("sourceText") or "").strip()
            ]
            dialogue_text = "\n".join(
                str(line.get("sourceText") or "").strip()
                for line in dialogue_lines
            ).strip()
            speaker_labelled_dialogue_text = "\n".join(
                f"[{str(line.get('speaker') or 'A').strip()}] "
                f"{str(line.get('sourceText') or '').strip()}"
                for line in dialogue_lines
            ).strip()
            submitted_transcript = str(values["transcript"] or "").strip()
            if submitted_transcript not in {
                dialogue_text,
                speaker_labelled_dialogue_text,
            }:
                values["dialogue"] = []
        if "title" in values and not values["title"].strip():
            raise HTTPException(400, "Title cannot be blank.")
        if (
            "transcript" in values
            and values["transcript"] != project.get("transcript")
            and "dialogue" not in values
        ):
            # A manually changed transcript no longer matches the stored speaker
            # segmentation; force the next full run to rebuild dialogue from it.
            project["dialogue"] = []
        script_changed = _script_fields_changed(project, values)
        export_changed = bool(_changed_fields(project, values, EXPORT_INVALIDATING_FIELDS))
        project.update(values)
        if script_changed:
            project["scriptVersion"] = _integer_version(project, "scriptVersion") + 1
        if export_changed:
            _invalidate_generated_assets(project)
        store.event(project, "Project changes saved")
        store.save(conn, request.state.owner, "project", project)
        return public_project(project)


@app.delete("/api/studio/projects/{id}", status_code=204)
def delete_project(id: str, request: Request):
    with store.connection() as conn:
        try:
            project = project_or_404(conn, request.state.owner, id, lock=True)
        except HTTPException as exc:
            if exc.status_code == 404:
                # Deletion is idempotent, but a missing project record provides
                # no ownership proof for its old, project-ID-only export prefix.
                # Never delete durable objects when the owner cannot be verified.
                return Response(status_code=204)
            raise
        if project.get("status") in ACTIVE:
            raise HTTPException(409, "Cancel pending processing before deleting.")
        # Delete media before metadata so failed cleanup can be retried.
        if (
            project.get("exports")
            or project.get("sourceObjectPath")
            or project.get("logoObjectPath")
            or project.get("backgroundMusicObjectPath")
            or project.get("sfxObjectPath")
        ):
            prefixes = project.get("exportObjectPrefixes") or {}
            prefix = project.get("objectPrefix", f"studio/{id}")
            try:
                client = storage_client()
                if project.get("sourceObjectPath"):
                    client.delete(project["sourceObjectPath"], ignore_not_found=True)
                if project.get("logoObjectPath"):
                    client.delete(project["logoObjectPath"], ignore_not_found=True)
                for audio_path in (
                    project.get("backgroundMusicObjectPath"),
                    project.get("sfxObjectPath"),
                ):
                    if audio_path:
                        client.delete(audio_path, ignore_not_found=True)
                # Export filenames are title/timestamp based, so deleting
                # guessed names such as ``myanmar.mp4`` leaves completed
                # media behind. Remove each published run prefix instead.
                export_prefixes = {
                    str(raw_prefix).strip()
                    for raw_prefix in (prefix, *prefixes.values())
                    if str(raw_prefix or "").strip()
                }
                for export_prefix in export_prefixes:
                    client.delete_prefix(export_prefix)
            except Exception:
                raise HTTPException(503, "Could not remove stored exports. Please retry deletion.")
        store.delete_project_records(conn, request.state.owner, id)


@app.delete("/api/studio/projects/{id}/exports/{language}")
def delete_project_export(id: str, language: str, request: Request):
    if language not in {"myanmar", "english"}:
        raise HTTPException(404, "Export language not found.")
    with store.connection() as conn:
        project = project_or_404(conn, request.state.owner, id, lock=True)
        if project.get("status") in ACTIVE:
            raise HTTPException(409, "Cancel pending processing before deleting an export.")
        exports = project.get("exports")
        if not isinstance(exports, list):
            raise HTTPException(404, "This project has no completed exports.")
        target = next(
            (
                item for item in exports
                if isinstance(item, dict) and item.get("language") == language
            ),
            None,
        )
        if target is None:
            raise HTTPException(404, "This project has no export in that language.")

        prefixes = dict(project.get("exportObjectPrefixes") or {})
        target_prefix = str(
            prefixes.get(language)
            or project.get("objectPrefix")
            or f"studio/{id}"
        ).strip()
        other_prefixes = {
            str(prefix).strip()
            for other_language, prefix in prefixes.items()
            if other_language != language and str(prefix or "").strip()
        }
        if not other_prefixes:
            other_prefixes = {
                str(project.get("objectPrefix") or "").strip()
            } - {""}
        try:
            client = storage_client()
            if target_prefix not in other_prefixes:
                client.delete_prefix(target_prefix)
            else:
                for field_name in (
                    "videoFilename",
                    "capcutVideoFilename",
                    "subtitleFilename",
                    "audioFilename",
                    "thumbnailFilename",
                ):
                    stored_filename = str(target.get(field_name) or "").strip()
                    if stored_filename:
                        client.delete(
                            f"{target_prefix}/{Path(stored_filename).name}",
                            ignore_not_found=True,
                        )
        except Exception as exc:
            raise HTTPException(
                503,
                "Could not remove the completed export. Please retry.",
            ) from exc

        project["exports"] = [
            item for item in exports
            if not (isinstance(item, dict) and item.get("language") == language)
        ]
        prefixes.pop(language, None)
        project["exportObjectPrefixes"] = prefixes
        project["exportsStale"] = False
        store.event(project, f"Deleted {language} export")
        store.save(conn, request.state.owner, "project", project)
        return public_project(project)


@app.api_route("/api/studio/projects/{id}/source", methods=["GET", "HEAD"])
def get_source_preview(id: str, request: Request):
    with store.connection() as conn:
        project = project_or_404(conn, request.state.owner, id)
        source_object_path = project.get("sourceObjectPath")
        if not source_object_path:
            raise HTTPException(404, "This project does not have an uploaded source preview.")

    suffix = Path(source_object_path).suffix.lower()
    media_type = {
        ".mp4": "video/mp4",
        ".mov": "video/quicktime",
        ".mkv": "video/x-matroska",
        ".webm": "video/webm",
    }.get(suffix)
    if not media_type:
        raise HTTPException(404, "Source preview is unavailable.")

    descriptor, temporary_path = tempfile.mkstemp(prefix="recap-source-preview-", suffix=suffix)
    os.close(descriptor)
    path = Path(temporary_path)
    try:
        storage_client().download_to_filename(source_object_path, str(path))
    except Exception:
        path.unlink(missing_ok=True)
        raise HTTPException(503, "Source preview storage is unavailable. Try again shortly.")
    return local_media_response(
        path,
        request,
        media_type=media_type,
        filename=f"{project['title']}{suffix}",
        disposition="inline",
    )


@app.api_route("/api/studio/projects/{id}/logo", methods=["GET", "HEAD"])
def get_logo_preview(id: str, request: Request):
    with store.connection() as conn:
        project = project_or_404(conn, request.state.owner, id)
        logo_object_path = str(project.get("logoObjectPath") or "").strip()
        if not logo_object_path:
            raise HTTPException(404, "This project does not have a channel logo.")

    descriptor, temporary_name = tempfile.mkstemp(prefix="recap-logo-preview-", suffix=".png")
    os.close(descriptor)
    path = Path(temporary_name)
    try:
        storage_client().download_to_filename(logo_object_path, str(path))
    except Exception:
        path.unlink(missing_ok=True)
        raise HTTPException(503, "Logo preview storage is unavailable. Try again shortly.")
    return local_media_response(
        path,
        request,
        media_type="image/png",
        filename="channel-logo.png",
        disposition="inline",
    )


@app.post("/api/studio/projects/{id}/run")
def run_project(id: str, data: RunInput, request: Request):
    with store.connection() as conn:
        project = project_or_404(conn, request.state.owner, id, lock=True)
        run_values = data.model_dump(exclude_unset=True)
        run_values.pop("action", None)
        run_values.pop("quality", None)
        incoming_revision = run_values.pop("scriptUpdatedAt", None)
        submitted_script_fields = SCRIPT_FIELDS.intersection(run_values)
        if submitted_script_fields:
            current_revision = int(project.get("_scriptUpdatedAt") or 0)
            if incoming_revision is not None and int(incoming_revision) < current_revision:
                for field_name in submitted_script_fields:
                    run_values.pop(field_name, None)
            elif incoming_revision is not None:
                project["_scriptUpdatedAt"] = int(incoming_revision)
        preview_width = run_values.pop("previewWidth", None)
        preview_height = run_values.pop("previewHeight", None)
        export_width = run_values.pop("exportWidth", None)
        export_height = run_values.pop("exportHeight", None)
        if "dialogue" in run_values:
            run_values["dialogue"] = _validate_dialogue_records(
                run_values["dialogue"],
                project.get("sourceDuration") or project.get("duration") or 0,
            )
        _validate_story_end_boundary(run_values, project)
        # Validate and persist the exact run snapshot before the schedule is
        # created.  This makes a click on Export an authoritative save even if
        # the debounced browser autosave has not completed yet.
        effective_project = dict(project)
        effective_project.update(run_values)
        check_requirements(effective_project, data.action)
        if data.action in {
            "export", "export_english", "export_capcut", "full", "test_export"
        }:
            log.info(
                "[EXPORT CONFIG] preview=%sx%s requested_export=%sx%s "
                "blur_boxes=%s logo=(%s,%s) logo_scale=%s "
                "subtitle=(font=%s,margin=%s,alignment=%s,canvas=%sx%s)",
                preview_width or "?",
                preview_height or "?",
                export_width or "?",
                export_height or "?",
                len(run_values.get("blurBoxes") or []),
                run_values.get("logoX", project.get("logoX", 0.75)),
                run_values.get("logoY", project.get("logoY", 0.05)),
                run_values.get("logoScale", project.get("logoScale", 0.22)),
                run_values.get("subtitleFontSize", project.get("subtitleFontSize", 32)),
                run_values.get("subtitleMarginV", project.get("subtitleMarginV", 160)),
                run_values.get("subtitleAlignment", project.get("subtitleAlignment", "center")),
                export_width or "?",
                export_height or "?",
            )
        enqueue(
            conn,
            request.state.owner,
            project,
            data.action,
            datetime.now(timezone.utc),
            "instant",
            store.settings(conn, request.state.owner)["timezone"],
            data.quality,
            overrides=run_values,
        )
        return public_project(project)


@app.post("/api/studio/projects/{id}/post-metadata")
def generate_post_metadata(id: str, request: Request):
    from .engine import _fallback_post_metadata, _generate_post_metadata

    with store.connection() as conn:
        project = project_or_404(conn, request.state.owner, id, lock=True)
        if (
            project.get("status") != "completed"
            or not project.get("exports")
            or project.get("exportsStale")
        ):
            raise HTTPException(409, "Complete a video export before generating post metadata.")
        script = str(project.get("myanmarScript") or "").strip()
        if not script:
            raise HTTPException(400, "A Burmese narration script is required.")
        try:
            metadata = _generate_post_metadata(script, str(project.get("title") or ""))
        except Exception as exc:
            log.warning(
                "AI post metadata unavailable; using known-story fallback "
                "project_id=%s type=%s",
                id,
                type(exc).__name__,
            )
            metadata = _fallback_post_metadata(script, str(project.get("title") or ""))
        project["viralHookTitle"] = metadata["hookTitle"]
        project["viralCaption"] = metadata["caption"]
        project["viralTitles"] = [metadata["hookTitle"]]
        project["viralHashtags"] = metadata["hashtags"]
        store.event(
            project,
            "Ready-to-post metadata generated"
            if metadata.get("source") == "gemini"
            else "Ready-to-post metadata generated from known story data",
        )
        store.save(conn, request.state.owner, "project", project)
        return public_project(project)


def public_schedule(value):
    return {k: v for k, v in value.items() if not k.startswith("_")}


@app.get("/api/studio/schedules")
def list_schedules(request: Request):
    with store.connection() as conn:
        return [public_schedule(s) for s in store.all_records(conn, request.state.owner, "schedule")]


@app.post("/api/studio/schedules", status_code=201)
def create_schedule(data: ScheduleInput, request: Request):
    try:
        tz = ZoneInfo(data.timezone)
    except (ZoneInfoNotFoundError, ValueError):
        raise HTTPException(400, "Invalid timezone.")
    when = datetime.now(timezone.utc)
    with store.connection() as conn:
        project = project_or_404(conn, request.state.owner, data.projectId, lock=True)
        if data.mode == "manual":
            try:
                when = datetime.fromisoformat((data.scheduledAt or "").replace("Z", "+00:00"))
                if when.tzinfo is None:
                    # UI submits local clock time with its selected timezone.
                    local = when.replace(tzinfo=tz)
                    if local.astimezone(timezone.utc).astimezone(tz).replace(tzinfo=None) != when:
                        raise ValueError()
                    when = local
                when = when.astimezone(timezone.utc)
            except ValueError:
                raise HTTPException(400, "Choose a valid date and time in your selected timezone.")
            if when <= datetime.now(timezone.utc):
                raise HTTPException(400, "Schedule must be in the future.")
        elif data.mode == "smart":
            local = when.astimezone(tz)
            hours = store.settings(conn, request.state.owner)["peakHours"]
            candidates = [
                (local + timedelta(days=d)).replace(hour=h, minute=0, second=0, microsecond=0)
                for d in range(3) for h in hours
            ]
            when = min(c for c in candidates if c > local).astimezone(timezone.utc)
        return public_schedule(
            enqueue(
                conn,
                request.state.owner,
                project,
                "full",
                when,
                data.mode,
                data.timezone,
                "1080p",
            )
        )


@app.delete("/api/studio/schedules/{id}", status_code=204)
def cancel_schedule(id: str, request: Request):
    with store.connection() as conn:
        # Lock ordering matches enqueue: project before schedule.
        schedule = store.get(conn, request.state.owner, "schedule", id)
        if not schedule:
            raise HTTPException(404, "Schedule not found.")
        project = project_or_404(conn, request.state.owner, schedule["projectId"], lock=True)
        schedule = store.get(conn, request.state.owner, "schedule", id, lock=True)
        if schedule["status"] != "scheduled":
            raise HTTPException(409, "Only pending jobs can be cancelled.")
        schedule["status"] = "cancelled"
        store.save(conn, request.state.owner, "schedule", schedule)
        project.update(status="draft", stage="Cancelled", progress=0)
        store.event(project, "Scheduled job cancelled")
        store.save(conn, request.state.owner, "project", project)


@app.get("/api/studio/dashboard")
def dashboard(request: Request):
    with store.connection() as conn:
        projects = store.all_records(conn, request.state.owner, "project")
        schedules = store.all_records(conn, request.state.owner, "schedule")
    events = sorted([e for p in projects for e in p["events"]], key=lambda e: e["createdAt"], reverse=True)
    return {
        "totalProjects": len(projects), "activeJobs": sum(p["status"] == "processing" for p in projects),
        "completedExports": sum(len(p["exports"]) for p in projects),
        "scheduledJobs": sum(s["status"] == "scheduled" for s in schedules),
        "projects": [public_project(p) for p in projects[:6]],
        "schedules": [public_schedule(s) for s in schedules if s["status"] == "scheduled"][:6],
        "recentActivity": events[:10]
    }


def _serve_export_file(
    id: str,
    filename: str,
    request: Request,
    *,
    download_name: str | None = None,
    disposition: str = "attachment",
):
    allowed_filenames = {
        f"{l}.{e}" for l in ("myanmar", "english") for e in ("mp4", "srt", "mp3", "jpg")
    }
    allowed_filenames.update({f"{l}-capcut.mp4" for l in ("myanmar", "english")})
    allowed_filenames.update(
        {
            f"{l}-{asset}.{extension}"
            for l in ("myanmar", "english")
            for asset, extension in (("metadata", "json"), ("export", "zip"))
        }
    )
    if filename not in allowed_filenames:
        raise HTTPException(404, "File not found.")
    with store.connection() as conn:
        project = project_or_404(conn, request.state.owner, id)
        if not project.get("exports") or project.get("exportsStale"):
            raise HTTPException(
                409 if project.get("exportsStale") else 404,
                "Generate a current final export before downloading this file."
                if project.get("exportsStale")
                else "This project has no exports yet.",
            )
        if project.get("status") in ACTIVE or float(project.get("progress") or 0) < 100:
            raise HTTPException(409, "This export is not ready for download yet.")
    path: Path | None = None
    cleanup_after_response = False
    try:
        filename_stem, extension = filename.rsplit(".", 1)
        is_capcut = filename_stem.endswith("-capcut") and extension == "mp4"
        is_metadata = filename_stem.endswith("-metadata") and extension == "json"
        is_package = filename_stem.endswith("-export") and extension == "zip"
        language = (
            filename_stem.removesuffix("-capcut")
            if is_capcut
            else filename_stem.removesuffix("-metadata")
            if is_metadata
            else filename_stem.removesuffix("-export")
            if is_package
            else filename_stem
        )
        if language not in {"myanmar", "english"}:
            raise HTTPException(404, "File not found.")
        prefixes = project.get("exportObjectPrefixes") or {}
        prefix = prefixes.get(language, project.get("objectPrefix", f"studio/{id}"))
        export_record = next(
            (
                item for item in (project.get("exports") or [])
                if isinstance(item, dict) and item.get("language") == language
            ),
            {},
        )
        if extension == "srt" and not export_record.get("srtSequence"):
            _assign_export_sequences(conn, request.state.owner, project)
            export_record = next(
                (
                    item for item in (project.get("exports") or [])
                    if isinstance(item, dict) and item.get("language") == language
                ),
                {},
            )
        filename_field = {
            "mp4": "videoFilename",
            "srt": "subtitleFilename",
            "mp3": "audioFilename",
            "jpg": "thumbnailFilename",
            "json": "metadataFilename",
            "zip": "packageFilename",
        }[filename.rsplit(".", 1)[-1]]
        if is_capcut:
            filename_field = "capcutVideoFilename"
        stored_filename = str(export_record.get(filename_field) or filename)
        if (is_capcut or is_metadata or is_package) and not export_record.get(filename_field):
            raise HTTPException(404, "This project has no requested export asset yet.")
        try:
            thumbnail_version = int(
                export_record.get("thumbnailProcessingVersion") or 0
            )
        except (TypeError, ValueError):
            thumbnail_version = 0
        refresh_thumbnail_candidate = (
            extension == "jpg"
            and bool(
                str(project.get("sourceObjectPath") or "").strip()
                or str(project.get("sourceUrl") or "").strip()
            )
            and thumbnail_version < CLEAN_THUMBNAIL_VERSION
        )
        refresh_thumbnail = (
            request.method != "HEAD" and refresh_thumbnail_candidate
        )
        if refresh_thumbnail:
            descriptor, temporary_path = tempfile.mkstemp(
                prefix="recap-thumbnail-download-",
                suffix=Path(filename).suffix,
            )
            os.close(descriptor)
            path = Path(temporary_path)
            cleanup_after_response = True
            _refresh_clean_thumbnail(
                project,
                request.state.owner,
                language,
                prefix,
                stored_filename,
                path,
            )
        else:
            media_store = storage_client()
            object_name = f"{prefix}/{stored_filename}"
            can_check_without_download = (
                request.method == "HEAD"
                and not request.headers.get("range")
                and bool(getattr(media_store, "supports_lightweight_head", False))
            )
            if can_check_without_download:
                object_to_check = (
                    str(project.get("sourceObjectPath") or "").strip()
                    if refresh_thumbnail_candidate
                    else object_name
                )
                if object_to_check:
                    if not media_store.exists(object_to_check):
                        raise FileNotFoundError(object_to_check)
                elif not project.get("sourceUrl"):
                    raise FileNotFoundError(object_name)
            else:
                path = media_store.path_for(object_name)
                cleanup_after_response = bool(
                    getattr(media_store, "path_for_returns_temporary_file", False)
                )
        if path is not None and (
            not path.is_file() or path.stat().st_size <= 0
        ):
            raise RuntimeError("Downloaded export was empty.")
        if not download_name:
            project_number = max(0, int(project.get("projectNumber") or 0))
            suffix = extension
            if extension == "mp4":
                download_name = (
                    f"Project_{project_number}_Final"
                    f"{'_English' if language == 'english' else ''}.mp4"
                )
            elif extension == "srt":
                sequence = int(export_record.get("srtSequence") or 0)
                download_name = f"SRT No. {sequence}.srt"
            elif extension == "jpg":
                download_name = f"Project_{project_number}_Thumbnail.jpg"
            elif extension == "json":
                download_name = f"Project_{project_number}_Metadata.json"
            elif extension == "zip":
                download_name = f"Project_{project_number}_Export.zip"
            else:
                download_name = f"Project_{project_number}_Narration.mp3"
    except HTTPException:
        if path is not None and cleanup_after_response:
            path.unlink(missing_ok=True)
        raise
    except FileNotFoundError:
        if path is not None and cleanup_after_response:
            path.unlink(missing_ok=True)
        raise HTTPException(404, "The requested export asset was not found.")
    except Exception:
        if path is not None and cleanup_after_response:
            path.unlink(missing_ok=True)
        raise HTTPException(503, "Export storage is unavailable. Try again shortly.")
    media = {
        "mp4": "video/mp4", "mp3": "audio/mpeg", "srt": "application/x-subrip",
        "jpg": "image/jpeg", "json": "application/json", "zip": "application/zip",
    }[filename.split(".")[-1]]
    if path is None:
        return lightweight_head_response(
            media,
            download_name or filename,
            disposition,
        )
    return local_media_response(
        path,
        request,
        media_type=media,
        filename=download_name or filename,
        disposition=disposition,
        cleanup_after_response=cleanup_after_response,
    )


@app.api_route("/api/studio/projects/{id}/files/{filename}", methods=["GET", "HEAD"])
def get_file(id: str, filename: str, request: Request):
    return _serve_export_file(id, filename, request, disposition="attachment")


def _download_language_file(
    id: str,
    language: str,
    request: Request,
    extension: str,
    download_name: str,
):
    if language not in {"myanmar", "english"}:
        raise HTTPException(404, "Export language not found.")
    return _serve_export_file(
        id,
        f"{language}.{extension}",
        request,
        download_name=download_name,
        disposition="attachment",
    )


def _download_capcut_video(id: str, language: str, request: Request):
    if language != "myanmar":
        raise HTTPException(404, "CapCut-ready export language not found.")
    return _serve_export_file(
        id,
        f"{language}-capcut.mp4",
        request,
        download_name="",
        disposition="attachment",
    )


def _refresh_clean_thumbnail(
    project: dict,
    owner: str,
    language: str,
    object_prefix: str,
    stored_filename: str,
    destination: Path,
) -> None:
    """Regenerate an old stored thumbnail without rerunning the export job."""
    source_object_path = str(project.get("sourceObjectPath") or "").strip()
    source_url = str(project.get("sourceUrl") or "").strip()
    if not source_object_path and not source_url:
        raise RuntimeError("The source video is unavailable for thumbnail refresh.")

    from .engine import (
        _download_direct_video,
        _extract_thumbnail,
        _probe_video,
        _probe_video_dimensions,
    )

    suffix = Path(source_object_path or source_url).suffix.lower() or ".mp4"
    descriptor, temporary_name = tempfile.mkstemp(
        prefix="recap-thumbnail-source-",
        suffix=suffix,
    )
    os.close(descriptor)
    source = Path(temporary_name)
    try:
        if source_object_path:
            storage_client().download_to_filename(source_object_path, str(source))
        else:
            _download_direct_video(source_url, source)
        try:
            duration = float(project.get("sourceDuration") or project.get("duration") or 0)
        except (TypeError, ValueError):
            duration = 0.0
        if duration <= 0:
            duration = _probe_video(source)
        frame_width, frame_height = _probe_video_dimensions(source)
        _extract_thumbnail(
            source,
            duration,
            destination,
            frame_width=frame_width,
            frame_height=frame_height,
            clean_publish_thumbnail=True,
        )
        storage_client().upload_from_filename(
            f"{object_prefix}/{stored_filename}",
            str(destination),
        )
    finally:
        source.unlink(missing_ok=True)

    with store.connection() as conn:
        current = project_or_404(conn, owner, str(project.get("id") or ""), lock=True)
        for export in current.get("exports") or []:
            if isinstance(export, dict) and export.get("language") == language:
                export["thumbnailProcessingVersion"] = CLEAN_THUMBNAIL_VERSION
                break
        store.save(conn, owner, "project", current)


@app.api_route("/api/download/video", methods=["GET", "HEAD"])
def download_video(
    request: Request,
    projectId: str = Query(..., min_length=1, max_length=128),
    language: str = Query("myanmar"),
):
    return _download_language_file(
        projectId, language, request, "mp4", ""
    )


@app.api_route("/api/download/capcut-video", methods=["GET", "HEAD"])
def download_capcut_video(
    request: Request,
    projectId: str = Query(..., min_length=1, max_length=128),
    language: str = Query("myanmar"),
):
    return _download_capcut_video(projectId, language, request)


@app.api_route("/api/download/thumbnail", methods=["GET", "HEAD"])
def download_thumbnail(
    request: Request,
    projectId: str = Query(..., min_length=1, max_length=128),
    language: str = Query("myanmar"),
):
    return _download_language_file(
        projectId, language, request, "jpg", "Drama_Recap_Thumbnail.jpg"
    )