"""Run the complete Studio unittest suite with isolated storage and no egress."""
from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path


def main() -> int:
    api_root = Path(__file__).resolve().parents[1]
    if str(api_root) not in sys.path:
        sys.path.insert(0, str(api_root))

    from studio.offline_test_support import (
        blocked_network_operations,
        install_network_guard,
    )

    install_network_guard()

    # Isolate files without changing DATABASE_URL or the configured database
    # backend. PostgreSQL remains selected whenever the environment selects it.
    with tempfile.TemporaryDirectory(prefix="studio-offline-tests-") as temporary:
        root = Path(temporary)
        os.environ["STUDIO_DATA_ROOT"] = str(root / "data")
        os.environ["STUDIO_DATABASE_PATH"] = str(root / "data" / "studio.sqlite3")
        os.environ["STUDIO_MEDIA_ROOT"] = str(root / "media")
        os.environ["STUDIO_CHECKPOINT_ROOT"] = str(root / "checkpoints")

        suite = unittest.defaultTestLoader.discover(
            start_dir=str(Path(__file__).resolve().parent),
            pattern="test_*.py",
            top_level_dir=str(api_root),
        )
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        attempts = blocked_network_operations()
        if attempts:
            print(
                "\nOffline isolation failure: blocked "
                f"{len(attempts)} network operation(s): "
                + ", ".join(attempts)
            )
        return 0 if result.wasSuccessful() and not attempts else 1


if __name__ == "__main__":
    raise SystemExit(main())