-- Idempotent PostgreSQL schema for the Studio record store.
CREATE TABLE IF NOT EXISTS studio_records (
  id text PRIMARY KEY,
  owner text NOT NULL,
  kind text NOT NULL,
  data jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS studio_records_owner_kind ON studio_records(owner, kind);