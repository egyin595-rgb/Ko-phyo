import re
from typing import Literal
from pathlib import Path
from pydantic import BaseModel, Field, field_validator, model_validator
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from urllib.parse import urlsplit

Edit = Literal["none", "crop", "zoom", "blur"]
ViralPlatform = Literal["youtube", "bilibili", "rednote"]
LogoPosition = Literal["top-right", "top-left", "bottom-right"]
SubtitleAlignment = Literal["left", "center", "right"]
MaskStyle = Literal["dark-translucent", "light-translucent", "clean-boxblur"]
SubtitlePreset = Literal["classic-yellow", "clean-white", "neon-green", "cyan", "custom"]
SubtitleFontFamily = Literal["Noto Sans Myanmar"]
ExportQuality = Literal["720p", "1080p", "original"]
TargetDurationMinutes = Literal[3, 5, 8, 10]

SUBTITLE_PRESET_VALUES = {
    "classic-yellow": {"primaryColor": "#FFEB3B", "outlineColor": "#000000", "outlineWidth": 4, "shadowOpacity": 75},
    "clean-white": {"primaryColor": "#FFFFFF", "outlineColor": "#000000", "outlineWidth": 4, "shadowOpacity": 75},
    "neon-green": {"primaryColor": "#39FF14", "outlineColor": "#000000", "outlineWidth": 3, "shadowOpacity": 75},
    "cyan": {"primaryColor": "#00FFFF", "outlineColor": "#000000", "outlineWidth": 3, "shadowOpacity": 75},
}


class BlurBox(BaseModel):
    id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_-]+$")
    xPercent: float = Field(ge=0.0, le=100.0)
    yPercent: float = Field(ge=0.0, le=100.0)
    widthPercent: float = Field(gt=0.0, le=100.0)
    heightPercent: float = Field(gt=0.0, le=100.0)
    strength: int = Field(default=20, ge=5, le=50)

    @model_validator(mode="before")
    @classmethod
    def migrate_legacy_geometry(cls, value):
        if not isinstance(value, dict):
            return value
        data = dict(value)
        for current, legacy in (
            ("xPercent", "x"),
            ("yPercent", "y"),
            ("widthPercent", "width"),
            ("heightPercent", "height"),
        ):
            if current not in data and legacy in data:
                data[current] = float(data[legacy]) * 100.0
        data.setdefault("strength", 20)
        return data

    @model_validator(mode="after")
    def stays_inside_frame(self):
        if (
            self.xPercent + self.widthPercent > 100.0
            or self.yPercent + self.heightPercent > 100.0
        ):
            raise ValueError("Blur boxes must stay inside the video frame.")
        return self


class SubtitleBox(BaseModel):
    xPercent: float = Field(ge=0.0, le=100.0)
    yPercent: float = Field(ge=0.0, le=100.0)
    widthPercent: float = Field(gt=0.0, le=100.0)
    heightPercent: float = Field(gt=0.0, le=100.0)

    @model_validator(mode="before")
    @classmethod
    def migrate_legacy_geometry(cls, value):
        if not isinstance(value, dict):
            return value
        data = dict(value)
        for current, legacy in (
            ("xPercent", "x"),
            ("yPercent", "y"),
            ("widthPercent", "width"),
            ("heightPercent", "height"),
        ):
            if current not in data and legacy in data:
                data[current] = float(data[legacy]) * 100.0
        return data

    @model_validator(mode="after")
    def stays_inside_frame(self):
        if (
            self.xPercent + self.widthPercent > 100.0
            or self.yPercent + self.heightPercent > 100.0
        ):
            raise ValueError("The subtitle box must stay inside the video frame.")
        return self


class SubtitleStyle(BaseModel):
    preset: SubtitlePreset = "clean-white"
    primaryColor: str = "#FFFFFF"
    outlineColor: str = "#000000"
    outlineWidth: float = Field(default=3, ge=0, le=8)
    shadowOpacity: float = Field(default=75, ge=0, le=100)

    @field_validator("primaryColor", "outlineColor")
    @classmethod
    def hex_color_valid(cls, value):
        value = value.strip().upper()
        if not re.fullmatch(r"#[0-9A-F]{6}", value):
            raise ValueError("Subtitle colors must be six-digit hexadecimal values such as #FFFF00.")
        return value

    @model_validator(mode="after")
    def canonicalize_preset(self):
        if self.preset != "custom":
            values = SUBTITLE_PRESET_VALUES[self.preset]
            self.primaryColor = values["primaryColor"]
            self.outlineColor = values["outlineColor"]
            self.outlineWidth = values["outlineWidth"]
        return self


class DialogueLine(BaseModel):
    """One source-video speech segment that remains editable through export."""

    id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_-]+$")
    speaker: str = Field(default="A", min_length=1, max_length=32, pattern=r"^[A-Za-z0-9_-]+$")
    start: float = Field(ge=0.0, le=86400.0)
    end: float = Field(gt=0.0, le=86400.0)
    sourceText: str = Field(min_length=1, max_length=2000)
    reviewRequired: bool = False
    timingWarning: list[str] = Field(default_factory=list, max_length=5)
    myanmarText: str | None = Field(default=None, max_length=4000)
    englishText: str | None = Field(default=None, max_length=4000)
    translationFallback: bool = False

    @field_validator("sourceText", "myanmarText", "englishText")
    @classmethod
    def normalize_text(cls, value):
        if value is None:
            return value
        return value.strip()

    @model_validator(mode="after")
    def valid_range(self):
        if self.end <= self.start:
            raise ValueError("Dialogue end time must be greater than start time.")
        return self


class StoryTimelineItem(BaseModel):
    """One exported recap cue linked to its source and final video clocks."""

    id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_-]+$")
    sourceEventId: str = Field(min_length=1, max_length=64)
    sourceStart: float = Field(ge=0.0, le=86400.0)
    sourceEnd: float = Field(gt=0.0, le=86400.0)
    narrationStart: float = Field(ge=0.0, le=86400.0)
    narrationEnd: float = Field(gt=0.0, le=86400.0)
    # Optional for compatibility with exports created before the unified
    # story-to-video timeline was published.
    videoStart: float | None = Field(default=None, ge=0.0, le=86400.0)
    videoEnd: float | None = Field(default=None, gt=0.0, le=86400.0)
    sourceText: str = Field(min_length=1, max_length=2000)
    subtitleText: str = Field(min_length=1, max_length=4000)

    @model_validator(mode="after")
    def valid_ranges(self):
        if self.sourceEnd <= self.sourceStart:
            raise ValueError("Story source end time must be greater than start time.")
        if self.narrationEnd <= self.narrationStart:
            raise ValueError("Story narration end time must be greater than start time.")
        if (
            self.videoStart is not None
            and self.videoEnd is not None
            and self.videoEnd <= self.videoStart
        ):
            raise ValueError("Story video end time must be greater than start time.")
        return self


class CameraMove(BaseModel):
    """Timestamped camera framing segment applied before final canvas fitting."""
    startSeconds: float = Field(ge=0.0, le=900.0)
    endSeconds: float = Field(gt=0.0, le=900.0)
    zoom: float = Field(default=1.15, ge=1.0, le=2.5)
    panX: float = Field(default=0.0, ge=-1.0, le=1.0)
    panY: float = Field(default=0.0, ge=-1.0, le=1.0)
    transitionSeconds: float | None = Field(default=None, gt=0.0, le=2.0)


class VideoTransform(BaseModel):
    """Normalized and timestamped transforms applied to the source video."""
    scale: float = Field(default=1.0, ge=1.0, le=2.0)
    zoom: float = Field(default=1.0, ge=1.0, le=2.0)
    x: float = Field(default=0.0, ge=-1.0, le=1.0)
    y: float = Field(default=0.0, ge=-1.0, le=1.0)
    mirrorHorizontal: bool = False
    cameraMoves: list[CameraMove] = Field(default_factory=list, max_length=32)


class ProjectInput(BaseModel):
    title: str = Field(min_length=1, max_length=160)
    sourceUrl: str = Field(default="", max_length=2048)
    sourceObjectPath: str | None = Field(default=None, max_length=512)
    rightsConfirmed: bool
    globalEdit: Edit = "crop"
    blurBoxes: list[BlurBox] = Field(default_factory=list, max_length=20)
    subtitleBox: SubtitleBox | None = None
    maskStyle: MaskStyle = "clean-boxblur"
    subtitleStyle: SubtitleStyle = Field(default_factory=lambda: SubtitleStyle(
        preset="clean-white",
        primaryColor="#FFFFFF",
        outlineColor="#000000",
        outlineWidth=3,
        shadowOpacity=75,
    ))
    originalAudioVolume: float = Field(default=0.0, ge=0.0, le=0.0)
    subtitleFontSize: int = Field(default=32, ge=12, le=120)
    subtitleMarginV: int = Field(default=160, ge=80, le=240)
    subtitleFontFamily: SubtitleFontFamily = "Noto Sans Myanmar"
    subtitleBold: bool = True
    timingOffset: float = Field(default=0.0, ge=-30.0, le=30.0)
    subtitleAlignment: SubtitleAlignment = "center"
    logoScale: float = Field(default=0.22, ge=0.05, le=0.5)
    backgroundMusicObjectPath: str | None = Field(default=None, max_length=512)
    backgroundMusicVolume: float = Field(default=0.15, ge=0.0, le=1.0)
    sfxObjectPath: str | None = Field(default=None, max_length=512)
    sfxVolume: float = Field(default=0.25, ge=0.0, le=1.0)
    narrationDucking: float = Field(default=0.8, ge=0.0, le=1.0)
    videoTransform: VideoTransform = Field(default_factory=VideoTransform)
    targetDurationMinutes: TargetDurationMinutes | None = None
    narrationStartSeconds: float = Field(default=0.5, ge=0.0, le=900.0)
    narrationDurationSeconds: float | None = Field(
        default=None,
        gt=0.0,
        le=900.0,
        description="Optional maximum narration window in seconds; natural speech may finish earlier.",
    )
    narrationSpeed: float = Field(default=1.0, ge=0.8, le=1.5)

    @field_validator("title")
    @classmethod
    def title_valid(cls, value):
        if not value.strip():
            raise ValueError("A project title is required.")
        return value.strip()

    @field_validator("sourceUrl")
    @classmethod
    def source_valid(cls, value):
        if not value.strip():
            return ""
        url = urlsplit(value)
        if url.scheme != "https" or not url.hostname or url.username or url.password:
            raise ValueError("Use a public direct HTTPS video URL, not a webpage.")
        if url.port not in (None, 443):
            raise ValueError("Only standard HTTPS URLs are supported.")
        return value

    @field_validator("sourceObjectPath")
    @classmethod
    def source_object_valid(cls, value):
        if value is None:
            return value
        if not value.startswith("studio/") or ".." in value or len(value) > 512:
            raise ValueError("The uploaded source path is invalid.")
        return value


class ProjectUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=160)
    transcript: str | None = Field(default=None, max_length=60000)
    dialogue: list[DialogueLine] | None = Field(default=None, max_length=500)
    myanmarScript: str | None = Field(default=None, max_length=12000)
    englishScript: str | None = Field(default=None, max_length=12000)
    globalEdit: Edit | None = None
    blurBoxes: list[BlurBox] | None = Field(default=None, max_length=20)
    subtitleBox: SubtitleBox | None = None
    maskStyle: MaskStyle | None = None
    subtitleStyle: SubtitleStyle | None = None
    originalAudioVolume: float | None = Field(default=None, ge=0.0, le=0.0)
    subtitleFontSize: int | None = Field(default=None, ge=12, le=120)
    subtitleMarginV: int | None = Field(default=None, ge=80, le=240)
    subtitleFontFamily: SubtitleFontFamily | None = None
    subtitleBold: bool | None = None
    timingOffset: float | None = Field(default=None, ge=-30.0, le=30.0)
    subtitleAlignment: SubtitleAlignment | None = None
    logoScale: float | None = Field(default=None, ge=0.05, le=0.5)
    logoObjectPath: str | None = Field(default=None, max_length=512)
    logoPosition: LogoPosition | None = None
    logoX: float | None = Field(default=None, ge=0.0, le=1.0)
    logoY: float | None = Field(default=None, ge=0.0, le=1.0)
    watermarkText: str | None = Field(default=None, max_length=80)
    backgroundMusicObjectPath: str | None = Field(default=None, max_length=512)
    backgroundMusicVolume: float | None = Field(default=None, ge=0.0, le=1.0)
    sfxObjectPath: str | None = Field(default=None, max_length=512)
    sfxVolume: float | None = Field(default=None, ge=0.0, le=1.0)
    narrationDucking: float | None = Field(default=None, ge=0.0, le=1.0)
    narrationStartSeconds: float | None = Field(default=None, ge=0.0, le=900.0)
    narrationDurationSeconds: float | None = Field(
        default=None,
        gt=0.0,
        le=900.0,
        description="Optional maximum narration window in seconds; natural speech may finish earlier.",
    )
    storyEndSeconds: float | None = Field(
        default=None,
        ge=0.1,
        le=900.0,
        description="Optional user-confirmed story end on the original source timeline.",
    )
    videoTransform: VideoTransform | None = None
    targetDurationMinutes: TargetDurationMinutes | None = None
    lastRequestedQuality: ExportQuality | None = None
    narrationSpeed: float | None = Field(default=None, ge=0.8, le=1.5)
    scriptUpdatedAt: int | None = Field(default=None, ge=0)

    @field_validator("logoObjectPath", "backgroundMusicObjectPath", "sfxObjectPath")
    @classmethod
    def media_object_valid(cls, value, info):
        if value is None:
            return value
        if not value.startswith("studio/") or ".." in value or len(value) > 512:
            raise ValueError("The uploaded media path is invalid.")
        field_name = info.field_name
        if field_name == "logoObjectPath" and not value.lower().endswith(".png"):
            raise ValueError("Channel logos must be PNG files.")
        if field_name in {"backgroundMusicObjectPath", "sfxObjectPath"}:
            allowed = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"}
            if Path(value).suffix.lower() not in allowed:
                raise ValueError("Audio tracks must use a supported audio file extension.")
        return value


class ViralSearchInput(BaseModel):
    query: str = Field(min_length=1, max_length=256)
    platform: ViralPlatform = "youtube"
    limit: int = Field(default=8, ge=1, le=12)

    @field_validator("query")
    @classmethod
    def query_valid(cls, value):
        value = value.strip()
        if not value:
            raise ValueError("Enter a video URL or search query.")
        return value


class ViralIngestInput(BaseModel):
    url: str = Field(min_length=1, max_length=2048)
    title: str = Field(default="Viral source", min_length=1, max_length=160)
    platform: ViralPlatform
    rightsConfirmed: bool = False

    @field_validator("url")
    @classmethod
    def url_valid(cls, value):
        value = value.strip()
        parsed = urlsplit(value)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Use a public HTTPS source video URL.")
        if parsed.port not in (None, 443):
            raise ValueError("Only standard HTTPS URLs are supported.")
        return value

    @field_validator("title")
    @classmethod
    def ingest_title_valid(cls, value):
        return value.strip() or "Viral source"


class UploadCleanupInput(BaseModel):
    sourceObjectPath: str = Field(min_length=1, max_length=512)


class RunInput(BaseModel):
    action: Literal[
        "full",
        "transcribe",
        "translate",
        "export",
        "export_english",
        "export_capcut",
        "test_export",
    ]
    quality: ExportQuality = "1080p"
    transcript: str | None = Field(default=None, max_length=60000)
    dialogue: list[DialogueLine] | None = Field(default=None, max_length=500)
    myanmarScript: str | None = Field(default=None, max_length=12000)
    englishScript: str | None = Field(default=None, max_length=12000)
    globalEdit: Edit | None = None
    scriptUpdatedAt: int | None = Field(default=None, ge=0)
    previewWidth: int | None = Field(default=None, ge=1, le=10000)
    previewHeight: int | None = Field(default=None, ge=1, le=10000)
    exportWidth: int | None = Field(default=None, ge=1, le=10000)
    exportHeight: int | None = Field(default=None, ge=1, le=10000)
    blurBoxes: list[BlurBox] | None = Field(default=None, max_length=20)
    subtitleBox: SubtitleBox | None = None
    maskStyle: MaskStyle | None = None
    subtitleStyle: SubtitleStyle | None = None
    originalAudioVolume: float | None = Field(default=None, ge=0.0, le=0.0)
    subtitleFontSize: int | None = Field(default=None, ge=12, le=120)
    subtitleMarginV: int | None = Field(default=None, ge=80, le=240)
    subtitleFontFamily: SubtitleFontFamily | None = None
    subtitleBold: bool | None = None
    timingOffset: float | None = Field(default=None, ge=-30.0, le=30.0)
    narrationStartSeconds: float | None = Field(default=None, ge=0.0, le=900.0)
    narrationDurationSeconds: float | None = Field(
        default=None,
        gt=0.0,
        le=900.0,
        description="Optional maximum narration window in seconds; natural speech may finish earlier.",
    )
    storyEndSeconds: float | None = Field(
        default=None,
        ge=0.1,
        le=900.0,
        description="Optional user-confirmed story end on the original source timeline.",
    )
    narrationSpeed: float | None = Field(default=None, ge=0.8, le=1.5)
    subtitleAlignment: SubtitleAlignment | None = None
    logoPosition: LogoPosition | None = None
    logoX: float | None = Field(default=None, ge=0.0, le=1.0)
    logoY: float | None = Field(default=None, ge=0.0, le=1.0)
    logoScale: float | None = Field(default=None, ge=0.05, le=0.5)
    watermarkText: str | None = Field(default=None, max_length=80)
    videoTransform: VideoTransform | None = None


class ScheduleInput(BaseModel):
    projectId: str
    mode: Literal["instant", "smart", "manual"]
    scheduledAt: str | None = None
    timezone: str = "Asia/Yangon"


class SettingsInput(BaseModel):
    timezone: str
    peakHours: list[int] = Field(min_length=1, max_length=24)
    myanmarVoice: Literal["my-MM-NilarNeural", "my-MM-ThihaNeural"]
    myanmarRate: int = Field(default=15, ge=0, le=15)
    englishVoice: Literal["en-US-JennyNeural", "en-US-GuyNeural", "en-GB-SoniaNeural"]

    @field_validator("timezone")
    @classmethod
    def timezone_valid(cls, value):
        try:
            ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError):
            raise ValueError("Choose a valid IANA timezone.")
        return value

    @field_validator("peakHours")
    @classmethod
    def hours_valid(cls, value):
        if any(h < 0 or h > 23 for h in value):
            raise ValueError("Peak hours must be between 0 and 23.")
        return sorted(set(value))