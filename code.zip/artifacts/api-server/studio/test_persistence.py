"""Persistence and restart-recovery tests for studio project state."""
import json
import sqlite3
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import Mock, patch

from .offline_test_support import install_network_guard

install_network_guard()

from fastapi import HTTPException

from . import main, storage, store


class PersistenceStoreTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.state_path = Path(self.directory.name) / "data" / "projects.json"
        self.database_path = Path(self.directory.name) / "data" / "studio.sqlite3"
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(str(self.database_path))
        self.connection.row_factory = sqlite3.Row
        store._initialize_database(self.connection)

    def tearDown(self):
        self.connection.close()
        self.directory.cleanup()

    def test_saved_project_is_written_to_disk_and_hydrated_after_restart(self):
        project = {
            "id": "restart-safe-project",
            "title": "Restart safe",
            "status": "processing",
            "myanmarScript": "မြန်မာစာသား",
            "settings": {"narrationSpeed": 1.1},
        }
        with patch.object(store, "PROJECT_STATE_PATH", self.state_path), \
                patch.object(store, "SQLITE_DATABASE_PATH", self.database_path):
            store.save(self.connection, "old-owner", "project", project)
            self.assertTrue(self.state_path.is_file())
            payload = json.loads(self.state_path.read_text(encoding="utf-8"))
            self.assertEqual(
                payload["records"]["project:restart-safe-project"]["data"],
                project,
            )

            self.connection.close()
            self.database_path.unlink()
            restarted = sqlite3.connect(str(self.database_path))
            restarted.row_factory = sqlite3.Row
            try:
                store._initialize_database(restarted)
                store._hydrate_from_disk(restarted)
                self.assertEqual(
                    store.get(restarted, "old-owner", "project", "restart-safe-project"),
                    project,
                )
            finally:
                restarted.close()

    def test_deleted_project_is_removed_from_disk_recovery(self):
        project = {"id": "deleted-project", "title": "Delete me"}
        with patch.object(store, "PROJECT_STATE_PATH", self.state_path), \
                patch.object(store, "SQLITE_DATABASE_PATH", self.database_path):
            store.save(self.connection, "owner", "project", project)
            linked_records = {
                "subtitle-record": {"id": "subtitle-record", "projectId": project["id"]},
                "audio-record": {"id": "audio-record", "projectId": project["id"]},
                "blur-record": {"id": "blur-record", "projectId": project["id"]},
                "render-log": {"id": "render-log", "projectId": project["id"]},
            }
            for kind, record in linked_records.items():
                store.save(self.connection, "owner", kind, record)
            store.delete_project_records(self.connection, "owner", project["id"])
            payload = json.loads(self.state_path.read_text(encoding="utf-8"))
        self.assertEqual(payload["records"], {})
        for kind, record in linked_records.items():
            self.assertIsNone(store.get(self.connection, "owner", kind, record["id"]))

    def test_sqlite_tombstone_blocks_stale_snapshot_after_snapshot_write_failure(self):
        project = {"id": "delete-failure-project", "title": "Must stay deleted"}
        with patch.object(store, "PROJECT_STATE_PATH", self.state_path), \
                patch.object(store, "SQLITE_DATABASE_PATH", self.database_path):
            store.save(self.connection, "owner", "project", project)
            stale_snapshot = self.state_path.read_text(encoding="utf-8")
            with patch.object(
                store,
                "_write_disk_records",
                side_effect=OSError("injected snapshot failure"),
            ):
                store.delete_project_records(
                    self.connection, "owner", project["id"]
                )
            self.assertEqual(
                self.state_path.read_text(encoding="utf-8"),
                stale_snapshot,
            )

            restarted = sqlite3.connect(str(self.database_path))
            restarted.row_factory = sqlite3.Row
            try:
                store._initialize_database(restarted)
                store._hydrate_from_disk(restarted)
                self.assertIsNone(
                    store.get(restarted, "owner", "project", project["id"])
                )
            finally:
                restarted.close()

    def test_stale_snapshot_cannot_overwrite_newer_sqlite_record(self):
        project = {"id": "newer-row-project", "title": "Snapshot version"}
        with patch.object(store, "PROJECT_STATE_PATH", self.state_path):
            store.save(self.connection, "owner", "project", project)
            newer = {**project, "title": "SQLite version"}
            self.connection.execute(
                "UPDATE studio_records SET data=? WHERE id=?",
                (store._json_data(newer), project["id"]),
            )
            self.connection.commit()

            store._hydrate_from_disk(self.connection)

        self.assertEqual(
            store.get(self.connection, "owner", "project", project["id"])["title"],
            "SQLite version",
        )

    def test_snapshot_tombstone_blocks_deleted_project_after_database_rebuild(self):
        project = {"id": "tombstoned-project", "title": "Deleted"}
        with patch.object(store, "PROJECT_STATE_PATH", self.state_path):
            store.save(self.connection, "owner", "project", project)
            store.delete_project_records(
                self.connection, "owner", project["id"]
            )
            snapshot = json.loads(self.state_path.read_text(encoding="utf-8"))
            self.assertIn(project["id"], snapshot["tombstones"])

            rebuilt_path = Path(self.directory.name) / "data" / "rebuilt.sqlite3"
            rebuilt = sqlite3.connect(str(rebuilt_path))
            rebuilt.row_factory = sqlite3.Row
            try:
                store._initialize_database(rebuilt)
                store._hydrate_from_disk(rebuilt)
                self.assertIsNone(
                    store.get(rebuilt, "owner", "project", project["id"])
                )
            finally:
                rebuilt.close()

    def test_delete_missing_project_is_idempotent_without_deleting_unowned_media(self):
        request = Mock()
        request.state.owner = "requesting-owner"
        media_root = Path(self.directory.name) / "media"
        client = storage.LocalStorageClient(media_root)
        orphaned = media_root / "studio" / "another-owner-project" / "old-run"
        orphaned.mkdir(parents=True, exist_ok=True)
        (orphaned / "completed.mp4").write_bytes(b"orphaned video")
        other_owner_project = {
            "id": "another-owner-project",
            "title": "Private project",
            "status": "completed",
            "exports": [{"language": "myanmar"}],
            "objectPrefix": "studio/another-owner-project/old-run",
        }
        with patch.object(store, "PROJECT_STATE_PATH", self.state_path), \
                patch.object(store, "SQLITE_DATABASE_PATH", self.database_path), \
                patch.object(main.store, "connection", return_value=self.connection), \
                patch.object(main, "storage_client", return_value=client):
            store.save(self.connection, "different-owner", "project", other_owner_project)
            response = main.delete_project("another-owner-project", request)

        self.assertEqual(response.status_code, 204)
        self.assertEqual((orphaned / "completed.mp4").read_bytes(), b"orphaned video")

    def test_delete_project_with_legacy_missing_status_does_not_crash(self):
        project = {"id": "legacy-without-status", "title": "Legacy project"}
        request = Mock()
        request.state.owner = "owner"
        with patch.object(main.store, "connection", return_value=self.connection), \
                patch.object(main.store, "delete_project_records") as delete_records:
            store.save(self.connection, "owner", "project", project)
            main.delete_project(project["id"], request)
        delete_records.assert_called_once_with(
            self.connection,
            "owner",
            project["id"],
        )

    def test_delete_project_removes_timestamped_exports_from_each_published_prefix(self):
        project = {
            "id": "completed-project",
            "title": "Completed project",
            "status": "completed",
            "exports": [{"language": "myanmar"}],
            "objectPrefix": "studio/completed-project/legacy-run",
            "exportObjectPrefixes": {
                "myanmar": "studio/completed-project/run-myanmar",
                "english": "studio/completed-project/run-english",
            },
        }
        media_root = Path(self.directory.name) / "media"
        client = storage.LocalStorageClient(media_root)
        published_prefixes = {
            project["objectPrefix"],
            *project["exportObjectPrefixes"].values(),
        }
        for prefix in published_prefixes:
            output = media_root / prefix / "Completed_project_20260923_myanmar.mp4"
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(b"completed video")

        request = Mock()
        request.state.owner = "owner"
        with patch.object(main.store, "connection", return_value=self.connection), \
                patch.object(main, "storage_client", return_value=client), \
                patch.object(main.store, "delete_project_records") as delete_records:
            store.save(self.connection, "owner", "project", project)
            main.delete_project(project["id"], request)

        delete_records.assert_called_once_with(
            self.connection,
            "owner",
            project["id"],
        )
        for prefix in published_prefixes:
            self.assertFalse((media_root / prefix).exists())

    def test_delete_project_export_removes_only_selected_language_assets(self):
        project = {
            "id": "language-export-delete",
            "title": "Language export delete",
            "status": "completed",
            "progress": 100,
            "exports": [
                {
                    "language": "myanmar",
                    "videoFilename": "myanmar-final.mp4",
                    "subtitleFilename": "myanmar.srt",
                    "audioFilename": "myanmar.mp3",
                    "thumbnailFilename": "myanmar.jpg",
                },
                {
                    "language": "english",
                    "videoFilename": "english-final.mp4",
                    "subtitleFilename": "english.srt",
                    "audioFilename": "english.mp3",
                    "thumbnailFilename": "english.jpg",
                },
            ],
            "objectPrefix": "studio/language-export-delete/legacy",
            "exportObjectPrefixes": {
                "myanmar": "studio/language-export-delete/myanmar",
                "english": "studio/language-export-delete/english",
            },
        }
        media_root = Path(self.directory.name) / "media"
        client = storage.LocalStorageClient(media_root)
        for language, filenames in (
            ("myanmar", ("myanmar-final.mp4", "myanmar.srt", "myanmar.mp3", "myanmar.jpg")),
            ("english", ("english-final.mp4", "english.srt", "english.mp3", "english.jpg")),
        ):
            prefix = project["exportObjectPrefixes"][language]
            for filename in filenames:
                output = media_root / prefix / filename
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_bytes(b"export")

        request = Mock()
        request.state.owner = "owner"
        with patch.object(main.store, "connection", return_value=self.connection), \
                patch.object(main, "storage_client", return_value=client):
            store.save(self.connection, "owner", "project", project)
            result = main.delete_project_export(project["id"], "myanmar", request)

        self.assertEqual([item["language"] for item in result["exports"]], ["english"])
        self.assertFalse((media_root / project["exportObjectPrefixes"]["myanmar"]).exists())
        self.assertTrue((media_root / project["exportObjectPrefixes"]["english"]).exists())

    def test_enqueue_persists_the_exact_script_and_processing_version(self):
        owner = "owner"
        project = {
            "id": "queued-project",
            "title": "Queued project",
            "status": "draft",
            "stage": "Not started",
            "progress": 0,
            "sourceObjectPath": "studio/owner/sources/source.mp4",
            "sourceUrl": "",
            "transcript": "原始文本",
            "dialogue": [],
            "myanmarScript": "အဟောင်း",
            "englishScript": "Old",
            "exports": [{"language": "myanmar"}],
            "exportsStale": False,
            "events": [],
            "scriptVersion": 0,
            "processingVersion": 0,
            "outputVersion": 0,
        }
        with patch.object(store, "PROJECT_STATE_PATH", self.state_path), \
                patch.object(store, "SQLITE_DATABASE_PATH", self.database_path), \
                patch.object(store, "database_backend", return_value="sqlite"):
            store.save(self.connection, owner, "project", project)
            schedule = main.enqueue(
                self.connection,
                owner,
                project,
                "export",
                datetime.now(timezone.utc),
                "instant",
                "Asia/Yangon",
                quality="720p",
                overrides={
                    "myanmarScript": "အသစ်",
                    "scriptUpdatedAt": 123,
                    "narrationSpeed": 1.15,
                    "globalEdit": "zoom",
                },
            )
            saved = store.get(self.connection, owner, "project", project["id"])
            snapshot = json.loads(self.state_path.read_text(encoding="utf-8"))

        self.assertEqual(saved["myanmarScript"], "အသစ်")
        self.assertEqual(saved["narrationSpeed"], 1.15)
        self.assertEqual(saved["globalEdit"], "zoom")
        self.assertEqual(saved["scriptVersion"], 1)
        self.assertEqual(saved["processingVersion"], 1)
        self.assertEqual(saved["lastRequestedQuality"], "720p")
        self.assertTrue(saved["exportsStale"])
        self.assertEqual(schedule["processingVersion"], 1)
        self.assertEqual(schedule["scriptVersion"], 1)
        self.assertEqual(schedule["_projectOverrides"]["globalEdit"], "zoom")
        self.assertEqual(
            snapshot["records"]["project:queued-project"]["data"]["globalEdit"],
            "zoom",
        )
        self.assertEqual(
            snapshot["records"][f"schedule:{schedule['id']}"]["data"]["projectId"],
            project["id"],
        )

    def test_run_endpoint_persists_global_edit_from_the_current_editor(self):
        owner = "owner"
        project = {
            "id": "run-global-edit",
            "title": "Run global edit",
            "status": "draft",
            "stage": "Not started",
            "progress": 0,
            "sourceObjectPath": "studio/owner/sources/source.mp4",
            "sourceUrl": "",
            "myanmarScript": "မြန်မာစာသား",
            "englishScript": "English script",
            "events": [],
            "exports": [],
            "scriptVersion": 0,
            "processingVersion": 0,
        }
        request = Mock()
        request.state.owner = owner
        with patch.object(store, "PROJECT_STATE_PATH", self.state_path), \
                patch.object(store, "SQLITE_DATABASE_PATH", self.database_path), \
                patch.object(main.store, "connection", return_value=self.connection):
            store.save(self.connection, owner, "project", project)
            result = main.run_project(
                project["id"],
                main.RunInput(action="export", quality="720p", globalEdit="zoom"),
                request,
            )
            saved = store.get(self.connection, owner, "project", project["id"])
            schedules = store.all_records(self.connection, owner, "schedule")

        self.assertEqual(result["status"], "queued")
        self.assertEqual(saved["globalEdit"], "zoom")
        self.assertEqual(schedules[0]["_projectOverrides"]["globalEdit"], "zoom")

    def test_stale_concurrent_run_request_cannot_queue_a_duplicate_job(self):
        owner = "owner"
        project = {
            "id": "duplicate-run",
            "title": "Duplicate run",
            "status": "draft",
            "stage": "Not started",
            "progress": 0,
            "sourceObjectPath": "studio/owner/sources/source.mp4",
            "sourceUrl": "",
            "myanmarScript": "မြန်မာစာသား",
            "events": [],
            "exports": [],
            "scriptVersion": 0,
            "processingVersion": 0,
        }
        with patch.object(store, "PROJECT_STATE_PATH", self.state_path), \
                patch.object(store, "SQLITE_DATABASE_PATH", self.database_path):
            store.save(self.connection, owner, "project", project)
            first_snapshot = store.get(self.connection, owner, "project", project["id"])
            stale_snapshot = store.get(self.connection, owner, "project", project["id"])
            main.enqueue(
                self.connection,
                owner,
                first_snapshot,
                "export",
                datetime.now(timezone.utc),
                "instant",
                "Asia/Yangon",
                overrides={"globalEdit": "zoom"},
            )
            with self.assertRaises(HTTPException) as raised:
                main.enqueue(
                    self.connection,
                    owner,
                    stale_snapshot,
                    "export",
                    datetime.now(timezone.utc),
                    "instant",
                    "Asia/Yangon",
                    overrides={"globalEdit": "blur"},
                )
            schedules = store.all_records(self.connection, owner, "schedule")
            saved = store.get(self.connection, owner, "project", project["id"])

        self.assertEqual(raised.exception.status_code, 409)
        self.assertEqual(len(schedules), 1)
        self.assertEqual(saved["globalEdit"], "zoom")


class ProjectLookupPersistenceTests(unittest.TestCase):
    def test_public_project_exposes_retry_metadata_and_quality_defaults_for_legacy_records(self):
        result = main.public_project({
            "id": "legacy-project",
            "title": "Legacy project",
            "status": "failed",
            "stage": "Failed",
            "error": "A render failed.",
        })

        self.assertEqual(result["lastRequestedQuality"], "1080p")
        self.assertEqual(result["error"], "A render failed.")
        self.assertEqual(result["errorDetails"], "")
        self.assertEqual(result["errorStage"], "")
        self.assertEqual(result["errorCode"], "")
        self.assertEqual(result["pipelineCheckpoint"], {"version": 1, "stages": {}})

    def test_public_project_preserves_retry_metadata_from_a_failed_job(self):
        result = main.public_project({
            "id": "failed-project",
            "title": "Failed project",
            "status": "failed",
            "stage": "Failed",
            "lastRequestedQuality": "720p",
            "error": "FFmpeg failed.",
            "errorDetails": "FFmpeg failed.",
            "errorStage": "final-render",
            "errorCode": "FFMPEG_RENDER_ERROR",
            "pipelineCheckpoint": {
                "version": 1,
                "stages": {"source": "completed", "render": "completed"},
            },
        })

        self.assertEqual(result["lastRequestedQuality"], "720p")
        self.assertEqual(result["errorStage"], "final-render")
        self.assertEqual(result["errorCode"], "FFMPEG_RENDER_ERROR")
        self.assertEqual(
            result["pipelineCheckpoint"]["stages"]["render"],
            "completed",
        )

    def test_project_library_uses_recovery_snapshot_when_database_is_unavailable(self):
        request = Mock()
        request.state.owner = "previous-owner"
        project = {
            "id": "snapshot-project",
            "title": "Snapshot project",
            "status": "draft",
            "sourceUrl": "",
        }
        with patch.object(
            main.store,
            "connection",
            side_effect=store.StoreUnavailableError(),
        ), patch.object(
            main.store,
            "disk_records",
            return_value=[(project, "previous-owner")],
        ), patch.object(
            main.store,
            "database_backend",
            return_value="sqlite",
        ):
            result = main.projects(request)

        self.assertEqual([item["id"] for item in result], ["snapshot-project"])
        self.assertEqual(result[0]["title"], "Snapshot project")

    def test_malformed_project_record_does_not_break_library_response(self):
        request = Mock()
        request.state.owner = "owner"
        with patch.object(main.store, "connection") as connection_context, \
                patch.object(
                    main.store,
                    "all_records",
                    return_value=[{"id": "good", "title": "Good"}, "not-a-record"],
                ):
            connection_context.return_value.__enter__.return_value = Mock()
            result = main.projects(request)

        self.assertEqual(result[0]["id"], "good")
        self.assertTrue(result[1]["id"].startswith("unavailable-"))
        self.assertEqual(result[1]["status"], "unavailable")

    def test_project_detail_uses_recovery_snapshot_when_database_is_unavailable(self):
        request = Mock()
        request.state.owner = "owner"
        project = {"id": "detail-snapshot", "title": "Recovered detail", "status": "draft"}
        with patch.object(
            main.store,
            "connection",
            side_effect=store.StoreUnavailableError(),
        ), patch.object(
            main.store,
            "disk_records",
            return_value=[(project, "owner")],
        ), patch.object(
            main.store,
            "database_backend",
            return_value="sqlite",
        ):
            result = main.get_project(project["id"], request)

        self.assertEqual(result["id"], project["id"])
        self.assertEqual(result["title"], "Recovered detail")

    def test_project_id_is_not_reassigned_after_workspace_cookie_change(self):
        project = {"id": "private-id", "title": "Private project"}
        connection = Mock()
        with patch.object(main.store, "get", return_value=None), \
                patch.object(main.store, "get_any_owner") as get_any_owner, \
                patch.object(main.store, "reassign_project_owner") as reassign:
            with self.assertRaisesRegex(HTTPException, "Project not found"):
                main.project_or_404(connection, "new-owner", project["id"])

        get_any_owner.assert_not_called()
        reassign.assert_not_called()

    def test_missing_project_still_returns_not_found(self):
        connection = Mock()
        with patch.object(main.store, "get", return_value=None):
            with self.assertRaisesRegex(HTTPException, "Project not found"):
                main.project_or_404(connection, "owner", "actually-deleted")

    def test_new_workspace_project_library_does_not_reassign_other_owners(self):
        project = {"id": "library-project", "title": "Library project"}
        request = Mock()
        request.state.owner = "new-owner"
        connection = Mock()
        with patch.object(main.store, "connection") as connection_context, \
                patch.object(main.store, "all_records", return_value=[]), \
                patch.object(main.store, "all_records_any_owner") as any_owner, \
                patch.object(main.store, "reassign_project_owner") as reassign:
            connection_context.return_value.__enter__.return_value = connection
            result = main.projects(request)

        self.assertEqual(result, [])
        any_owner.assert_not_called()
        reassign.assert_not_called()

    def test_snapshot_lookup_never_falls_back_to_other_owners(self):
        with patch.object(
            main.store,
            "disk_records",
            return_value=[],
        ) as disk_records:
            self.assertEqual(main._disk_project_records("new-owner"), [])

        disk_records.assert_called_once_with(kind="project", owner="new-owner")


class HealthEndpointTests(unittest.TestCase):
    def test_both_health_endpoints_return_503_when_database_is_degraded(self):
        for endpoint in (main.health, main.api_root):
            with self.subTest(endpoint=endpoint.__name__), \
                    patch.object(main, "database_degraded", True):
                response = endpoint()

            self.assertEqual(response.status_code, 503)
            self.assertEqual(
                json.loads(response.body),
                {"status": "degraded", "database": "unavailable"},
            )

    def test_both_health_endpoints_return_200_when_database_is_available(self):
        for endpoint in (main.health, main.api_root):
            with self.subTest(endpoint=endpoint.__name__), \
                    patch.object(main, "database_degraded", False):
                response = endpoint()

            self.assertEqual(response.status_code, 200)
            self.assertEqual(
                json.loads(response.body),
                {"status": "ok", "database": "ok"},
            )


class PostgresSchemaInitializationTests(unittest.TestCase):
    def test_postgres_initialization_applies_the_canonical_schema(self):
        connection = Mock()
        connection.dialect = "postgres"
        connection.in_transaction = False

        store.initialize_postgres_schema(connection)

        statements = [call.args[0] for call in connection.execute.call_args_list]
        schema = "\n".join(statements).lower()
        self.assertIn("create table if not exists studio_records", schema)
        self.assertIn("data jsonb not null", schema)
        self.assertIn("created_at timestamptz", schema)
        self.assertIn("create index if not exists studio_records_owner_kind", schema)
        connection.commit.assert_called_once_with()

    def test_postgres_initialization_is_a_noop_for_sqlite(self):
        connection = Mock()
        connection.dialect = "sqlite"

        store.initialize_postgres_schema(connection)

        connection.execute.assert_not_called()
        connection.commit.assert_not_called()


if __name__ == "__main__":
    unittest.main()