"""Deterministic offline coverage for durable Studio recovery."""
from __future__ import annotations

import asyncio
import hashlib
import io
import json
import os
import shutil
import subprocess
import tempfile
import threading
import unittest
import urllib.error
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from .offline_test_support import install_network_guard

install_network_guard()

from fastapi import HTTPException, UploadFile

from . import engine, main, migrate_local_to_durable, storage, store


class MemoryResponse:
    def __init__(self, body: bytes):
        self.body = body

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self):
        return self.body


class FakeObjectStorage:
    def __init__(self):
        self.objects: dict[str, bytes] = {}

    def upload_from_filename(self, object_name, filename):
        self.objects[object_name] = Path(filename).read_bytes()

    def download_to_filename(self, object_name, filename):
        if object_name not in self.objects:
            raise FileNotFoundError(object_name)
        Path(filename).write_bytes(self.objects[object_name])

    def exists(self, object_name):
        return object_name in self.objects

    def list(self, prefix=None, **_kwargs):
        return [
            SimpleNamespace(name=name)
            for name in self.objects
            if prefix is None or name.startswith(prefix)
        ]

    def delete(self, object_name, ignore_not_found=False):
        if object_name not in self.objects and not ignore_not_found:
            raise FileNotFoundError(object_name)
        self.objects.pop(object_name, None)


def _completed_transcript():
    return {
        "status": "completed",
        "text": "你好",
        "utterances": [
            {"text": "你好", "start": 0, "end": 900, "speaker": "A"},
        ],
    }


def _http_error(request, status):
    return urllib.error.HTTPError(
        request.full_url,
        status,
        "mock provider response",
        {},
        io.BytesIO(b'{"error":"offline fixture"}'),
    )


class DurableRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.database_path = self.root / "studio.sqlite3"
        self.snapshot_path = self.root / "projects.json"
        self.owner = "owner-a"
        self.project_id = "recovery-project"
        self.stack = [
            patch.dict(
                os.environ,
                {
                    "STUDIO_DATABASE_BACKEND": "sqlite",
                    "STUDIO_MEDIA_BACKEND": "local",
                },
            ),
            patch.object(store, "SQLITE_DATABASE_PATH", self.database_path),
            patch.object(store, "PROJECT_STATE_PATH", self.snapshot_path),
        ]
        for item in self.stack:
            item.start()
        self.addCleanup(self.temporary.cleanup)
        self.addCleanup(self._stop_patches)
        with store.connection() as conn:
            store.save(conn, self.owner, "project", self._project())

    def _stop_patches(self):
        for item in reversed(self.stack):
            item.stop()

    def _project(self):
        return {
            "id": self.project_id,
            "title": "Offline fixture",
            "status": "draft",
            "stage": "Not started",
            "progress": 0,
            "sourceObjectPath": "studio/owner-a/sources/source.mp4",
            "sourceUrl": "",
            "myanmarScript": "စမ်းသပ်စာသား",
            "englishScript": "Test script",
            "events": [],
            "exports": [],
            "exportsStale": False,
            "scriptVersion": 0,
            "processingVersion": 0,
        }

    def _callbacks(
        self,
        job_id,
        *,
        load_barrier=None,
        after_save=None,
        after_claim=None,
    ):
        def load(operation_key):
            with store.connection() as conn:
                result = store.get_provider_operation(conn, self.owner, operation_key)
            if load_barrier:
                load_barrier.wait(timeout=10)
            return result

        def claim_create(operation_key, record):
            payload = dict(record or {})
            payload.update(
                provider="assemblyai",
                projectId=self.project_id,
                jobId=job_id,
            )
            with store.connection() as conn:
                claimed = store.claim_provider_operation(
                    conn,
                    self.owner,
                    self.project_id,
                    operation_key,
                    payload,
                )
            if after_claim:
                after_claim(claimed)
            return claimed

        def save(operation_key, record):
            payload = dict(record or {})
            payload.update(
                provider="assemblyai",
                projectId=self.project_id,
                jobId=job_id,
            )
            with store.connection() as conn:
                saved = store.save_provider_operation(
                    conn,
                    self.owner,
                    operation_key,
                    payload,
                )
            if after_save:
                after_save(saved)
            return saved

        return {
            "load": load,
            "claim_create": claim_create,
            "save": save,
        }

    def _source(self):
        source = self.root / "audio.wav"
        source.write_bytes(b"offline audio fixture")
        return source

    def _base_provider_patches(self):
        return [
            patch.object(engine, "_assemblyai_key", return_value="offline-test-key"),
            patch.object(
                engine,
                "_transcription_audio_details",
                return_value={
                    "audio_format": "wav",
                    "audio_duration": 1,
                    "file_size": 21,
                },
            ),
            patch.object(
                engine,
                "_assemblyai_request_bytes",
                return_value=b'{"upload_url":"https://upload.invalid/audio"}',
            ),
            patch.object(engine.time, "sleep"),
        ]

    def _start_patches(self, patches):
        for item in patches:
            item.start()
            self.addCleanup(item.stop)

    def test_provider_id_is_persisted_before_restart_and_reused_once(self):
        posts = []
        gets = []

        def request(_key, _endpoint, method, _payload=None, deadline=None):
            if method == "POST":
                posts.append(deadline)
                return {"id": "transcript-42"}
            gets.append(deadline)
            return _completed_transcript()

        def crash_after_durable_id(record):
            if record.get("status") == "PROVIDER_ID_KNOWN":
                raise RuntimeError("simulated process interruption")

        self._start_patches(
            self._base_provider_patches()
            + [patch.object(engine, "_assemblyai_json_request", side_effect=request)]
        )
        source = self._source()
        callbacks = self._callbacks("job-1", after_save=crash_after_durable_id)
        with self.assertRaises(engine.EngineError):
            engine._assemblyai_transcript_with_dialogue(
                source,
                callbacks,
                "job-1:chunk:0",
            )

        with store.connection() as conn:
            persisted = store.get_provider_operation(
                conn,
                self.owner,
                "job-1:chunk:0",
            )
        self.assertEqual(persisted["providerTranscriptId"], "transcript-42")
        self.assertEqual(persisted["status"], "PROVIDER_ID_KNOWN")

        text, dialogue = engine._assemblyai_transcript_with_dialogue(
            source,
            self._callbacks("job-1"),
            "job-1:chunk:0",
        )
        self.assertEqual(text, "你好")
        self.assertEqual(len(dialogue), 1)
        self.assertEqual(len(posts), 1)
        self.assertEqual(len(gets), 1)
        self.assertEqual(persisted["jobId"], "job-1")
        self.assertEqual(persisted["projectId"], self.project_id)

    def test_transient_poll_503_resumes_the_same_id_without_a_second_create(self):
        create_posts = 0
        poll_requests = 0

        def fake_urlopen(request, timeout=None):
            nonlocal create_posts, poll_requests
            if request.full_url.endswith("/upload"):
                return MemoryResponse(b'{"upload_url":"https://upload.invalid/audio"}')
            if request.method == "POST":
                create_posts += 1
                return MemoryResponse(b'{"id":"transcript-503"}')
            poll_requests += 1
            if poll_requests <= 3:
                raise _http_error(request, 503)
            return MemoryResponse(json.dumps(_completed_transcript()).encode())

        self._start_patches([
            patch.object(engine, "_assemblyai_key", return_value="offline-test-key"),
            patch.object(
                engine,
                "_transcription_audio_details",
                return_value={"audio_format": "wav", "audio_duration": 1, "file_size": 21},
            ),
            patch.object(engine.urllib.request, "urlopen", side_effect=fake_urlopen),
            patch.object(engine.time, "sleep"),
        ])
        source = self._source()
        callbacks = self._callbacks("job-503")
        with self.assertRaises(engine.EngineError):
            engine._assemblyai_transcript_with_dialogue(
                source,
                callbacks,
                "job-503:chunk:0",
            )
        with store.connection() as conn:
            interrupted = store.get_provider_operation(
                conn,
                self.owner,
                "job-503:chunk:0",
            )
        self.assertEqual(interrupted["providerTranscriptId"], "transcript-503")
        self.assertEqual(interrupted["status"], "POLLING")

        text, _dialogue = engine._assemblyai_transcript_with_dialogue(
            source,
            self._callbacks("job-503"),
            "job-503:chunk:0",
        )
        self.assertEqual(text, "你好")
        self.assertEqual(create_posts, 1)
        self.assertEqual(poll_requests, 4)

    def test_ambiguous_create_is_blocked_after_restart(self):
        upload_requests = 0
        create_requests = 0

        def upload(*_args, **_kwargs):
            nonlocal upload_requests
            upload_requests += 1
            return b'{"upload_url":"https://upload.invalid/audio"}'

        def create(_key, endpoint, method, *_args, **_kwargs):
            nonlocal create_requests
            if method == "POST" and endpoint.endswith("/transcript"):
                create_requests += 1
                raise _http_error(
                    SimpleNamespace(full_url=endpoint),
                    503,
                )
            raise AssertionError("No poll should follow an ambiguous create.")

        self._start_patches(
            self._base_provider_patches()
            + [
                patch.object(engine, "_assemblyai_request_bytes", side_effect=upload),
                patch.object(engine, "_assemblyai_json_request", side_effect=create),
            ]
        )
        source = self._source()
        with self.assertRaises(engine.EngineError) as raised:
            engine._assemblyai_transcript_with_dialogue(
                source,
                self._callbacks("job-ambiguous"),
                "job-ambiguous:chunk:0",
            )
        self.assertEqual(raised.exception.code, "ASSEMBLYAI_AMBIGUOUS_CREATE")
        with store.connection() as conn:
            persisted = store.get_provider_operation(
                conn,
                self.owner,
                "job-ambiguous:chunk:0",
            )
        self.assertEqual(persisted["status"], "AMBIGUOUS_CREATE")

        with self.assertRaises(engine.EngineError) as restarted:
            engine._assemblyai_transcript_with_dialogue(
                source,
                self._callbacks("job-ambiguous"),
                "job-ambiguous:chunk:0",
            )
        self.assertEqual(restarted.exception.code, "ASSEMBLYAI_AMBIGUOUS_CREATE")
        self.assertEqual(upload_requests, 1)
        self.assertEqual(create_requests, 1)

    def test_create_429_retries_are_bounded_and_401_is_not_retried(self):
        for status_code, expected_attempts, job_id in (
            (429, 3, "job-429"),
            (401, 1, "job-401"),
        ):
            with self.subTest(status_code=status_code):
                create_requests = 0

                def fake_urlopen(request, timeout=None):
                    nonlocal create_requests
                    if request.full_url.endswith("/upload"):
                        return MemoryResponse(b'{"upload_url":"https://upload.invalid/audio"}')
                    if request.method == "POST":
                        create_requests += 1
                        raise _http_error(request, status_code)
                    raise AssertionError("Create rejection must not start polling.")

                callbacks = self._callbacks(job_id)
                patches = [
                    patch.object(engine, "_assemblyai_key", return_value="offline-test-key"),
                    patch.object(
                        engine,
                        "_transcription_audio_details",
                        return_value={"audio_format": "wav", "audio_duration": 1, "file_size": 21},
                    ),
                    patch.object(engine.urllib.request, "urlopen", side_effect=fake_urlopen),
                    patch.object(engine.time, "sleep"),
                ]
                started = []
                try:
                    for item in patches:
                        item.start()
                        started.append(item)
                    with self.assertRaises(engine.EngineError):
                        engine._assemblyai_transcript_with_dialogue(
                            self._source(),
                            callbacks,
                            f"{job_id}:chunk:0",
                        )
                    self.assertEqual(create_requests, expected_attempts)
                    with store.connection() as conn:
                        persisted = store.get_provider_operation(
                            conn,
                            self.owner,
                            f"{job_id}:chunk:0",
                        )
                    self.assertEqual(persisted["status"], "CREATE_REJECTED")
                    with self.assertRaises(engine.EngineError):
                        engine._assemblyai_transcript_with_dialogue(
                            self._source(),
                            callbacks,
                            f"{job_id}:chunk:0",
                        )
                    self.assertEqual(create_requests, expected_attempts)
                finally:
                    for item in reversed(started):
                        item.stop()

    def test_same_job_concurrent_provider_claim_creates_one_provider_job(self):
        barrier = threading.Barrier(2)
        create_started = threading.Event()
        duplicate_claim_finished = threading.Event()
        finish_create = threading.Event()

        def observe_claim(result):
            if not result[1]:
                duplicate_claim_finished.set()

        callbacks = self._callbacks(
            "job-race",
            load_barrier=barrier,
            after_claim=observe_claim,
        )
        post_lock = threading.Lock()
        create_requests = 0

        def request(_key, _endpoint, method, _payload=None, deadline=None):
            nonlocal create_requests
            if method == "POST":
                with post_lock:
                    create_requests += 1
                create_started.set()
                if not finish_create.wait(timeout=10):
                    raise TimeoutError("The offline create fixture was not released.")
                return {"id": "transcript-race"}
            return _completed_transcript()

        self._start_patches(
            self._base_provider_patches()
            + [patch.object(engine, "_assemblyai_json_request", side_effect=request)]
        )
        source = self._source()

        def run():
            return engine._assemblyai_transcript_with_dialogue(
                source,
                callbacks,
                "job-race:chunk:0",
            )

        successes = []
        failures = []
        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(run), executor.submit(run)]
            self.assertTrue(create_started.wait(timeout=10))
            self.assertTrue(duplicate_claim_finished.wait(timeout=10))
            finish_create.set()
            for future in futures:
                try:
                    successes.append(future.result(timeout=20))
                except Exception as exc:
                    failures.append(exc)
        self.assertEqual(len(successes), 1)
        self.assertEqual(len(failures), 1)
        self.assertIsInstance(failures[0], engine.EngineError)
        self.assertEqual(failures[0].code, "ASSEMBLYAI_AMBIGUOUS_CREATE")
        self.assertEqual(create_requests, 1)

    def test_duplicate_run_request_queues_once_and_creates_no_provider_job(self):
        project = self._project()
        results = []
        start = threading.Barrier(2)

        def enqueue():
            start.wait(timeout=10)
            try:
                with store.connection() as conn:
                    main.enqueue(
                        conn,
                        self.owner,
                        dict(project),
                        "export",
                        engine.datetime.now(engine.timezone.utc),
                        "instant",
                        "Asia/Yangon",
                        quality="720p",
                    )
                return "queued"
            except HTTPException as exc:
                return exc.status_code

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(enqueue), executor.submit(enqueue)]
            results = [future.result(timeout=20) for future in futures]
        with store.connection() as conn:
            schedules = store.all_records(conn, self.owner, "schedule")
            operations = store.all_records(conn, self.owner, "provider_operation")
        self.assertCountEqual(results, ["queued", 409])
        self.assertEqual(len(schedules), 1)
        self.assertEqual(operations, [])

    def test_project_and_provider_state_survive_database_reopen(self):
        operation_key = "job-reopen:chunk:0"
        with store.connection() as conn:
            store.save_provider_operation(
                conn,
                self.owner,
                operation_key,
                {
                    "provider": "assemblyai",
                    "providerTranscriptId": "transcript-reopen",
                    "providerOperationId": "transcript-reopen",
                    "projectId": self.project_id,
                    "jobId": "job-reopen",
                    "status": "POLLING",
                    "createAttempted": True,
                    "createAttemptCount": 1,
                    "createdAt": store.now(),
                },
            )
        with store.connection() as reopened:
            project = store.get(reopened, self.owner, "project", self.project_id)
            operation = store.get_provider_operation(
                reopened,
                self.owner,
                operation_key,
            )
        self.assertEqual(project["id"], self.project_id)
        self.assertEqual(operation["providerTranscriptId"], "transcript-reopen")
        self.assertEqual(operation["jobId"], "job-reopen")
        self.assertEqual(operation["status"], "POLLING")
        self.assertTrue(operation["createAttempted"])

    def test_worker_restart_requeues_same_schedule_id_and_retains_provider_id(self):
        schedule_id = "stable-schedule-id"
        operation_key = f"{schedule_id}:chunk:0"
        project = self._project()
        project.update(status="processing", stage="Transcribing", progress=25)
        schedule = {
            "id": schedule_id,
            "projectId": self.project_id,
            "status": "processing",
            "attempts": 1,
            "scheduledAt": store.now(),
            "mode": "instant",
            "quality": "720p",
            "_action": "transcribe",
        }
        with store.connection() as conn:
            store.save(conn, self.owner, "project", project)
            store.save(conn, self.owner, "schedule", schedule)
            store.save_provider_operation(
                conn,
                self.owner,
                operation_key,
                {
                    "provider": "assemblyai",
                    "providerTranscriptId": "transcript-restart",
                    "providerOperationId": "transcript-restart",
                    "projectId": self.project_id,
                    "jobId": schedule_id,
                    "status": "POLLING",
                    "createAttempted": True,
                    "createAttemptCount": 1,
                },
            )
            main.requeue_interrupted_jobs(conn)

        with store.connection() as reopened:
            queued = store.get(reopened, self.owner, "schedule", schedule_id)
            resumed_project = store.get(reopened, self.owner, "project", self.project_id)
            operation = store.get_provider_operation(
                reopened,
                self.owner,
                operation_key,
            )
        self.assertEqual(queued["id"], schedule_id)
        self.assertEqual(queued["status"], "scheduled")
        self.assertEqual(queued["attempts"], 1)
        self.assertEqual(resumed_project["status"], "queued")
        self.assertEqual(operation["providerTranscriptId"], "transcript-restart")
        self.assertEqual(operation["jobId"], schedule_id)

    def test_app_storage_reference_survives_client_and_database_reopen(self):
        fake_storage = FakeObjectStorage()
        media = storage.AppStorageClient(
            client=fake_storage,
            temporary_root=self.root / "downloads",
        )
        local_source = self.root / "source.mp4"
        local_source.write_bytes(b"durable source fixture")
        key = "studio/owner-a/sources/source.mp4"
        media.upload_from_filename(key, str(local_source))
        project = self._project()
        project["sourceObjectPath"] = key
        with store.connection() as conn:
            store.save(conn, self.owner, "project", project)

        with store.connection() as reopened:
            persisted = store.get(reopened, self.owner, "project", self.project_id)
        new_media_client = storage.AppStorageClient(
            client=fake_storage,
            temporary_root=self.root / "downloads-after-reopen",
        )
        downloaded = new_media_client.path_for(persisted["sourceObjectPath"])
        try:
            self.assertEqual(downloaded.read_bytes(), b"durable source fixture")
        finally:
            downloaded.unlink(missing_ok=True)

    def test_legacy_local_object_key_still_resolves_when_media_exists(self):
        media = storage.LocalStorageClient(self.root / "legacy-media")
        source = self.root / "legacy-source.mp4"
        source.write_bytes(b"legacy local source fixture")
        key = self._project()["sourceObjectPath"]
        media.upload_from_filename(key, str(source))

        resolved = media.path_for(key)
        self.assertEqual(resolved.read_bytes(), source.read_bytes())

    def test_app_storage_uses_the_provisioned_bucket_explicitly(self):
        fake_storage = FakeObjectStorage()
        with patch.dict(
            os.environ,
            {
                "STUDIO_MEDIA_BACKEND": "app_storage",
                "DEFAULT_OBJECT_STORAGE_BUCKET_ID": "offline-test-bucket",
            },
        ), patch("replit.object_storage.Client", return_value=fake_storage) as sdk_client:
            media = storage.storage_client()

        sdk_client.assert_called_once_with(bucket_id="offline-test-bucket")
        self.assertIsInstance(media, storage.AppStorageClient)
        self.assertIs(media.client, fake_storage)

    def test_app_storage_fails_clearly_without_a_bucket_instead_of_falling_back(self):
        with patch.dict(
            os.environ,
            {
                "STUDIO_MEDIA_BACKEND": "app_storage",
                "DEFAULT_OBJECT_STORAGE_BUCKET_ID": "",
            },
        ):
            with self.assertRaisesRegex(
                RuntimeError,
                "Replit App Storage is not configured",
            ):
                storage.storage_client()

    def test_missing_legacy_source_fails_with_a_clear_reupload_message(self):
        media = storage.AppStorageClient(client=FakeObjectStorage())
        project = self._project()
        with patch.object(engine, "storage_client", return_value=media), \
                patch.object(engine, "CHECKPOINT_ROOT", self.root / "checkpoints"):
            with self.assertRaisesRegex(
                engine.EngineError,
                "The uploaded source video is unavailable. Upload it again.",
            ):
                engine.process_project(
                    project,
                    {},
                    "transcribe",
                    lambda *_args: None,
                    self.root / "worker",
                )

    def test_uploaded_source_is_cleaned_if_project_database_write_fails(self):
        class Upload:
            filename = "source.mp4"
            content_type = "video/mp4"

            def __init__(self):
                self.chunks = [b"original", b""]

            async def read(self, _size):
                return self.chunks.pop(0)

            async def close(self):
                return None

        fake_storage = FakeObjectStorage()
        media = storage.AppStorageClient(client=fake_storage)
        request = SimpleNamespace(state=SimpleNamespace(owner=self.owner))

        def normalize(_source, destination):
            destination.write_bytes(b"normalized source")

        with patch.object(main, "_prune_temporary_media"), \
                patch.object(main, "_ensure_free_disk_space"), \
                patch.object(main, "normalize_uploaded_video", side_effect=normalize), \
                patch.object(main, "storage_client", return_value=media):
            upload = asyncio.run(main.upload_source(request, Upload()))
            object_key = upload["sourceObjectPath"]
            self.assertIn(object_key, fake_storage.objects)

            data = main.ProjectInput(
                title="Failed create fixture",
                sourceObjectPath=object_key,
                rightsConfirmed=True,
            )
            with patch.object(
                store,
                "save",
                side_effect=OSError("isolated database write failure"),
            ):
                with self.assertRaisesRegex(OSError, "database write failure"):
                    main.create_project(data, request)

            unrelated_key = "studio/another-owner/sources/keep.mp4"
            fake_storage.objects[unrelated_key] = b"unrelated durable media"
            main.discard_uploaded_source(
                SimpleNamespace(sourceObjectPath=object_key),
                request,
            )

        self.assertNotIn(object_key, fake_storage.objects)
        self.assertEqual(
            fake_storage.objects[unrelated_key],
            b"unrelated durable media",
        )

    def test_source_cleanup_preserves_media_after_commit_or_owner_mismatch(self):
        fake_storage = FakeObjectStorage()
        media = storage.AppStorageClient(client=fake_storage)
        local_source = self.root / "uploaded-source.mp4"
        local_source.write_bytes(b"uploaded source")
        object_key = f"studio/{self.owner}/sources/committed.mp4"
        media.upload_from_filename(object_key, str(local_source))
        request = SimpleNamespace(state=SimpleNamespace(owner=self.owner))
        project_data = main.ProjectInput(
            title="Committed source fixture",
            sourceObjectPath=object_key,
            rightsConfirmed=True,
        )

        with patch.object(main, "storage_client", return_value=media):
            main.create_project(project_data, request)

            other_workspace = SimpleNamespace(
                state=SimpleNamespace(owner="owner-b")
            )
            with self.assertRaises(HTTPException) as wrong_owner:
                main.discard_uploaded_source(
                    SimpleNamespace(sourceObjectPath=object_key),
                    other_workspace,
                )
            self.assertEqual(wrong_owner.exception.status_code, 403)

            with self.assertRaises(HTTPException) as already_attached:
                main.discard_uploaded_source(
                    SimpleNamespace(sourceObjectPath=object_key),
                    request,
                )
            self.assertEqual(already_attached.exception.status_code, 409)

        self.assertIn(object_key, fake_storage.objects)

    def test_hevc_upload_survives_storage_reopen_and_reaches_local_worker_handoff(self):
        if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
            self.skipTest("FFmpeg and ffprobe are required for the HEVC regression.")

        source = self.root / "source-hevc.mp4"
        subprocess.run(
            [
                "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
                "-f", "lavfi", "-i", "color=c=black:s=1220x2712:r=24.25",
                "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000",
                "-t", "55.053", "-map", "0:v:0", "-map", "1:a:0", "-threads", "2",
                "-c:v", "libx265", "-preset", "ultrafast",
                "-x265-params", "log-level=error:pools=1:frame-threads=1",
                "-crf", "38", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "96k", "-ar", "48000", "-ac", "2",
                "-movflags", "+faststart", str(source),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=300,
            check=True,
        )
        source_probe = subprocess.run(
            [
                "ffprobe", "-v", "error", "-show_entries",
                "format=duration:stream=codec_type,codec_name,width,height",
                "-of", "json", str(source),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=30,
            check=True,
        )
        source_details = json.loads(source_probe.stdout)
        source_video = next(
            stream for stream in source_details["streams"]
            if stream["codec_type"] == "video"
        )
        source_audio = next(
            stream for stream in source_details["streams"]
            if stream["codec_type"] == "audio"
        )
        self.assertEqual(source_video["codec_name"], "hevc")
        self.assertEqual((source_video["width"], source_video["height"]), (1220, 2712))
        self.assertEqual(source_audio["codec_name"], "aac")
        self.assertAlmostEqual(float(source_details["format"]["duration"]), 55.053, delta=0.1)

        fake_storage = FakeObjectStorage()
        media = storage.AppStorageClient(
            client=fake_storage,
            temporary_root=self.root / "storage-downloads",
        )
        request = SimpleNamespace(state=SimpleNamespace(owner=self.owner))
        with source.open("rb") as stream:
            uploaded_file = UploadFile(filename="source-hevc.mp4", file=stream)
            with patch.object(main, "_prune_temporary_media"), \
                    patch.object(main, "_ensure_free_disk_space"), \
                    patch.object(main, "storage_client", return_value=media):
                upload = asyncio.run(main.upload_source(request, uploaded_file))

        object_key = upload["sourceObjectPath"]
        self.assertTrue(object_key.startswith(f"studio/{self.owner}/sources/"))
        stored_bytes = fake_storage.objects[object_key]
        self.assertEqual(len(stored_bytes), upload["size"])

        project = self._project()
        project.update({
            "id": "hevc-storage-regression",
            "title": "HEVC storage regression",
            "sourceObjectPath": object_key,
        })
        with store.connection() as conn:
            store.save(conn, self.owner, "project", project)
        with store.connection() as reopened:
            persisted = store.get(
                reopened,
                self.owner,
                "project",
                project["id"],
            )
        self.assertEqual(persisted["sourceObjectPath"], object_key)

        downloaded = media.path_for(persisted["sourceObjectPath"])
        stored_hash = hashlib.sha256(stored_bytes).hexdigest()
        try:
            self.assertEqual(
                hashlib.sha256(downloaded.read_bytes()).hexdigest(),
                stored_hash,
            )
            self.assertAlmostEqual(
                engine._probe_video(downloaded),
                55.053,
                delta=0.2,
            )
            self.assertEqual(engine._probe_video_dimensions(downloaded), (1220, 2712))
            self.assertTrue(engine._source_has_audio(downloaded))
            decode = subprocess.run(
                [
                    "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error",
                    "-i", str(downloaded), "-map", "0:v:0", "-f", "null", "-",
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=120,
                check=False,
            )
            self.assertEqual(decode.returncode, 0, decode.stderr[-1000:])
        finally:
            downloaded.unlink(missing_ok=True)

        handoff = {}

        def mock_transcription(audio_path, _workdir, report=None, **kwargs):
            audio_path = Path(audio_path)
            source_path = Path(kwargs["subtitle_source"])
            handoff["audio_size"] = audio_path.stat().st_size
            handoff["audio_header"] = audio_path.read_bytes()[:4]
            handoff["source_hash"] = hashlib.sha256(source_path.read_bytes()).hexdigest()
            return "你好", [{
                "speaker": "A",
                "start": 0.0,
                "end": 1.0,
                "sourceText": "你好",
            }]

        reports = []
        with patch.object(engine, "CHECKPOINT_ROOT", self.root / "checkpoints"), \
                patch.object(engine, "storage_client", return_value=media), \
                patch.object(engine, "_transcribe_in_chunks", side_effect=mock_transcription):
            result = engine.process_project(
                persisted,
                {},
                "transcribe",
                lambda stage, progress, values: reports.append(stage),
                self.root / "worker",
            )

        self.assertEqual(handoff["audio_header"], b"RIFF")
        self.assertGreater(handoff["audio_size"], 44)
        self.assertEqual(handoff["source_hash"], stored_hash)
        self.assertEqual(result["transcript"], "[A] 你好")
        self.assertIn("Source video ready", reports)
        self.assertIn("Extracting clean audio for speech-to-text", reports)
        self.assertIn("Transcribing Chinese audio", reports)

    def test_migration_dry_run_checks_local_references_without_opening_destinations(self):
        media_root = self.root / "source-media"
        source_key = "studio/owner-a/sources/source.mp4"
        source_file = media_root / source_key
        source_file.parent.mkdir(parents=True)
        source_file.write_bytes(b"local source media")
        (media_root / "unused.tmp").write_bytes(b"leave unreferenced")
        plan = migrate_local_to_durable.build_plan(
            self.database_path,
            media_root,
        )
        self.assertEqual(plan["record_count"], 1)
        self.assertEqual(plan["media_count"], 1)
        self.assertEqual(plan["media"][source_key], source_file)
        self.assertEqual(plan["unreferenced_media_count"], 1)

        with patch.object(
            storage,
            "AppStorageClient",
            side_effect=AssertionError("Dry-run must not open App Storage."),
        ):
            result = migrate_local_to_durable.main([
                "--source-db",
                str(self.database_path),
                "--media-root",
                str(media_root),
            ])
        self.assertEqual(result, 0)

    def test_temporary_and_checkpoint_cleanup_cannot_delete_final_object(self):
        fake_storage = FakeObjectStorage()
        media = storage.AppStorageClient(
            client=fake_storage,
            temporary_root=self.root / "downloads",
        )
        durable_objects = {
            "studio/project/source/source.mp4": b"durable source",
            "studio/project/export/final.mp4": b"final durable export",
            "studio/project/export/capcut.mp4": b"CapCut export",
            "studio/project/export/final.srt": b"durable subtitles",
            "studio/project/export/narration.mp3": b"durable narration",
            "studio/project/export/thumbnail.jpg": b"durable thumbnail",
            "studio/project/export/approved.mp4": b"user-approved output",
        }
        for index, (key, content) in enumerate(durable_objects.items()):
            local_file = self.root / f"durable-{index}.bin"
            local_file.write_bytes(content)
            media.upload_from_filename(key, str(local_file))

        temporary_root = self.root / "tmp"
        temporary_root.mkdir()
        old_download = temporary_root / "recap-storage-download-old.mp4"
        old_download.write_bytes(b"temporary")
        job_root = temporary_root / "jobs"
        job_root.mkdir()
        old_job = job_root / "old-job"
        old_job.mkdir()
        (old_job / "render.mp4").write_bytes(b"temporary render")
        checkpoint_root = self.root / "checkpoints"
        with patch.object(main.tempfile, "gettempdir", return_value=str(temporary_root)), \
                patch.object(main, "TEMP_JOB_ROOT", job_root), \
                patch.object(main, "TEMP_CLEANUP_MAX_AGE_SECONDS", 0), \
                patch.object(engine, "CHECKPOINT_ROOT", checkpoint_root):
            checkpoint = engine._checkpoint_directory(self.project_id)
            engine._write_checkpoint(
                checkpoint,
                {"version": engine.CHECKPOINT_VERSION, "stages": {"transcription": "completed"}},
            )
            main._prune_temporary_media()
            shutil.rmtree(checkpoint, ignore_errors=True)
        self.assertFalse(old_download.exists())
        self.assertFalse(old_job.exists())
        for key, expected_content in durable_objects.items():
            with self.subTest(object_key=key):
                self.assertEqual(fake_storage.objects.get(key), expected_content)

    def test_owner_isolation_blocks_cross_owner_export_storage_lookup(self):
        project = self._project()
        project.update(
            status="completed",
            progress=100,
            exports=[
                {
                    "language": "myanmar",
                    "videoFilename": "myanmar.mp4",
                }
            ],
            exportObjectPrefixes={
                "myanmar": "studio/owner-a/project/export",
            },
        )
        with store.connection() as conn:
            store.save(conn, self.owner, "project", project)
        request = Mock()
        request.state.owner = "owner-b"
        request.method = "GET"
        client = Mock()

        with patch.object(main, "storage_client", return_value=client):
            with self.assertRaises(HTTPException) as raised:
                main._serve_export_file(self.project_id, "myanmar.mp4", request)
        self.assertEqual(raised.exception.status_code, 404)
        client.path_for.assert_not_called()

    def test_postgres_outage_never_falls_back_to_local_snapshot(self):
        request = Mock()
        request.state.owner = self.owner
        failure = store.StoreUnavailableError("offline fixture")
        with (
            patch.object(store, "connection", side_effect=failure),
            patch.object(store, "database_backend", return_value="postgres"),
            patch.object(main, "_disk_project_records") as local_snapshot,
        ):
            with self.assertRaises(store.StoreUnavailableError):
                main.get_project(self.project_id, request)
        local_snapshot.assert_not_called()


if __name__ == "__main__":
    unittest.main()