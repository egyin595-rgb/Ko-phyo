"""Small, secure local media store used by the studio runtime.

Metadata and media intentionally use the same local-data boundary.  Keeping
the object-style path names (``studio/<owner>/...``) means existing project
records and API contracts remain valid while the runtime no longer depends on
an external object-storage service.
"""
from __future__ import annotations

import os
import shutil
import tempfile
import uuid
from pathlib import Path

from . import store


MEDIA_ROOT = Path(
    os.environ.get("STUDIO_MEDIA_ROOT", store.DATA_ROOT / "media")
).expanduser()


def _validated_object_name(object_name: str) -> str:
    value = str(object_name or "").strip()
    if not value or "\x00" in value:
        raise ValueError("The media object path is invalid.")
    relative = Path(value)
    if relative.is_absolute() or any(part in {"", ".", ".."} for part in relative.parts):
        raise ValueError("The media object path is invalid.")
    return relative.as_posix()


class LocalStorageClient:
    """Object-storage-compatible file client scoped to ``MEDIA_ROOT``."""

    def __init__(self, root: Path | None = None):
        self.root = Path(root if root is not None else MEDIA_ROOT).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, object_name: str) -> Path:
        relative = Path(_validated_object_name(object_name))
        path = (self.root / relative).resolve()
        if path != self.root and self.root not in path.parents:
            raise ValueError("The media object path is outside local storage.")
        return path

    def upload_from_filename(self, object_name: str, filename: str) -> None:
        source = Path(filename)
        if not source.is_file():
            raise FileNotFoundError(str(source))
        destination = self._path(object_name)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(
            f".{destination.name}.{uuid.uuid4().hex}.uploading"
        )
        try:
            shutil.copyfile(source, temporary)
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)

    def download_to_filename(self, object_name: str, filename: str) -> None:
        source = self._path(object_name)
        if not source.is_file():
            raise FileNotFoundError(str(source))
        destination = Path(filename)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)

    def path_for(self, object_name: str) -> Path:
        """Return the authoritative local path for a stored object."""
        path = self._path(object_name)
        if not path.is_file():
            raise FileNotFoundError(str(path))
        return path

    def delete(self, object_name: str, ignore_not_found: bool = False) -> None:
        path = self._path(object_name)
        try:
            path.unlink()
        except FileNotFoundError:
            if not ignore_not_found:
                raise

    def delete_prefix(self, prefix: str) -> None:
        """Remove an unpublished run directory without touching siblings."""
        directory = self._path(prefix)
        if not directory.exists():
            return
        if not directory.is_dir():
            raise ValueError("The media prefix is not a directory.")
        shutil.rmtree(directory)


class AppStorageClient:
    """Replit App Storage adapter with safe local working copies."""

    path_for_returns_temporary_file = True
    supports_lightweight_head = True

    def __init__(self, client=None, temporary_root: Path | None = None):
        if client is None:
            from replit.object_storage import Client

            bucket_id = str(
                os.environ.get("DEFAULT_OBJECT_STORAGE_BUCKET_ID") or ""
            ).strip()
            if not bucket_id:
                raise RuntimeError("Replit App Storage is not configured.")
            client = Client(bucket_id=bucket_id)
        self.client = client
        self.temporary_root = Path(
            temporary_root if temporary_root is not None else tempfile.gettempdir()
        ).expanduser()

    def upload_from_filename(self, object_name: str, filename: str) -> None:
        key = _validated_object_name(object_name)
        source = Path(filename)
        if not source.is_file():
            raise FileNotFoundError(str(source))
        self.client.upload_from_filename(key, str(source))
        if not self.client.exists(key):
            raise OSError("The uploaded media object could not be verified.")

    def download_to_filename(self, object_name: str, filename: str) -> None:
        key = _validated_object_name(object_name)
        destination = Path(filename)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(
            f".{destination.name}.{uuid.uuid4().hex}.downloading"
        )
        try:
            self.client.download_to_filename(key, str(temporary))
            if not temporary.is_file():
                raise FileNotFoundError(key)
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)

    def exists(self, object_name: str) -> bool:
        return bool(self.client.exists(_validated_object_name(object_name)))

    def path_for(self, object_name: str) -> Path:
        """Download a durable object to a disposable path for range serving."""
        key = _validated_object_name(object_name)
        if not self.exists(key):
            raise FileNotFoundError(key)
        self.temporary_root.mkdir(parents=True, exist_ok=True)
        descriptor, name = tempfile.mkstemp(
            prefix="recap-storage-download-",
            suffix=Path(key).suffix,
            dir=self.temporary_root,
        )
        os.close(descriptor)
        destination = Path(name)
        try:
            self.download_to_filename(key, str(destination))
            return destination
        except Exception:
            destination.unlink(missing_ok=True)
            raise

    def delete(self, object_name: str, ignore_not_found: bool = False) -> None:
        key = _validated_object_name(object_name)
        self.client.delete(key, ignore_not_found=ignore_not_found)

    def delete_prefix(self, prefix: str) -> None:
        """Delete only objects below this exact directory prefix."""
        key = _validated_object_name(prefix).rstrip("/")
        objects = self.client.list(prefix=f"{key}/")
        for item in objects:
            if isinstance(item, dict):
                object_name = item.get("name") or item.get("object_name")
            else:
                object_name = (
                    getattr(item, "name", None)
                    or getattr(item, "object_name", None)
                )
            if not object_name:
                raise RuntimeError("App Storage returned an object without a name.")
            safe_name = _validated_object_name(object_name)
            if not safe_name.startswith(f"{key}/"):
                raise RuntimeError(
                    "App Storage returned an object outside the requested prefix."
                )
            self.client.delete(safe_name, ignore_not_found=True)


def storage_backend() -> str:
    explicit = str(os.environ.get("STUDIO_MEDIA_BACKEND") or "").strip().lower()
    if explicit in {"local", "app_storage"}:
        return explicit
    if explicit:
        raise RuntimeError("STUDIO_MEDIA_BACKEND must be local or app_storage.")
    # A deployment with the managed database must not silently fall back to
    # ephemeral local media if App Storage has not been provisioned.
    if os.environ.get("DATABASE_URL") or os.environ.get(
        "DEFAULT_OBJECT_STORAGE_BUCKET_ID"
    ):
        return "app_storage"
    return "local"


def storage_client():
    backend = storage_backend()
    if backend == "app_storage":
        if not os.environ.get("DEFAULT_OBJECT_STORAGE_BUCKET_ID"):
            raise RuntimeError("Replit App Storage is not configured.")
        return AppStorageClient()
    return LocalStorageClient()