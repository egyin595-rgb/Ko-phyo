"""Explicit opt-in verifier for one real, paid-provider API pipeline run."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import tempfile
import time
import uuid
from pathlib import Path
from urllib.parse import urljoin

import httpx


DEFAULT_FIXTURE = Path("/tmp/recap-live-fixtures/short-chinese-speech.mp4")
COOKIE_FILE = Path("/tmp/recap-live-fixtures/live-workspace-cookie")


def require_ok(response: httpx.Response) -> dict:
    try:
        payload = response.json()
    except ValueError:
        payload = {}
    if response.is_error:
        message = payload.get("error") if isinstance(payload, dict) else None
        raise RuntimeError(
            f"API request failed with HTTP {response.status_code}: "
            f"{message or 'no structured error'}"
        )
    return payload


def probe_video_dimensions(path: Path) -> tuple[int, int]:
    payload = json.loads(subprocess.run(
        [
            "ffprobe", "-v", "error",
            "-select_streams", "v:0",
            "-show_entries", "stream=width,height",
            "-of", "json", str(path),
        ],
        check=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=60,
    ).stdout)
    stream = (payload.get("streams") or [{}])[0]
    width = int(stream.get("width") or 0)
    height = int(stream.get("height") or 0)
    if width <= 0 or height <= 0:
        raise RuntimeError(f"Could not read source video dimensions: {stream}")
    return width, height


def verify_media(path: Path, expected_width: int, expected_height: int) -> dict:
    minimum_audio_bitrate = 8_000
    completed = subprocess.run(
        [
            "ffprobe", "-v", "error",
            "-show_entries",
            "stream=codec_type,codec_name,width,height,pix_fmt,channels,sample_rate,bit_rate",
            "-show_entries", "format=duration,size",
            "-of", "json", str(path),
        ],
        check=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=60,
    )
    payload = json.loads(completed.stdout)
    streams = payload.get("streams", [])
    video_streams = [item for item in streams if item.get("codec_type") == "video"]
    audio_streams = [item for item in streams if item.get("codec_type") == "audio"]
    sidecar_forbidden_streams = [
        item for item in streams if item.get("codec_type") in {"subtitle", "data"}
    ]
    codecs = {
        item["codec_type"]: item["codec_name"]
        for item in streams
    }
    video_stream = video_streams[0] if len(video_streams) == 1 else {}
    audio_stream = audio_streams[0] if len(audio_streams) == 1 else {}
    if (
        len(video_streams) != 1
        or len(audio_streams) != 1
        or sidecar_forbidden_streams
        or codecs.get("video") != "h264"
        or codecs.get("audio") != "aac"
        or video_stream.get("width") != expected_width
        or video_stream.get("height") != expected_height
        or video_stream.get("pix_fmt") != "yuv420p"
        or int(audio_stream.get("channels") or 0) != 2
        or int(audio_stream.get("sample_rate") or 0) != 44100
        or int(audio_stream.get("bit_rate") or 0) < minimum_audio_bitrate
    ):
        raise RuntimeError(
            "Unexpected verified export streams; subtitle/data streams are forbidden: "
            f"{streams}"
        )
    width = int(video_stream.get("width") or 0)
    height = int(video_stream.get("height") or 0)
    if width != expected_width or height != expected_height:
        raise RuntimeError(
            f"Export is not the default {expected_width}x{expected_height} canvas: "
            f"{width}x{height}"
        )
    return {
        "codecs": codecs,
        "dimensions": {"width": width, "height": height},
        "duration": float(payload["format"]["duration"]),
        "bytes": int(payload["format"]["size"]),
    }


def verify_audio(path: Path) -> dict:
    payload = json.loads(subprocess.run(
        [
            "ffprobe", "-v", "error",
            "-show_entries", "stream=codec_name,sample_rate,channels",
            "-show_entries", "format=duration",
            "-of", "json", str(path),
        ],
        check=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=60,
    ).stdout)
    stream = next(
        (item for item in payload.get("streams", []) if item.get("codec_name")),
        {},
    )
    if (
        stream.get("codec_name") != "mp3"
        or int(stream.get("sample_rate") or 0) != 44100
        or int(stream.get("channels") or 0) != 2
    ):
        raise RuntimeError(f"Unexpected narration audio format: {stream}")
    return {
        "codec": stream["codec_name"],
        "sampleRate": int(stream["sample_rate"]),
        "channels": int(stream["channels"]),
        "duration": float(payload["format"]["duration"]),
        "bytes": path.stat().st_size,
    }


def verify_subtitle_cues(text: str, audio_duration: float) -> list[dict]:
    cues = []
    timestamp = re.compile(
        r"(\d{2}):(\d{2}):(\d{2}),(\d{3})\s+-->\s+"
        r"(\d{2}):(\d{2}):(\d{2}),(\d{3})"
    )

    def seconds(match: re.Match, offset: int) -> float:
        hours, minutes, whole_seconds, milliseconds = (
            int(match.group(offset + index))
            for index in range(4)
        )
        return hours * 3600 + minutes * 60 + whole_seconds + milliseconds / 1000

    for block in re.split(r"\r?\n[ \t]*\r?\n", text.strip()):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if len(lines) < 3:
            raise RuntimeError("Subtitle file contains a malformed cue.")
        match = timestamp.fullmatch(lines[1])
        if not match:
            raise RuntimeError("Subtitle file contains an invalid cue timestamp.")
        start = seconds(match, 1)
        end = seconds(match, 5)
        cue_text = "\n".join(lines[2:])
        if (
            end <= start
            or len(cue_text.splitlines()) > 2
            or not re.search(r"[\u1000-\u109f]", cue_text)
        ):
            raise RuntimeError(
                "Subtitle cue must contain Burmese text on one or two visible lines."
            )
        cues.append({"start": start, "end": end, "text": cue_text})

    if not cues:
        raise RuntimeError("Subtitle download contains no timed cues.")
    for previous, current in zip(cues, cues[1:]):
        if current["start"] < previous["end"] - 0.01:
            raise RuntimeError("Subtitle cues overlap in the final SRT.")
    if cues[-1]["end"] > audio_duration + 0.15:
        raise RuntimeError("Subtitle cues extend past the measured narration audio.")
    return cues


def verify_thumbnail(path: Path) -> dict:
    payload = json.loads(subprocess.run(
        [
            "ffprobe", "-v", "error",
            "-show_entries", "stream=codec_name,width,height",
            "-of", "json", str(path),
        ],
        check=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=60,
    ).stdout)
    stream = payload.get("streams", [{}])[0]
    if (
        stream.get("codec_name") != "mjpeg"
        or int(stream.get("width") or 0) != 1080
        or int(stream.get("height") or 0) != 1920
    ):
        raise RuntimeError(f"Unexpected clean thumbnail format: {stream}")
    return {
        "codec": stream["codec_name"],
        "dimensions": {"width": int(stream["width"]), "height": int(stream["height"])},
        "bytes": path.stat().st_size,
    }


def run_live(
    base_url: str,
    fixture: Path,
    keep_project: bool,
    save_export: Path | None = None,
    *,
    subtitle_font_size: int,
) -> dict:
    if not fixture.is_file() or fixture.stat().st_size == 0:
        raise RuntimeError(f"Fixture is missing: {fixture}")
    if save_export and save_export.exists():
        raise RuntimeError(f"Refusing to overwrite the saved export: {save_export}")
    if not 12 <= int(subtitle_font_size) <= 120:
        raise RuntimeError("Selected subtitle font size must be between 12 and 120.")
    subtitle_font_size = int(subtitle_font_size)
    source_width, source_height = probe_video_dimensions(fixture)
    if source_width == source_height:
        expected_dimensions = (1080, 1080)
    elif source_width < source_height:
        expected_dimensions = (1080, 1920)
    else:
        expected_dimensions = (1920, 1080)
    base_url = base_url.rstrip("/") + "/"
    project_id = ""
    with httpx.Client(base_url=base_url, timeout=180.0, follow_redirects=False) as client:
        try:
            with fixture.open("rb") as media:
                upload = require_ok(client.post(
                    "api/studio/uploads",
                    files={"file": (fixture.name, media, "video/mp4")},
                ))
            project = require_ok(client.post("api/studio/projects", json={
                "title": f"isolated-live-verifier-{uuid.uuid4().hex[:8]}",
                "sourceUrl": "",
                "sourceObjectPath": upload["sourceObjectPath"],
                "rightsConfirmed": True,
                "globalEdit": "none",
                "blurBoxes": [{
                    "id": "live-bbox",
                    "x": 0.15,
                    "y": 0.82,
                    "width": 0.30,
                    "height": 0.12,
                }],
                "subtitleBox": None,
                "subtitleFontSize": subtitle_font_size,
            }))
            project_id = project["id"]
            if int(project.get("subtitleFontSize") or 0) != subtitle_font_size:
                raise RuntimeError(
                    "The isolated project did not retain the selected "
                    f"{subtitle_font_size}px subtitle size."
                )

            settings = require_ok(client.put("api/studio/settings", json={
                "timezone": "Asia/Yangon",
                "peakHours": [12, 18, 20],
                "myanmarVoice": "my-MM-NilarNeural",
                "myanmarRate": 15,
                "englishVoice": "en-US-GuyNeural",
            }))
            if settings.get("myanmarVoice") != "my-MM-NilarNeural":
                raise RuntimeError("Selected Nilar voice did not persist.")
            if settings.get("myanmarRate") != 15:
                raise RuntimeError("Production Myanmar speech rate did not persist.")

            preview = client.get(
                f"api/studio/projects/{project_id}/source",
                headers={"Range": "bytes=0-1023"},
            )
            if (
                preview.status_code != 206
                or preview.headers.get("content-type", "").split(";")[0] != "video/mp4"
                or preview.headers.get("accept-ranges") != "bytes"
                or not preview.headers.get("content-range", "").startswith("bytes 0-1023/")
                or preview.headers.get("content-length") != "1024"
                or not preview.content.startswith(b"\x00\x00")
            ):
                raise RuntimeError("Uploaded source ranged preview failed.")

            require_ok(client.post(
                f"api/studio/projects/{project_id}/run",
                json={
                    "action": "full",
                    "quality": "1080p",
                    "subtitleFontSize": subtitle_font_size,
                },
            ))
            deadline = time.monotonic() + 15 * 60
            last_stage = ""
            while time.monotonic() < deadline:
                project = require_ok(client.get(f"api/studio/projects/{project_id}"))
                stage = str(project.get("stage") or "")
                if stage != last_stage:
                    print(f"{project.get('status')}: {stage}", flush=True)
                    last_stage = stage
                if project.get("status") in {"completed", "failed"}:
                    break
                time.sleep(3)
            else:
                raise RuntimeError("Live pipeline did not finish within 15 minutes.")

            if project.get("status") != "completed":
                raise RuntimeError(
                    f"Live pipeline failed closed: {project.get('error') or last_stage}"
                )
            if int(project.get("subtitleFontSize") or 0) != subtitle_font_size:
                raise RuntimeError(
                    "Completed project did not preserve the selected "
                    f"{subtitle_font_size}px subtitle size."
                )
            dialogue = project.get("dialogue") or []
            if not dialogue or any(
                float(line.get("end", 0)) <= float(line.get("start", 0))
                for line in dialogue
            ):
                raise RuntimeError("Completed project lacks exact timestamped dialogue.")
            exports = project.get("exports") or []
            myanmar = next(
                (item for item in exports if item.get("language") == "myanmar"),
                None,
            )
            if not myanmar:
                raise RuntimeError("Completed project lacks a Myanmar export.")
            if myanmar.get("quality") != "1080p":
                raise RuntimeError(
                    f"Completed project used unexpected export quality: {myanmar.get('quality')!r}"
                )
            if abs(float(project.get("narrationSpeed") or 0) - 1.0) > 0.001:
                raise RuntimeError("Completed project did not preserve the default 1.00x narration speed.")

            with tempfile.TemporaryDirectory(prefix="recap-live-export-") as directory:
                output = save_export or (Path(directory) / "myanmar.mp4")
                if save_export:
                    output.parent.mkdir(parents=True, exist_ok=True)
                export_url = urljoin(base_url, myanmar["videoUrl"].lstrip("/"))
                ranged_export = client.get(
                    export_url,
                    headers={"Range": "bytes=0-1023"},
                )
                if (
                    ranged_export.status_code != 206
                    or ranged_export.headers.get("content-type", "").split(";")[0] != "video/mp4"
                    or ranged_export.headers.get("accept-ranges") != "bytes"
                    or not ranged_export.headers.get("content-range", "").startswith("bytes 0-1023/")
                    or ranged_export.headers.get("content-length") != "1024"
                    or len(ranged_export.content) != 1024
                ):
                    raise RuntimeError("Export ranged playback response failed.")
                response = client.get(export_url)
                response.raise_for_status()
                if (
                    response.headers.get("content-type", "").split(";")[0] != "video/mp4"
                    or response.headers.get("accept-ranges") != "bytes"
                    or int(response.headers.get("content-length", "0")) != len(response.content)
                ):
                    raise RuntimeError("Export full playback response headers failed.")
                output.write_bytes(response.content)
                media_result = verify_media(output, *expected_dimensions)
                if abs(media_result["duration"] - float(project["duration"])) > 0.15:
                    raise RuntimeError("MP4 duration does not match the completed narration duration.")

                audio_url = urljoin(base_url, myanmar["audioUrl"].lstrip("/"))
                audio_response = client.get(audio_url)
                audio_response.raise_for_status()
                audio = Path(directory) / "myanmar.mp3"
                audio.write_bytes(audio_response.content)
                audio_result = verify_audio(audio)

                subtitle_url = urljoin(base_url, myanmar["subtitleUrl"].lstrip("/"))
                subtitle_response = client.get(subtitle_url)
                subtitle_response.raise_for_status()
                subtitle_text = subtitle_response.text
                if not re.search(r"[\u1000-\u109f]", subtitle_text):
                    raise RuntimeError("Subtitle download does not contain Myanmar text.")
                if b"\xef\xbb\xbf" in subtitle_response.content:
                    raise RuntimeError("Subtitle download contains an unexpected UTF-8 BOM.")
                subtitle_cues = verify_subtitle_cues(
                    subtitle_text,
                    audio_result["duration"],
                )

                thumbnail_url = urljoin(
                    base_url,
                    myanmar["thumbnailDownloadUrl"].lstrip("/"),
                )
                thumbnail_response = client.get(thumbnail_url)
                thumbnail_response.raise_for_status()
                disposition = thumbnail_response.headers.get("content-disposition", "")
                if (
                    thumbnail_response.headers.get("content-type", "").split(";")[0] != "image/jpeg"
                    or not disposition.startswith("attachment;")
                    or "Drama_Recap_Thumbnail.jpg" not in disposition
                ):
                    raise RuntimeError("Thumbnail attachment headers are incorrect.")
                thumbnail = Path(directory) / "thumbnail.jpg"
                thumbnail.write_bytes(thumbnail_response.content)
                thumbnail_result = verify_thumbnail(thumbnail)

                download_url = urljoin(base_url, myanmar["downloadUrl"].lstrip("/"))
                download_response = client.get(download_url)
                download_response.raise_for_status()
                disposition = download_response.headers.get("content-disposition", "")
                if (
                    download_response.headers.get("content-type", "").split(";")[0] != "video/mp4"
                    or not disposition.startswith("attachment;")
                    or not re.search(r'filename="[^"]+\.mp4"', disposition, re.IGNORECASE)
                ):
                    raise RuntimeError("Video attachment headers are incorrect.")
            return {
                "status": "completed",
                "projectId": project_id,
                "dialogueCues": len(dialogue),
                "firstCue": {
                    "start": dialogue[0]["start"],
                    "end": dialogue[0]["end"],
                },
                "selectedVoice": settings["myanmarVoice"],
                "selectedRate": settings["myanmarRate"],
                "subtitleFontSize": subtitle_font_size,
                "export": media_result,
                "narrationAudio": audio_result,
                "subtitle": {
                    "timedCues": len(subtitle_cues),
                    "myanmarCues": len(re.findall(r"[\u1000-\u109f]", subtitle_text)),
                    "maxVisibleLines": max(
                        len(cue["text"].splitlines())
                        for cue in subtitle_cues
                    ),
                    "lastCueEnd": subtitle_cues[-1]["end"],
                },
                "thumbnail": thumbnail_result,
                "downloadHeaders": "attachment filenames verified",
                "savedExport": str(save_export) if save_export else None,
            }
        finally:
            if project_id and keep_project:
                workspace_cookie = client.cookies.get("recap_workspace")
                if workspace_cookie:
                    COOKIE_FILE.parent.mkdir(parents=True, exist_ok=True)
                    COOKIE_FILE.write_text(workspace_cookie, encoding="utf-8")
            if project_id and not keep_project:
                response = client.delete(f"api/studio/projects/{project_id}")
                if response.status_code != 204:
                    print(
                        f"warning: isolated project cleanup returned HTTP "
                        f"{response.status_code}",
                        flush=True,
                    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://localhost:80/")
    parser.add_argument("--fixture", type=Path, default=DEFAULT_FIXTURE)
    parser.add_argument("--keep-project", action="store_true")
    parser.add_argument(
        "--save-export",
        type=Path,
        help="optional path for retaining the verified MP4 for visual inspection",
    )
    parser.add_argument(
        "--subtitle-font-size",
        type=int,
        choices=range(12, 121),
        required=True,
        help="explicit user-selected subtitle size for this acceptance run",
    )
    parser.add_argument(
        "--confirm-paid-live-run",
        action="store_true",
        help="required acknowledgement before calling paid transcription/translation providers",
    )
    arguments = parser.parse_args()
    if not arguments.confirm_paid_live_run:
        parser.error("pass --confirm-paid-live-run to execute one real provider pipeline")
    result = run_live(
        arguments.base_url,
        arguments.fixture,
        arguments.keep_project,
        arguments.save_export,
        subtitle_font_size=arguments.subtitle_font_size,
    )
    print(json.dumps(result, indent=2, sort_keys=True))