"""Opt-in real FFmpeg verification for uploaded HEVC container normalization."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import tempfile
from pathlib import Path

from .main import MAX_UPLOAD_BYTES, normalize_uploaded_video


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        check=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=900,
    )


def make_hevc_fixture(destination: Path) -> None:
    command = [
        "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
        "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=15:duration=1",
        "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=1",
        "-c:v", "libx265", "-preset", "ultrafast",
        "-x265-params", "log-level=error:pools=1",
        "-c:a", "aac",
    ]
    if destination.suffix == ".mov":
        command.extend(["-tag:v", "hvc1"])
    run([*command, str(destination)])


def verify_normalized(path: Path) -> dict[str, object]:
    probe = json.loads(run([
        "ffprobe", "-v", "error",
        "-show_entries", "stream=codec_type,codec_name,pix_fmt",
        "-show_entries", "format=format_name,duration",
        "-of", "json", str(path),
    ]).stdout)
    streams = {
        stream["codec_type"]: stream
        for stream in probe.get("streams", [])
        if stream.get("codec_type") in {"video", "audio"}
    }
    assert streams["video"]["codec_name"] == "h264", streams
    assert streams["video"]["pix_fmt"] == "yuv420p", streams
    assert streams["audio"]["codec_name"] == "aac", streams
    payload = path.read_bytes()
    moov = payload.find(b"moov")
    mdat = payload.find(b"mdat")
    assert 0 <= moov < mdat, (moov, mdat)
    run([
        "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error",
        "-i", str(path), "-map", "0:v:0", "-map", "0:a:0", "-f", "null", "-",
    ])
    return {
        "bytes": path.stat().st_size,
        "duration": float(probe["format"]["duration"]),
        "video": "h264/yuv420p",
        "audio": "aac",
        "faststart": True,
    }


def verify(include_500mb: bool = False) -> dict[str, object]:
    for executable in ("ffmpeg", "ffprobe"):
        if not shutil.which(executable):
            raise RuntimeError(f"{executable} is required for real-media verification.")
    results: dict[str, object] = {}
    with tempfile.TemporaryDirectory(prefix="recap-real-media-") as directory:
        root = Path(directory)
        for suffix in ("mkv", "mov"):
            source = root / f"hevc.{suffix}"
            output = root / f"normalized-{suffix}.mp4"
            make_hevc_fixture(source)
            normalize_uploaded_video(source, output)
            results[f"hevc_{suffix}"] = verify_normalized(output)

        if include_500mb:
            source = root / "exact-500mb-hevc.mkv"
            make_hevc_fixture(source)
            with source.open("r+b") as handle:
                handle.truncate(MAX_UPLOAD_BYTES)
            assert source.stat().st_size == MAX_UPLOAD_BYTES
            output = root / "normalized-exact-500mb.mp4"
            normalize_uploaded_video(source, output)
            results["exact_500mb_hevc_mkv"] = {
                "inputBytes": source.stat().st_size,
                **verify_normalized(output),
            }
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--include-500mb",
        action="store_true",
        help="also verify the exact upload-size boundary using a sparse MKV",
    )
    arguments = parser.parse_args()
    print(json.dumps(verify(arguments.include_500mb), indent=2, sort_keys=True))