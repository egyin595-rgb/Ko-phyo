"""Studio document repository with SQLite test and PostgreSQL durable backends."""
import json
import logging
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from uuid import uuid4


DATA_ROOT = Path(
    os.environ.get(
        "STUDIO_DATA_ROOT",
        Path(__file__).resolve().parents[1] / "data",
    )
)
SQLITE_DATABASE_PATH = Path(
    os.environ.get("STUDIO_DATABASE_PATH", DATA_ROOT / "studio.sqlite3")
)
PROJECT_STATE_PATH = Path(
    os.environ.get("STUDIO_PROJECT_STATE_PATH", DATA_ROOT / "projects.json")
)
_state_lock = RLock()
log = logging.getLogger("studio.store")
SEQUENCE_OWNER = "__studio_sequences__"


class StoreUnavailableError(RuntimeError):
    """The local SQLite store cannot be opened or written."""


class SnapshotReadError(RuntimeError):
    """The local recovery snapshot cannot be read safely."""


class ProviderOperationBlockedError(RuntimeError):
    """An unresolved provider create prevents another create for this project."""


class PostgresRow(dict):
    """Mapping row that also preserves sqlite3.Row's integer indexing."""

    def __getitem__(self, key):
        if isinstance(key, int):
            key = tuple(self.keys())[key]
        return super().__getitem__(key)


class PostgresCursor:
    def __init__(self, cursor):
        self._cursor = cursor
        self.rowcount = cursor.rowcount

    @staticmethod
    def _row(value):
        return PostgresRow(value) if value is not None else None

    def fetchone(self):
        return self._row(self._cursor.fetchone())

    def fetchall(self):
        return [self._row(row) for row in self._cursor.fetchall()]


class PostgresConnection:
    """Small sqlite-shaped facade over psycopg's autocommit connection."""

    dialect = "postgres"

    def __init__(self, connection):
        self._connection = connection
        self._in_transaction = False
        self._savepoint_started_transaction = False

    @property
    def in_transaction(self):
        return self._in_transaction

    def execute(self, sql, parameters=()):
        statement = str(sql).strip()
        upper = statement.upper()
        if upper == "BEGIN IMMEDIATE":
            statement = "BEGIN"
            upper = "BEGIN"
        if upper == "BEGIN":
            cursor = self._connection.execute(statement)
            self._in_transaction = True
            return PostgresCursor(cursor)
        if upper.startswith("SAVEPOINT ") and not self._in_transaction:
            self._connection.execute("BEGIN")
            self._in_transaction = True
            self._savepoint_started_transaction = True
        cursor = self._connection.execute(
            statement.replace("?", "%s"),
            tuple(parameters or ()),
        )
        if upper.startswith("RELEASE SAVEPOINT ") and self._savepoint_started_transaction:
            self._connection.commit()
            self._in_transaction = False
            self._savepoint_started_transaction = False
        return PostgresCursor(cursor)

    def commit(self):
        self._connection.commit()
        self._in_transaction = False
        self._savepoint_started_transaction = False

    def rollback(self):
        self._connection.rollback()
        self._in_transaction = False
        self._savepoint_started_transaction = False

    def close(self):
        self._connection.close()


def now():
    return datetime.now(timezone.utc).isoformat()


def uid():
    return str(uuid4())


def next_sequence(conn, name):
    """Return the next durable sequence value without reusing deleted numbers."""
    record_id = f"sequence:{name}"
    with _state_lock:
        if getattr(conn, "dialect", "sqlite") == "postgres":
            if not conn.in_transaction:
                conn.execute("BEGIN")
            conn.execute(
                "SELECT pg_advisory_xact_lock(hashtext(?))",
                (str(name),),
            )
        row = conn.execute(
            "SELECT data FROM studio_records WHERE owner=? AND kind='sequence' AND id=?",
            (SEQUENCE_OWNER, record_id),
        ).fetchone()
        current = 0
        if row:
            try:
                current = max(0, int(_decode_data(row["data"]).get("value") or 0))
            except (TypeError, ValueError, RuntimeError):
                log.warning("Invalid sequence record; restarting sequence name=%s", name)
        value = current + 1
        data = {"id": record_id, "name": str(name), "value": value}
        timestamp = datetime.now(timezone.utc).timestamp()
        if getattr(conn, "dialect", "sqlite") == "postgres":
            conn.execute(
                """
                INSERT INTO studio_records (id, owner, kind, data, created_at)
                VALUES (?, ?, 'sequence', ?, ?)
                ON CONFLICT(id) DO UPDATE SET data=excluded.data
                """,
                (
                    record_id,
                    SEQUENCE_OWNER,
                    _database_json(conn, data),
                    _database_timestamp(conn, timestamp),
                ),
            )
        else:
            conn.execute(
                """
                INSERT INTO studio_records (id, owner, kind, data, created_at, updated_at)
                VALUES (?, ?, 'sequence', ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    data=excluded.data,
                    updated_at=excluded.updated_at
                """,
                (
                    record_id,
                    SEQUENCE_OWNER,
                    _database_json(conn, data),
                    timestamp,
                    timestamp,
                ),
            )
        conn.commit()
        if getattr(conn, "dialect", "sqlite") != "postgres":
            try:
                _persist_record(SEQUENCE_OWNER, "sequence", data)
            except (OSError, SnapshotReadError, RuntimeError):
                log.exception("Recovery snapshot write failed sequence=%s", name)
        return value


def _utc_timestamp(value=None):
    if value is None:
        return datetime.now(timezone.utc).timestamp()
    if isinstance(value, datetime):
        parsed = value
    else:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc).timestamp()


def _json_data(value):
    try:
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    except (TypeError, ValueError) as exc:
        raise RuntimeError("The project record contains unsupported data.") from exc


def database_backend():
    configured = str(os.environ.get("STUDIO_DATABASE_BACKEND") or "").strip().lower()
    if configured in {"sqlite", "postgres", "postgresql"}:
        return "postgres" if configured in {"postgres", "postgresql"} else "sqlite"
    if configured:
        raise RuntimeError("STUDIO_DATABASE_BACKEND must be sqlite or postgres.")
    return (
        "postgres"
        if os.environ.get("EXTERNAL_DATABASE_URL") or os.environ.get("DATABASE_URL")
        else "sqlite"
    )


def _database_json(conn, value):
    if getattr(conn, "dialect", "sqlite") == "postgres":
        from psycopg.types.json import Jsonb

        return Jsonb(value)
    return _json_data(value)


def _database_timestamp(conn, timestamp):
    if getattr(conn, "dialect", "sqlite") == "postgres":
        return datetime.fromtimestamp(timestamp, timezone.utc)
    return timestamp


def _decode_data(raw):
    if isinstance(raw, dict):
        return raw
    try:
        value = json.loads(raw)
    except (TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError("The local project record contains invalid JSON.") from exc
    if not isinstance(value, dict):
        raise RuntimeError("The local project record has an invalid shape.")
    return value


def _initialize_database(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS studio_records (
            id TEXT PRIMARY KEY,
            owner TEXT NOT NULL,
            kind TEXT NOT NULL,
            data TEXT NOT NULL,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS studio_records_owner_kind "
        "ON studio_records(owner, kind)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS studio_records_kind_updated "
        "ON studio_records(kind, updated_at)"
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS studio_tombstones (
            id TEXT PRIMARY KEY,
            deleted_at REAL NOT NULL
        )
        """
    )
    conn.commit()


def initialize_postgres_schema(conn):
    """Idempotently create the PostgreSQL record store from its schema source."""
    if getattr(conn, "dialect", "sqlite") != "postgres":
        return

    try:
        schema_path = Path(__file__).with_name("schema.sql")
        schema_sql = schema_path.read_text(encoding="utf-8")
        schema_sql = "\n".join(
            line
            for line in schema_sql.splitlines()
            if not line.lstrip().startswith("--")
        )
        statements = [
            statement.strip()
            for statement in schema_sql.split(";")
            if statement.strip()
        ]
        if not statements:
            raise RuntimeError("The PostgreSQL schema source is empty.")
        for statement in statements:
            conn.execute(statement)
        conn.commit()
    except Exception as exc:
        if getattr(conn, "in_transaction", False):
            try:
                conn.rollback()
            except Exception:
                pass
        raise StoreUnavailableError(
            "The durable PostgreSQL schema is temporarily unavailable."
        ) from exc


@contextmanager
def connection():
    """Open the configured database; only SQLite uses the local snapshot."""
    db_url = os.environ.get("EXTERNAL_DATABASE_URL") or os.environ.get("DATABASE_URL")
    if database_backend() == "postgres":
        if not db_url:
            raise StoreUnavailableError(
                "The durable project database is not configured."
            )
        try:
            import psycopg
            from psycopg.rows import dict_row

            raw_connection = psycopg.connect(
                db_url,
                autocommit=True,
                row_factory=dict_row,
                connect_timeout=15,
            )
        except Exception as exc:
            raise StoreUnavailableError(
                "The durable project database is temporarily unavailable."
            ) from exc
        conn = PostgresConnection(raw_connection)
        try:
            yield conn
        finally:
            conn.close()
        return

    try:
        SQLITE_DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(
            str(SQLITE_DATABASE_PATH),
            timeout=30,
            isolation_level=None,
        )
        conn.row_factory = sqlite3.Row
        _initialize_database(conn)
        _hydrate_from_disk(conn)
    except (OSError, sqlite3.Error, RuntimeError) as exc:
        raise StoreUnavailableError(
            "The local project database is temporarily unavailable."
        ) from exc
    try:
        yield conn
    finally:
        conn.close()


def _record_key(kind, record_id):
    return f"{kind}:{record_id}"


def _read_disk_state():
    with _state_lock:
        if not PROJECT_STATE_PATH.exists():
            return {}, set()
        try:
            payload = json.loads(PROJECT_STATE_PATH.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise SnapshotReadError(
                "The persistent project state file is unreadable."
            ) from exc
        records = payload.get("records", {}) if isinstance(payload, dict) else {}
        if not isinstance(records, dict):
            raise SnapshotReadError(
                "The persistent project state file has an invalid format."
            )
        tombstones = payload.get("tombstones", []) if isinstance(payload, dict) else []
        if not isinstance(tombstones, list) or any(
            not isinstance(record_id, str) or not record_id
            for record_id in tombstones
        ):
            raise SnapshotReadError(
                "The persistent project state file has invalid deletion markers."
            )
        return records, set(tombstones)


def _read_disk_records():
    return _read_disk_state()[0]


def disk_records(kind=None, owner=None):
    """Return valid snapshot records without allowing one bad entry to abort reads."""
    try:
        records = _read_disk_records()
    except SnapshotReadError:
        log.exception("Project recovery snapshot could not be read")
        return []

    result = []
    for key, record in records.items():
        if not isinstance(record, dict):
            log.warning("Skipping malformed recovery record key=%s", key)
            continue
        record_kind = record.get("kind")
        record_owner = record.get("owner")
        data = record.get("data")
        if kind is not None and record_kind != kind:
            continue
        if owner is not None and record_owner != owner:
            continue
        if not record_owner or not isinstance(data, dict) or not data.get("id"):
            log.warning("Skipping incomplete recovery record key=%s", key)
            continue
        result.append((data, record_owner))
    return result


def _write_disk_records(records, tombstones=()):
    PROJECT_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary = PROJECT_STATE_PATH.with_name(f".{PROJECT_STATE_PATH.name}.tmp")
    payload = {
        "version": 2,
        "records": records,
        "tombstones": sorted({str(record_id) for record_id in tombstones}),
    }
    with _state_lock:
        temporary.write_text(
            json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2),
            encoding="utf-8",
        )
        os.replace(temporary, PROJECT_STATE_PATH)


def _persist_record(owner, kind, data, tombstones=None):
    _persist_records([(owner, kind, data)], tombstones=tombstones)


def persist_committed_records(records_to_persist):
    """Persist one committed SQLite write-set as one recovery-snapshot update."""
    if database_backend() == "postgres":
        return
    _persist_records(records_to_persist)


def _persist_records(records_to_persist, tombstones=None):
    records, disk_tombstones = _read_disk_state()
    current_tombstones = (
        set(disk_tombstones) if tombstones is None else set(tombstones)
    )
    for owner, kind, data in records_to_persist:
        records[_record_key(kind, data["id"])] = {
            "owner": owner,
            "kind": kind,
            "data": data,
        }
        current_tombstones.discard(str(data["id"]))
    _write_disk_records(records, current_tombstones)


def _hydrate_from_disk(conn):
    """Import snapshot records without overriding live rows or deletion markers."""
    try:
        records, snapshot_tombstones = _read_disk_state()
    except SnapshotReadError:
        log.exception("Skipping damaged project recovery snapshot during hydration")
        return

    conn.execute("BEGIN IMMEDIATE")
    try:
        for record_id in snapshot_tombstones:
            current = conn.execute(
                "SELECT 1 FROM studio_records WHERE id=?",
                (record_id,),
            ).fetchone()
            if current:
                # A live SQLite row is newer and authoritative.
                conn.execute("DELETE FROM studio_tombstones WHERE id=?", (record_id,))
                continue
            conn.execute(
                "INSERT OR IGNORE INTO studio_tombstones (id, deleted_at) VALUES (?, ?)",
                (record_id, datetime.now(timezone.utc).timestamp()),
            )

        for key, record in records.items():
            if not isinstance(record, dict):
                log.warning("Skipping malformed recovery record key=%s", key)
                continue
            owner = record.get("owner")
            kind = record.get("kind")
            data = record.get("data")
            if not owner or not kind or not isinstance(data, dict) or not data.get("id"):
                log.warning("Skipping incomplete recovery record key=%s", key)
                continue
            record_id = str(data["id"])
            deleted = conn.execute(
                "SELECT 1 FROM studio_tombstones WHERE id=?",
                (record_id,),
            ).fetchone()
            if deleted:
                continue
            timestamp = _utc_timestamp(data.get("updatedAt") or data.get("createdAt"))
            conn.execute(
                """
                INSERT OR IGNORE INTO studio_records
                    (id, owner, kind, data, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    record_id,
                    str(owner),
                    str(kind),
                    _json_data(data),
                    timestamp,
                    timestamp,
                ),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def _row_data(row):
    return _decode_data(row["data"])


def get(conn, owner, kind, record_id, lock=False):
    lock_sql = (
        " FOR UPDATE"
        if lock and getattr(conn, "dialect", "sqlite") == "postgres"
        else ""
    )
    row = conn.execute(
        "SELECT data FROM studio_records WHERE owner=? AND kind=? AND id=?"
        + lock_sql,
        (owner, kind, record_id),
    ).fetchone()
    return _decode_data(row["data"]) if row else None


def get_any_owner(conn, kind, record_id, lock=False):
    lock_sql = (
        " FOR UPDATE"
        if lock and getattr(conn, "dialect", "sqlite") == "postgres"
        else ""
    )
    row = conn.execute(
        "SELECT owner,data FROM studio_records WHERE kind=? AND id=?"
        + lock_sql,
        (kind, record_id),
    ).fetchone()
    return (_decode_data(row["data"]), row["owner"]) if row else (None, None)


def all_records(conn, owner, kind):
    rows = conn.execute(
        "SELECT data FROM studio_records "
        "WHERE owner=? AND kind=? ORDER BY created_at DESC",
        (owner, kind),
    ).fetchall()
    return [_row_data(row) for row in rows]


def all_records_any_owner(conn, kind):
    rows = conn.execute(
        "SELECT data,owner FROM studio_records "
        "WHERE kind=? ORDER BY created_at DESC",
        (kind,),
    ).fetchall()
    return [(_decode_data(row["data"]), row["owner"]) for row in rows]


def count_since(conn, kind, since):
    timestamp = _utc_timestamp(since)
    if getattr(conn, "dialect", "sqlite") == "postgres":
        timestamp = datetime.fromtimestamp(timestamp, timezone.utc)
    return int(
        conn.execute(
            "SELECT count(*) FROM studio_records WHERE kind=? AND created_at>=?",
            (kind, timestamp),
        ).fetchone()[0]
    )


def due_schedule(conn, at=None):
    """Return the earliest scheduled job whose ISO timestamp is due."""
    current = at or datetime.now(timezone.utc)
    candidates = []
    for data, owner in all_records_any_owner(conn, "schedule"):
        if data.get("status") != "scheduled":
            continue
        try:
            scheduled_at = datetime.fromisoformat(
                str(data.get("scheduledAt")).replace("Z", "+00:00")
            )
            if scheduled_at.tzinfo is None:
                scheduled_at = scheduled_at.replace(tzinfo=timezone.utc)
            scheduled_at = scheduled_at.astimezone(timezone.utc)
        except (TypeError, ValueError):
            log.warning("Skipping schedule with invalid scheduledAt id=%s", data.get("id"))
            continue
        if scheduled_at <= current:
            candidates.append((scheduled_at, owner, data))
    if not candidates:
        return None
    _scheduled_at, owner, data = min(candidates, key=lambda item: item[0])
    return owner, data


def claim_due_schedule(conn, at=None):
    """Select one due schedule under a database transaction/row lock."""
    if getattr(conn, "dialect", "sqlite") == "postgres":
        rows = conn.execute(
            """
            SELECT owner,data FROM studio_records
            WHERE kind='schedule' AND data->>'status'='scheduled'
            FOR UPDATE SKIP LOCKED
            """
        ).fetchall()
        current = at or datetime.now(timezone.utc)
        candidates = []
        for row in rows:
            data = _decode_data(row["data"])
            try:
                scheduled_at = datetime.fromisoformat(
                    str(data.get("scheduledAt")).replace("Z", "+00:00")
                )
                if scheduled_at.tzinfo is None:
                    scheduled_at = scheduled_at.replace(tzinfo=timezone.utc)
                scheduled_at = scheduled_at.astimezone(timezone.utc)
            except (TypeError, ValueError):
                log.warning(
                    "Skipping schedule with invalid scheduledAt id=%s",
                    data.get("id"),
                )
                continue
            if scheduled_at <= current:
                candidates.append((scheduled_at, row["owner"], data))
        if not candidates:
            return None
        _scheduled_at, owner, data = min(candidates, key=lambda item: item[0])
        return owner, data
    return due_schedule(conn, at)


def records_with_status(conn, kind, status):
    return [
        (data, owner)
        for data, owner in all_records_any_owner(conn, kind)
        if data.get("status") == status
    ]


def provider_operation_record_id(operation_key):
    return f"provider-operation:{str(operation_key)}"


def get_provider_operation(conn, owner, operation_key, lock=False):
    return get(
        conn,
        owner,
        "provider_operation",
        provider_operation_record_id(operation_key),
        lock=lock,
    )


def save_provider_operation(conn, owner, operation_key, data):
    record = dict(data)
    record["id"] = provider_operation_record_id(operation_key)
    record["operationKey"] = str(operation_key)
    record.setdefault("createdAt", now())
    record["updatedAt"] = now()
    save(conn, owner, "provider_operation", record)
    return record


def claim_provider_operation(conn, owner, project_id, operation_key, data):
    """Atomically persist an at-most-once provider-create claim."""
    started_transaction = not conn.in_transaction
    if started_transaction:
        conn.execute("BEGIN IMMEDIATE")
    try:
        project_lock = conn.execute(
            "SELECT id FROM studio_records WHERE owner=? AND kind='project' AND id=?"
            + (
                " FOR UPDATE"
                if getattr(conn, "dialect", "sqlite") == "postgres"
                else ""
            ),
            (owner, str(project_id)),
        ).fetchone()
        if project_lock is None:
            raise RuntimeError("The project could not be verified before provider submission.")

        existing = get_provider_operation(conn, owner, operation_key, lock=True)
        if existing:
            if started_transaction:
                conn.rollback()
            return existing, False

        unresolved_states = {
            "CREATE_IN_PROGRESS",
            "AMBIGUOUS_CREATE",
            "PROVIDER_ID_KNOWN",
            "POLLING",
        }
        for operation in all_records(conn, owner, "provider_operation"):
            if (
                str(operation.get("projectId") or "") == str(project_id)
                and operation.get("status") in unresolved_states
            ):
                raise ProviderOperationBlockedError(
                    "An AssemblyAI transcript operation is unresolved for this project."
                )

        record = dict(data)
        record["id"] = provider_operation_record_id(operation_key)
        record["operationKey"] = str(operation_key)
        record["projectId"] = str(project_id)
        record["owner"] = str(owner)
        record.setdefault("createdAt", now())
        record["updatedAt"] = now()
        save(conn, owner, "provider_operation", record)
        if started_transaction:
            conn.commit()
            persist_committed_records([(owner, "provider_operation", record)])
        return record, True
    except Exception:
        if started_transaction and conn.in_transaction:
            conn.rollback()
        raise


def save(conn, owner, kind, data):
    record_id = str(data["id"])
    timestamp = _utc_timestamp(data.get("updatedAt") or data.get("createdAt"))
    was_in_transaction = conn.in_transaction
    conn.execute("SAVEPOINT studio_save")
    try:
        if getattr(conn, "dialect", "sqlite") == "postgres":
            conn.execute(
                """
                INSERT INTO studio_records (id, owner, kind, data, created_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET data=excluded.data
                WHERE studio_records.owner=excluded.owner
                  AND studio_records.kind=excluded.kind
                """,
                (
                    record_id,
                    owner,
                    kind,
                    _database_json(conn, data),
                    _database_timestamp(conn, timestamp),
                ),
            )
        else:
            conn.execute(
                """
                INSERT INTO studio_records
                    (id, owner, kind, data, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    data=excluded.data,
                    updated_at=excluded.updated_at
                WHERE studio_records.owner=excluded.owner
                  AND studio_records.kind=excluded.kind
                """,
                (
                    record_id,
                    owner,
                    kind,
                    _database_json(conn, data),
                    timestamp,
                    timestamp,
                ),
            )
        persisted = conn.execute(
            "SELECT 1 FROM studio_records WHERE owner=? AND kind=? AND id=?",
            (owner, kind, record_id),
        ).fetchone()
        if persisted is None:
            raise RuntimeError("The project could not be verified after saving.")
        if getattr(conn, "dialect", "sqlite") != "postgres":
            conn.execute("DELETE FROM studio_tombstones WHERE id=?", (record_id,))
        conn.execute("RELEASE SAVEPOINT studio_save")
    except Exception:
        conn.execute("ROLLBACK TO SAVEPOINT studio_save")
        conn.execute("RELEASE SAVEPOINT studio_save")
        raise
    if not was_in_transaction and getattr(conn, "dialect", "sqlite") != "postgres":
        try:
            tombstones = {
                row["id"]
                for row in conn.execute("SELECT id FROM studio_tombstones").fetchall()
            }
            _persist_record(owner, kind, data, tombstones)
        except (OSError, SnapshotReadError, RuntimeError):
            log.exception(
                "Recovery snapshot write failed kind=%s record_id=%s",
                kind,
                record_id,
            )


def reassign_project_owner(conn, project_id, previous_owner, owner):
    """Reattach a persisted project and its schedules to a new workspace cookie."""
    conn.execute(
        "UPDATE studio_records SET owner=? "
        "WHERE owner=? AND kind='project' AND id=?",
        (owner, previous_owner, project_id),
    )
    schedules = conn.execute(
        "SELECT id,data FROM studio_records "
        "WHERE owner=? AND kind='schedule'",
        (previous_owner,),
    ).fetchall()
    for row in schedules:
        schedule = _decode_data(row["data"])
        if schedule.get("projectId") != project_id:
            continue
        conn.execute(
            "UPDATE studio_records SET owner=? WHERE id=?",
            (owner, row["id"]),
        )
    conn.commit()

    if getattr(conn, "dialect", "sqlite") == "postgres":
        return
    try:
        records, tombstones = _read_disk_state()
        for record in records.values():
            if not isinstance(record, dict) or record.get("owner") != previous_owner:
                continue
            data = record.get("data") or {}
            if (
                record.get("kind") == "project"
                and data.get("id") == project_id
            ) or (
                record.get("kind") == "schedule"
                and data.get("projectId") == project_id
            ):
                record["owner"] = owner
        _write_disk_records(records, tombstones)
    except (OSError, SnapshotReadError):
        log.exception("Recovery snapshot owner reassignment failed project_id=%s", project_id)


def delete_project_records(conn, owner, project_id):
    """Delete a project and every owner record linked to it."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        associated_records = conn.execute(
            "SELECT id,data FROM studio_records WHERE owner=? AND id<>?",
            (owner, project_id),
        ).fetchall()
        associated_ids = [
            row["id"]
            for row in associated_records
            if _decode_data(row["data"]).get("projectId") == project_id
        ]
        deleted_ids = {str(project_id), *(str(record_id) for record_id in associated_ids)}
        if getattr(conn, "dialect", "sqlite") != "postgres":
            for record_id in deleted_ids:
                conn.execute(
                    "INSERT OR IGNORE INTO studio_tombstones (id, deleted_at) VALUES (?, ?)",
                    (record_id, datetime.now(timezone.utc).timestamp()),
                )
        for record_id in deleted_ids:
            conn.execute(
                "DELETE FROM studio_records WHERE owner=? AND id=?",
                (owner, record_id),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise

    if getattr(conn, "dialect", "sqlite") == "postgres":
        return
    try:
        records, _disk_tombstones = _read_disk_state()
        records = {
            key: record
            for key, record in records.items()
            if not (
                isinstance(record, dict)
                and record.get("owner") == owner
                and (
                    (record.get("data") or {}).get("id") == project_id
                    or (record.get("data") or {}).get("projectId") == project_id
                )
            )
        }
        tombstones = {
            row["id"]
            for row in conn.execute("SELECT id FROM studio_tombstones").fetchall()
        }
        _write_disk_records(records, tombstones)
    except (OSError, SnapshotReadError):
        log.exception("Recovery snapshot deletion failed project_id=%s", project_id)


def event(project, message):
    project["updatedAt"] = now()
    project["events"] = ([{
        "id": uid(), "title": project["title"], "message": message, "createdAt": now()
    }] + project.get("events", []))[:60]


DEFAULT_SETTINGS = {
    "timezone": "Asia/Yangon", "peakHours": [12, 18, 20],
    "myanmarVoice": "my-MM-ThihaNeural", "myanmarRate": 15,
    "englishVoice": "en-US-JennyNeural",
}


def settings(conn, owner):
    return get(conn, owner, "settings", f"settings:{owner}") or DEFAULT_SETTINGS.copy()