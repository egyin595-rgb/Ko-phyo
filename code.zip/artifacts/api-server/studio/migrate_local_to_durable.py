"""Explicit, non-destructive copy from local Studio SQLite/media to durable services.

This command is dry-run by default. It never deletes local data or overwrites
different destination objects/records. Run with --apply --confirm-target only
after reviewing the local source and durable target.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import storage, store


class MigrationError(RuntimeError):
    """The local source or durable destination cannot be copied safely."""


def _read_source_records(database_path: Path) -> list[dict[str, Any]]:
    if not database_path.is_file():
        raise MigrationError("The local SQLite database file does not exist.")
    uri = f"file:{database_path.resolve().as_posix()}?mode=ro"
    try:
        connection = sqlite3.connect(uri, uri=True, timeout=10)
        connection.row_factory = sqlite3.Row
        try:
            rows = connection.execute(
                "SELECT id,owner,kind,data,created_at FROM studio_records ORDER BY id"
            ).fetchall()
        finally:
            connection.close()
    except sqlite3.Error as exc:
        raise MigrationError("The local SQLite records could not be read safely.") from exc

    records = []
    for row in rows:
        try:
            data = store._decode_data(row["data"])
        except RuntimeError as exc:
            raise MigrationError("A local record has invalid JSON and was not copied.") from exc
        records.append({
            "id": str(row["id"]),
            "owner": str(row["owner"]),
            "kind": str(row["kind"]),
            "data": data,
            "created_at": row["created_at"],
        })
    return records


def _collect_object_references(records: list[dict[str, Any]]) -> set[str]:
    references: set[str] = set()

    def visit(value: Any):
        if isinstance(value, dict):
            for key, item in value.items():
                if (
                    isinstance(item, str)
                    and key.lower().endswith("objectpath")
                    and item.strip()
                ):
                    references.add(storage._validated_object_name(item))
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)

    for record in records:
        data = record["data"]
        visit(data)
        if record["kind"] != "project":
            continue
        prefixes = data.get("exportObjectPrefixes") or {}
        default_prefix = str(data.get("objectPrefix") or "").strip()
        for export in data.get("exports") or []:
            if not isinstance(export, dict):
                continue
            language = str(export.get("language") or "")
            prefix = str(prefixes.get(language) or default_prefix).strip()
            if not prefix:
                continue
            for field in (
                "videoFilename",
                "subtitleFilename",
                "audioFilename",
                "thumbnailFilename",
                "metadataFilename",
                "packageFilename",
                "capcutVideoFilename",
            ):
                filename = str(export.get(field) or "").strip()
                if filename:
                    references.add(
                        storage._validated_object_name(f"{prefix}/{filename}")
                    )
    return references


def _local_media_files(media_root: Path) -> dict[str, Path]:
    root = media_root.expanduser().resolve()
    if not root.is_dir():
        raise MigrationError("The local media directory does not exist.")
    files: dict[str, Path] = {}
    for path in root.rglob("*"):
        if path.is_symlink() or not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part.startswith(".") for part in relative.parts):
            continue
        if path.name.endswith((".uploading", ".downloading")):
            continue
        files[relative.as_posix()] = path
    return files


def build_plan(database_path: Path, media_root: Path) -> dict[str, Any]:
    records = _read_source_records(database_path)
    references = _collect_object_references(records)
    files = _local_media_files(media_root)
    missing = sorted(references - files.keys())
    if missing:
        raise MigrationError(
            f"{len(missing)} referenced local media object(s) are missing; no data was copied."
        )
    selected = {key: files[key] for key in references}
    total_bytes = sum(path.stat().st_size for path in selected.values())
    return {
        "records": records,
        "media": selected,
        "record_count": len(records),
        "media_count": len(selected),
        "media_bytes": total_bytes,
        "unreferenced_media_count": len(files.keys() - references),
    }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _verify_remote_object(media_client, key: str, local_path: Path) -> bool:
    """Return true when a matching object exists; never overwrite a mismatch."""
    if not media_client.client.exists(key):
        return False
    downloaded = media_client.path_for(key)
    try:
        if _sha256(downloaded) != _sha256(local_path):
            raise MigrationError(
                "A durable media key already exists with different content; no overwrite was attempted."
            )
    finally:
        downloaded.unlink(missing_ok=True)
    return True


def _preflight_database(database_url: str) -> None:
    try:
        import psycopg
    except ImportError as exc:
        raise MigrationError("The PostgreSQL driver is not installed.") from exc
    try:
        with psycopg.connect(database_url, autocommit=True, connect_timeout=15) as conn:
            conn.execute("SELECT id FROM studio_records LIMIT 0")
    except Exception as exc:
        raise MigrationError(
            "The durable database is unavailable or does not have the Studio schema."
        ) from exc


def _copy_records_to_database(records: list[dict[str, Any]], database_url: str) -> int:
    import psycopg
    from psycopg.rows import dict_row
    from psycopg.types.json import Jsonb

    copied = 0
    try:
        with psycopg.connect(
            database_url,
            autocommit=False,
            row_factory=dict_row,
            connect_timeout=15,
        ) as conn:
            for record in records:
                created_at = record["created_at"]
                if not isinstance(created_at, datetime):
                    created_at = datetime.fromtimestamp(
                        float(created_at or 0),
                        timezone.utc,
                    )
                conn.execute(
                    """
                    INSERT INTO studio_records (id,owner,kind,data,created_at)
                    VALUES (%s,%s,%s,%s,%s)
                    ON CONFLICT(id) DO NOTHING
                    """,
                    (
                        record["id"],
                        record["owner"],
                        record["kind"],
                        Jsonb(record["data"]),
                        created_at,
                    ),
                )
                existing = conn.execute(
                    "SELECT owner,kind,data FROM studio_records WHERE id=%s",
                    (record["id"],),
                ).fetchone()
                if (
                    existing is None
                    or existing["owner"] != record["owner"]
                    or existing["kind"] != record["kind"]
                    or existing["data"] != record["data"]
                ):
                    raise MigrationError(
                        "A durable record ID already contains different data; no records were changed."
                    )
                copied += 1
        return copied
    except MigrationError:
        raise
    except Exception as exc:
        raise MigrationError(
            "The durable database copy failed; its transaction was rolled back."
        ) from exc


def apply_plan(plan: dict[str, Any], database_url: str, media_client) -> tuple[int, int]:
    _preflight_database(database_url)
    copied_media = 0
    for key, local_path in plan["media"].items():
        if _verify_remote_object(media_client, key, local_path):
            copied_media += 1
            continue
        media_client.upload_from_filename(key, str(local_path))
        if not _verify_remote_object(media_client, key, local_path):
            raise MigrationError("A durable media upload could not be verified.")
        copied_media += 1
    copied_records = _copy_records_to_database(plan["records"], database_url)
    return copied_records, copied_media


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-db", type=Path, default=store.SQLITE_DATABASE_PATH)
    parser.add_argument("--media-root", type=Path, default=storage.MEDIA_ROOT)
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Copy to PostgreSQL and App Storage; without this flag the command is read-only.",
    )
    parser.add_argument(
        "--confirm-target",
        action="store_true",
        help="Confirm that DATABASE_URL and App Storage point to the intended target.",
    )
    args = parser.parse_args(argv)
    try:
        plan = build_plan(args.source_db, args.media_root)
        print(
            "စမ်းသပ်အစီအစဉ် — "
            f"မှတ်တမ်း {plan['record_count']} ခု၊ "
            f"ရည်ညွှန်းထားသော မီဒီယာ {plan['media_count']} ခု၊ "
            f"စုစုပေါင်း {plan['media_bytes']} bytes; "
            f"မရည်ညွှန်းသော local ဖိုင် {plan['unreferenced_media_count']} ခုကို မပြောင်းလဲပါ။"
        )
        if not args.apply:
            print("ဤ dry-run တွင် database သို့မဟုတ် App Storage ကို မဝင်ရောက်ခဲ့ပါ။")
            return 0
        if not args.confirm_target:
            raise MigrationError("--apply requires --confirm-target.")
        database_url = str(os.environ.get("DATABASE_URL") or "").strip()
        if not database_url:
            raise MigrationError("DATABASE_URL is not configured.")
        if not os.environ.get("DEFAULT_OBJECT_STORAGE_BUCKET_ID"):
            raise MigrationError("Replit App Storage is not configured.")
        media_client = storage.AppStorageClient()
        records, media = apply_plan(plan, database_url, media_client)
        print(
            f"ရွှေ့ပြောင်းမှု အတည်ပြုပြီးပါပြီ — မှတ်တမ်း {records} ခုနှင့် "
            f"မီဒီယာ object {media} ခုကို ကူးယူပြီးပါပြီ။ "
            "Local SQLite မှတ်တမ်းနှင့် မီဒီယာများကို မဖျက်ဘဲ ထားရှိထားပါသည်။"
        )
        return 0
    except (MigrationError, OSError, ValueError) as exc:
        print(f"ဘေးကင်းစွာ ရပ်လိုက်သည် — {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())