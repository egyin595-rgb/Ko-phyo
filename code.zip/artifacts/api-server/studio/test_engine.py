"""Offline regression checks for issues found by the opt-in live validation."""
import tempfile
import unittest
import asyncio
import json
import os
import re
import shutil
import subprocess
import threading
import time
import zipfile
from contextlib import nullcontext
import urllib.error
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, Mock, patch

from .offline_test_support import install_network_guard

install_network_guard()

from fastapi import HTTPException
from PIL import Image

from . import engine, main, storage
from .models import ProjectUpdate, RunInput


def _fake_render_run(command, *_args, **_kwargs):
    """Materialize mocked FFmpeg outputs for the two-pass render tests."""
    Path(command[-1]).write_bytes(b"render fixture")


def _write_test_subtitles(path: Path):
    path.write_text(
        "1\n00:00:00,000 --> 00:00:01,000\nမင်္ဂလာပါ။\n",
        encoding="utf-8",
    )


def _write_test_thumbnail(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", (engine.THUMBNAIL_WIDTH, engine.THUMBNAIL_HEIGHT), "black").save(
        path,
        format="JPEG",
    )


def _prepare_test_font(font_dir: Path) -> Path:
    font_dir.mkdir(parents=True, exist_ok=True)
    source = Path(engine.__file__).resolve().parent / "fonts" / engine.MYANMAR_FONT_FILENAME
    shutil.copyfile(source, font_dir / engine.MYANMAR_FONT_FILENAME)
    return font_dir


class ProviderFailureTests(unittest.TestCase):
    def setUp(self):
        self._checkpoint_directory = tempfile.TemporaryDirectory()
        self._gemini_unavailable_models = dict(engine._GEMINI_UNAVAILABLE_MODELS)
        engine._GEMINI_UNAVAILABLE_MODELS.clear()
        self._original_audio_loudness_db = engine._audio_loudness_db
        self._checkpoint_root_patch = patch.object(
            engine,
            "CHECKPOINT_ROOT",
            Path(self._checkpoint_directory.name),
        )
        self._checkpoint_root_patch.start()
        self._loudness_patch = patch.object(
            engine,
            "_audio_loudness_db",
            return_value=(-20.0, -3.0),
        )
        self._loudness_patch.start()

    def tearDown(self):
        self._loudness_patch.stop()
        self._checkpoint_root_patch.stop()
        self._checkpoint_directory.cleanup()
        engine._GEMINI_UNAVAILABLE_MODELS.clear()
        engine._GEMINI_UNAVAILABLE_MODELS.update(self._gemini_unavailable_models)

    def test_prepared_checkpoint_restores_only_matching_fingerprint(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            source_srt = directory / "source.srt"
            source_audio = directory / "source.mp3"
            source_srt.write_text("1\n00:00:00,000 --> 00:00:01,000\nမင်္ဂလာပါ။\n", encoding="utf-8")
            source_audio.write_bytes(b"audio fixture")
            fallback_status = {
                "providers": ["gtts"],
                "fallbackUsed": True,
                "status": "fallback",
                "fallbackReason": "alternate_speech_provider",
            }
            manifest = {"version": engine.CHECKPOINT_VERSION, "stages": {}, "prepared": {}}
            engine._store_prepared_checkpoint(
                directory,
                manifest,
                "myanmar",
                "fingerprint-a",
                4.25,
                source_srt,
                source_audio,
                fallback_status,
            )

            restored_srt = directory / "restored.srt"
            restored_audio = directory / "restored.mp3"
            restored_status: dict[str, object] = {}
            duration = engine._restore_prepared_checkpoint(
                directory,
                manifest,
                "myanmar",
                "fingerprint-a",
                restored_srt,
                restored_audio,
                narration_status_out=restored_status,
            )
            self.assertEqual(duration, 4.25)
            self.assertEqual(restored_status, fallback_status)
            self.assertEqual(restored_srt.read_text(encoding="utf-8"), source_srt.read_text(encoding="utf-8"))
            self.assertEqual(restored_audio.read_bytes(), b"audio fixture")

            stale_srt = directory / "stale.srt"
            stale_audio = directory / "stale.mp3"
            self.assertIsNone(
                engine._restore_prepared_checkpoint(
                    directory,
                    manifest,
                    "myanmar",
                    "fingerprint-b",
                    stale_srt,
                    stale_audio,
                )
            )
            self.assertFalse(stale_srt.exists())
            self.assertFalse(stale_audio.exists())

            legacy_manifest = {
                "version": engine.CHECKPOINT_VERSION,
                "stages": {},
                "prepared": {
                    "myanmar": {
                        key: value
                        for key, value in manifest["prepared"]["myanmar"].items()
                        if key != "narrationStatus"
                    },
                },
            }
            self.assertIsNone(
                engine._restore_prepared_checkpoint(
                    directory,
                    legacy_manifest,
                    "myanmar",
                    "fingerprint-a",
                    directory / "legacy.srt",
                    directory / "legacy.mp3",
                )
            )

    def test_manual_source_actions_reject_projects_without_a_video(self):
        project = {"sourceObjectPath": "", "sourceUrl": "", "transcript": "", "myanmarScript": "", "englishScript": ""}
        for action in ("full", "transcribe", "export", "export_english"):
            with self.subTest(action=action), self.assertRaisesRegex(HTTPException, "Upload a video"):
                main.check_requirements(project, action)

    def test_manual_export_accepts_uploaded_or_direct_source(self):
        base = {"sourceObjectPath": "studio/source.mp4", "sourceUrl": "", "transcript": "", "myanmarScript": "", "englishScript": ""}
        main.check_requirements(base, "full")
        direct = {**base, "sourceObjectPath": "", "sourceUrl": "https://example.test/video.mp4"}
        main.check_requirements(direct, "full")

    def test_async_upload_offloads_ffmpeg_and_storage_from_event_loop(self):
        class Upload:
            filename = "fixture.mkv"
            content_type = "video/x-matroska"

            def __init__(self):
                self.chunks = [b"video", b""]

            async def read(self, _size):
                return self.chunks.pop(0)

            async def close(self):
                return None

        event_loop_thread = threading.get_ident()
        worker_threads = []

        def normalize(_source, destination):
            worker_threads.append(threading.get_ident())
            destination.write_bytes(b"normalized")

        client = SimpleNamespace()

        def upload(_object_name, _filename):
            worker_threads.append(threading.get_ident())

        client.upload_from_filename = upload
        request = SimpleNamespace(state=SimpleNamespace(owner="a" * 64))
        with patch.object(main, "normalize_uploaded_video", side_effect=normalize), \
                patch.object(main, "storage_client", return_value=client):
            result = asyncio.run(main.upload_source(request, Upload()))

        self.assertEqual(result["size"], len(b"normalized"))
        self.assertEqual(len(worker_threads), 2)
        self.assertTrue(all(thread_id != event_loop_thread for thread_id in worker_threads))

    def test_upload_rejects_stream_immediately_after_500mb_limit(self):
        class Upload:
            filename = "fixture.mov"
            content_type = "video/quicktime"

            def __init__(self):
                self.chunks = [b"1234", b"56", b""]

            async def read(self, _size):
                return self.chunks.pop(0)

            async def close(self):
                return None

        request = SimpleNamespace(state=SimpleNamespace(owner="a" * 64))
        with patch.object(main, "MAX_UPLOAD_BYTES", 5), \
                patch.object(main, "normalize_uploaded_video") as normalize:
            with self.assertRaises(HTTPException) as raised:
                asyncio.run(main.upload_source(request, Upload()))
        self.assertEqual(raised.exception.status_code, 413)
        normalize.assert_not_called()

    def test_upload_accepts_video_mime_with_nonstandard_extension(self):
        class Upload:
            filename = "fixture.avi"
            content_type = "video/x-msvideo"

            def __init__(self):
                self.chunks = [b"video", b""]

            async def read(self, _size):
                return self.chunks.pop(0)

            async def close(self):
                return None

        source_suffixes = []

        def normalize(source, destination):
            source_suffixes.append(source.suffix)
            destination.write_bytes(b"normalized")

        client = SimpleNamespace(upload_from_filename=lambda *_args: None)
        request = SimpleNamespace(state=SimpleNamespace(owner="a" * 64))
        with patch.object(main, "_prune_temporary_media"), \
                patch.object(main, "normalize_uploaded_video", side_effect=normalize), \
                patch.object(main, "storage_client", return_value=client):
            result = asyncio.run(main.upload_source(request, Upload()))

        self.assertEqual(result["size"], len(b"normalized"))
        self.assertEqual(source_suffixes, [".upload"])

    def test_upload_accepts_empty_or_octet_mime_for_supported_extensions(self):
        self.assertTrue(main.upload_content_type_allowed("", "fixture.MP4"))
        self.assertTrue(main.upload_content_type_allowed("application/octet-stream", "fixture.mov"))
        self.assertEqual(main.upload_suffix("fixture.MKV", ""), ".mkv")

    def test_upload_rejects_unknown_extension_without_video_mime(self):
        with self.assertRaisesRegex(HTTPException, "MP4, MOV, MKV, or WebM"):
            main.upload_suffix("fixture.avi", "application/octet-stream")
        with self.assertRaisesRegex(HTTPException, "MP4, MOV, MKV, or WebM"):
            main.upload_suffix("fixture.avi", "")

    def test_temp_media_pruning_keeps_active_job_and_removes_orphaned_media(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            job_root = root / "recap-studio-jobs"
            orphan = job_root / "orphan-project"
            active = job_root / "active-project"
            orphan.mkdir(parents=True)
            active.mkdir(parents=True)
            (orphan / "unused-tts.wav").write_bytes(b"wav")
            (orphan / "orphan-render.mp4").write_bytes(b"mp4")
            (active / "active-render.mp4").write_bytes(b"mp4")
            stale_upload = root / "recap-upload-stale.mp4"
            stale_upload.write_bytes(b"stale")
            stale_timestamp = time.time() - main.TEMP_CLEANUP_MAX_AGE_SECONDS - 1
            for path in (orphan, stale_upload):
                os.utime(path, (stale_timestamp, stale_timestamp))
            with patch.object(main.tempfile, "gettempdir", return_value=directory), \
                    patch.object(main, "TEMP_JOB_ROOT", job_root):
                main._track_temporary_path(active)
                try:
                    deleted = main._prune_temporary_media()
                finally:
                    main._untrack_temporary_path(active)

            self.assertGreaterEqual(deleted, 2)
            self.assertFalse(orphan.exists())
            self.assertFalse(stale_upload.exists())
            self.assertTrue(active.exists())

    def test_ffmpeg_failure_is_structured_without_exposing_stderr(self):
        if not shutil.which("ffmpeg"):
            self.skipTest("FFmpeg is required for the process failure regression.")
        with self.assertLogs(engine.log, level="ERROR") as logs:
            with self.assertRaises(engine.EngineError) as raised:
                engine._run(
                    [
                        "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error",
                        "-f", "lavfi", "-i", "definitely-invalid-filter",
                        "-frames:v", "1", "-f", "null", "-",
                    ],
                    "Final render",
                    timeout=15,
                )
        self.assertEqual(raised.exception.stage, "final-render")
        self.assertEqual(raised.exception.code, "FFMPEG_RENDER_ERROR")
        self.assertEqual(
            raised.exception.client_message,
            "FFmpeg video rendering failed.",
        )
        self.assertNotIn("definitely-invalid-filter", raised.exception.client_message)
        self.assertIn("[EXPORT ERROR]", "\n".join(logs.output))

    def test_worker_failure_cleans_unique_export_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            project = {"id": "cleanup-project", "title": "Cleanup"}
            schedule = {
                "id": "cleanup-schedule",
                "projectId": project["id"],
                "_action": "export",
                "_projectOverrides": {},
                "quality": "720p",
            }
            connection = MagicMock()
            with patch.object(main, "TEMP_JOB_ROOT", root / "jobs"), \
                    patch.object(main.store, "connection", return_value=nullcontext(connection)), \
                    patch.object(main, "project_or_404", return_value=project), \
                    patch.object(main.store, "settings", return_value={}), \
                    patch.object(main.store, "get", return_value=project), \
                    patch.object(main.store, "save"), \
                    patch.object(main.store, "event"), \
                    patch.object(
                        engine,
                        "process_project",
                        side_effect=engine.EngineError(
                            "internal ffmpeg path",
                            stage="final-render",
                            code="FFMPEG_RENDER_ERROR",
                            client_message="FFmpeg video rendering failed.",
                        ),
                    ):
                main.busy.acquire()
                try:
                    main.work("owner", schedule)
                finally:
                    if main.busy.locked():
                        main.busy.release()

            self.assertEqual(schedule["status"], "failed")
            jobs_root = root / "jobs"
            self.assertTrue(jobs_root.exists())
            self.assertEqual(list(jobs_root.iterdir()), [])
            self.assertEqual(project["error"], "FFmpeg video rendering failed.")
            self.assertEqual(project["errorCode"], "FFMPEG_RENDER_ERROR")
            self.assertEqual(project["errorStage"], "final-render")

    def test_faststart_validator_requires_moov_before_mdat(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)

            def atom(name, payload=b""):
                return (8 + len(payload)).to_bytes(4, "big") + name + payload

            fast = root / "fast.mp4"
            fast.write_bytes(atom(b"ftyp", b"isom0000") + atom(b"moov") + atom(b"mdat", b"x"))
            engine._verify_faststart_mp4(fast)

            slow = root / "slow.mp4"
            slow.write_bytes(atom(b"ftyp", b"isom0000") + atom(b"mdat", b"x") + atom(b"moov"))
            with self.assertRaisesRegex(engine.EngineError, "faststart"):
                engine._verify_faststart_mp4(slow)

    def test_upload_fails_explicitly_when_disk_would_drop_below_reserve(self):
        with patch.object(main, "_free_disk_bytes", return_value=main.MIN_FREE_DISK_BYTES - 1):
            with self.assertRaisesRegex(HTTPException, "Disk storage full"):
                main._ensure_free_disk_space()

    def test_myanmar_subtitles_use_dynamic_backdrop_boxes(self):
        style = engine._ass_style_values("myanmar")
        self.assertEqual(style["font_name"], engine.MYANMAR_FONT_NAME)
        self.assertEqual(style["font_size"], 32)
        self.assertEqual(style["border_style"], 1)
        self.assertEqual(style["bold"], -1)
        self.assertEqual(style["outline"], 4)
        self.assertEqual(style["shadow"], 2)
        self.assertEqual(style["margin_v"], 160)
        self.assertEqual(style["primary_color"], "&H00FFFFFF")
        self.assertEqual(style["outline_color"], "&H00000000")
        self.assertEqual(style["alignment"], 2)

    def test_bundled_myanmar_font_matches_ass_family_and_bold_face(self):
        font = engine._find_myanmar_font()
        self.assertEqual(font.name, engine.MYANMAR_FONT_FILENAME)
        self.assertEqual(
            font.parent,
            Path(engine.__file__).resolve().parent / "fonts",
        )
        self.assertGreater(font.stat().st_size, 0)
        self.assertEqual(
            engine._ass_style_values("myanmar")["font_name"],
            engine.MYANMAR_FONT_NAME,
        )

        fc_scan = engine.shutil.which("fc-scan")
        if not fc_scan:
            self.skipTest("fc-scan is required to inspect the bundled font metadata")
        probe = engine.subprocess.run(
            [fc_scan, "--format=%{family}|%{style}", str(font)],
            stdout=engine.subprocess.PIPE,
            stderr=engine.subprocess.PIPE,
            text=True,
            timeout=10,
            check=False,
        )
        self.assertEqual(probe.returncode, 0, probe.stderr)
        family, face_style = probe.stdout.split("|", 1)
        self.assertEqual(family, engine.MYANMAR_FONT_NAME)
        self.assertEqual(face_style.lower(), "bold")

    def test_missing_bundled_myanmar_font_fails_without_system_fallback(self):
        with patch.object(engine, "MYANMAR_FONT_FILENAME", "MissingMyanmar.ttf"):
            with self.assertRaisesRegex(engine.EngineError, "required font"):
                engine._find_myanmar_font()

    def test_ffmpeg_build_has_libass_harfbuzz_and_fribidi(self):
        if not engine.shutil.which("ffmpeg"):
            self.skipTest("FFmpeg is required for Myanmar subtitle rendering")
        engine._verify_myanmar_shaping_support()

    def test_english_subtitles_keep_outline_only(self):
        style = engine._ass_style_values("english")
        self.assertEqual(style["border_style"], 1)
        self.assertEqual(style["outline"], 4)

    def test_ass_style_uses_requested_alignment_and_size_controls(self):
        for alignment, ass_value in (("left", 1), ("center", 2), ("right", 3)):
            with self.subTest(alignment=alignment):
                style = engine._ass_style_values(
                    "myanmar",
                    font_size=24,
                    margin_v=48,
                    subtitle_alignment=alignment,
                )
                self.assertEqual(style["font_size"], 24)
                self.assertEqual(style["margin_v"], 80)
                self.assertEqual(style["alignment"], ass_value)

    def test_user_selected_70px_subtitle_size_reaches_render_profile_unchanged(self):
        public = main.public_project({
            "id": "subtitle-size-70",
            "subtitleFontSize": 70,
            "subtitleMarginV": 160,
        })
        profile = engine._render_profile(
            attempt=0,
            subtitle_font_size=public["subtitleFontSize"],
            subtitle_margin_v=public["subtitleMarginV"],
        )
        style = engine._ass_style_values(
            "myanmar",
            font_size=profile["subtitle_font_size"],
            margin_v=profile["subtitle_margin_v"],
        )

        self.assertEqual(public["subtitleFontSize"], 70)
        self.assertEqual(profile["subtitle_font_size"], 70)
        self.assertEqual(style["font_size"], 70)

    def test_subtitle_presets_change_ass_fill_outline_and_thickness(self):
        clean_white = engine._ass_style_values(
            "myanmar",
            subtitle_style={"preset": "clean-white"},
        )
        self.assertEqual(clean_white["primary_color"], "&H00FFFFFF")
        self.assertEqual(clean_white["outline_color"], "&H00000000")
        self.assertEqual(clean_white["outline"], 4)

        custom = engine._ass_style_values(
            "english",
            subtitle_style={
                "preset": "custom",
                "primaryColor": "#39FF14",
                "outlineColor": "#FF0000",
                "outlineWidth": 5,
            },
        )
        self.assertEqual(custom["primary_color"], "&H0014FF39")
        self.assertEqual(custom["outline_color"], "&H000000FF")
        self.assertEqual(custom["outline"], 5)

    def test_positioned_ass_uses_fixed_mobile_subtitle_style_and_canvas(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            srt = root / "myanmar.srt"
            ass = root / "myanmar.ass"
            srt.write_text(
                "1\n00:00:01,000 --> 00:00:03,250\nမင်္ဂလာပါ။\n",
                encoding="utf-8",
            )
            engine._write_positioned_ass(
                srt,
                ass,
                "myanmar",
                {"x": 0.10, "y": 0.70, "width": 0.80, "height": 0.20},
                subtitle_style={
                    "preset": "custom",
                    "primaryColor": "#00FFFF",
                    "outlineColor": "#000000",
                    "outlineWidth": 4,
                },
            )
            content = ass.read_text(encoding="utf-8")
        self.assertIn("PlayResX: 1080", content)
        self.assertIn("PlayResY: 1920", content)
        self.assertIn("&H00FFFF00,&H00FFFF00,&H00000000", content)
        self.assertIn(
            ",&H40000000,-1,0,0,0,100,100,0,0,1,4,2,2,108,108,160,1",
            content,
        )

    def test_positioned_ass_uses_actual_export_canvas(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            srt = root / "myanmar.srt"
            ass = root / "myanmar.ass"
            srt.write_text(
                "1\n00:00:01,000 --> 00:00:03,250\nမင်္ဂလာပါ။\n",
                encoding="utf-8",
            )
            engine._write_positioned_ass(
                srt,
                ass,
                "myanmar",
                {"x": 0.10, "y": 0.70, "width": 0.80, "height": 0.20},
                frame_width=720,
                frame_height=1280,
            )
            content = ass.read_text(encoding="utf-8")
        self.assertIn("PlayResX: 720", content)
        self.assertIn("PlayResY: 1280", content)
        self.assertIn(
            ",&H40000000,-1,0,0,0,100,100,0,0,1,3,1,2,72,72,106,1",
            content,
        )
        self.assertIn(r"\an8\pos(360,896)", content)
        self.assertIn(r"\clip(72,896,648,1152)", content)

    def test_blur_boxes_use_resource_safe_boxblur_and_translucent_banner(self):
        result = engine._blur_box_filter([{
            "x": 0.1,
            "y": 0.7,
            "width": 0.8,
            "height": 0.12,
        }])
        self.assertIn(
            "boxblur=luma_radius=20:luma_power=1:chroma_radius=0:alpha_radius=0",
            result,
        )
        self.assertIn("drawbox=x=0:y=0:w=iw:h=ih:color=black@0.25:t=fill", result)
        self.assertIn("null", result)

    def test_thumbnail_blur_graph_separates_following_logo_input(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            source = root / "source.mp4"
            logo = root / "logo.png"
            title = root / "title.txt"
            destination = root / "thumbnail.jpg"
            source.write_bytes(b"source")
            logo.write_bytes(b"logo")
            title.write_text("Hook title", encoding="utf-8")
            font_dir = _prepare_test_font(root / "fonts")

            captured: list[list[str]] = []

            def fake_run(command, _purpose, **_kwargs):
                captured.append(command)
                _write_test_thumbnail(destination)

            with patch.object(engine, "_run", side_effect=fake_run), \
                    patch.object(engine, "_probe_video_dimensions", return_value=(720, 1280)), \
                    patch.object(engine.subprocess, "run", return_value=MagicMock(returncode=0)):
                engine._extract_thumbnail(
                    source,
                    2.0,
                    destination,
                    blur_boxes=[{
                        "x": 0.1,
                        "y": 0.2,
                        "width": 0.3,
                        "height": 0.1,
                        "strength": 20,
                    }],
                    logo=logo,
                    hook_title_file=title,
                    font_file=font_dir / engine.MYANMAR_FONT_FILENAME,
                    frame_width=720,
                    frame_height=1280,
                )

            filter_complex = captured[0][captured[0].index("-filter_complex") + 1]
            self.assertIn(
                "[thumbnail_blurred]scale=1080:1920:force_original_aspect_ratio=increase",
                filter_complex,
            )
            self.assertIn("[thumbnail_cropped];[1:v]", filter_complex)

    def test_publish_thumbnail_omits_masks_logo_and_generated_text(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            source = root / "source.mp4"
            logo = root / "logo.png"
            title = root / "title.txt"
            destination = root / "thumbnail.jpg"
            source.write_bytes(b"source")
            logo.write_bytes(b"logo")
            title.write_text("Hook title", encoding="utf-8")
            font_dir = _prepare_test_font(root / "fonts")

            captured: list[list[str]] = []

            def fake_run(command, _purpose, **_kwargs):
                captured.append(command)
                _write_test_thumbnail(destination)

            with patch.object(engine, "_run", side_effect=fake_run), \
                    patch.object(
                        engine,
                        "_select_thumbnail_frame",
                        return_value={
                            "timestamp": 1.25,
                            "score": 0.9,
                            "candidateCount": 9,
                            "strategy": "visual-quality-score",
                        },
                    ), \
                    patch.object(engine, "_probe_video_dimensions", return_value=(720, 1280)), \
                    patch.object(engine.subprocess, "run", return_value=MagicMock(returncode=0)):
                engine._extract_thumbnail(
                    source,
                    2.0,
                    destination,
                    blur_boxes=[{
                        "x": 0.1,
                        "y": 0.2,
                        "width": 0.3,
                        "height": 0.1,
                        "strength": 20,
                    }],
                    logo=logo,
                    hook_title_file=title,
                    font_file=font_dir / engine.MYANMAR_FONT_FILENAME,
                    frame_width=720,
                    frame_height=1280,
                    clean_publish_thumbnail=True,
                )

            filter_complex = captured[0][captured[0].index("-filter_complex") + 1]
            self.assertNotIn("boxblur=", filter_complex)
            self.assertNotIn("[1:v]", filter_complex)
            self.assertNotIn("drawtext=", filter_complex)
            self.assertIn(
                "[thumbnail_blurred]crop=iw:1026:0:102[thumbnail_clean_source]",
                filter_complex,
            )
            self.assertIn("[thumbnail_cropped]format=yuvj420p[thumbnail]", filter_complex)

    def test_render_audio_maps_only_full_volume_narration(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "source.mp4"
            audio = Path(directory) / "voice.mp3"
            subtitles = Path(directory) / "myanmar.srt"
            output = Path(directory) / "output.mp4"
            for path in (source, audio):
                path.write_bytes(b"fixture")
            _write_test_subtitles(subtitles)
            font_dir = _prepare_test_font(Path(directory) / "fonts")
            with patch.object(engine, "_run", side_effect=_fake_render_run) as run:
                engine._render_video(
                    source, audio, subtitles, output, 2.0, "none",
                    font_dir, "myanmar", source_audio_present=True,
                    original_audio_volume=0.0,
                )
            command = run.call_args.args[0]
            filter_complex = command[command.index("-filter_complex") + 1]
            visual_command = run.call_args_list[0].args[0]
            self.assertIn("-an", visual_command)
            self.assertIn("[1:a]aresample=44100,volume=1.0", filter_complex)
            self.assertIn("aformat=sample_rates=44100:channel_layouts=stereo[narration_only]", filter_complex)
            self.assertNotIn("sidechaincompress=", filter_complex)
            first_map = command.index("-map")
            second_map = command.index("-map", first_map + 1)
            self.assertEqual(command[second_map + 1], "[narration_only]")
            self.assertEqual(command[command.index("-ar") + 1], "44100")
            self.assertEqual(command[command.index("-ac") + 1], "2")

    def test_render_quality_profiles_scale_and_bound_video_bitrate(self):
        expected = {
            "720p": ((720, 1280), "2M", "23", "128k"),
            "1080p": ((1080, 1920), "5M", "23", "192k"),
            "original": ((1080, 1920), "8M", "23", "192k"),
        }
        for quality, (dimensions, bitrate, crf, audio_bitrate) in expected.items():
            with self.subTest(quality=quality), tempfile.TemporaryDirectory() as directory, \
                    patch.object(engine, "_run", side_effect=_fake_render_run) as run:
                subtitle_path = Path(directory) / "myanmar.srt"
                _write_test_subtitles(subtitle_path)
                font_dir = _prepare_test_font(Path(directory) / "fonts")
                engine._render_video(
                    Path(directory) / "source.mp4",
                    Path(directory) / "audio.mp3",
                    subtitle_path,
                    Path(directory) / "output.mp4",
                    2.0,
                    "none",
                    font_dir,
                    "myanmar",
                    source_audio_present=False,
                    export_quality=quality,
                )
                visual_command = run.call_args_list[0].args[0]
                final_command = run.call_args_list[-1].args[0]
            filter_graph = visual_command[visual_command.index("-filter_complex") + 1]
            final_filter_graph = final_command[final_command.index("-filter_complex") + 1]
            width, height = dimensions
            scale = f"scale={width}:{height}:flags=lanczos,fps=30"
            self.assertIn(scale, filter_graph)
            self.assertIn(scale, final_filter_graph)
            self.assertEqual(final_command[final_command.index("-b:v") + 1], bitrate)
            self.assertIn("-preset", visual_command)
            self.assertEqual(
                visual_command[visual_command.index("-preset") + 1],
                "veryfast",
            )
            self.assertIn("-tune", visual_command)
            self.assertIn("fastdecode", visual_command)
            self.assertEqual(
                visual_command[visual_command.index("-crf") + 1],
                crf,
            )
            self.assertIn("-threads", visual_command)
            self.assertIn("0", visual_command)
            self.assertEqual(
                final_command[final_command.index("-preset") + 1],
                "veryfast",
            )
            self.assertEqual(final_command[final_command.index("-b:a") + 1], audio_bitrate)

        with self.assertRaisesRegex(engine.EngineError, "supported export quality"):
            engine._export_quality_profile("4k")

    def test_render_profiles_keep_audio_off_and_increase_readability(self):
        first = engine._render_profile(1)
        second = engine._render_profile(2)
        third = engine._render_profile(3)
        self.assertEqual(first["original_audio_volume"], 0.0)
        self.assertEqual(second["original_audio_volume"], 0.0)
        self.assertEqual(third["original_audio_volume"], 0.0)
        self.assertEqual(first["subtitle_font_size"], 32)
        self.assertEqual(second["myanmar_wrap_width"], first["myanmar_wrap_width"])
        self.assertEqual(third["subtitle_font_size"], 32)

    def test_export_dimensions_preserve_aspect_for_quality_and_native_profiles(self):
        self.assertEqual(engine._export_dimensions(1080, 1920, "720p"), (720, 1280))
        self.assertEqual(engine._export_dimensions(1080, 1920, "1080p"), (1080, 1920))
        self.assertEqual(engine._export_dimensions(320, 568, "720p"), (720, 1280))
        self.assertEqual(engine._export_dimensions(320, 568, "1080p"), (1080, 1920))
        self.assertEqual(engine._export_dimensions(1080, 1920, "original"), (1080, 1920))
        self.assertEqual(engine._export_dimensions(1920, 1080, "original"), (1920, 1080))
        self.assertEqual(engine._export_dimensions(1920, 1080, "720p"), (1280, 720))

    def test_test_export_bypasses_ai_and_uses_built_in_burmese_script(self):
        narration_calls = []
        uploaded_video_paths = []

        def download(_url, destination):
            destination.write_bytes(b"source fixture")

        def narration(
            script,
            language,
            voice,
            workdir,
            rate_percent=0,
            target_duration=None,
            **_kwargs,
        ):
            narration_calls.append((script, language, voice, target_duration))
            audio = workdir / f"{language}.mp3"
            subtitles = workdir / f"{language}.srt"
            audio.write_bytes(b"audio fixture")
            subtitles.write_text(
                "1\n00:00:00,000 --> 00:00:02,000\nမင်္ဂလာပါ။\n",
                encoding="utf-8",
            )
            return audio, subtitles, 2.0

        def render(_source, _audio, _srt, output, *_args, **_kwargs):
            def atom(name, payload=b""):
                return (
                    (8 + len(payload)).to_bytes(4, "big")
                    + name
                    + payload
                )

            output.write_bytes(
                atom(b"ftyp", b"isom0000")
                + atom(b"moov")
                + atom(b"mdat", b"video fixture")
            )

        def upload_exports(_project_id, files, _languages, *_args, **_kwargs):
            uploaded_video_paths.append(files["myanmar"][0])
            self.assertTrue(files["myanmar"][0].is_file())
            self.assertEqual(files["myanmar"][0].name, "myanmar-clean.mp4")
            return [{"language": "myanmar"}], "studio/test-export"

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_download_direct_video", side_effect=download), \
            patch.object(engine, "_probe_video", return_value=10.0), \
                patch.object(engine, "_probe_video_dimensions", return_value=(320, 568)), \
                patch.object(engine, "_make_narration", side_effect=narration), \
                patch.object(engine, "_render_video", side_effect=render), \
                patch.object(engine, "_validate_render_output"), \
                patch.object(
                    engine,
                    "_extract_thumbnail",
                    side_effect=lambda _video, _duration, destination, **_kwargs: destination.write_bytes(b"thumbnail"),
                ), \
                patch.object(
                    engine,
                    "_upload_exports",
                     side_effect=upload_exports,
                ), \
                patch.object(
                    engine,
                    "_generate_scripts",
                    side_effect=AssertionError("AI translation must not run"),
                ), \
                patch.object(
                    engine,
                    "_gemini_settings",
                    side_effect=AssertionError("Gemini settings must not be read"),
                ):
            result = engine.process_project(
                {
                    "id": "test-export",
                    "sourceUrl": "https://example.test/video.mp4",
                    "sourceObjectPath": "",
                    "targetDurationMinutes": None,
                    "globalEdit": "none",
                    "blurBoxes": [],
                    "subtitleBox": None,
                },
                {
                    "myanmarVoice": "my-MM-NilarNeural",
                    "englishVoice": "en-US-JennyNeural",
                    "myanmarRate": 10,
                },
                "test_export",
                lambda *_args: None,
                Path(directory),
                quality="720p",
            )

        self.assertEqual([item["language"] for item in result["exports"]], ["myanmar"])
        self.assertEqual(result["exports"][0]["scriptVersion"], 0)
        self.assertEqual(result["exports"][0]["processingVersion"], 0)
        self.assertEqual(result["exports"][0]["quality"], "720p")
        self.assertEqual(len(uploaded_video_paths), 1)
        self.assertEqual(uploaded_video_paths[0].name, "myanmar-clean.mp4")
        self.assertEqual(narration_calls[0][0], engine.EMERGENCY_TEST_MYANMAR_SCRIPT)
        self.assertEqual(narration_calls[0][1:], ("myanmar", "my-MM-NilarNeural", 8.0))

    def test_subtitle_metrics_scale_from_short_edge_and_keep_width_budget(self):
        low = engine._ass_style_values(
            "myanmar",
            frame_width=720,
            frame_height=1280,
        )
        baseline = engine._ass_style_values(
            "myanmar",
            frame_width=1080,
            frame_height=1920,
        )
        self.assertEqual(low["font_size"], 21)
        self.assertEqual(low["margin_v"], 106)
        self.assertEqual(low["outline"], 3)
        self.assertEqual(low["shadow"], 1)
        self.assertEqual(low["margin_l"], 43)
        self.assertEqual(low["margin_r"], 43)
        self.assertEqual(baseline["font_size"], 32)
        self.assertEqual(baseline["margin_v"], 160)
        self.assertEqual(baseline["outline"], 4)
        self.assertEqual(
            engine._subtitle_wrap_width("myanmar", 720, 1280),
            engine._subtitle_wrap_width("myanmar", 1080, 1920),
        )

    def test_render_output_validation_requires_decodable_audio_video_and_safe_subtitles(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine.subprocess, "run", side_effect=[
                    SimpleNamespace(
                        returncode=0,
                        stdout=json.dumps({
                            "format": {"format_name": "mov,mp4,m4a,3gp", "duration": "1.0"},
                            "streams": [
                                {
                                    "codec_type": "video", "codec_name": "h264",
                                    "width": 1080, "height": 1920, "pix_fmt": "yuv420p",
                                },
                                {
                                    "codec_type": "audio", "codec_name": "aac",
                                    "channels": 2, "sample_rate": "44100", "bit_rate": "192000",
                                },
                            ],
                        }),
                        stderr="",
                    ),
                    SimpleNamespace(returncode=0, stdout="", stderr=""),
                ]):
            root = Path(directory)
            output = root / "myanmar.mp4"
            subtitles = root / "myanmar.srt"
            font_dir = root / "fonts"
            font_dir.mkdir()
            output.write_bytes(
                (16).to_bytes(4, "big") + b"ftyp" + b"isom0000"
                + (8).to_bytes(4, "big") + b"moov"
                + (21).to_bytes(4, "big") + b"mdat" + b"video fixture"
            )
            (font_dir / "NotoSansMyanmar-Bold.ttf").write_bytes(b"font fixture")
            subtitles.write_text(
                "1\n00:00:00,000 --> 00:00:01,000\n"
                "[A] မင်္ဂလာပါ။\n",
                encoding="utf-8",
            )
            engine._validate_render_output(
                output,
                subtitles,
                "myanmar",
                font_dir,
                engine._render_profile(1),
                1.0,
                [],
            )

    def test_render_output_validation_accepts_silence_heavy_aac_vbr_average(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine.subprocess, "run", side_effect=[
                    SimpleNamespace(
                        returncode=0,
                        stdout=json.dumps({
                            "format": {"format_name": "mov,mp4,m4a,3gp,3g2,mj2", "duration": "42.7"},
                            "streams": [
                                {
                                    "codec_type": "video", "codec_name": "h264",
                                    "width": 720, "height": 1280, "pix_fmt": "yuv420p",
                                },
                                {
                                    "codec_type": "audio", "codec_name": "aac",
                                    "channels": 2, "sample_rate": "44100", "bit_rate": "14480",
                                },
                            ],
                        }),
                        stderr="",
                    ),
                    SimpleNamespace(returncode=0, stdout="", stderr=""),
                ]):
            root = Path(directory)
            output = root / "myanmar.mp4"
            subtitles = root / "myanmar.srt"
            font_dir = root / "fonts"
            font_dir.mkdir()
            output.write_bytes(
                (16).to_bytes(4, "big") + b"ftyp" + b"isom0000"
                + (8).to_bytes(4, "big") + b"moov"
                + (21).to_bytes(4, "big") + b"mdat" + b"video fixture"
            )
            (font_dir / "NotoSansMyanmar-Bold.ttf").write_bytes(b"font fixture")
            subtitles.write_text(
                "1\n00:00:00,000 --> 00:00:42,700\n"
                "မင်္ဂလာပါ။\n",
                encoding="utf-8",
            )
            engine._validate_render_output(
                output,
                subtitles,
                "myanmar",
                font_dir,
                engine._render_profile(
                    1,
                    frame_width=720,
                    frame_height=1280,
                ),
                42.7,
                [],
                frame_width=720,
                frame_height=1280,
                export_quality="720p",
            )

    def test_render_output_validation_rejects_non_utf8_subtitles(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "myanmar.mp4"
            subtitles = root / "myanmar.srt"
            font_dir = root / "fonts"
            font_dir.mkdir()
            output.write_bytes(b"video fixture")
            (font_dir / "NotoSansMyanmar-Bold.ttf").write_bytes(b"font fixture")
            subtitles.write_bytes(b"\xff\xfe")
            with self.assertRaisesRegex(engine.EngineError, "valid UTF-8"):
                engine._validate_subtitle_file(
                    subtitles, "myanmar", font_dir, engine._render_profile(1),
                )

    def test_gemini_audio_transcription_returns_timestamped_dialogue(self):
        content = json.dumps({
            "transcript": "这是中文转录。",
            "dialogue": [
                {"speaker": "A", "start": 0.25, "end": 1.2, "sourceText": "这是中文转录。"},
            ],
        }, ensure_ascii=False)
        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_gemini_generate", return_value=content) as generate:
            source = Path(directory) / "source.wav"
            source.write_bytes(b"RIFF test audio")
            text, dialogue = engine._transcribe_with_dialogue(source)
        self.assertEqual(text, "这是中文转录。")
        self.assertEqual(dialogue[0]["start"], 0.25)
        self.assertEqual(dialogue[0]["end"], 1.2)
        self.assertEqual(generate.call_args.args[2], "Gemini audio transcription")
        parts = generate.call_args.kwargs["user_parts"]
        self.assertEqual(parts[1]["inlineData"]["mimeType"], "audio/wav")

    def test_gemini_failure_uses_assemblyai_timestamped_transcript(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {
                    "GEMINI_API_KEY": "test-key",
                    "ASSEMBLYAI_API_KEY": "test-assembly-key",
                }, clear=True), \
                patch.object(
                    engine,
                    "_gemini_transcript_dialogue",
                    side_effect=engine.EngineError(
                        "Gemini was rate limited.",
                        stage="transcription",
                        code="GEMINI_RATE_LIMIT",
                        client_message="Speech transcription service is temporarily unavailable.",
                    ),
                ), \
                patch.object(
                    engine,
                    "_assemblyai_transcript_with_dialogue",
                    return_value=(
                        "这是来自备用服务的中文转录。",
                        [{
                            "speaker": "A",
                            "start": 0.0,
                            "end": 1.5,
                            "sourceText": "这是来自备用服务的中文转录。",
                        }],
                    ),
                ) as assemblyai:
            text, dialogue = engine._transcribe_with_dialogue(Path(directory) / "audio.wav")
        self.assertIn("备用服务", text)
        self.assertEqual(dialogue[0]["start"], 0.0)
        assemblyai.assert_called_once()

    def test_assemblyai_uses_current_speech_models_payload(self):
        upload_response = MagicMock()
        upload_response.__enter__.return_value = upload_response
        upload_response.__exit__.return_value = None
        upload_response.read.return_value = b'{"upload_url":"https://assembly.test/audio"}'
        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {"ASSEMBLYAI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_audio_duration", return_value=1.0), \
                patch.object(
                    engine.urllib.request,
                    "urlopen",
                    return_value=upload_response,
                ), \
                patch.object(
                    engine,
                    "_assemblyai_json_request",
                    side_effect=[
                        {"id": "transcript-id"},
                        {
                            "status": "completed",
                            "text": "这是中文转录。",
                            "utterances": [{
                                "speaker": "A",
                                "start": 100,
                                "end": 1200,
                                "text": "这是中文转录。",
                            }],
                        },
                    ],
                ) as request:
            source = Path(directory) / "audio.wav"
            source.write_bytes(b"audio")
            text, dialogue = engine._assemblyai_transcript_with_dialogue(source)

        payload = request.call_args_list[0].args[3]
        self.assertEqual(payload["speech_models"], [engine.ASSEMBLYAI_MODEL])
        self.assertNotIn("speech_model", payload)
        self.assertEqual(text, "这是中文转录。")
        self.assertEqual(dialogue[0]["start"], 0.1)
        self.assertEqual(dialogue[0]["end"], 1.2)

    def test_assemblyai_retries_temporary_failures_within_a_deadline(self):
        def response(payload):
            value = MagicMock()
            value.__enter__.return_value = value
            value.__exit__.return_value = None
            value.read.return_value = json.dumps(payload).encode("utf-8")
            return value

        def http_error(status):
            return urllib.error.HTTPError(
                "https://api.assemblyai.com/v2",
                status,
                "temporary failure",
                {"Retry-After": "0"},
                engine.BytesIO(b""),
            )

        responses = [
            http_error(503),  # upload: safe to retry; no transcript exists yet
            response({"upload_url": "https://assembly.test/audio"}),
            http_error(429),  # create: explicit rate-limit rejection is retryable
            response({"id": "transcript-id"}),
            urllib.error.URLError("temporary network reset"),  # poll: GET is safe
            http_error(503),
            response({
                "status": "completed",
                "text": "这是中文转录。",
                "utterances": [{
                    "speaker": "A",
                    "start": 100,
                    "end": 1200,
                    "text": "这是中文转录。",
                }],
            }),
        ]
        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {"ASSEMBLYAI_API_KEY": "test-key"}, clear=True), \
                patch.object(
                    engine,
                    "_transcription_audio_details",
                    return_value={
                        "audio_format": "wav",
                        "audio_duration": 1.2,
                        "file_size": 5,
                    },
                ), \
                patch.object(
                    engine.urllib.request,
                    "urlopen",
                    side_effect=responses,
                ) as urlopen, \
                patch.object(engine.time, "sleep") as sleep:
            source = Path(directory) / "audio.wav"
            source.write_bytes(b"audio")
            text, dialogue = engine._assemblyai_transcript_with_dialogue(source)

        self.assertEqual(urlopen.call_count, 7)
        self.assertEqual(sleep.call_count, 4)
        self.assertEqual(text, "这是中文转录。")
        self.assertEqual(dialogue[0]["start"], 0.1)
        self.assertEqual(dialogue[0]["end"], 1.2)
        create_request = urlopen.call_args_list[3].args[0]
        self.assertEqual(create_request.get_method(), "POST")
        self.assertEqual(
            json.loads(create_request.data)["speech_models"],
            [engine.ASSEMBLYAI_MODEL],
        )

    def test_assemblyai_does_not_retry_ambiguous_transcript_create_failure(self):
        upload_response = MagicMock()
        upload_response.__enter__.return_value = upload_response
        upload_response.__exit__.return_value = None
        upload_response.read.return_value = (
            b'{"upload_url":"https://assembly.test/audio"}'
        )
        create_error = urllib.error.HTTPError(
            "https://api.assemblyai.com/v2/transcript",
            503,
            "service unavailable",
            {},
            engine.BytesIO(b"temporary"),
        )
        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {"ASSEMBLYAI_API_KEY": "test-key"}, clear=True), \
                patch.object(
                    engine,
                    "_transcription_audio_details",
                    return_value={
                        "audio_format": "wav",
                        "audio_duration": 1.2,
                        "file_size": 5,
                    },
                ), \
                patch.object(
                    engine.urllib.request,
                    "urlopen",
                    side_effect=[upload_response, create_error],
                ) as urlopen, \
                patch.object(engine.time, "sleep") as sleep, \
                patch.object(engine, "_log_transcription_failure"):
            source = Path(directory) / "audio.wav"
            source.write_bytes(b"audio")
            with self.assertRaises(engine.EngineError) as raised:
                engine._assemblyai_transcript_with_dialogue(source)

        self.assertEqual(raised.exception.code, "ASSEMBLYAI_TRANSCRIPTION_ERROR")
        self.assertEqual(urlopen.call_count, 2)
        sleep.assert_not_called()

    def test_assemblyai_request_rejects_an_expired_deadline_before_network_access(self):
        request = engine.urllib.request.Request("https://assembly.test/status")
        with patch.object(engine.urllib.request, "urlopen") as urlopen:
            with self.assertRaises(TimeoutError):
                engine._assemblyai_request_bytes(
                    request,
                    timeout_seconds=5,
                    deadline=time.monotonic() - 1,
                    retryable_statuses={429, 503},
                    retry_network_errors=True,
                )
        urlopen.assert_not_called()

    def test_missing_gemini_uses_local_timeline_without_assemblyai(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {}, clear=True), \
                patch.object(engine, "_audio_duration", return_value=62.0):
            text, dialogue = engine._transcribe_with_dialogue(Path(directory) / "audio.wav")
        self.assertIn("Local audio timeline segment", text)
        self.assertEqual(len(dialogue), 3)
        self.assertEqual(dialogue[-1]["end"], 62.0)

    def test_offline_scripts_fail_closed_without_real_burmese_source(self):
        with self.assertRaisesRegex(engine.EngineError, "real Gemini Burmese recap"):
            engine._offline_scripts(
                "Local audio timeline segment 1",
                [{
                    "speaker": "A",
                    "start": 0,
                    "end": 2,
                    "sourceText": "Local audio timeline segment 1",
                }],
            )

    def test_whisper_transcription_preserves_exact_segment_timestamps(self):
        response = SimpleNamespace(
            text="你好。再见。",
            segments=[
                SimpleNamespace(start=0.25, end=1.2, text="你好。"),
                SimpleNamespace(start=1.4, end=2.3, text="再见。"),
            ],
        )
        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {
                    "OPENAI_API_KEY": "direct-test-key",
                }, clear=True), patch.object(engine, "OpenAI") as openai:
            source = Path(directory) / "source.mp4"
            source.write_bytes(b"test audio bytes")
            openai.return_value.audio.transcriptions.create.return_value = response
            text, dialogue = engine._whisper_transcript_with_dialogue(source)
        self.assertEqual(text, "你好。再见。")
        self.assertEqual(dialogue, [
            {"speaker": "A", "start": 0.25, "end": 1.2, "sourceText": "你好。"},
            {"speaker": "A", "start": 1.4, "end": 2.3, "sourceText": "再见。"},
        ])

    def test_whisper_rejects_text_without_timestamped_segments(self):
        response = SimpleNamespace(text="你好。", segments=[])
        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {"OPENAI_API_KEY": "direct-test-key"}, clear=True), \
                patch.object(engine, "OpenAI") as openai:
            source = Path(directory) / "source.mp4"
            source.write_bytes(b"test audio bytes")
            openai.return_value.audio.transcriptions.create.return_value = response
            with self.assertRaisesRegex(engine.EngineError, "no timestamped"):
                engine._whisper_transcript_with_dialogue(source)

    def test_missing_translation_provider_fails_closed(self):
        with patch.dict("os.environ", {}, clear=True):
            with self.assertRaisesRegex(engine.EngineError, "real Gemini Burmese recap"):
                engine._offline_scripts("这是一个中文故事。", [])

    def test_recap_translation_provider_failure_does_not_create_dummy_scripts(self):
        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_gemini_generate", side_effect=RuntimeError("provider unavailable")), \
                patch.object(
                    engine,
                    "_fallback_translator_pair",
                    side_effect=AssertionError("continuous recaps must not use direct translation"),
                ) as fallback:
            with self.assertRaisesRegex(engine.EngineError, "No continuous recap script was saved"):
                engine._generate_scripts("这是一个中文故事。")
        fallback.assert_not_called()

    def test_missing_gemini_fails_closed_for_continuous_recap(self):
        with patch.dict("os.environ", {}, clear=True), \
                patch.object(
                    engine,
                    "_fallback_translator_pair",
                    side_effect=AssertionError("continuous recaps must not use direct translation"),
                ) as fallback:
            with self.assertRaisesRegex(
                engine.EngineError,
                "Gemini is not configured; continuous recap generation requires Gemini",
            ) as raised:
                engine._generate_scripts("他回到了家。")
        self.assertEqual(raised.exception.stage, "translation")
        self.assertEqual(raised.exception.code, "GEMINI_RECAP_UNAVAILABLE")
        fallback.assert_not_called()

    def test_invalid_burmese_unicode_is_rejected(self):
        with self.assertRaisesRegex(engine.EngineError, "valid Unicode Myanmar"):
            engine._validate_myanmar_script("garbled \ufffd text")

    def test_direct_openai_key_uses_openai_default_endpoint(self):
        with patch.dict("os.environ", {"OPENAI_API_KEY": "direct-test-key"}, clear=True):
            key, base_url = engine._openai_settings()
        self.assertEqual(key, "direct-test-key")
        self.assertEqual(base_url, "https://api.openai.com/v1")

    def test_gemini_translation_response_flows_into_scripts(self):
        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_gemini_generate", return_value=json.dumps({
                    "storyBeats": [{
                        "role": "resolution",
                        "sourceEventIds": [],
                        "visualTimestampsSeconds": [],
                        "myanmarNarration": "ဒါက အမှန်တကယ် မြန်မာဇာတ်ညွှန်းပါ။",
                        "englishNarration": "This is the real English recap.",
                    }],
                    "omittedSourceEvents": [],
                }, ensure_ascii=False)) as generate:
            myanmar, english = engine._generate_scripts("这是一个中文故事。")
        self.assertEqual(myanmar, "ဒါက အမှန်တကယ် မြန်မာဇာတ်ညွှန်းပါ။")
        self.assertEqual(english, "This is the real English recap.")
        self.assertEqual(generate.call_args.args[2], "Recap translation")

    def test_story_outline_covers_reviewed_events_in_chronological_order(self):
        transcript = "\n".join([
            "[0.000-1.000s] [event event_a] [speaker A] 起点",
            "[1.000-2.000s] [event event_b] [speaker B] 变化",
            "[2.000-3.000s] [event event_c] [speaker A] 结果",
        ])
        data = {
            "storyBeats": [
                {
                    "role": "opening",
                    "sourceEventIds": ["event_a"],
                    "visualTimestampsSeconds": [0.5],
                    "myanmarNarration": "အစပိုင်းကို ရှင်းပြထားသည်။",
                    "englishNarration": "The opening is established.",
                },
                {
                    "role": "development",
                    "sourceEventIds": ["event_b"],
                    "visualTimestampsSeconds": [1.5],
                    "myanmarNarration": "အရေးကြီးသော အပြောင်းအလဲ ဖြစ်လာသည်။",
                    "englishNarration": "An important change follows.",
                },
                {
                    "role": "resolution",
                    "sourceEventIds": ["event_c"],
                    "visualTimestampsSeconds": [2.5],
                    "myanmarNarration": "ဇာတ်လမ်းက အဆုံးသတ်ရလဒ်ကို ရောက်သွားသည်။",
                    "englishNarration": "The story reaches its outcome.",
                },
            ],
            "omittedSourceEvents": [],
        }

        myanmar, english, coverage = engine._validate_story_recap_response(
            data,
            transcript,
            [0.5, 1.5, 2.5],
        )

        self.assertIn("အစပိုင်း", myanmar)
        self.assertIn("အဆုံးသတ်ရလဒ်", myanmar)
        self.assertIn("The opening", english)
        self.assertEqual(
            coverage,
            {
                "beats": 3,
                "sourceEvents": 3,
                "coveredSourceEvents": 3,
                "omittedSourceEvents": 0,
            },
        )

    def test_story_outline_rejects_unaccounted_reviewed_events(self):
        transcript = "\n".join([
            "[0.000-1.000s] [event event_a] [speaker A] 起点",
            "[1.000-2.000s] [event event_b] [speaker B] 结果",
        ])
        data = {
            "storyBeats": [{
                "role": "resolution",
                "sourceEventIds": ["event_a"],
                "visualTimestampsSeconds": [],
                "myanmarNarration": "အဖြစ်အပျက်တစ်ခု။",
                "englishNarration": "One event.",
            }],
            "omittedSourceEvents": [],
        }

        with self.assertRaisesRegex(
            engine.EngineError,
            "did not account for every reviewed source event",
        ):
            engine._validate_story_recap_response(data, transcript, [])

    def test_recap_generation_attaches_sparse_video_context_to_gemini(self):
        generated = json.dumps({
            "storyBeats": [{
                "role": "resolution",
                "sourceEventIds": [],
                "visualTimestampsSeconds": [1.0],
                "myanmarNarration": "ဗီဒီယိုအထောက်အထားအရ ဇာတ်လမ်းပြီးဆုံးသည်။",
                "englishNarration": "The source video shows the story ending.",
            }],
            "omittedSourceEvents": [],
        }, ensure_ascii=False)
        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(
                    engine,
                    "_make_story_context_contact_sheet",
                    return_value=(b"jpeg-fixture", [1.0]),
                ), \
                patch.object(engine, "_gemini_generate", return_value=generated) as generate:
            engine._generate_scripts(
                "ဇာတ်လမ်းအကြောင်း",
                source_video=Path("sample.mp4"),
                source_duration=3.0,
            )

        user_parts = generate.call_args.kwargs["user_parts"]
        self.assertEqual(user_parts[0]["text"], generate.call_args.args[1])
        self.assertEqual(user_parts[1]["inlineData"]["mimeType"], "image/jpeg")
        self.assertEqual(
            engine.base64.b64decode(user_parts[1]["inlineData"]["data"]),
            b"jpeg-fixture",
        )

    def test_story_context_sampling_is_bounded_and_honors_confirmed_end(self):
        sampled = engine._story_context_sample_times(600, story_end_seconds=37)

        self.assertLessEqual(len(sampled), engine.STORY_CONTEXT_MAX_FRAMES)
        self.assertGreaterEqual(sampled[0], 0)
        self.assertLess(sampled[-1], 37)
        self.assertEqual(
            len(engine._story_context_sample_times(600)),
            engine.STORY_CONTEXT_MAX_FRAMES,
        )

    def test_story_context_contact_sheet_is_bounded_and_decodable(self):
        def create_frame(command, *_args, **_kwargs):
            output = Path(command[-1])
            timestamp = float(command[command.index("-ss") + 1])
            frame = engine.Image.new(
                "RGB",
                (480, 854),
                (int(timestamp * 10) % 255, 80, 150),
            )
            frame.save(output, format="JPEG")
            frame.close()

        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "source.mp4"
            source.write_bytes(b"synthetic video fixture")
            with patch.object(engine, "_run", side_effect=create_frame) as run:
                image_bytes, times = engine._make_story_context_contact_sheet(
                    source,
                    duration=25,
                    story_end_seconds=20,
                )

        self.assertEqual(run.call_count, len(times))
        self.assertLessEqual(len(times), engine.STORY_CONTEXT_MAX_FRAMES)
        with engine.Image.open(engine.BytesIO(image_bytes)) as sheet:
            self.assertEqual(sheet.format, "JPEG")
            self.assertEqual(sheet.width, 960)
            self.assertGreater(sheet.height, 560)

    def test_subtitle_wrap_width_uses_the_selected_box_width(self):
        standard = engine._subtitle_wrap_width("myanmar", 1080, 1920, 32)
        large_subtitle = engine._subtitle_wrap_width("myanmar", 1080, 1920, 120)
        narrow = engine._subtitle_wrap_width(
            "myanmar",
            1080,
            1920,
            32,
            {"x": 0.28, "y": 0.7, "width": 0.44, "height": 0.2},
        )

        self.assertLess(narrow, standard)
        self.assertAlmostEqual(narrow, round(standard * 0.5), delta=1)
        self.assertEqual(large_subtitle, 8)

    def test_translate_action_uses_narration_window_across_source_durations(self):
        scenarios = [
            {"source": 5.0},
            {"source": 30.0},
            {"source": 300.0, "target_minutes": 3},
            {"source": 42.7},
            {
                "source": 180.0,
                "narration_start": 2.5,
                "narration_duration": 25.0,
            },
        ]
        for case_number, scenario in enumerate(scenarios):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as directory:
                source_duration = scenario["source"]
                target_minutes = scenario.get("target_minutes")
                target_video_duration = (
                    min(source_duration, target_minutes * 60)
                    if target_minutes
                    else source_duration
                )
                narration_start = scenario.get(
                    "narration_start",
                    engine.DEFAULT_NARRATION_START_SECONDS,
                )
                expected_narration_window = scenario.get(
                    "narration_duration",
                    target_video_duration
                    - narration_start
                    - engine.NARRATION_END_PADDING_SECONDS,
                )
                calibration = Mock(
                    return_value=("က " * 462) + "အချိန်နှင့်ကိုက်သော ဇာတ်လမ်းအနှစ်ချုပ်။"
                )
                generate = Mock(
                    return_value=("တိုသော ဇာတ်လမ်း။", "A complete English recap.")
                )

                with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                        patch.object(
                            engine,
                            "_download_direct_video",
                            side_effect=lambda _url, destination: destination.write_bytes(b"source"),
                        ), \
                        patch.object(
                            engine,
                            "_probe_video",
                            return_value=source_duration,
                        ), \
                        patch.object(
                            engine,
                            "_probe_video_dimensions",
                            return_value=(1080, 1920),
                        ), \
                        patch.object(engine, "_generate_scripts", generate), \
                        patch.object(
                            engine,
                            "_calibrate_generated_myanmar_script",
                            calibration,
                        ):
                    result = engine.process_project(
                        {
                            "id": f"translate-calibration-project-{case_number}",
                            "sourceUrl": "https://example.test/video.mp4",
                            "sourceDuration": source_duration,
                            "targetDurationMinutes": target_minutes,
                            "narrationStartSeconds": narration_start,
                            "narrationDurationSeconds": scenario.get("narration_duration"),
                            "transcript": "တရုတ်ဇာတ်လမ်းအဖြစ်အပျက်များ။",
                            "dialogue": [],
                            "myanmarScript": "",
                            "englishScript": "",
                        },
                        {"myanmarVoice": "my-MM-NilarNeural", "myanmarRatePercent": 0},
                        "translate",
                        lambda *_args: None,
                        Path(directory),
                    )

                self.assertEqual(result["myanmarScript"], calibration.return_value)
                generate.assert_called_once()
                self.assertEqual(
                    generate.call_args.kwargs["source_video"],
                    Path(directory) / "source-video",
                )
                self.assertAlmostEqual(
                    generate.call_args.args[1],
                    expected_narration_window,
                )
                calibration.assert_called_once()
                self.assertAlmostEqual(
                    calibration.call_args.args[5],
                    expected_narration_window,
                )

    def test_gemini_429_uses_bounded_operation_retry_budget(self):
        rate_limits = [
            urllib.error.HTTPError("https://gemini.test", 429, "limited", {}, None)
            for _ in range(engine.GEMINI_OPERATION_MAX_ATTEMPTS)
        ]
        response = MagicMock()
        response.__enter__.return_value.read.return_value = json.dumps({
            "candidates": [{"content": {"parts": [{"text": '{"ok": true}'}]}}],
        }).encode()
        with patch.dict("os.environ", {
                "GEMINI_API_KEY": "test-key",
                "GEMINI_BASE_URL": "https://gemini.test/v1beta",
            }, clear=True), \
                patch.object(
                    engine.urllib.request,
                    "urlopen",
                    side_effect=rate_limits + [response],
                ) as urlopen, \
                patch.object(engine, "_gemini_catalog_models", return_value=[]), \
                patch.object(engine.time, "sleep") as sleep, \
                patch.object(engine.random, "uniform", return_value=0):
            content = engine._gemini_generate("system", "prompt", "Translation")

        self.assertEqual([call.args[0] for call in sleep.call_args_list], [1, 2])
        requested_urls = [call.args[0].full_url for call in urlopen.call_args_list]
        self.assertEqual(content, '{"ok": true}')
        self.assertEqual(len(requested_urls), engine.GEMINI_OPERATION_MAX_ATTEMPTS + 1)
        self.assertTrue(all("gemini-3-flash-preview" in url for url in requested_urls[:3]))
        self.assertIn("gemini-2.5-flash", requested_urls[3])

    def test_gemini_uses_secondary_key_after_primary_provider_failure(self):
        primary_failure = urllib.error.HTTPError(
            "https://gemini.test", 401, "primary rejected", {}, None
        )
        response = MagicMock()
        response.__enter__.return_value.read.return_value = json.dumps({
            "candidates": [{"content": {"parts": [{"text": '{"ok": true}'}]}}],
        }).encode()
        with patch.dict("os.environ", {
                "GEMINI_API_KEY": "primary-key",
                "GEMINI_API_KEY2": "secondary-key",
                "GEMINI_BASE_URL": "https://gemini.test/v1beta",
            }, clear=True), \
                patch.object(engine, "_gemini_catalog_models", return_value=[]), \
                patch.object(
                    engine.urllib.request,
                    "urlopen",
                    side_effect=[primary_failure, response],
                ) as urlopen:
            content = engine._gemini_generate("system", "prompt", "Translation")

        self.assertEqual(content, '{"ok": true}')
        requested_urls = [call.args[0].full_url for call in urlopen.call_args_list]
        self.assertIn("primary-key", requested_urls[0])
        self.assertIn("secondary-key", requested_urls[1])

    def test_gemini_catalog_outage_keeps_static_fallback_queue(self):
        first_failure = urllib.error.HTTPError(
            "https://gemini.test", 404, "model not found", {}, None
        )
        response = MagicMock()
        response.__enter__.return_value.read.return_value = json.dumps({
            "candidates": [{"content": {"parts": [{"text": '{"ok": true}'}]}}],
        }).encode()
        with patch.dict("os.environ", {
                "GEMINI_API_KEY": "test-key",
                "GEMINI_BASE_URL": "https://gemini.test/v1beta",
            }, clear=True), \
                patch.object(engine, "_gemini_catalog_models", return_value=[]), \
                patch.object(
                    engine.urllib.request,
                    "urlopen",
                    side_effect=[first_failure, response],
                ) as urlopen:
            content = engine._gemini_generate("system", "prompt", "Translation")

        self.assertEqual(content, '{"ok": true}')
        requested_urls = [call.args[0].full_url for call in urlopen.call_args_list]
        self.assertIn("gemini-3-flash-preview", requested_urls[0])
        self.assertIn("gemini-2.5-flash", requested_urls[1])

    def test_gemini_catalog_prefers_current_lite_model_when_older_ids_are_retired(self):
        with patch.dict(
            "os.environ",
            {
                "GEMINI_API_KEY": "test-key",
                "GEMINI_BASE_URL": engine.GEMINI_OFFICIAL_BASE_URL,
            },
            clear=True,
        ), patch.object(
            engine,
            "_gemini_catalog_models",
            return_value=["gemini-2.5-flash", "gemini-3.5-flash-lite"],
        ), patch.object(
            engine,
            "_gemini_sdk_generate",
            return_value='{"ok": true}',
        ) as generate:
            result = engine._gemini_generate("system", "prompt", "Translation")

        self.assertEqual(result, '{"ok": true}')
        self.assertEqual(generate.call_args.args[1], "gemini-2.5-flash")

    def test_gemini_catalog_does_not_append_static_models_it_does_not_list(self):
        unavailable = urllib.error.HTTPError(
            "https://gemini.test", 404, "model not found", {}, None
        )
        with patch.dict(
            "os.environ",
            {
                "GEMINI_API_KEY": "test-key",
                "GEMINI_BASE_URL": engine.GEMINI_OFFICIAL_BASE_URL,
            },
            clear=True,
        ), patch.object(
            engine,
            "_gemini_catalog_models",
            return_value=["gemini-discovered-flash"],
        ), patch.object(
            engine,
            "_gemini_sdk_generate",
            side_effect=unavailable,
        ) as generate:
            with self.assertRaises(engine.EngineError):
                engine._gemini_generate("system", "prompt", "Translation")

        self.assertEqual(
            [call.args[1] for call in generate.call_args_list],
            ["gemini-discovered-flash"],
        )

    def test_gemini_caches_model_404_per_key_for_later_operations(self):
        unavailable = urllib.error.HTTPError(
            "https://gemini.test", 404, "model not found", {}, None
        )
        with patch.dict(
            "os.environ",
            {
                "GEMINI_API_KEY": "test-key",
                "GEMINI_BASE_URL": engine.GEMINI_OFFICIAL_BASE_URL,
            },
            clear=True,
        ), patch.object(
            engine,
            "_gemini_catalog_models",
            return_value=["gemini-2.5-flash", "gemini-flash-lite-latest"],
        ), patch.object(
            engine,
            "_gemini_sdk_generate",
            side_effect=[
                unavailable,
                '{"ok": true}',
                '{"ok": true}',
                '{"ok": true}',
            ],
        ) as generate:
            first = engine._gemini_generate("system", "prompt", "Translation")
            second = engine._gemini_generate("system", "prompt", "Timing revision")
            with patch.dict("os.environ", {"GEMINI_API_KEY": "other-key"}):
                other_key = engine._gemini_generate("system", "prompt", "Translation")

        self.assertEqual(first, '{"ok": true}')
        self.assertEqual(second, '{"ok": true}')
        self.assertEqual(other_key, '{"ok": true}')
        self.assertEqual(
            [call.args[1] for call in generate.call_args_list],
            [
                "gemini-2.5-flash",
                "gemini-flash-lite-latest",
                "gemini-flash-lite-latest",
                "gemini-2.5-flash",
            ],
        )

    def test_thumbnail_uses_selected_source_frame(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source.mp4"
            destination = root / "thumbnail.jpg"
            source.write_bytes(b"source")

            def fake_run(command, *_args, **_kwargs):
                _write_test_thumbnail(Path(command[-1]))

            with patch.object(engine, "_run", side_effect=fake_run) as run, \
                    patch.object(
                        engine,
                        "_select_thumbnail_frame",
                        return_value={
                            "timestamp": 1.25,
                            "score": 0.8,
                            "candidateCount": 9,
                            "strategy": "visual-quality-score",
                        },
                    ), \
                    patch.object(engine.subprocess, "run", return_value=MagicMock(returncode=0)):
                engine._extract_thumbnail(
                    source,
                    2.0,
                    destination,
                    frame_width=720,
                    frame_height=1280,
                )
                self.assertTrue(destination.is_file())

        command = run.call_args.args[0]
        self.assertEqual(command[command.index("-ss") + 1], "1.250")
        self.assertEqual(command[command.index("-q:v") + 1], "2")

    def test_thumbnail_selection_prefers_highest_scored_real_candidate(self):
        candidate_scores = [0.22, 0.31, 0.44, 0.28, 0.36, 0.91, 0.40, 0.33, 0.27]
        responses = [
            MagicMock(returncode=0, stdout=b"jpeg")
            for _ in candidate_scores
        ]
        with patch.object(engine.subprocess, "run", side_effect=responses), \
                patch.object(
                    engine,
                    "_thumbnail_frame_score",
                    side_effect=candidate_scores,
                ):
            result = engine._select_thumbnail_frame(Path("source.mp4"), 90.0)

        self.assertEqual(result["candidateCount"], len(candidate_scores))
        self.assertEqual(result["timestamp"], 54.0)
        self.assertEqual(result["strategy"], "visual-quality-score")

    def test_post_metadata_fallback_uses_known_story_data(self):
        result = engine._fallback_post_metadata(
            "မင်းသားက အမှန်တရားကို ရှာဖွေပြီး မင်းသမီးကို ကယ်တင်ခဲ့သည်။",
            "The Hidden Promise",
        )

        self.assertEqual(result["source"], "known-story-fallback")
        self.assertEqual(result["hookTitle"], "The Hidden Promise")
        self.assertEqual(len(result["hashtags"]), 5)
        self.assertEqual(len(set(result["hashtags"])), 5)
        self.assertTrue(all(tag.startswith("#") for tag in result["hashtags"]))
        self.assertIn("#TheHiddenPromise", result["hashtags"])

    def test_post_metadata_fallback_uses_script_when_title_is_generic(self):
        result = engine._fallback_post_metadata(
            "လျှို့ဝှက်ချက်ကို ဖော်ထုတ်လိုက်သောအခါ အရာအားလုံး ပြောင်းလဲသွားသည်။",
            "Untitled project",
        )

        self.assertEqual(
            result["hookTitle"],
            "လျှို့ဝှက်ချက်ကို ဖော်ထုတ်လိုက်သောအခါ အရာအားလုံး ပြောင်းလဲသွားသည်။",
        )
        self.assertEqual(len(result["hashtags"]), 5)
        self.assertEqual(len(set(result["hashtags"])), 5)

    def test_gemini_uses_discovered_supported_flash_after_known_models_fail(self):
        response = MagicMock()
        response.__enter__.return_value.read.return_value = json.dumps({
            "candidates": [{"content": {"parts": [{"text": '{"ok": true}'}]}}],
        }).encode()
        with patch.dict("os.environ", {
                "GEMINI_API_KEY": "test-key",
                "GEMINI_BASE_URL": "https://gemini.test/v1beta",
            }, clear=True), \
                patch.object(engine.urllib.request, "urlopen", return_value=response) as urlopen, \
                patch.object(
                    engine,
                    "_gemini_catalog_models",
                    return_value=["gemini-discovered-flash"],
                ):
            content = engine._gemini_generate("system", "prompt", "Translation")

        self.assertEqual(content, '{"ok": true}')
        self.assertIn("gemini-discovered-flash", urlopen.call_args.args[0].full_url)

    def test_dialogue_rate_limit_uses_validated_line_preserving_fallback(self):
        dialogue = [
            {
                "id": "line_001",
                "speaker": "A",
                "start": 1.25,
                "end": 3.5,
                "sourceText": "你好。",
            }
        ]

        class FakeTranslator:
            def __init__(self, source, target):
                self.target = target

            def translate(self, text):
                return "မင်္ဂလာပါ။" if self.target == "my-MM" else "Hello."

        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.dict(
                    "sys.modules",
                    {"deep_translator": SimpleNamespace(MyMemoryTranslator=FakeTranslator)},
                ), \
                patch.object(
                    engine,
                    "_gemini_generate",
                    side_effect=engine.GeminiRateLimitError("Chinese dialogue translation"),
                ):
            translated = engine._generate_dialogue(dialogue)

        self.assertEqual(translated[0]["sourceText"], "你好。")
        self.assertEqual(translated[0]["speaker"], "A")
        self.assertEqual(translated[0]["start"], 1.25)
        self.assertEqual(translated[0]["end"], 3.5)
        self.assertEqual(translated[0]["myanmarText"], "မင်္ဂလာပါ။")
        self.assertEqual(translated[0]["englishText"], "Hello.")
        self.assertTrue(translated[0]["translationFallback"])

    def test_dialogue_translation_preserves_line_order_and_speakers(self):
        dialogue = [
            {"speaker": "A", "start": 0, "end": 1, "sourceText": "你好。"},
            {"speaker": "B", "start": 1, "end": 2, "sourceText": "再见。"},
        ]
        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_gemini_generate", return_value=json.dumps({
                    "lines": [
                        {"lineNumber": 1, "speaker": "A", "myanmarText": "မင်္ဂလာပါ။", "englishText": "Hello."},
                        {"lineNumber": 2, "speaker": "B", "myanmarText": "သွားတော့မယ်။", "englishText": "Goodbye."},
                    ],
                }, ensure_ascii=False)):
            translated = engine._generate_dialogue(dialogue)
        self.assertEqual([line["speaker"] for line in translated], ["A", "B"])
        self.assertEqual([line["englishText"] for line in translated], ["Hello.", "Goodbye."])
        self.assertEqual([line["sourceText"] for line in translated], ["你好。", "再见。"])

    def test_dialogue_translation_requests_third_person_recap_narration(self):
        dialogue = [{"speaker": "A", "start": 0, "end": 1, "sourceText": "她转身离开。"}]
        captured: dict[str, str] = {}

        def translate(system, _prompt, _operation):
            captured["system"] = system
            return json.dumps({
                "lines": [{
                    "lineNumber": 1,
                    "speaker": "A",
                    "myanmarText": "သူမက နောက်လှည့်ပြီး ထွက်ခွာသွားပါတယ်။",
                    "englishText": "She turns around and walks away.",
                }],
            }, ensure_ascii=False)

        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_gemini_generate", side_effect=translate):
            engine._generate_dialogue(dialogue)

        self.assertIn("third-person storytelling narration", captured["system"])
        self.assertIn("not a literal word-for-word translation", captured["system"])
        self.assertIn("sounds good when read aloud", captured["system"])

    def test_malformed_structured_dialogue_fails_without_per_line_api_fallback(self):
        dialogue = [
            {"speaker": "A", "start": 0, "end": 1, "sourceText": "你好。"},
            {"speaker": "B", "start": 1, "end": 2, "sourceText": "再见。"},
        ]
        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(
                    engine,
                    "_gemini_generate",
                    return_value="{not valid structured JSON",
                ) as generate:
            with self.assertRaisesRegex(engine.EngineError, "translation failed"):
                engine._generate_dialogue(dialogue)
        self.assertEqual(generate.call_count, 1)

    def test_dialogue_translation_uses_ordered_json_batches_of_at_most_fifteen(self):
        dialogue = [
            {
                "speaker": f"S{index}",
                "start": float(index),
                "end": float(index + 1),
                "sourceText": f"中文台词{index}",
            }
            for index in range(31)
        ]
        batch_sizes = []

        def translate_batch(_system, prompt, _operation):
            payload_text = prompt.split("<dialogue>\n", 1)[1].split("\n</dialogue>", 1)[0]
            source = json.loads(payload_text)["lines"]
            batch_sizes.append(len(source))
            return json.dumps({
                "lines": [
                    {
                        "lineNumber": item["lineNumber"],
                        "speaker": item["speaker"],
                        "myanmarText": f"မြန်မာစာ {item['lineNumber']}။",
                        "englishText": f"English {item['lineNumber']}.",
                    }
                    for item in source
                ]
            }, ensure_ascii=False)

        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_gemini_generate", side_effect=translate_batch) as generate:
            translated = engine._generate_dialogue(dialogue)

        self.assertEqual(batch_sizes, [15, 15, 1])
        self.assertEqual(generate.call_count, 3)
        self.assertEqual(
            [line["englishText"] for line in translated],
            [f"English {index}." for index in range(1, 32)],
        )

    def test_dialogue_translation_rejects_wrong_batch_count_and_order(self):
        dialogue = [
            {"speaker": "A", "start": 0, "end": 1, "sourceText": "你好。"},
            {"speaker": "B", "start": 1, "end": 2, "sourceText": "再见。"},
        ]
        wrong_count = json.dumps({"lines": [
            {"lineNumber": 1, "speaker": "A", "myanmarText": "မင်္ဂလာပါ။", "englishText": "Hello."},
        ]}, ensure_ascii=False)
        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_gemini_generate", return_value=wrong_count):
            with self.assertRaisesRegex(engine.EngineError, "number of dialogue lines"):
                engine._generate_dialogue(dialogue)

        wrong_order = json.dumps({"lines": [
            {"lineNumber": 2, "speaker": "A", "myanmarText": "မင်္ဂလာပါ။", "englishText": "Hello."},
            {"lineNumber": 1, "speaker": "B", "myanmarText": "သွားတော့မယ်။", "englishText": "Goodbye."},
        ]}, ensure_ascii=False)
        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_gemini_generate", return_value=wrong_order):
            with self.assertRaisesRegex(engine.EngineError, "line order"):
                engine._generate_dialogue(dialogue)

    def test_missing_dialogue_provider_fails_without_dummy_translation(self):
        dialogue = [
            {"speaker": "A", "start": 0, "end": 1, "sourceText": "你好，这是视频文件“episode-01”。"},
            {"speaker": "B", "start": 1, "end": 2, "sourceText": "你好，我们会保留角色之间的对话顺序。"},
        ]
        with patch.dict("os.environ", {}, clear=True):
            with self.assertRaisesRegex(engine.EngineError, "GEMINI_API_KEY"):
                engine._generate_dialogue(dialogue)

    def test_provider_dialogue_failure_does_not_create_dummy_lines(self):
        dialogue = [
            {"speaker": "A", "start": 0, "end": 1, "sourceText": "你好，发生什么事了？"},
        ]
        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_gemini_generate", side_effect=RuntimeError("provider unavailable")):
            with self.assertRaisesRegex(engine.EngineError, "translation failed"):
                engine._generate_dialogue(dialogue)

    def test_full_pipeline_reaches_export_with_continuous_narrator(self):
        dialogue = [
            {"speaker": "A", "start": 0, "end": 1, "sourceText": "你好。"},
        ]
        progress = []

        def download(_url, destination):
            destination.write_bytes(b"source fixture")

        def narration(
            script,
            language,
            voice,
            workdir,
            rate_percent=0,
            target_duration=None,
            **_kwargs,
        ):
            narration.calls.append((script, language, voice, rate_percent))
            audio = workdir / f"{language}.mp3"
            srt = workdir / f"{language}.srt"
            audio.write_bytes(b"audio fixture")
            srt.write_text("1\n00:00:00,000 --> 00:00:01,000\nမင်္ဂလာပါ။\n")
            return audio, srt, 1.0
        narration.calls = []

        def render(source, audio, srt, output, *args):
            output.write_bytes(b"final video fixture")

        validation = Mock(side_effect=[engine.EngineError("subtitle too small"), None, None])
        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_download_direct_video", side_effect=download), \
                 patch.object(engine, "_probe_video", return_value=10.0), \
                 patch.object(engine, "_probe_video_dimensions", return_value=(1080, 1920)), \
                 patch.object(
                     engine,
                     "_extract_transcription_audio",
                     side_effect=lambda _source, destination: destination.write_bytes(b"wav fixture") or destination,
                 ), \
                 patch.object(engine, "_audio_duration", return_value=2.0), \
                patch.object(engine, "_transcribe_with_dialogue", return_value=("你好。", dialogue)), \
                 patch.object(
                     engine,
                     "_generate_scripts",
                     return_value=("အဲဒီအချိန်မှာ ကလေးကို ကယ်တင်ဖို့ အကူအညီတောင်းပြီး အနားမှာရှိသူက ချက်ချင်း ကူညီပေးခဲ့ပါတယ်။", "At that moment, someone called for help and the nearby person quickly rescued the child."),
                   ) as generate_scripts, \
                 patch.object(
                     engine,
                     "_calibrate_generated_myanmar_script",
                     side_effect=lambda script, *_args, **_kwargs: script,
                  ) as calibrate, \
                patch.object(engine, "_source_has_audio", return_value=False), \
                 patch.object(engine, "_make_narration", side_effect=narration), \
                patch.object(
                    engine,
                    "_find_myanmar_font",
                    return_value=Path(engine.__file__).resolve().parent
                    / "fonts"
                    / engine.MYANMAR_FONT_FILENAME,
                ), \
                patch.object(engine, "_render_video", side_effect=render), \
                patch.object(
                    engine,
                    "_burn_subtitles_into_video",
                    side_effect=lambda _clean, _srt, output, *_args, **_kwargs: output.write_bytes(
                        b"final burned fixture"
                    ),
                ), \
                patch.object(engine, "_validate_burned_subtitle_pixels"), \
                patch.object(engine, "_validate_render_output", side_effect=validation), \
                 patch.object(
                     engine,
                     "_extract_thumbnail",
                     side_effect=lambda _video, _duration, destination, **_kwargs: destination.write_bytes(b"thumbnail"),
                 ), \
                patch.object(
                    engine,
                    "_generate_post_metadata",
                    side_effect=engine._fallback_post_metadata,
                ), \
                patch.object(
                    engine,
                    "_upload_exports",
                    return_value=([{"language": "myanmar"}], "studio/test"),
                ):
            result = engine.process_project(
                {
                    "id": "fixture-project",
                    "sourceUrl": "https://example.test/video.mp4",
                    "transcript": "",
                    "dialogue": [],
                    "myanmarScript": "",
                    "englishScript": "",
                    "globalEdit": "none",
                    "blurBoxes": [],
                    "subtitleBox": None,
                },
                {
                    "myanmarVoice": "my-MM-NilarNeural",
                    "myanmarRate": 10,
                    "englishVoice": "en-US-JennyNeural",
                },
                "full",
                lambda stage, value, patch: progress.append((stage, value, patch)),
                Path(directory),
            )

            self.assertEqual(
                [
                    (line["sourceText"], line["start"], line["end"])
                    for line in result["dialogue"]
                ],
                [
                    (line["sourceText"], line["start"], line["end"])
                    for line in dialogue
                ],
            )
        self.assertEqual(
            narration.calls,
             [("အဲဒီအချိန်မှာ ကလေးကို ကယ်တင်ဖို့ အကူအညီတောင်းပြီး အနားမှာရှိသူက ချက်ချင်း ကူညီပေးခဲ့ပါတယ်။", "myanmar", "my-MM-NilarNeural", 10)],
        )
        self.assertAlmostEqual(generate_scripts.call_args.args[1], 8.0)
        self.assertAlmostEqual(calibrate.call_args.args[5], 8.0)
        self.assertIn(
            ("Continuous recap narration ready", 58),
            [(stage, value) for stage, value, _ in progress],
        )
        self.assertEqual(validation.call_count, 3)
        self.assertIn(
            "အလိုအလျောက်ပြုပြင်နေသည် (2/3)",
            [stage for stage, _, _ in progress],
        )
        self.assertEqual(progress[-1][1], 100)
        self.assertEqual(len(result["exports"]), 1)

    def test_english_export_only_renders_english_and_keeps_myanmar_export(self):
        dialogue = [{
            "speaker": "A",
            "start": 0,
            "end": 1,
            "sourceText": "你好。",
            "myanmarText": "မင်္ဂလာပါ။",
            "englishText": "Hello.",
        }]
        narration_languages = []

        def download(_url, destination):
            destination.write_bytes(b"source fixture")

        def narration(
            script,
            language,
            voice,
            workdir,
            rate_percent=0,
            target_duration=None,
            **_kwargs,
        ):
            narration_languages.append(language)
            audio = workdir / f"{language}.mp3"
            srt = workdir / f"{language}.srt"
            audio.write_bytes(b"audio fixture")
            srt.write_text("1\n00:00:00,000 --> 00:00:01,000\nHello.\n")
            (workdir / f"{language}-tts-status.json").write_text(
                json.dumps({
                    "providers": ["gtts"],
                    "fallbackUsed": True,
                    "status": "fallback",
                    "fallbackReason": "alternate_speech_provider",
                }),
                encoding="utf-8",
            )
            return audio, srt, 1.0

        def render(source, audio, srt, output, *args):
            output.write_bytes(b"final video fixture")

        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {"GEMINI_API_KEY": "", "GEMINI_API_KEY2": ""}), \
                patch.object(engine, "_download_direct_video", side_effect=download), \
                patch.object(engine, "_probe_video", return_value=2.0), \
                 patch.object(engine, "_probe_video_dimensions", return_value=(1080, 1920)), \
                patch.object(engine, "_source_has_audio", return_value=False), \
                 patch.object(engine, "_make_narration", side_effect=narration), \
                patch.object(
                    engine,
                    "_find_myanmar_font",
                    return_value=Path(engine.__file__).resolve().parent
                    / "fonts"
                    / engine.MYANMAR_FONT_FILENAME,
                ), \
                patch.object(engine, "_render_video", side_effect=render), \
                patch.object(
                    engine,
                    "_burn_subtitles_into_video",
                    side_effect=lambda _clean, _srt, output, *_args, **_kwargs: output.write_bytes(
                        b"final burned fixture"
                    ),
                ), \
                patch.object(engine, "_validate_burned_subtitle_pixels"), \
                patch.object(engine, "_validate_render_output"), \
                 patch.object(
                     engine,
                     "_extract_thumbnail",
                     side_effect=lambda _video, _duration, destination, **_kwargs: destination.write_bytes(b"thumbnail"),
                 ), \
                patch.object(
                    engine,
                    "_upload_exports",
                    return_value=([{"language": "english", "videoUrl": "/english.mp4"}], "studio/new"),
                ):
            result = engine.process_project(
                {
                    "id": "fixture-project",
                    "sourceUrl": "https://example.test/video.mp4",
                    "transcript": "你好。",
                    "dialogue": dialogue,
                     "myanmarScript": "အဲဒီအချိန်မှာ သူတို့နှစ်ယောက် ပြန်တွေ့ခဲ့ကြပါတယ်။",
                     "englishScript": "At that moment, the two of them met again.",
                    "exports": [{"language": "myanmar", "videoUrl": "/myanmar.mp4"}],
                    "objectPrefix": "studio/old",
                    "exportObjectPrefixes": {"myanmar": "studio/old"},
                    "globalEdit": "none",
                    "blurBoxes": [],
                    "subtitleBox": None,
                },
                {"myanmarVoice": "my-MM-NilarNeural", "englishVoice": "en-US-JennyNeural"},
                "export_english",
                lambda *_: None,
                Path(directory),
            )

        self.assertEqual(narration_languages, ["english"])
        self.assertEqual([item["language"] for item in result["exports"]], ["myanmar", "english"])
        self.assertEqual(result["exportObjectPrefixes"], {
            "myanmar": "studio/old",
            "english": "studio/new",
        })
        fallback_status = result["narrationStatus"]["english"]
        self.assertEqual(fallback_status["providers"], ["gtts"])
        self.assertIs(fallback_status["fallbackUsed"], True)
        self.assertEqual(fallback_status["status"], "fallback")
        self.assertEqual(
            result["exportMetadata"]["english"]["narration_status"],
            fallback_status,
        )
        prepared_checkpoint = engine._read_checkpoint(
            engine._checkpoint_directory("fixture-project")
        )["prepared"]["english"]
        self.assertEqual(prepared_checkpoint["narrationStatus"], fallback_status)

    @unittest.skip("The full pipeline now uses the local fallback when Gemini is absent.")
    def test_full_pipeline_stops_before_tts_when_real_translation_is_unavailable(self):
        dialogue = [
            {"speaker": "A", "start": 0, "end": 1, "sourceText": "你好。"},
        ]
        progress = []

        def download(_url, destination):
            destination.write_bytes(b"source fixture")

        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {}, clear=True), \
                patch.object(engine, "_download_direct_video", side_effect=download), \
                patch.object(engine, "_probe_video", return_value=2.0), \
                 patch.object(engine, "_probe_video_dimensions", return_value=(1080, 1920)), \
                 patch.object(
                     engine,
                     "_extract_transcription_audio",
                     side_effect=lambda _source, destination: destination.write_bytes(b"wav fixture") or destination,
                 ), \
                 patch.object(engine, "_audio_duration", return_value=2.0), \
                patch.object(engine, "_transcribe_with_dialogue", return_value=("你好。", dialogue)):
            with self.assertRaisesRegex(engine.EngineError, "GEMINI_API_KEY"):
                engine.process_project(
                    {
                        "id": "fixture-project",
                        "sourceUrl": "https://example.test/video.mp4",
                        "transcript": "",
                        "dialogue": [],
                        "myanmarScript": "",
                        "englishScript": "",
                        "globalEdit": "none",
                        "blurBoxes": [],
                        "subtitleBox": None,
                    },
                    {"myanmarVoice": "my-MM-NilarNeural", "englishVoice": "en-US-JennyNeural"},
                    "full",
                    lambda stage, value, patch: progress.append((stage, value, patch)),
                    Path(directory),
                )
        self.assertEqual(progress[-1][0], "Generating continuous recap narration")
        self.assertEqual(progress[-1][1], 44)

    def test_chunked_transcription_offsets_dialogue_timestamps(self):
        calls = []
        responses = [
            ("第一段。", [{"speaker": "A", "start": 1.25, "end": 2.5, "sourceText": "第一段。"}]),
            ("第二段。", [{"speaker": "B", "start": 2.0, "end": 3.5, "sourceText": "第二段。"}]),
            ("第三段。", [{"speaker": "A", "start": 0.5, "end": 1.0, "sourceText": "第三段。"}]),
        ]

        def transcribe(chunk):
            calls.append(chunk.name)
            return responses[len(calls) - 1]

        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {"GEMINI_API_KEY": "offline-test-key"}), \
                patch.object(engine, "_audio_duration", return_value=125.0), \
                patch.object(engine, "_transcribe_with_dialogue", side_effect=transcribe), \
                patch.object(engine, "_run") as run:
            text, dialogue = engine._transcribe_in_chunks(Path(directory) / "audio.wav", Path(directory))

        self.assertEqual(text, "第一段。 第二段。 第三段。")
        self.assertEqual([line["start"] for line in dialogue], [1.25, 62.0, 120.5])
        self.assertEqual([line["end"] for line in dialogue], [2.5, 63.5, 121.0])
        commands = [call.args[0] for call in run.call_args_list]
        self.assertEqual([command[command.index("-ss") + 1] for command in commands], ["0.000", "60.000", "120.000"])

    def test_proportional_trim_stitches_segments_and_cleans_intermediates(self):
        def ffmpeg(command, *_args, **_kwargs):
            Path(command[-1]).write_bytes(b"media")

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_run", side_effect=ffmpeg) as run:
            root = Path(directory)
            source = root / "source.mp4"
            source.write_bytes(b"source")
            trimmed = engine._trim_source_proportionally(source, 180.0, 60.0, root)
            self.assertTrue(trimmed.is_file())
            self.assertEqual(len(list(root.glob("trim-segment-*.mp4"))), 0)
            self.assertFalse((root / "trim-segments.txt").exists())
            self.assertEqual(run.call_count, 4)
            self.assertIn("-f", run.call_args_list[-1].args[0])
            self.assertIn("concat", run.call_args_list[-1].args[0])

    def test_narration_window_prompt_treats_duration_as_a_maximum(self):
        generated = json.dumps({
            "storyBeats": [{
                "role": "resolution",
                "sourceEventIds": [],
                "visualTimestampsSeconds": [],
                "myanmarNarration": "က " * 1200,
                "englishNarration": "This is the real English recap.",
            }],
            "omittedSourceEvents": [],
        })
        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}, clear=True), \
                patch.object(engine, "_gemini_generate", return_value=generated) as generate:
            engine._generate_scripts("这是一个中文故事。", target_duration=300)

        self.assertIn("available narration window is up to 300.000 seconds", generate.call_args.args[0])
        self.assertIn("a maximum, not an exact duration target", generate.call_args.args[0])
        self.assertNotIn("The uploaded video is exactly", generate.call_args.args[0])
        self.assertIn("approximately 1200 Burmese syllable/word units", generate.call_args.args[0])
        self.assertIn("between 1140 and 1260 Burmese syllable/word units", generate.call_args.args[0])
        self.assertIn("660 English spoken words", generate.call_args.args[0])
        self.assertIn("Edge-TTS +15%", generate.call_args.args[0])

    def test_restart_requeues_processing_schedule_and_project(self):
        schedule = {
            "id": "schedule-1",
            "projectId": "project-1",
            "status": "processing",
            "scheduledAt": "2026-09-18T00:00:00+00:00",
            "attempts": 1,
        }
        project = {
            "id": "project-1",
            "title": "Fixture",
            "status": "processing",
            "stage": "Rendering",
            "error": "worker stopped",
            "events": [],
        }
        conn = MagicMock()
        with patch.object(main.store, "get", side_effect=[schedule, project]) as get, \
                patch.object(main.store, "records_with_status", return_value=[(schedule, "owner-1")]), \
                patch.object(main.store, "save") as save, \
                patch.object(main.store, "event") as event:
            main.requeue_interrupted_jobs(conn)

        self.assertEqual(get.call_count, 2)
        self.assertEqual(schedule["status"], "scheduled")
        self.assertEqual(schedule["attempts"], 1)
        self.assertEqual(project["status"], "queued")
        self.assertEqual(project["stage"], "Queued after server restart")
        self.assertEqual(project["error"], "")
        event.assert_called_once_with(project, "Queued after server restart")
        self.assertEqual(save.call_count, 2)

    def test_dialogue_validation_rejects_placeholder_text(self):
        with self.assertRaisesRegex(engine.EngineError, "placeholder text"):
            engine._validate_dialogue([{
                "speaker": "A",
                "start": 0,
                "end": 1,
                "sourceText": "你好。",
                "myanmarText": "ဇာတ်ကောင် A ၏ ပြောဆိုချက်ကို တိုက်ရိုက် ဘာသာပြန်ထားပါသည်။",
                "englishText": "Direct dialogue spoken by character A.",
            }])

    def test_selected_narrator_voice_is_used_for_every_speaker(self):
        dialogue = [
            {"speaker": "A"},
            {"speaker": "B"},
            {"speaker": "C"},
        ]
        voices = engine._speaker_voice_map(dialogue, "myanmar", "my-MM-NilarNeural")
        self.assertEqual(voices["A"], "my-MM-NilarNeural")
        self.assertEqual(voices["B"], "my-MM-NilarNeural")
        self.assertEqual(voices["C"], "my-MM-NilarNeural")
        self.assertEqual(set(voices.values()), {"my-MM-NilarNeural"})

    def test_dialogue_srt_contains_speaker_labels(self):
        dialogue = [
            {
                "speaker": "A", "start": 0, "end": 1, "sourceText": "你好。",
                "myanmarText": "မင်္ဂလာပါ။", "englishText": "Hello.",
            },
            {
                "speaker": "B", "start": 1, "end": 2, "sourceText": "再见。",
                "myanmarText": "သွားတော့မယ်။", "englishText": "Goodbye.",
            },
        ]
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_dialogue_parts", new=AsyncMock(
                    return_value=[Path("one.mp3"), Path("two.mp3")]
                )), patch.object(engine, "_audio_duration", side_effect=[1.1, 1.3, 2.4]), \
                patch.object(engine, "_run"):
            _, srt, _ = engine._make_dialogue_narration(
                dialogue, "myanmar", "my-MM-NilarNeural", Path(directory),
            )
            content = srt.read_text(encoding="utf-8")
            self.assertIn("မင်္ဂလာပါ။", content)
            self.assertIn("သွားတော့မယ်။", content)
            self.assertNotIn("[A]", content)
            self.assertNotIn("[B]", content)
            self.assertIn("00:00:00,000 --> 00:00:01,000", content)
            self.assertIn("00:00:01,000 --> 00:00:02,000", content)

    def test_dialogue_timeline_uses_exact_start_time_adelay(self):
        dialogue = [
            {"speaker": "A", "start": 0.375, "end": 1.0, "sourceText": "你好。"},
            {"speaker": "B", "start": 1.625, "end": 2.5, "sourceText": "再见。"},
        ]
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_audio_duration", side_effect=[0.5, 0.7, 2.5]), \
                patch.object(engine, "_run") as run:
            engine._assemble_dialogue_timeline(
                [Path("one.mp3"), Path("two.mp3")],
                dialogue,
                Path(directory) / "timeline.mp3",
                2.5,
            )
        graph = run.call_args.args[0][run.call_args.args[0].index("-filter_complex") + 1]
        self.assertIn("adelay=375:all=1", graph)
        self.assertIn("adelay=1625:all=1", graph)

    def test_dialogue_subtitles_wrap_long_cues_for_phone_readability(self):
        dialogue = [{
            "speaker": "A", "start": 0, "end": 4, "sourceText": "你好。",
            "myanmarText": "ကယ်ကြပါဦး ကလေးတို့ မခုန်ကြနဲ့နော် ကလေးတွေကို ငါ့ဆီ ကမ်းပေးပါ",
            "englishText": "Help the children and bring them down safely.",
        }]
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_dialogue_parts", new=AsyncMock(
                    return_value=[Path("one.mp3")]
                )), patch.object(engine, "_audio_duration", side_effect=[1.1, 4.0]), \
                patch.object(engine, "_run"):
            _, srt, _ = engine._make_dialogue_narration(
                dialogue, "myanmar", "my-MM-ThihaNeural", Path(directory),
            )
            content = srt.read_text(encoding="utf-8")
            blocks = [
                block for block in content.strip().split("\n\n")
                if block.strip()
            ]

        self.assertGreater(len(blocks), 1)
        visible_lines = []
        for block in blocks:
            block_lines = block.splitlines()
            self.assertIn("-->", block_lines[1])
            cue_lines = [line for line in block_lines[2:] if line.strip()]
            self.assertLessEqual(len(cue_lines), engine.MAX_SUBTITLE_LINES)
            visible_lines.extend(cue_lines)
        self.assertEqual(
            [word for line in visible_lines for word in line.split()],
            dialogue[0]["myanmarText"].split(),
        )

    def test_dialogue_subtitles_never_stack_more_than_two_active_cues(self):
        dialogue = [
            {
                "speaker": "A", "start": 0, "end": 4, "sourceText": "一。",
                "myanmarText": "ပထမစာကြောင်း။", "englishText": "First.",
            },
            {
                "speaker": "B", "start": 1, "end": 5, "sourceText": "二。",
                "myanmarText": "ဒုတိယစာကြောင်း။", "englishText": "Second.",
            },
            {
                "speaker": "C", "start": 2, "end": 6, "sourceText": "三。",
                "myanmarText": "တတိယစာကြောင်း။", "englishText": "Third.",
            },
        ]
        with tempfile.TemporaryDirectory() as directory:
            srt = Path(directory) / "myanmar.srt"
            engine._write_dialogue_srt(dialogue, "myanmar", srt)
            content = srt.read_text(encoding="utf-8")

        self.assertIn("00:00:00,000 --> 00:00:04,000", content)
        self.assertIn("00:00:01,000 --> 00:00:05,000", content)
        self.assertIn("00:00:04,000 --> 00:00:06,000", content)
        self.assertNotIn("00:00:02,000 --> 00:00:06,000", content)

    def test_all_tts_fallbacks_fail_explicitly(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_edge_tts_part", new=AsyncMock(return_value=False)), \
                patch.object(engine, "_gtts_part", new=AsyncMock(return_value=False)), \
                patch.object(engine, "_write_emergency_audio") as emergency_audio:
            with self.assertRaisesRegex(
                engine.EngineError,
                "local emergency timing audio is not publishable narration",
            ):
                asyncio.run(
                    engine._synthesize_parts(
                        ["Hello."], "en-US-JennyNeural", Path(directory)
                    )
                )
            emergency_audio.assert_not_called()

    def test_valid_gtts_fallback_is_reported_as_degraded_speech(self):
        async def valid_gtts(_sentence, destination, _language):
            destination.write_bytes(b"valid-gtts-audio")
            return True

        providers: list[str] = []
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_edge_tts_part", new=AsyncMock(return_value=False)), \
                patch.object(engine, "_gtts_part", side_effect=valid_gtts), \
                patch.object(engine, "_audio_duration", return_value=2.0):
            parts = asyncio.run(
                engine._synthesize_parts(
                    ["This is a complete sentence."],
                    "en-US-JennyNeural",
                    Path(directory),
                    providers_out=providers,
                )
            )

        self.assertEqual(len(parts), 1)
        self.assertEqual(providers, ["gtts"])
        self.assertEqual(
            engine._build_narration_status(providers),
            {
                "providers": ["gtts"],
                "fallbackUsed": True,
                "status": "fallback",
                "fallbackReason": "alternate_speech_provider",
            },
        )

    def test_tts_validation_rejects_silence_and_near_silence(self):
        levels = [(-float("inf"), -float("inf")), (-65.0, -55.0)]
        with tempfile.TemporaryDirectory() as directory:
            audio = Path(directory) / "provider-output.mp3"
            audio.write_bytes(b"nonempty provider output")
            for mean_db, peak_db in levels:
                with self.subTest(mean_db=mean_db, peak_db=peak_db), \
                        patch.object(engine, "_audio_duration", return_value=2.0), \
                        patch.object(
                            engine,
                            "_audio_loudness_db",
                            return_value=(mean_db, peak_db),
                        ):
                    with self.assertRaisesRegex(engine.EngineError, "silent or too quiet"):
                        engine._validate_tts_audio_duration(
                            "This is a complete sentence.",
                            audio,
                            "english",
                        )

    def test_loudness_probe_parses_silence_as_negative_infinity(self):
        ffmpeg_output = SimpleNamespace(
            returncode=0,
            stderr=(
                "[Parsed_volumedetect] mean_volume: -inf dB\n"
                "[Parsed_volumedetect] max_volume: -inf dB\n"
            ),
        )
        with patch.object(
            engine,
            "_audio_loudness_db",
            side_effect=self._original_audio_loudness_db,
        ), patch.object(engine.shutil, "which", return_value="/usr/bin/ffmpeg"), \
                patch.object(engine.subprocess, "run", return_value=ffmpeg_output):
            levels = engine._audio_loudness_db(Path("silent.mp3"))

        self.assertEqual(levels, (-float("inf"), -float("inf")))

    def test_empty_or_severely_short_gtts_output_fails_closed(self):
        for audio_bytes, measured_duration in ((b"", 0.05), (b"truncated", 0.05)):
            with self.subTest(audio_bytes=audio_bytes), \
                    tempfile.TemporaryDirectory() as directory, \
                    patch.object(engine, "_edge_tts_part", new=AsyncMock(return_value=False)), \
                    patch.object(engine, "_audio_duration", return_value=measured_duration), \
                    patch.object(engine, "_write_emergency_audio") as emergency_audio:
                async def invalid_gtts(_sentence, destination, _language):
                    destination.write_bytes(audio_bytes)
                    return True

                with patch.object(engine, "_gtts_part", side_effect=invalid_gtts):
                    with self.assertRaisesRegex(
                        engine.EngineError,
                        "returned unusable english narration audio",
                    ):
                        asyncio.run(
                            engine._synthesize_parts(
                                ["This is a complete sentence."],
                                "en-US-JennyNeural",
                                Path(directory),
                            )
                        )
                emergency_audio.assert_not_called()
                self.assertFalse((Path(directory) / "part-0000.mp3").exists())

    def test_edge_tts_batch_success_persists_measured_boundaries_and_provider(self):
        boundaries = [
            {"text": "A", "offset": 0.0, "duration": 0.3},
            {"text": "complete", "offset": 0.35, "duration": 0.6},
            {"text": "sentence.", "offset": 1.0, "duration": 0.7},
        ]

        async def synthesize(_text, destination, *_args, **_kwargs):
            destination.write_bytes(b"edge-tts-batch-audio")
            return boundaries

        providers: list[str] = []
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_edge_tts_batch", side_effect=synthesize), \
                patch.object(engine, "_audio_duration", return_value=2.0), \
                patch.object(
                    engine,
                    "_batch_clause_windows",
                    return_value=[(0.0, 2.0)],
                ), \
                patch.object(engine, "_slice_narration_block"):
            parts = asyncio.run(
                engine._synthesize_parts(
                    ["A complete sentence."],
                    "en-US-JennyNeural",
                    Path(directory),
                    batch=True,
                    language="english",
                    providers_out=providers,
                )
            )
            cached_metadata = json.loads(
                (Path(directory) / "cache" / "audio_part_00.json").read_text(
                    encoding="utf-8"
                )
            )
        self.assertEqual(len(parts), 1)
        self.assertEqual(providers, ["edge_tts_batch"])
        self.assertEqual(cached_metadata["provider"], "edge_tts_batch")
        self.assertEqual(cached_metadata["boundaries"], boundaries)

    def test_all_dialogue_tts_fallbacks_fail_explicitly(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_edge_tts_part", new=AsyncMock(return_value=False)), \
                patch.object(engine, "_gtts_part", new=AsyncMock(return_value=False)), \
                patch.object(engine, "_write_emergency_audio", side_effect=engine.EngineError("offline failed")), \
                self.assertRaisesRegex(engine.EngineError, "Edge-TTS Burmese narration failed"):
            asyncio.run(
                engine._synthesize_dialogue_parts(
                    [("မင်္ဂလာပါ။", "my-MM-NilarNeural")],
                    Path(directory),
                    "myanmar",
                )
            )

    def test_edge_tts_writes_audio(self):
        async def save_audio(filename):
            Path(filename).write_bytes(b"mock-mp3")

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine.edge_tts, "Communicate") as communicate, \
                patch.object(engine, "_normalize_audio_mp3"), \
                patch.object(engine, "_audio_duration", return_value=1.0):
            communicate.return_value.save = save_audio
            destination = Path(directory) / "speech.mp3"
            parts = asyncio.run(
                engine._synthesize_parts(
                    ["မင်္ဂလာပါ။"], "my-MM-NilarNeural", Path(directory)
                )
            )
            self.assertEqual(parts, [Path(directory) / "part-0000.mp3"])
            self.assertTrue(parts[0].is_file())

    def test_edge_tts_retries_timed_out_chunk_with_ten_second_deadline(self):
        attempts = []

        class Communicate:
            def __init__(self, *args, **kwargs):
                attempts.append((args, kwargs))

            async def save(self, filename):
                if len(attempts) < 3:
                    await asyncio.sleep(0.02)
                    raise asyncio.TimeoutError()
                Path(filename).write_bytes(b"retry-mp3")

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine.edge_tts, "Communicate", Communicate), \
                patch.object(engine, "TTS_REQUEST_TIMEOUT_SECONDS", 0.01), \
                patch.object(engine, "_normalize_audio_mp3"), \
                patch.object(engine, "_audio_duration", return_value=1.0), \
                patch.object(engine, "TTS_MAX_RETRIES", 3), \
                patch.object(engine, "TTS_RETRY_DELAY_SECONDS", 0):
            destination = Path(directory) / "speech.mp3"
            result = asyncio.run(engine._edge_tts_part(
                "Hello.", destination, "en-US-JennyNeural", "english"
            ))

        self.assertTrue(result)
        self.assertEqual(len(attempts), 3)
        self.assertEqual(
            attempts[0][1]["connect_timeout"],
            0.01,
        )

    def test_edge_tts_batch_uses_three_total_attempts(self):
        attempts = []

        class Communicate:
            def __init__(self, *args, **kwargs):
                attempts.append((args, kwargs))

            def stream(self):
                async def chunks():
                    if len(attempts) < 3:
                        raise asyncio.TimeoutError()
                    yield {"type": "audio", "data": b"batch-mp3"}
                    yield {
                        "type": "WordBoundary",
                        "offset": 0,
                        "duration": 10_000_000,
                        "text": "Hello",
                    }
                return chunks()

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine.edge_tts, "Communicate", Communicate), \
                patch.object(engine, "TTS_BATCH_TIMEOUT_SECONDS", 0.01), \
                patch.object(engine, "TTS_BATCH_MAX_RETRIES", 2), \
                patch.object(engine, "TTS_NORMALIZATION_TIMEOUT_SECONDS", 1), \
                patch.object(engine, "_normalize_audio_mp3"), \
                patch.object(engine, "_audio_duration", return_value=1.0):
            destination = Path(directory) / "batch.mp3"
            boundaries = asyncio.run(engine._edge_tts_batch(
                "Hello.", destination, "en-US-JennyNeural", "english"
            ))
            self.assertTrue(destination.is_file())

        self.assertEqual(len(attempts), 3)
        self.assertEqual(boundaries[0]["text"], "Hello")

    def test_edge_tts_batch_logs_raw_invalid_timing_without_provider_call(self):
        class Communicate:
            def __init__(self, *_args, **_kwargs):
                pass

            def stream(self):
                async def chunks():
                    yield {"type": "audio", "data": b"batch-mp3"}
                    yield {
                        "type": "WordBoundary",
                        "offset": 10_000_000,
                        "duration": 0,
                        "text": "Hello",
                    }
                return chunks()

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine.edge_tts, "Communicate", Communicate), \
                patch.object(engine, "_normalize_audio_mp3"), \
                patch.object(engine, "_audio_duration", return_value=1.0):
            destination = Path(directory) / "batch.mp3"
            with self.assertLogs(engine.log, level="WARNING") as captured:
                boundaries = asyncio.run(engine._edge_tts_batch(
                    "Hello.",
                    destination,
                    "en-US-JennyNeural",
                    "english",
                ))
                with self.assertRaisesRegex(
                    engine.EngineError,
                    "invalid word timing",
                ):
                    engine._aligned_provider_word_boundaries(
                        "Hello.",
                        boundaries,
                        1.0,
                    )

        diagnostics = "\n".join(captured.output)
        self.assertIn("event_index=0", diagnostics)
        self.assertIn("text='Hello'", diagnostics)
        self.assertIn("raw_offset=10000000", diagnostics)
        self.assertIn("raw_offset_type=int", diagnostics)
        self.assertIn("raw_duration=0", diagnostics)
        self.assertIn("raw_duration_type=int", diagnostics)
        self.assertIn("normalized_duration=0.0", diagnostics)
        self.assertIn("duration_not_positive", diagnostics)

    def test_batch_clause_windows_handles_punctuation_attached_to_previous_phrase(self):
        batch_text = (
            "ဒီဇာတ်လမ်းမှာ လူငယ်တစ်ယောက်က အရေးကြီးတဲ့ "
            "လျှို့ဝှက်ချက်ကို ရှာဖွေတွေ့ရှိခဲ့ပါတယ်။ အဲဒီနောက် "
            "သူ့ရဲ့ဘဝက အလုံးစုံ ပြောင်းလဲသွားပြီး အန္တရာယ်တွေကြားမှာ "
            "ဆုံးဖြတ်ချက်တွေ ချရပါတော့တယ်။ နောက်ဆုံးမှာ သူက "
            "အမှန်တရားကို ဖော်ထုတ်ဖို့ ကြိုးစားခဲ့ပါတယ်။"
        )
        clauses = engine._subtitle_phrases(batch_text, "myanmar")
        boundaries = [
            {"text": "ဒီဇာတ်လမ်းမှာ", "offset": 0.0, "duration": 0.5},
            {"text": "လူငယ်တစ်ယောက်က", "offset": 0.5, "duration": 0.5},
            {"text": "အရေးကြီးတဲ့", "offset": 1.0, "duration": 0.5},
            {"text": "လျှို့ဝှက်ချက်ကို", "offset": 1.5, "duration": 0.5},
            {"text": "ရှာဖွေတွေ့ရှိခဲ့ပါတယ်။", "offset": 2.0, "duration": 0.5},
            {"text": "အဲဒီနောက်", "offset": 2.5, "duration": 0.5},
            {"text": "သူ့ရဲ့ဘဝက", "offset": 3.0, "duration": 0.5},
            {"text": "အလုံးစုံ", "offset": 3.5, "duration": 0.5},
            {"text": "ပြောင်းလဲသွားပြီး", "offset": 4.0, "duration": 0.5},
            {"text": "အန္တရာယ်တွေကြားမှာ", "offset": 4.5, "duration": 0.5},
            {"text": "ဆုံးဖြတ်ချက်တွေ", "offset": 5.0, "duration": 0.5},
            {"text": "ချရပါတော့တယ်။", "offset": 5.5, "duration": 0.5},
            {"text": "နောက်ဆုံးမှာ", "offset": 6.0, "duration": 0.5},
            {"text": "သူက", "offset": 6.5, "duration": 0.5},
            {"text": "အမှန်တရားကို", "offset": 7.0, "duration": 0.5},
            {"text": "ဖော်ထုတ်ဖို့", "offset": 7.5, "duration": 0.5},
            {"text": "ကြိုးစားခဲ့ပါတယ်။", "offset": 8.0, "duration": 0.5},
        ]

        windows = engine._batch_clause_windows(
            clauses,
            boundaries,
            9.0,
            batch_text=batch_text,
        )

        self.assertEqual(len(windows), len(clauses))
        self.assertTrue(all(end > start for start, end in windows))
        self.assertEqual(windows[-1][1], 9.0)

    def test_dialogue_tts_propagates_selected_voice_and_rate(self):
        async def save_audio(filename):
            Path(filename).write_bytes(b"real-provider-shaped-mp3")

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine.edge_tts, "Communicate") as communicate, \
                patch.object(engine, "_normalize_audio_mp3"), \
                patch.object(engine, "_audio_duration", return_value=1.0):
            communicate.return_value.save = save_audio
            asyncio.run(engine._synthesize_dialogue_parts(
                [("မင်္ဂလာပါ။", "my-MM-NilarNeural")],
                Path(directory),
                "myanmar",
                "+35%",
            ))
        communicate.assert_called_once_with(
            "မင်္ဂလာပါ။",
            voice="my-MM-NilarNeural",
            rate="+35%",
            boundary="SentenceBoundary",
            connect_timeout=10,
            receive_timeout=10,
        )

    def test_export_uses_continuous_script_without_timestamped_dialogue(self):
        narration_calls = []

        def narration(
            script,
            language,
            voice,
            workdir,
            rate_percent=0,
            target_duration=None,
            **_kwargs,
        ):
            narration_calls.append((script, language, rate_percent))
            audio = workdir / f"{language}.mp3"
            srt = workdir / f"{language}.srt"
            audio.write_bytes(b"audio fixture")
            srt.write_text("1\n00:00:00,000 --> 00:00:01,000\nမင်္ဂလာပါ။\n", encoding="utf-8")
            return audio, srt, 1.0

        def render(_source, _audio, _srt, output, *args):
            output.write_bytes(b"video fixture")

        with tempfile.TemporaryDirectory() as directory, \
                patch.dict("os.environ", {"GEMINI_API_KEY": "", "GEMINI_API_KEY2": ""}), \
                patch.object(engine, "_download_direct_video", side_effect=lambda _, p: p.write_bytes(b"x")), \
                patch.object(engine, "_probe_video", return_value=1.0), \
                 patch.object(engine, "_probe_video_dimensions", return_value=(1080, 1920)), \
                patch.object(engine, "_source_has_audio", return_value=False), \
                patch.object(engine, "_make_narration", side_effect=narration), \
                patch.object(
                    engine,
                    "_find_myanmar_font",
                    return_value=Path(engine.__file__).resolve().parent
                    / "fonts"
                    / engine.MYANMAR_FONT_FILENAME,
                ), \
                patch.object(engine, "_render_video", side_effect=render), \
                patch.object(
                    engine,
                    "_burn_subtitles_into_video",
                    side_effect=lambda _clean, _srt, output, *_args, **_kwargs: output.write_bytes(
                        b"final burned fixture"
                    ),
                ), \
                patch.object(engine, "_validate_burned_subtitle_pixels"), \
                patch.object(engine, "_validate_render_output"), \
                 patch.object(
                     engine,
                     "_extract_thumbnail",
                     side_effect=lambda _video, _duration, destination, **_kwargs: destination.write_bytes(b"thumbnail"),
                 ), \
                patch.object(engine, "_upload_exports", return_value=([{"language": "myanmar"}], "studio/test")):
            result = engine.process_project(
                {
                    "id": "no-timestamps",
                    "sourceUrl": "https://example.test/video.mp4",
                    "transcript": "你好。",
                    "dialogue": [],
                    "myanmarScript": "မင်္ဂလာပါ။",
                    "englishScript": "Hello.",
                },
                {"myanmarVoice": "my-MM-NilarNeural", "myanmarRate": 10},
                "export",
                lambda *_: None,
                Path(directory),
            )
        self.assertEqual([item["language"] for item in result["exports"]], ["myanmar"])
        self.assertEqual(result["exports"][0]["scriptVersion"], 0)
        self.assertEqual(result["exports"][0]["processingVersion"], 0)
        self.assertEqual(result["exports"][0]["quality"], "1080p")
        self.assertEqual(narration_calls, [("မင်္ဂလာပါ။", "myanmar", 10)])

    def test_narration_subtitle_phrases_stay_within_six_words(self):
        phrases = engine._subtitle_phrases(
            "One two three four five six seven eight nine ten eleven twelve thirteen",
            "english",
        )
        self.assertTrue(all(3 <= len(phrase.split()) <= 6 for phrase in phrases))
        self.assertTrue(all(len(phrase) <= 26 for phrase in phrases))

    def test_myanmar_phrase_splitter_keeps_long_unspaced_text_in_one_timed_phrase(self):
        script = "ဇာတ်လိုက်ဟာလျှို့ဝှက်ချက်တစ်ခုကိုစတင်တွေ့ရှိသွားခဲ့ပါတယ်"

        phrases = engine._subtitle_phrases(script, "myanmar")

        self.assertEqual(phrases, [script])

    def test_myanmar_short_tail_does_not_split_unspaced_compound_across_cues(self):
        compound = "ကျေးဇူးတင်ပါတယ်"
        script = f"{compound}။ က"

        phrases = engine._subtitle_phrases(script, "myanmar")

        self.assertTrue(
            any(compound in phrase for phrase in phrases),
            f"short-tail balancing split {compound!r} across timed cues: {phrases!r}",
        )

    def test_myanmar_short_tail_rebalances_only_at_explicit_whitespace(self):
        compound = "ကျေးဇူး တင်ပါတယ်"
        script = f"က က က ခ {compound}။ က"

        phrases = engine._subtitle_phrases(script, "myanmar")

        self.assertEqual(
            phrases,
            ["က က က ခ", f"{compound}။ က"],
        )

    def test_myanmar_oversized_unspaced_phrase_is_not_split_by_provider_tokens(self):
        script = "အပြန်အလှန်ကျေးဇူးတင်စကားဆိုခဲ့ကြသည်။"

        phrases = engine._subtitle_phrases(
            script,
            "myanmar",
            subtitle_wrap_width=8,
        )

        self.assertEqual(phrases, [script])
        self.assertEqual(len(engine._myanmar_syllables(script)), 18)

    def test_myanmar_phrase_splitter_does_not_emit_punctuation_only_tail(self):
        phrases = engine._subtitle_phrases(
            "ကူညီပါ! အားလုံး ဘေးကင်းကြ၏.",
            "myanmar",
        )
        self.assertTrue(phrases)
        self.assertTrue(all(
            any("\u1000" <= character <= "\u109f" for character in phrase)
            for phrase in phrases
        ))
        self.assertTrue(phrases[-1].endswith("၏."))

    def test_narration_batches_bound_provider_request_size(self):
        clauses = ["a" * 20 for _ in range(40)]
        batches = engine._narration_batches(clauses)
        self.assertGreater(len(batches), 1)
        self.assertTrue(all(len(batch) <= engine.TTS_BATCH_MAX_CLAUSES for batch in batches))
        self.assertTrue(all(
            len(" ".join(batch).encode("utf-8")) <= engine.TTS_BATCH_MAX_BYTES
            for batch in batches
        ))
        self.assertEqual([clause for batch in batches for clause in batch], clauses)

    def test_batched_word_boundaries_map_to_phrase_windows(self):
        windows = engine._batch_clause_windows(
            ["one two", "three four", "five six"],
            [
                {"text": "one", "offset": 0.0, "duration": 0.2},
                {"text": "two", "offset": 0.25, "duration": 0.2},
                {"text": "three", "offset": 0.9, "duration": 0.2},
                {"text": "four", "offset": 1.15, "duration": 0.2},
                {"text": "five", "offset": 1.8, "duration": 0.2},
                {"text": "six", "offset": 2.05, "duration": 0.2},
            ],
            2.5,
        )
        for actual, expected in zip(
            windows,
            [(0.0, 0.9), (0.9, 1.8), (1.8, 2.5)],
        ):
            self.assertAlmostEqual(actual[0], expected[0], places=6)
            self.assertAlmostEqual(actual[1], expected[1], places=6)

    def test_provider_boundaries_cannot_split_myanmar_word_or_orphan_punctuation(self):
        script = "မခုန်ရန်။"
        boundaries = [
            {"text": "မခုန်ရ", "offset": 0.0, "duration": 0.7},
            {"text": "န်", "offset": 0.955, "duration": 0.2},
            {"text": "။", "offset": 1.2, "duration": 0.1},
        ]
        windows = engine._batch_clause_windows(
            [script],
            boundaries,
            1.5,
            batch_text=script,
        )

        cues = engine._myanmar_timed_subtitle_cues(
            [script], windows, boundaries, 1.5, script, 100
        )

        self.assertEqual(len(cues), 1)
        self.assertEqual(cues[0][0], script)
        self.assertFalse(cues[0][0].startswith(("။", "၊", "!", "?", ".")))
        self.assertLessEqual(len(cues[0][0].splitlines()), engine.MAX_SUBTITLE_LINES)
        self.assertAlmostEqual(cues[0][1], 0.0)
        self.assertAlmostEqual(cues[0][2], 1.5)

    def test_myanmar_combining_medial_stack_and_punctuation_text_is_preserved(self):
        samples = [
            "မင်္ဂလာပါ။",
            "ကျွန်မတို့ မကြာခင် ပြန်လာမယ်။",
            "အောင်မြင်မှု၊ ကြိုးစားမှုနှင့် မေတ္တာ။",
            "ဇာတ်ကောင်၏ သတ္တိကြောင့် သူ ပြန်လာခဲ့သည်။",
        ]
        for script in samples:
            boundaries = [
                {"text": script[: max(1, len(script) // 2)], "offset": 0.0, "duration": 0.4},
                {"text": script[max(1, len(script) // 2):], "offset": 0.5, "duration": 0.4},
            ]
            windows = engine._batch_clause_windows(
                [script], boundaries, 1.0, batch_text=script
            )
            cues = engine._myanmar_timed_subtitle_cues(
                [script], windows, boundaries, 1.0, script, 200
            )
            rendered = "".join(text.replace("\n", "") for text, _, _ in cues)
            self.assertEqual(
                re.sub(r"\s+", "", rendered),
                re.sub(r"\s+", "", script),
            )
            self.assertTrue(all(
                len(text.splitlines()) <= engine.MAX_SUBTITLE_LINES
                for text, _, _ in cues
            ))
            self.assertFalse(any(
                text.lstrip().startswith(("။", "၊", "!", "?", "."))
                for text, _, _ in cues
            ))

    def test_myanmar_long_unspaced_multiclause_text_gets_safe_timed_cues(self):
        script = (
            "အရေးပေါ်အန္တရာယ်ကြားမှာပိတ်မိနေတဲ့ကလေးငယ်တွေဟာကြောက်လန့်တကြား"
            "ထွက်ပြေးခဲ့ကြသည်။အဲဒီအချိန်မှာတံခါးပွင့်သွားပြီးသူမရဲ့အစ်ကို"
            "ပြန်ရောက်လာခဲ့တယ်။အားလုံးအံ့အားသင့်သွားကြသည်။"
        )
        boundaries = [
            {"text": script, "offset": 0.0, "duration": 6.0},
        ]
        windows = engine._batch_clause_windows(
            [script], boundaries, 6.0, batch_text=script
        )
        cues = engine._myanmar_timed_subtitle_cues(
            [script], windows, boundaries, 6.0, script, 14
        )

        rendered = "".join(text.replace("\n", "") for text, _, _ in cues)
        self.assertEqual(re.sub(r"\s+", "", rendered), re.sub(r"\s+", "", script))
        self.assertGreater(len(cues), 1)
        self.assertTrue(all(
            len(text.splitlines()) <= engine.MAX_SUBTITLE_LINES
            for text, _, _ in cues
        ))
        self.assertFalse(any(
            text.lstrip().startswith(("။", "၊", "!", "?", ".", ","))
            for text, _, _ in cues
        ))
        self.assertAlmostEqual(cues[0][1], 0.0)
        self.assertAlmostEqual(cues[-1][2], 6.0)
        for previous, current in zip(cues, cues[1:]):
            self.assertLessEqual(previous[1], current[1])
            self.assertLessEqual(previous[2], current[2])
            self.assertGreaterEqual(current[1], previous[2] - 0.01)

    def test_myanmar_sparse_provider_boundaries_time_uncovered_clauses(self):
        clauses = [
            "မင်္ဂလာပါ။",
            "ကျွန်မတို့မကြာခင်ပြန်လာမယ်။",
            "နောက်တစ်နေ့တွင်အားလုံးပြန်ဆုံခဲ့ကြသည်။",
        ]
        batch_text = " ".join(clauses)
        boundaries = [
            {"text": "မင်္ဂလာ", "offset": 0.0, "duration": 0.5},
            {"text": "အားလုံး", "offset": 2.8, "duration": 0.5},
        ]
        windows = engine._batch_clause_windows(
            clauses, boundaries, 4.0, batch_text=batch_text
        )
        cues = engine._myanmar_timed_subtitle_cues(
            clauses, windows, boundaries, 4.0, batch_text, 14
        )

        self.assertEqual(len(windows), len(clauses))
        self.assertEqual(len(cues), 4)
        self.assertEqual(
            re.sub(r"\s+", "", "".join(text for text, _, _ in cues)),
            re.sub(r"\s+", "", batch_text),
        )
        for previous, current in zip(cues, cues[1:]):
            self.assertGreaterEqual(current[1], previous[2] - 0.01)
            self.assertGreater(current[2], current[1])

    def test_myanmar_word_segmentation_preserves_unicode_clusters_and_punctuation(self):
        samples = [
            "မင်္ဂလာပါ။",
            "ကျွန်မတို့ မကြာခင် ပြန်လာမယ်။",
            "အောင်မြင်မှု၊ ကြိုးစားမှုနှင့် မေတ္တာ။",
            "ဇာတ်ကောင်၏ သတ္တိကြောင့် သူ ပြန်လာခဲ့သည်။",
            "မခုန်ရန်",
        ]
        for script in samples:
            spans = engine._myanmar_display_word_spans(script, 0)
            self.assertEqual(
                "".join(span["text"] for span in spans),
                re.sub(r"\s+", "", script),
            )
            safe_offsets = {0}
            offset = 0
            for cluster in engine._myanmar_syllables(script):
                offset += len(cluster)
                safe_offsets.add(offset)
            for span in spans:
                self.assertIn(span["start"], safe_offsets)
                self.assertIn(span["end"], safe_offsets)
            self.assertFalse(any(
                span["text"].startswith(("။", "၊", "!", "?", ".", ","))
                for span in spans
            ))
        source_offset = 17
        for leading in ("။", "!?"):
            narration = f"{leading}မင်္ဂလာပါ။"
            spans = engine._myanmar_display_word_spans(narration, source_offset)
            self.assertEqual(
                "".join(span["text"] for span in spans),
                narration[len(leading):],
            )
            self.assertEqual(spans[0]["start"], source_offset + len(leading))
            self.assertEqual(spans[-1]["end"], source_offset + len(narration))
            self.assertTrue(all(
                not span["text"].startswith(("။", "၊", "!", "?", ".", ","))
                for span in spans
            ))

        with self.assertRaisesRegex(
            engine.EngineError, "no text after punctuation cleanup"
        ):
            engine._myanmar_display_word_spans("။!?", source_offset)

    def test_myanmar_multiple_provider_boundaries_inside_one_word_merge_timing(self):
        script = "မခုန်ရန်။"
        entries = engine._myanmar_display_word_spans(script, 0)
        for entry in entries:
            entry["clause_index"] = 0
        boundaries = [
            {"text": "မ", "offset": 0.0, "duration": 0.1},
            {"text": "ခု", "offset": 0.2, "duration": 0.2},
            {"text": "န်", "offset": 0.6, "duration": 0.2},
            {"text": "။", "offset": 0.8, "duration": 0.1},
        ]
        aligned = engine._aligned_provider_word_boundaries(
            script, boundaries, 1.0
        )
        engine._time_myanmar_word_entries(
            entries,
            aligned,
            [(0, len(script))],
            [(0.0, 1.0)],
            script,
            1.0,
        )

        safe_word = next(entry for entry in entries if entry["text"] == "ခုန်")
        self.assertAlmostEqual(safe_word["timing"][0], 0.2)
        self.assertAlmostEqual(safe_word["timing"][1], 0.8)
        self.assertGreater(safe_word["timing"][1], safe_word["timing"][0])

    def test_myanmar_out_of_order_provider_timing_fails_explicitly(self):
        with self.assertRaisesRegex(engine.EngineError, "out-of-order"):
            engine._aligned_provider_word_boundaries(
                "မခုန်ရန်။",
                [
                    {"text": "ခုန်", "offset": 0.8, "duration": 0.2},
                    {"text": "မ", "offset": 0.0, "duration": 0.2},
                ],
                1.5,
            )

    def test_overwide_burmese_phrase_fails_without_provider_word_splitting(self):
        script = "အပြန်အလှန်ကျေးဇူးတင်စကားဆိုခဲ့ကြသည်။"
        boundaries = [
            {"text": script, "offset": 0.0, "duration": 2.5},
        ]
        windows = engine._batch_clause_windows(
            [script],
            boundaries,
            2.5,
            batch_text=script,
        )

        with self.assertRaisesRegex(
            engine.EngineError,
            "single Burmese lexical unit is wider than two subtitle lines",
        ):
            engine._myanmar_timed_subtitle_cues(
                [script],
                windows,
                boundaries,
                2.5,
                script,
                8,
            )

    def test_make_narration_keeps_full_tts_text_and_phrase_timing(self):
        words = ["အပြန်အလှန်", "ကျေးဇူးတင်", "စကား", "ဆိုခဲ့ကြသည်။"]
        script = "".join(words)
        boundaries = [
            {"text": word, "offset": index * 0.7, "duration": 0.55}
            for index, word in enumerate(words)
        ]
        tts_inputs = []

        async def synthesize(text, destination, *_args, **_kwargs):
            tts_inputs.append(text)
            destination.write_bytes(b"provider-shaped-audio")
            return boundaries

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_edge_tts_batch", side_effect=synthesize), \
                patch.object(engine, "_audio_duration", return_value=3.0), \
                patch.object(engine, "_slice_narration_block"), \
                patch.object(
                    engine,
                    "_assemble_phrase_audio",
                    return_value=(2.65, [2.65]),
                ), \
                patch.object(engine, "_validate_phrase_gated_audio"):
            _, subtitles, duration = engine._make_narration(
                script,
                "myanmar",
                "my-MM-NilarNeural",
                Path(directory),
                subtitle_wrap_width=100,
            )

            subtitle_text = subtitles.read_text(encoding="utf-8")

        self.assertEqual(tts_inputs, [script])
        self.assertAlmostEqual(duration, 2.65)
        self.assertIn(script, subtitle_text)
        self.assertIn("00:00:00,000 --> 00:00:02,650", subtitle_text)

    def test_batched_narration_reuses_completed_audio_cache(self):
        calls = []

        async def synthesize(text, destination, *_args, **_kwargs):
            calls.append((text, _args[2] if len(_args) > 2 else None))
            destination.write_bytes(b"cached-mp3")
            return [{"text": word, "offset": index * 0.3, "duration": 0.2}
                    for index, word in enumerate(text.split())]

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_edge_tts_batch", side_effect=synthesize), \
                patch.object(engine, "_audio_duration", return_value=2.0), \
                patch.object(engine, "_slice_narration_block"):
            clauses = ["one two", "three four"]
            first = asyncio.run(engine._synthesize_batched_narration_parts(
                clauses,
                "en-US-JennyNeural",
                Path(directory),
                "english",
            ))
            second = asyncio.run(engine._synthesize_batched_narration_parts(
                clauses,
                "en-US-JennyNeural",
                Path(directory),
                "english",
            ))
            third = asyncio.run(engine._synthesize_batched_narration_parts(
                clauses,
                "en-US-JennyNeural",
                Path(directory),
                "english",
                narration_speed=1.1,
            ))

        self.assertEqual(first, second)
        self.assertEqual(first, third)
        self.assertEqual(calls, [
            ("one two three four", "+0%"),
            ("one two three four", "+0%"),
        ])

    def test_selected_narration_speed_is_sent_to_tts_and_not_post_adjusted(self):
        captured = {}

        async def synthesize(
            _sentences,
            _voice,
            _directory,
            rate,
            **kwargs,
        ):
            captured["rate"] = rate
            captured.update(kwargs)
            return [Path("one.mp3")]

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_parts", new=AsyncMock(
                    side_effect=synthesize
                )), patch.object(
                    engine,
                    "_assemble_phrase_audio",
                    return_value=(2.0, [2.0]),
                ), patch.object(engine, "_validate_phrase_gated_audio"), \
                patch.object(engine, "_run") as run:
            engine._make_narration(
                "A short narrated story.",
                "english",
                "en-US-JennyNeural",
                Path(directory),
                rate_percent=0,
                narration_speed=1.1,
            )

        self.assertEqual(captured["rate"], "+10%")
        self.assertEqual(captured["narration_speed"], 1.1)
        self.assertFalse(any(
            "atempo=" in str(argument)
            for call in run.call_args_list
            for argument in call.args[0]
        ))

    def test_burmese_narration_sends_the_complete_script_once(self):
        calls = []

        async def synthesize(text, destination, *_args, **_kwargs):
            calls.append(text)
            destination.write_bytes(b"cached-mp3")
            return [
                {"text": "မင်္ဂလာပါ။", "offset": 0.0, "duration": 0.8},
                {"text": "ဇာတ်လမ်းပါ။", "offset": 1.0, "duration": 0.8},
            ]

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_edge_tts_batch", side_effect=synthesize), \
                patch.object(engine, "_audio_duration", return_value=2.0), \
                patch.object(engine, "_slice_narration_block"):
            parts = asyncio.run(engine._synthesize_batched_narration_parts(
                ["မင်္ဂလာပါ။", "ဇာတ်လမ်းပါ။"],
                "my-MM-NilarNeural",
                Path(directory),
                "myanmar",
                "+10%",
                continuous_text="မင်္ဂလာပါ။ ဇာတ်လမ်းပါ။",
            ))

        self.assertEqual(calls, ["မင်္ဂလာပါ။ ဇာတ်လမ်းပါ။"])
        self.assertEqual(len(parts), 2)

    def test_fallback_burmese_narration_uses_measured_single_phrase_windows(self):
        calls = []

        async def synthesize(text, destination, *_args, **_kwargs):
            calls.append(text)
            destination.write_bytes(b"cached-mp3")
            return []

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_edge_tts_batch", side_effect=synthesize), \
                patch.object(engine, "_audio_duration", return_value=1.25), \
                patch.object(engine, "_slice_narration_block"):
            parts = asyncio.run(engine._synthesize_batched_narration_parts(
                ["သူက ပြန်လာသည်။", "အားလုံး ဘေးကင်းသည်။"],
                "my-MM-NilarNeural",
                Path(directory),
                "myanmar",
                "+15%",
                measured_phrase_timing=True,
            ))

        self.assertEqual(calls, ["သူက ပြန်လာသည်။", "အားလုံး ဘေးကင်းသည်။"])
        self.assertEqual(len(parts), 2)

    def test_burmese_tts_default_rate_is_fast_recap_pace(self):
        self.assertEqual(engine._format_tts_rate(0, "myanmar"), "+0%")
        self.assertEqual(engine._setting_rate({}, "myanmar"), 15)

    def test_myanmar_tts_delivery_turns_unpunctuated_line_breaks_into_short_pauses(self):
        delivery = engine._prepare_myanmar_tts_delivery(
            "[A] ဒီနေ့ ဇာတ်လမ်း စတင်\n"
            "နောက်တစ်ဆင့်မှာ အရေးကြီးတဲ့ အဖြစ်အပျက် ဖြစ်လာပါတယ်။"
        )
        self.assertNotIn("[A]", delivery)
        self.assertIn("စတင်၊ နောက်တစ်ဆင့်", delivery)
        self.assertTrue(delivery.endswith("ဖြစ်လာပါတယ်။"))

    def test_myanmar_tts_delivery_keeps_sentence_boundaries_without_extra_pause(self):
        delivery = engine._prepare_myanmar_tts_delivery(
            "ပထမအပိုင်း ပြီးဆုံးပါပြီ။\n"
            "ဒုတိယအပိုင်း စတင်ပါပြီ။"
        )
        self.assertEqual(
            delivery,
            "ပထမအပိုင်း ပြီးဆုံးပါပြီ။ ဒုတိယအပိုင်း စတင်ပါပြီ။",
        )

    def test_narration_error_is_not_misreported_as_worker_error(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_parts", new=AsyncMock(
                    side_effect=engine.EngineError("Narration synthesis failed.")
                )):
            with self.assertRaisesRegex(engine.EngineError, "Narration synthesis failed"):
                engine._make_narration("An original story.", "english", "en-US-JennyNeural", Path(directory))

    def test_myanmar_narration_retries_the_other_voice_after_provider_failure(self):
        calls = []

        async def synthesize(_sentences, voice, directory, *_args, **_kwargs):
            calls.append(voice)
            if voice == "my-MM-ThihaNeural":
                raise engine.EngineError(
                    "Edge-TTS Burmese narration failed; no fallback audio is allowed."
                )
            return [directory / "part-0000.mp3"]

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_parts", side_effect=synthesize), \
                patch.object(
                    engine,
                    "_assemble_phrase_audio",
                    return_value=(1.0, [1.0]),
                ), \
                patch.object(engine, "_validate_phrase_gated_audio"):
            _, subtitles, duration = engine._make_narration(
                "ဒီနေ့ ဇာတ်လမ်း စတင်ပါပြီ။",
                "myanmar",
                "my-MM-ThihaNeural",
                Path(directory),
            )
            self.assertTrue(subtitles.exists())

        self.assertEqual(calls, ["my-MM-ThihaNeural", "my-MM-NilarNeural"])
        self.assertEqual(duration, 1.0)

    def test_media_storage_uses_local_root_without_bucket_configuration(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.dict(
                    "os.environ",
                    {
                        "STUDIO_MEDIA_BACKEND": "local",
                        "DEFAULT_OBJECT_STORAGE_BUCKET_ID": "",
                    },
                ), \
                patch.object(storage, "MEDIA_ROOT", Path(directory)):
            client = storage.storage_client()
            self.assertIsInstance(client, storage.LocalStorageClient)
            client.upload_from_filename("studio/owner/source.mp4", __file__)
            destination = Path(directory) / "downloaded.mp4"
            client.download_to_filename("studio/owner/source.mp4", str(destination))
            self.assertEqual(destination.read_bytes(), Path(__file__).read_bytes())
            client.delete("studio/owner/source.mp4")
            with self.assertRaises(FileNotFoundError):
                client.download_to_filename("studio/owner/source.mp4", str(destination))

    def test_media_storage_rejects_path_traversal(self):
        with tempfile.TemporaryDirectory() as directory:
            client = storage.LocalStorageClient(Path(directory))
            with self.assertRaises(ValueError):
                client.upload_from_filename("../outside", __file__)

    def test_srt_timing_tracks_assembled_audio(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_parts", new=AsyncMock(
                    return_value=[Path("one.mp3"), Path("two.mp3")]
                )), patch.object(engine, "_audio_duration", side_effect=[1.2, 2.4, 3.65]), \
                patch.object(engine, "_validate_phrase_gated_audio"), \
                patch.object(engine, "_run"):
            _, srt, duration = engine._make_narration(
                "First sentence. Second sentence.", "english", "en-US-JennyNeural", Path(directory),
            )
            self.assertEqual(duration, 3.65)
            content = srt.read_text()
            self.assertIn("00:00:00,000 --> 00:00:01,217", content)
            self.assertIn("00:00:01,217 --> 00:00:03,650", content)

    def test_narration_srt_final_cue_stops_at_natural_speech_end(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_parts", new=AsyncMock(
                    return_value=[Path("one.mp3"), Path("two.mp3")]
                )), patch.object(
                    engine,
                    "_assemble_phrase_audio",
                    side_effect=[
                        (3.65, [1.2, 2.4]),
                        (5.0, [2.0, 3.0]),
                    ],
                ), patch.object(engine, "_retime_narration_parts", return_value=[
                    Path("fitted-one.mp3"),
                    Path("fitted-two.mp3"),
                ]), patch.object(engine, "_audio_duration", return_value=5.0), \
                patch.object(engine, "_validate_phrase_gated_audio"), \
                patch.object(engine, "_run"):
            _, srt, duration = engine._make_narration(
                "First sentence. Second sentence.",
                "english",
                "en-US-JennyNeural",
                Path(directory),
                target_duration=5.0,
            )
            content = srt.read_text()
        self.assertEqual(duration, 5.0)
        self.assertIn("00:00:01,217 --> 00:00:03,650", content)

    def test_short_narration_finishes_early_without_slowing_to_fill_the_window(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_parts", new=AsyncMock(
                    return_value=[Path("one.mp3")]
                )), patch.object(
                    engine,
                    "_assemble_phrase_audio",
                    return_value=(2.0, [2.0]),
                ), patch.object(
                    engine,
                    "_align_phrase_gated_cues_to_audio",
                    side_effect=lambda _audio, cues: cues,
                ), patch.object(
                    engine,
                    "_coalesce_phrase_cues_without_silence",
                    side_effect=lambda _audio, cues, _language, _width: cues,
                ), \
                patch.object(engine, "_validate_phrase_gated_audio"), \
                patch.object(engine, "_run") as run:
            _, subtitles, duration = engine._make_narration(
                "စာတိုတစ်ကြောင်း။",
                "myanmar",
                "my-MM-NilarNeural",
                Path(directory),
                target_duration=10.0,
            )
            subtitle_text = subtitles.read_text(encoding="utf-8")

        self.assertEqual(duration, 10.0)
        self.assertIn("00:00:00,000 --> 00:00:02,000", subtitle_text)
        self.assertFalse(any(
            "atempo=" in str(argument) or "apad=whole_dur=10.000000" in str(argument)
            for call in run.call_args_list
            for argument in call.args[0]
        ))

    def test_confirmed_story_end_limits_narration_capacity_not_video_duration(self):
        settings = {
            "narrationSpeed": 1.0,
            "narrationStartSeconds": 0.5,
            "narrationDurationSeconds": None,
        }
        _, start, exact_limit, available = engine._narration_timeline_settings(
            settings,
            42.7,
            39.9,
        )

        self.assertEqual(start, 0.5)
        self.assertIsNone(exact_limit)
        self.assertAlmostEqual(
            available,
            39.9 - 0.5 - engine.NARRATION_END_PADDING_SECONDS,
        )
        self.assertEqual(engine._map_source_timestamp_to_target(39.9, 42.7, 42.7), 39.9)

    def test_60_second_source_with_35_second_story_end_keeps_full_render_timeline(self):
        target_duration = engine._resolve_target_duration(60.0, None)
        story_end = engine._map_source_timestamp_to_target(35.0, 60.0, target_duration)
        _, narration_start, exact_limit, narration_capacity = (
            engine._narration_timeline_settings(
                {
                    "narrationSpeed": 1.0,
                    "narrationStartSeconds": 0.5,
                    "narrationDurationSeconds": None,
                },
                target_duration,
                story_end,
            )
        )

        self.assertEqual(target_duration, 60.0)
        self.assertEqual(story_end, 35.0)
        self.assertEqual(narration_start, 0.5)
        self.assertIsNone(exact_limit)
        self.assertAlmostEqual(
            narration_capacity,
            35.0 - 0.5 - engine.NARRATION_END_PADDING_SECONDS,
        )

        with tempfile.TemporaryDirectory() as directory:
            subtitles = Path(directory) / "short.srt"
            subtitles.write_text(
                "1\n00:00:05,000 --> 00:00:06,000\nအစ\n\n"
                "2\n00:00:33,000 --> 00:00:34,500\nအဆုံး\n",
                encoding="utf-8",
            )
            timeline = engine._build_story_timeline(
                [
                    {
                        "id": "opening",
                        "start": 4.0,
                        "end": 8.0,
                        "sourceText": "The story begins.",
                    },
                    {
                        "id": "climax",
                        "start": 32.0,
                        "end": 37.0,
                        "sourceText": "The final confrontation.",
                    },
                    {
                        "id": "outro",
                        "start": 36.0,
                        "end": 39.0,
                        "sourceText": "Follow Xiaohongshu.",
                    },
                ],
                60.0,
                target_duration,
                subtitles,
                story_end,
            )

        self.assertEqual(
            [(cue["videoStart"], cue["videoEnd"]) for cue in timeline],
            [(5.0, 6.0), (33.0, 34.5)],
        )
        self.assertEqual(
            [cue["sourceEventId"] for cue in timeline],
            ["opening", "climax"],
        )
        self.assertTrue(all(cue["videoEnd"] <= story_end for cue in timeline))

    def test_target_duration_defaults_to_full_source_and_caps_longer_presets(self):
        self.assertEqual(engine._resolve_target_duration(42.7, None), 42.7)
        self.assertEqual(engine._resolve_target_duration(42.7, 3), 42.7)
        self.assertEqual(engine._resolve_target_duration(300.0, 3), 180.0)
        self.assertEqual(
            engine._map_source_timestamp_to_target(42.7, 42.7, 180.0),
            42.7,
        )

    def test_source_story_end_uses_the_same_proportional_segments_as_video(self):
        # A 300s source is rendered as five 36s excerpts sampled from 60s spans.
        self.assertEqual(engine._map_source_timestamp_to_target(85.0, 300.0, 180.0), 61.0)
        self.assertEqual(engine._map_source_timestamp_to_target(100.0, 300.0, 180.0), 72.0)

    def test_reviewed_timed_transcript_omits_events_after_confirmed_story_end(self):
        source = engine._story_source_transcript(
            "fallback transcript",
            [
                {
                    "id": "setup",
                    "speaker": "A",
                    "start": 1.0,
                    "end": 2.0,
                    "sourceText": "The story begins.",
                },
                {
                    "id": "outro",
                    "speaker": "A",
                    "start": 40.2,
                    "end": 41.2,
                    "sourceText": "Follow Xiaohongshu.",
                },
            ],
            39.9,
        )

        self.assertIn("[1.000-2.000s] [event setup]", source)
        self.assertIn("The story begins.", source)
        self.assertNotIn("Follow Xiaohongshu", source)
        self.assertNotIn("fallback transcript", source)

    def test_story_end_boundary_api_validation_uses_real_source_duration(self):
        main._validate_story_end_boundary(
            {"storyEndSeconds": 39.9},
            {"sourceDuration": 42.7},
        )
        with self.assertRaises(HTTPException) as invalid:
            main._validate_story_end_boundary(
                {"storyEndSeconds": 42.8},
                {"sourceDuration": 42.7},
            )
        self.assertEqual(invalid.exception.status_code, 422)
        with self.assertRaises(HTTPException) as unprocessed:
            main._validate_story_end_boundary(
                {"storyEndSeconds": 10.0},
                {"sourceDuration": 0},
            )
        self.assertEqual(unprocessed.exception.status_code, 409)

    def test_story_timeline_keeps_actual_short_subtitle_times_and_excludes_outro_events(self):
        with tempfile.TemporaryDirectory() as directory:
            subtitles = Path(directory) / "short.srt"
            subtitles.write_text(
                "1\n00:00:05,000 --> 00:00:06,000\nအစ\n\n"
                "2\n00:00:30,000 --> 00:00:31,000\nအဆုံး\n",
                encoding="utf-8",
            )
            timeline = engine._build_story_timeline(
                [
                    {
                        "id": "setup",
                        "start": 4.0,
                        "end": 8.0,
                        "sourceText": "The story begins.",
                    },
                    {
                        "id": "climax",
                        "start": 35.0,
                        "end": 39.0,
                        "sourceText": "The final confrontation.",
                    },
                    {
                        "id": "outro",
                        "start": 40.2,
                        "end": 41.0,
                        "sourceText": "Follow Xiaohongshu.",
                    },
                ],
                42.7,
                42.7,
                subtitles,
                39.9,
            )

        self.assertEqual([item["sourceEventId"] for item in timeline], ["setup", "climax"])
        self.assertEqual(
            [(item["videoStart"], item["videoEnd"]) for item in timeline],
            [(5.0, 6.0), (30.0, 31.0)],
        )
        self.assertTrue(all("Xiaohongshu" not in item["sourceText"] for item in timeline))

    def test_generated_burmese_script_is_compressed_only_when_over_the_time_limit(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(
                    engine,
                    "_make_narration",
                    side_effect=[
                        (Path(directory) / "draft.mp3", Path(directory) / "draft.srt", 7.0),
                        (Path(directory) / "revised.mp3", Path(directory) / "revised.srt", 5.0),
                    ],
                ) as make_narration, \
                patch.object(
                    engine,
                    "_revise_script_for_narration_duration",
                    return_value="ပြန်လည်ပြင်ဆင်ထားသော ဇာတ်လမ်း။",
                ) as revise:
            revised = engine._calibrate_generated_myanmar_script(
                "တိုသော ဇာတ်လမ်း။",
                "မူရင်း တရုတ် ဇာတ်လမ်း။",
                "my-MM-NilarNeural",
                0,
                1.0,
                5.0,
                Path(directory),
            )

        self.assertEqual(revised, "ပြန်လည်ပြင်ဆင်ထားသော ဇာတ်လမ်း။")
        self.assertEqual(make_narration.call_count, 2)
        revise.assert_called_once_with(
            "တိုသော ဇာတ်လမ်း။",
            "မူရင်း တရုတ် ဇာတ်လမ်း။",
            "myanmar",
            5.0,
            7.0,
            progress_callback=None,
        )

    def test_generated_complete_short_script_is_not_expanded_to_fill_available_time(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(
                    engine,
                    "_make_narration",
                    return_value=(
                        Path(directory) / "draft.mp3",
                        Path(directory) / "draft.srt",
                        2.0,
                    ),
                ) as make_narration, \
                patch.object(
                    engine,
                    "_revise_script_for_narration_duration",
                ) as revise:
            result = engine._calibrate_generated_myanmar_script(
                "အစ၊ အရေးကြီးဖြစ်ရပ်နှင့် အဆုံးသတ်ပါဝင်သော ဇာတ်လမ်း။",
                "အချိန်တံဆိပ်ပါ မူရင်းဖြစ်ရပ်များ။",
                "my-MM-NilarNeural",
                0,
                1.0,
                10.0,
                Path(directory),
            )

        self.assertEqual(
            result,
            "အစ၊ အရေးကြီးဖြစ်ရပ်နှင့် အဆုံးသတ်ပါဝင်သော ဇာတ်လမ်း။",
        )
        make_narration.assert_called_once()
        revise.assert_not_called()

    def test_burmese_timing_calibration_defers_visual_subtitle_layout(self):
        script = "အပြန်အလှန်ကျေးဇူးတင်စကားဆိုခဲ့ကြသည်။"
        original_synthesize = engine._synthesize_parts

        async def fake_edge_tts(text, block, voice, language, rate):
            block.write_bytes(b"fake-provider-audio")
            return [{"text": text, "offset": 0.0, "duration": 3.0}]

        def fake_slice(block, destination, start, end):
            destination.write_bytes(b"fake-provider-audio-slice")

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(
                    engine,
                    "_synthesize_parts",
                    new=AsyncMock(wraps=original_synthesize),
                ) as synthesize, \
                patch.object(
                    engine,
                    "_edge_tts_batch",
                    new=AsyncMock(side_effect=fake_edge_tts),
                ) as edge_tts, \
                patch.object(engine, "_audio_duration", return_value=3.0), \
                patch.object(
                    engine,
                    "_slice_narration_block",
                    side_effect=fake_slice,
                ), \
                patch.object(
                    engine,
                    "_assemble_phrase_audio",
                    return_value=(3.0, [3.0]),
                ), patch.object(
                    engine,
                    "_wrap_subtitle_text",
                    side_effect=AssertionError(
                        "timing calibration must defer visual subtitle layout"
                    ),
                ):
            result = engine._calibrate_generated_myanmar_script(
                script,
                "မူရင်း ဇာတ်လမ်း။",
                "my-MM-NilarNeural",
                15,
                1.0,
                5.0,
                Path(directory),
            )

        self.assertEqual(result, script)
        self.assertFalse(synthesize.call_args.kwargs["layout_subtitles"])
        self.assertEqual(synthesize.call_args.kwargs["subtitle_wrap_width"], None)
        edge_tts.assert_awaited_once()
        self.assertEqual(edge_tts.call_args.args[0], script)

    def test_script_inside_narration_window_tolerance_skips_gemini_revision(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(
                    engine,
                    "_make_narration",
                    return_value=(
                        Path(directory) / "draft.mp3",
                        Path(directory) / "draft.srt",
                        40.333,
                    ),
                ) as make_narration, \
                patch.object(
                    engine,
                    "_revise_script_for_narration_duration",
                ) as revise:
            result = engine._calibrate_generated_myanmar_script(
                "အတည်ပြုထားသော မြန်မာဇာတ်လမ်း။",
                "မူရင်း တရုတ် ဇာတ်လမ်း။",
                "my-MM-NilarNeural",
                0,
                1.0,
                40.7,
                Path(directory),
            )

        self.assertEqual(result, "အတည်ပြုထားသော မြန်မာဇာတ်လမ်း။")
        make_narration.assert_called_once()
        revise.assert_not_called()

    def test_generated_burmese_script_survives_timing_editor_rate_limit_when_fit_is_safe(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(
                    engine,
                    "_make_narration",
                    return_value=(
                        Path(directory) / "draft.mp3",
                        Path(directory) / "draft.srt",
                        6.5,
                    ),
                ), \
                patch.object(
                    engine,
                    "_revise_script_for_narration_duration",
                    side_effect=engine.GeminiRateLimitError("Recap timing revision"),
                ):
            result = engine._calibrate_generated_myanmar_script(
                "လက်ရှိ အတည်ပြုထားသော ဇာတ်လမ်း။",
                "မူရင်း တရုတ် ဇာတ်လမ်း။",
                "my-MM-NilarNeural",
                0,
                1.0,
                5.0,
                Path(directory),
            )

        self.assertEqual(result, "လက်ရှိ အတည်ပြုထားသော ဇာတ်လမ်း။")

    def test_generated_burmese_script_fails_when_timing_attempt_budget_cannot_cover_story(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(
                    engine,
                    "_make_narration",
                    side_effect=[
                        (Path(directory) / "draft-1.mp3", Path(directory) / "draft-1.srt", 10.0),
                        (Path(directory) / "draft-2.mp3", Path(directory) / "draft-2.srt", 10.0),
                        (Path(directory) / "draft-3.mp3", Path(directory) / "draft-3.srt", 10.0),
                        (Path(directory) / "draft-4.mp3", Path(directory) / "draft-4.srt", 10.0),
                        (Path(directory) / "draft-5.mp3", Path(directory) / "draft-5.srt", 10.0),
                    ],
                ), \
                patch.object(
                    engine,
                    "_revise_script_for_narration_duration",
                    return_value="ပြင်ဆင်ထားသော ဇာတ်လမ်း။",
                ):
            with self.assertRaisesRegex(
                engine.EngineError,
                "could not be timed to the available narration window naturally",
            ):
                engine._calibrate_generated_myanmar_script(
                    "လက်ရှိ အတည်ပြုထားသော ဇာတ်လမ်း။",
                    "မူရင်း တရုတ် ဇာတ်လမ်း။",
                    "my-MM-NilarNeural",
                    0,
                    1.0,
                    5.0,
                    Path(directory),
                )

    def test_generated_burmese_script_accepts_a_natural_early_finish_after_compression(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(
                    engine,
                    "_make_narration",
                    side_effect=[
                        (Path(directory) / "draft-1.mp3", Path(directory) / "draft-1.srt", 6.5),
                        (Path(directory) / "draft-2.mp3", Path(directory) / "draft-2.srt", 4.0),
                    ],
                ) as make_narration, \
                patch.object(
                    engine,
                    "_revise_script_for_narration_duration",
                    return_value="ပြင်ဆင်ထားသော ဇာတ်လမ်း ၂။",
                ) as revise:
            result = engine._calibrate_generated_myanmar_script(
                "ဘေးကင်းစွာ အရှိန်ညှိနိုင်သော ဇာတ်လမ်း။",
                "မူရင်း တရုတ် ဇာတ်လမ်း။",
                "my-MM-NilarNeural",
                0,
                1.0,
                5.0,
                Path(directory),
            )

        self.assertEqual(result, "ပြင်ဆင်ထားသော ဇာတ်လမ်း ၂။")
        self.assertEqual(make_narration.call_count, 2)
        self.assertEqual(revise.call_count, 1)

    def test_non_default_narration_speed_still_fits_requested_duration(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_parts", new=AsyncMock(
                    return_value=[Path("one.mp3"), Path("two.mp3")]
                )), patch.object(
                    engine,
                    "_assemble_phrase_audio",
                    side_effect=[
                        (6.25, [2.5, 3.75]),
                        (5.0, [2.0, 3.0]),
                    ],
                ), patch.object(engine, "_retime_narration_parts", return_value=[
                    Path("fitted-one.mp3"),
                    Path("fitted-two.mp3"),
                ]), patch.object(engine, "_audio_duration", return_value=5.0), \
                patch.object(engine, "_validate_phrase_gated_audio"), \
                patch.object(engine, "_run"):
            _, _, duration = engine._make_narration(
                "First sentence. Second sentence.",
                "english",
                "en-US-JennyNeural",
                Path(directory),
                target_duration=5.0,
                narration_speed=1.25,
            )

        self.assertEqual(duration, 5.0)

    def test_phrase_timeline_allows_adjacent_cues_but_rejects_overlap(self):
        engine._validate_phrase_gated_timeline(
            [(0.0, 1.0, "first"), (1.0, 2.0, "second")],
            2.0,
        )
        with self.assertRaisesRegex(engine.EngineError, "drift"):
            engine._validate_phrase_gated_timeline(
                [(0.0, 1.0, "first"), (0.99, 2.0, "second")],
                2.0,
            )

    def test_phrase_audio_validation_skips_adjacent_cues_without_silence(self):
        with patch.object(engine, "_phrase_silence_intervals", return_value=[]):
            engine._validate_phrase_gated_audio(
                Path("continuous.mp3"),
                [(0.0, 1.0, "first"), (1.0, 2.0, "second")],
            )

    def test_phrase_cues_follow_measured_encoded_silence_boundaries(self):
        cues = [
            (0.0, 1.2, "first"),
            (1.8, 3.0, "second"),
            (3.6, 4.0, "third"),
        ]
        with patch.object(
            engine,
            "_phrase_silence_intervals",
            return_value=[(0.0, 0.18), (1.15, 1.65), (3.0, 3.45)],
        ):
            aligned = engine._align_phrase_gated_cues_to_audio(
                Path("fitted.mp3"),
                cues,
            )
        self.assertEqual(aligned, [
            (0.0, 1.15, "first"),
            (1.65, 3.0, "second"),
            (3.45, 4.0, "third"),
        ])

    def test_phrase_alignment_ignores_trailing_encoded_silence(self):
        cues = [
            (0.0, 1.0, "first"),
            (1.0, 2.0, "last"),
        ]
        with patch.object(
            engine,
            "_phrase_silence_intervals",
            return_value=[(1.2, 1.95)],
        ), patch.object(engine, "_audio_duration", return_value=2.0):
            aligned = engine._align_phrase_gated_cues_to_audio(
                Path("fitted.mp3"),
                cues,
            )
        self.assertEqual(aligned, cues)

    def test_myanmar_srt_is_utf8_normalized(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_parts", new=AsyncMock(
                    return_value=[Path("one.mp3")]
                )), patch.object(engine, "_audio_duration", side_effect=[1.2, 1.2, 1.2]), \
                patch.object(engine, "_validate_phrase_gated_audio"), \
                patch.object(engine, "_run"):
            _, srt, _ = engine._make_narration(
                "ဒီဇာတ်လမ်းပါ။",
                "myanmar",
                "my-MM-NilarNeural",
                Path(directory),
            )
            raw = srt.read_bytes()
            content = raw.decode("utf-8")
            self.assertIn("ဒီဇာတ်လ", content)
            self.assertNotIn("\ufffd", content)

    def test_continuous_myanmar_srt_stays_valid_for_all_render_profiles(self):
        script = (
            "ဒီဗီဒီယို အကျဉ်းချုပ် စမ်းသပ်မှု ဇာတ်လမ်းမှာတော့၊ "
            "ဇာတ်လိုက်ဟာ လျှို့ဝှက်ချက်တစ်ခုကို စတင်တွေ့ရှိသွားခဲ့ပါတယ်။"
        )
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_synthesize_parts", new=AsyncMock(
                    return_value=[Path(f"part-{index}.mp3") for index in range(6)]
                )), patch.object(engine, "_audio_duration", return_value=4.0), \
                patch.object(engine, "_validate_phrase_gated_audio"), \
                patch.object(engine, "_run"):
            _, srt, _ = engine._make_narration(
                script, "myanmar", "my-MM-NilarNeural", Path(directory),
            )
            lines = [
                line for line in srt.read_text(encoding="utf-8").splitlines()
                if line and not line.isdigit() and "-->" not in line
            ]
        self.assertTrue(lines)
        self.assertLessEqual(max(len(line) for line in lines), 24)
        self.assertTrue(all(len(line.split()) <= 6 for line in lines))

    def test_myanmar_subtitle_wrapping_preserves_syllable_units(self):
        value = "မင်္ဂလာပါ။ လျှို့ဝှက်ချက်တစ်ခုကို"
        wrapped = engine._wrap_subtitle_text(value, "myanmar", width=30)
        self.assertEqual(re.sub(r"\s+", "", wrapped), re.sub(r"\s+", "", value))
        self.assertLessEqual(len(wrapped.splitlines()), engine.MAX_SUBTITLE_LINES)
        self.assertEqual(
            [word for line in wrapped.splitlines() for word in line.split()],
            value.split(),
        )

    def test_myanmar_subtitle_wrapping_counts_grapheme_clusters_not_codepoints(self):
        value = "မင်္ဂလာပါမြန်မာ"
        cluster_width = len(engine._myanmar_syllables(value))
        self.assertGreater(len(value), 10)
        self.assertLess(cluster_width, len(value))

        wrapped = engine._wrap_subtitle_text(
            value,
            "myanmar",
            width=cluster_width,
        )

        self.assertEqual(wrapped, value)

    def test_subtitle_validator_accepts_wrapped_myanmar_syllable_clusters(self):
        width = 30
        wrapped = engine._wrap_subtitle_text(
            "မင်္ဂလာပါ။ လျှို့ဝှက်ချက်တစ်ခုကို",
            "myanmar",
            width=width,
        )
        self.assertLessEqual(len(wrapped.splitlines()), engine.MAX_SUBTITLE_LINES)

        with tempfile.TemporaryDirectory() as directory:
            subtitles = Path(directory) / "myanmar.srt"
            subtitles.write_text(
                "1\n00:00:00,000 --> 00:00:01,000\n"
                f"{wrapped}\n",
                encoding="utf-8",
            )
            engine._validate_subtitle_file(
                subtitles,
                "myanmar",
                Path(directory),
                {"myanmar_wrap_width": width},
            )

    def test_subtitle_validator_reports_overwide_myanmar_syllable_line(self):
        width = 8
        text = (
            "အရေးပေါ် အန္တရာယ်ကြားမှာ ပိတ်မိနေတဲ့ "
            "ကလေးငယ်တွေဟာ ကြောက်လန့်တကြား"
        )
        self.assertGreater(
            len(engine._myanmar_syllables(text)),
            width + 6,
        )

        with tempfile.TemporaryDirectory() as directory:
            subtitles = Path(directory) / "myanmar.srt"
            subtitles.write_text(
                "1\n00:00:00,000 --> 00:00:01,000\n"
                f"{text}\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(
                engine.EngineError,
                r"line=1 width=\d+ limit=14",
            ):
                engine._validate_subtitle_file(
                    subtitles,
                    "myanmar",
                    Path(directory),
                    {"myanmar_wrap_width": width},
                )

    def test_myanmar_subtitle_wrapping_respects_narrow_width_below_ten(self):
        value = "မင်္ဂလာပါမြန်မာဘာသာ"
        with self.assertRaisesRegex(engine.EngineError, "without breaking a word"):
            engine._wrap_subtitle_text(value, "myanmar", width=3)

    def test_myanmar_phrase_cues_keep_words_intact_and_never_exceed_two_lines(self):
        script = " ".join(["က"] * 24)
        phrases = engine._subtitle_phrases(
            script,
            "myanmar",
            subtitle_wrap_width=3,
        )

        self.assertEqual(
            [word for phrase in phrases for word in phrase.split()],
            script.split(),
        )
        self.assertTrue(phrases)
        for phrase in phrases:
            wrapped = engine._wrap_subtitle_text(phrase, "myanmar", width=3)
            self.assertLessEqual(len(wrapped.splitlines()), engine.MAX_SUBTITLE_LINES)

    def test_phrase_coalescing_keeps_cues_separate_when_combined_text_overflows(self):
        phrase = "က က က က"
        cues = [
            (0.0, 1.0, phrase),
            (1.0, 2.0, phrase),
        ]

        with patch.object(
            engine,
            "_phrase_silence_intervals",
            return_value=[(5.0, 5.2)],
        ):
            result = engine._coalesce_phrase_cues_without_silence(
                Path("unused.mp3"),
                cues,
                "myanmar",
                subtitle_wrap_width=3,
            )

        self.assertEqual(result, cues)

    def test_subtitle_validator_rejects_three_visible_lines_in_one_cue(self):
        with tempfile.TemporaryDirectory() as directory:
            subtitles = Path(directory) / "myanmar.srt"
            subtitles.write_text(
                "1\n00:00:00,000 --> 00:00:01,000\n"
                "ပထမစာကြောင်း\nဒုတိယစာကြောင်း\nတတိယစာကြောင်း\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(engine.EngineError, r"cue=1 lines=3"):
                engine._validate_subtitle_file(
                    subtitles,
                    "myanmar",
                    Path(directory),
                    {"myanmar_wrap_width": 40},
                )

    def test_silent_transcription_audio_fails_explicitly(self):
        result = SimpleNamespace(
            returncode=0,
            stdout="",
            stderr="[Parsed_volumedetect_0 @ 0x0] max_volume: -inf dB",
        )
        with patch.object(engine.subprocess, "run", return_value=result), \
                self.assertLogs(engine.log, level="WARNING") as logs, \
                self.assertRaisesRegex(engine.EngineError, "audio is silent"):
            engine._warn_if_silent_audio(Path("silent.wav"))
        self.assertIn("audio is silent", "\n".join(logs.output))

    def test_subtitle_filter_declares_utf8_and_uses_transparent_blur(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_run", side_effect=_fake_render_run) as run:
            subtitle_path = Path(directory) / "myanmar.srt"
            _write_test_subtitles(subtitle_path)
            font_dir = _prepare_test_font(Path(directory) / "fonts")
            engine._render_video(
                Path(directory) / "source.mp4", Path(directory) / "audio.mp3",
                subtitle_path, Path(directory) / "output.mp4",
                2.0, "none", font_dir, "myanmar", True,
                [
                    {"id": "top-text", "x": 0.12, "y": 0.08, "width": 0.76, "height": 0.10},
                    {"id": "bottom-text", "x": 0.18, "y": 0.78, "width": 0.64, "height": 0.12},
                ],
                export_quality="1080p",
            )
        commands = [call.args[0] for call in run.call_args_list]
        visual_command, final_command = commands
        visual_graph = visual_command[visual_command.index("-filter_complex") + 1]
        final_graph = final_command[final_command.index("-filter_complex") + 1]
        all_arguments = visual_command + final_command
        self.assertNotIn("subtitles=filename=", final_graph)
        self.assertNotIn(".ass", " ".join(all_arguments))
        self.assertNotIn("fontsdir=", final_graph)
        self.assertNotIn("force_style", final_graph)
        self.assertIn("apad=whole_dur=2.000", final_graph)
        self.assertIn(
            "boxblur=luma_radius=20:luma_power=1:chroma_radius=0:alpha_radius=0",
            visual_graph,
        )
        self.assertIn("drawbox=x=0:y=0:w=iw:h=ih:color=black@0.25:t=fill", visual_graph)
        self.assertIn("crop=820:192:130:154", visual_graph)
        self.assertIn("overlay=x=130:y=154", visual_graph)
        self.assertIn("volume=1.0", final_graph)
        self.assertNotIn("volume=0.050", final_graph)
        self.assertNotIn("sidechaincompress=", final_graph)
        self.assertIn("-filter_complex_threads", visual_command)
        self.assertIn("-threads", final_command)
        self.assertIn("-max_muxing_queue_size", final_command)
        self.assertTrue(any("1080:1920" in argument for argument in visual_command))
        self.assertNotIn("-shortest", final_command)
        self.assertEqual(final_command[final_command.index("-t") + 1], "2.000")

    def test_60_second_render_and_subtitle_burn_ignore_early_narration_eof(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            subtitles = root / "myanmar.srt"
            subtitles.write_text(
                "1\n00:00:33,000 --> 00:00:34,500\nအဆုံး\n",
                encoding="utf-8",
            )
            font_dir = _prepare_test_font(root / "fonts")
            narration = root / "short-narration.mp3"
            narration.write_bytes(b"short narration fixture")
            clean_video = root / "myanmar-clean.mp4"
            final_video = root / "myanmar-final.mp4"

            mixed_audio = engine._mix_export_audio(
                narration,
                root / "mixed.mp3",
                60.0,
            )
            self.assertEqual(mixed_audio, narration)

            with patch.object(engine, "_run", side_effect=_fake_render_run) as run:
                engine._render_video(
                    root / "source.mp4",
                    mixed_audio,
                    subtitles,
                    clean_video,
                    60.0,
                    "none",
                    font_dir,
                    "myanmar",
                    True,
                    video_transform={
                        "mirrorHorizontal": True,
                        "cameraMoves": [
                            {
                                "startSeconds": 30.0,
                                "endSeconds": 32.0,
                                "zoom": 1.12,
                                "panX": 0.1,
                                "transitionSeconds": 0.5,
                            }
                        ],
                    },
                )
                with patch.object(engine, "_verify_myanmar_shaping_support"):
                    engine._burn_subtitles_into_video(
                        clean_video,
                        subtitles,
                        final_video,
                        font_dir,
                        "myanmar",
                        None,
                        60,
                        {
                            "preset": "custom",
                            "primaryColor": "#FFFFFF",
                            "outlineColor": "#000000",
                            "outlineWidth": 3,
                        },
                        "center",
                        160,
                        1080,
                        1920,
                        "1080p",
                        duration=60.0,
                    )
                ass_content = final_video.with_suffix(".ass").read_text(
                    encoding="utf-8"
                )

        visual_command, render_mux_command, subtitle_burn_command = [
            call.args[0] for call in run.call_args_list
        ]
        visual_graph = visual_command[visual_command.index("-filter_complex") + 1]
        camera_crop_index = visual_graph.index("[0:v:0]fps=30,zoompan=")
        mirror_index = visual_graph.index(",hflip,")
        aspect_fit_index = visual_graph.index(
            "scale=1080:1920:force_original_aspect_ratio=increase",
            mirror_index,
        )
        self.assertLess(camera_crop_index, mirror_index)
        self.assertLess(mirror_index, aspect_fit_index)
        self.assertNotIn("ass=filename=", visual_graph)
        self.assertIn(
            "ass=filename=",
            subtitle_burn_command[subtitle_burn_command.index("-vf") + 1],
        )
        render_audio_graph = render_mux_command[
            render_mux_command.index("-filter_complex") + 1
        ]
        self.assertEqual(visual_command[visual_command.index("-t") + 1], "60.000")
        self.assertIn("apad=whole_dur=60.000,atrim=duration=60.000", render_audio_graph)
        self.assertEqual(render_mux_command[render_mux_command.index("-t") + 1], "60.000")
        self.assertNotIn("-shortest", render_mux_command)
        self.assertEqual(subtitle_burn_command[subtitle_burn_command.index("-t") + 1], "60.000")
        self.assertNotIn("-shortest", subtitle_burn_command)
        subtitle_filter = subtitle_burn_command[subtitle_burn_command.index("-vf") + 1]
        self.assertEqual(
            subtitle_filter,
            f"ass=filename='{engine._filter_escape(final_video.with_suffix('.ass'))}'"
            f":fontsdir='{engine._filter_escape(font_dir)}'",
        )
        self.assertIn(f"Style: Default,{engine.MYANMAR_FONT_NAME},", ass_content)
        self.assertIn("အဆုံး", ass_content)

    def test_render_video_keeps_subtitles_out_of_the_mp4(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_run", side_effect=_fake_render_run) as run:
            subtitle_path = Path(directory) / "myanmar.srt"
            _write_test_subtitles(subtitle_path)
            font_dir = _prepare_test_font(Path(directory) / "fonts")
            engine._render_video(
                Path(directory) / "source.mp4", Path(directory) / "audio.mp3",
                subtitle_path, Path(directory) / "output.mp4",
                2.0, "none", font_dir, "myanmar", True,
                [], None, None, "top-right", 42, 0.0, "clean-boxblur",
            )
        command = run.call_args_list[-1].args[0]
        filter_graph = command[command.index("-filter_complex") + 1]
        self.assertNotIn("subtitles=filename=", filter_graph)
        self.assertNotIn(".ass", " ".join(command))
        self.assertNotIn("fontsdir=", filter_graph)
        self.assertNotIn("force_style", filter_graph)
        self.assertNotIn("zoompan=", filter_graph)
        self.assertNotIn("hflip", filter_graph)

    def test_render_video_mixes_independent_audio_layers_and_shared_transform(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_run", side_effect=_fake_render_run) as run:
            root = Path(directory)
            subtitle_path = root / "myanmar.srt"
            _write_test_subtitles(subtitle_path)
            font_dir = _prepare_test_font(root / "fonts")
            music = root / "music.mp3"
            sfx = root / "effects.wav"
            music.write_bytes(b"music")
            sfx.write_bytes(b"sfx")
            engine._render_video(
                root / "source.mp4",
                root / "audio.mp3",
                subtitle_path,
                root / "output.mp4",
                4.0,
                "none",
                font_dir,
                "myanmar",
                True,
                [],
                None,
                None,
                "top-right",
                70,
                0.0,
                "clean-boxblur",
                export_quality="1080p",
                background_music=music,
                sfx=sfx,
                background_music_volume=0.35,
                sfx_volume=0.2,
                narration_ducking=0.6,
                    video_transform={
                        "scale": 1.2,
                        "zoom": 1.1,
                        "x": 0.25,
                        "y": -0.2,
                        "mirrorHorizontal": True,
                        "cameraMoves": [
                            {
                                "startSeconds": 1.0,
                                "endSeconds": 3.0,
                                "zoom": 1.2,
                                "panX": 0.25,
                                "panY": -0.2,
                                "transitionSeconds": 0.5,
                            }
                        ],
                    },
            )
        visual_command, final_command = [call.args[0] for call in run.call_args_list]
        visual_graph = visual_command[visual_command.index("-filter_complex") + 1]
        final_graph = final_command[final_command.index("-filter_complex") + 1]
        camera_crop_index = visual_graph.index("[0:v:0]fps=30,zoompan=")
        mirror_index = visual_graph.index(",hflip,")
        aspect_fit_index = visual_graph.index(
            "scale=1080:1920:force_original_aspect_ratio=increase",
            mirror_index,
        )
        self.assertLess(camera_crop_index, mirror_index)
        self.assertLess(mirror_index, aspect_fit_index)
        self.assertIn(":d=1:s=1080x1920:fps=30", visual_graph)
        self.assertNotIn("ass=filename=", visual_graph)
        self.assertIn("scale=1426:2534", visual_graph)
        self.assertIn("crop=1080:1920:(iw-ow)/2-(0.250000)", visual_graph)
        self.assertNotIn("-stream_loop", final_command)
        self.assertNotIn(str(music), final_command)
        self.assertNotIn(str(sfx), final_command)
        self.assertNotIn("[3:a]", final_graph)
        self.assertNotIn("[4:a]", final_graph)
        self.assertNotIn("amix=", final_graph)
        self.assertNotIn("sidechaincompress=", final_graph)

    def test_camera_motion_filter_is_deterministic_and_disabled_by_default(self):
        self.assertEqual(engine._video_pre_scale_filter(None, 8.0), "")
        self.assertEqual(
            engine._video_pre_scale_filter(
                {"mirrorHorizontal": False, "cameraMoves": []},
                8.0,
            ),
            "",
        )
        self.assertEqual(
            engine._video_pre_scale_filter({"mirrorHorizontal": True}, 8.0),
            "hflip",
        )

        camera_filter = engine._video_pre_scale_filter(
            {
                "mirrorHorizontal": True,
                "cameraMoves": [
                    {
                        "startSeconds": 1.0,
                        "endSeconds": 3.0,
                        "zoom": 1.2,
                        "panX": 0.25,
                        "panY": -0.2,
                        "transitionSeconds": 0.5,
                    }
                ],
            },
            8.0,
        )
        self.assertIn("between(it,1.000000,3.000000)", camera_filter)
        self.assertIn("(it-1.000000)/0.500000", camera_filter)
        self.assertIn("(3.000000-it)/0.500000", camera_filter)
        self.assertIn("0.250000", camera_filter)
        self.assertIn("-0.200000", camera_filter)
        self.assertIn("fps=30,zoompan=", camera_filter)
        self.assertIn(":d=1:s=1080x1920:fps=30,hflip", camera_filter)

        max_zoom_filter = engine._video_pre_scale_filter(
            {
                "cameraMoves": [
                    {"startSeconds": 1.0, "endSeconds": 2.0, "zoom": 2.5}
                ]
            },
            3.0,
        )
        self.assertIn("2.500000", max_zoom_filter)

    def test_camera_motion_settings_survive_project_and_run_validation(self):
        transform = {
            "mirrorHorizontal": True,
            "cameraMoves": [
                {
                    "startSeconds": 2.0,
                    "endSeconds": 4.0,
                    "zoom": 2.5,
                    "panX": 0.25,
                    "panY": -0.2,
                    "transitionSeconds": 0.4,
                }
            ],
        }
        project_update = ProjectUpdate(videoTransform=transform)
        run_input = RunInput(action="export", videoTransform=transform)
        for model in (project_update, run_input):
            persisted = model.model_dump(exclude_unset=True)["videoTransform"]
            self.assertTrue(persisted["mirrorHorizontal"])
            self.assertEqual(persisted["cameraMoves"][0]["zoom"], 2.5)
            self.assertEqual(persisted["cameraMoves"][0]["panX"], 0.25)
            self.assertEqual(persisted["cameraMoves"][0]["transitionSeconds"], 0.4)

    def test_camera_motion_segments_reject_overlap_and_invalid_timestamps(self):
        with self.assertRaisesRegex(engine.EngineError, "must not overlap"):
            engine._video_pre_scale_filter(
                {
                    "cameraMoves": [
                        {"startSeconds": 1, "endSeconds": 3, "zoom": 1.1},
                        {"startSeconds": 2, "endSeconds": 4, "zoom": 1.2},
                    ]
                },
                5,
            )
        with self.assertRaisesRegex(engine.EngineError, "allowed range"):
            engine._video_pre_scale_filter(
                {
                    "cameraMoves": [
                        {"startSeconds": 4, "endSeconds": 6, "zoom": 1.1}
                    ]
                },
                5,
            )
        with self.assertRaisesRegex(engine.EngineError, "allowed range"):
            engine._video_pre_scale_filter(
                {
                    "cameraMoves": [
                        {"startSeconds": 1, "endSeconds": 3, "zoom": 2.51}
                    ]
                },
                5,
            )
        with self.assertRaisesRegex(engine.EngineError, "boolean"):
            engine._video_pre_scale_filter(
                {"mirrorHorizontal": "true"},
                5,
            )

    def test_video_transform_moves_at_one_x_over_blurred_fill(self):
        filter_graph = engine._video_transform_filter(
            {"scale": 1.0, "zoom": 1.0, "x": 0.5, "y": -0.5},
            1080,
            1920,
        )

        self.assertIn("[video_source]split=2", filter_graph)
        self.assertIn(
            "boxblur=luma_radius=8:luma_power=1:chroma_radius=0:alpha_radius=0",
            filter_graph,
        )
        self.assertIn("scale=1080:1920[position_foreground]", filter_graph)
        self.assertIn(
            "overlay=x='(W-w)/2+(0.500000)*0.050000*W'",
            filter_graph,
        )
        self.assertIn(
            "y='(H-h)/2+(-0.500000)*0.050000*H'",
            filter_graph,
        )
        self.assertTrue(filter_graph.endswith("[video_base]"))

    def test_video_transform_keeps_centered_one_x_crop_when_position_is_zero(self):
        filter_graph = engine._video_transform_filter(
            {"scale": 1.0, "zoom": 1.0, "x": 0.0, "y": 0.0},
            1080,
            1920,
        )

        self.assertIn("scale=1080:1920", filter_graph)
        self.assertIn("crop=1080:1920", filter_graph)
        self.assertNotIn("position_blurred_background", filter_graph)

    def test_positioned_subtitles_keep_margin_v_and_clip_to_target_box(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            srt = root / "myanmar.srt"
            ass = root / "myanmar.ass"
            srt.write_text(
                "1\n00:00:01,000 --> 00:00:03,250\n"
                "မင်္ဂလာပါ။\nဒုတိယစာကြောင်း\n",
                encoding="utf-8",
            )
            engine._write_positioned_ass(
                srt,
                ass,
                "myanmar",
                {"x": 0.10, "y": 0.70, "width": 0.80, "height": 0.20},
            )
            content = ass.read_text(encoding="utf-8")
        self.assertIn(r"\an8\pos(540,1344)", content)
        self.assertIn(",108,108,160,1", content)
        self.assertIn(r"\clip(108,1344,972,1728)", content)
        self.assertIn("မင်္ဂလာပါ။", content)
        self.assertIn("ဒုတိယစာကြောင်း", content)
        self.assertIn("Noto Sans Myanmar", content)

    def test_subtitle_box_rejects_out_of_frame_coordinates(self):
        with self.assertRaisesRegex(engine.EngineError, "stay inside"):
            engine._subtitle_box({
                "subtitleBox": {"x": 0.8, "y": 0.8, "width": 0.4, "height": 0.1},
            }, {})

    def test_blur_boxes_are_independently_configurable(self):
        mask = engine._blur_box_filter([
            {"id": "one", "x": 0.10, "y": 0.20, "width": 0.30, "height": 0.08},
            {"id": "two", "x": 0.55, "y": 0.70, "width": 0.35, "height": 0.12},
        ])
        self.assertIn("split=3", mask)
        self.assertIn("crop=324:154:108:384", mask)
        self.assertIn("crop=378:230:594:1344", mask)
        self.assertIn("overlay=x=594:y=1344", mask)
        self.assertEqual(
            mask.count("boxblur=luma_radius=20:luma_power=1:chroma_radius=0:alpha_radius=0"),
            2,
        )
        self.assertEqual(
            mask.count("drawbox=x=0:y=0:w=iw:h=ih:color=black@0.25:t=fill"),
            2,
        )

    def test_blur_boxes_reject_out_of_frame_coordinates(self):
        with self.assertRaisesRegex(engine.EngineError, "stay inside"):
            engine._blur_boxes({
                "blurBoxes": [{
                    "id": "invalid", "x": 0.8, "y": 0.8, "width": 0.4, "height": 0.1,
                }],
            }, {})

    def test_blur_boxes_use_only_user_defined_regions(self):
        boxes = engine._blur_boxes({
            "blurBoxes": [{
                "id": "top-text", "x": 0.1, "y": 0.1, "width": 0.8, "height": 0.1,
            }],
        }, {})
        self.assertEqual(boxes, [{
            "id": "top-text", "x": 0.1, "y": 0.1, "width": 0.8, "height": 0.1,
            "strength": 20,
        }])

    def test_blur_boxes_are_empty_when_user_has_not_configured_a_region(self):
        self.assertEqual(engine._blur_boxes({"blurBoxes": []}, {}), [])

    def test_render_video_overlays_channel_logo_with_bounded_position(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_run", side_effect=_fake_render_run) as run:
            subtitle_path = Path(directory) / "myanmar.srt"
            _write_test_subtitles(subtitle_path)
            font_dir = _prepare_test_font(Path(directory) / "fonts")
            engine._render_video(
                Path(directory) / "source.mp4", Path(directory) / "audio.mp3",
                subtitle_path, Path(directory) / "output.mp4",
                2.0, "none", font_dir, "myanmar", True,
                [], None, Path(directory) / "channel-logo.png", "top-left",
                export_quality="1080p",
            )
        command = run.call_args_list[0].args[0]
        filter_graph = command[command.index("-filter_complex") + 1]
        self.assertIn("-loop", command)
        self.assertIn("scale=236:-2", filter_graph)
        self.assertIn("overlay=32:32", filter_graph)
        self.assertIn("[video_logo]", filter_graph)

    def test_render_video_maps_logo_percentages_to_each_export_canvas_without_shifting(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_run", side_effect=_fake_render_run) as run:
            root = Path(directory)
            subtitles = root / "myanmar.srt"
            _write_test_subtitles(subtitles)
            font_dir = _prepare_test_font(root / "fonts")
            engine._render_video(
                root / "source.mp4",
                root / "audio.mp3",
                subtitles,
                root / "output.mp4",
                2.0,
                "none",
                font_dir,
                "myanmar",
                True,
                [],
                None,
                root / "channel-logo.png",
                "top-right",
                logo_x=0.75,
                logo_y=0.05,
                export_quality="720p",
                frame_width=1080,
                frame_height=1920,
            )
        visual_command = run.call_args_list[0].args[0]
        visual_graph = visual_command[visual_command.index("-filter_complex") + 1]
        self.assertIn("scale=158:-2", visual_graph)
        self.assertIn("overlay=540:64:eof_action=repeat:format=auto", visual_graph)
        self.assertEqual(visual_graph.count("overlay=540:64:eof_action=repeat:format=auto"), 1)
        self.assertNotIn("enable=", visual_graph)
        self.assertNotIn("overlay=480:", visual_graph)

    def test_logo_pixel_position_is_a_direct_percentage_of_the_output_frame(self):
        self.assertEqual(engine._logo_pixel_position(720, 1280, 0.75, 0.05), (540, 64))
        self.assertEqual(engine._logo_pixel_position(1080, 1920, 0.75, 0.05), (810, 96))
        self.assertEqual(engine._logo_pixel_position(1920, 1080, 0.75, 0.05), (1440, 54))

    def test_invalid_or_unavailable_stored_logo_is_nonfatal(self):
        with tempfile.TemporaryDirectory() as directory:
            workdir = Path(directory)
            with patch.object(engine, "storage_client") as storage:
                self.assertIsNone(engine._resolve_render_logo("not-a-logo", workdir))
                storage.assert_not_called()

                storage.reset_mock()
                storage.return_value.download_to_filename.side_effect = OSError(
                    "missing logo"
                )
                self.assertIsNone(
                    engine._resolve_render_logo(
                        "studio/workspace/logos/missing.png",
                        workdir,
                    )
                )
                self.assertFalse((workdir / "channel-logo.png").exists())

    def test_clean_render_stops_without_degraded_output(self):
        def render_clean_pass(command, purpose, *_args, **_kwargs):
            Path(command[-1]).write_bytes(b"render fixture")

        with tempfile.TemporaryDirectory() as directory, \
                patch.object(engine, "_run", side_effect=render_clean_pass) as run:
            root = Path(directory)
            subtitles = root / "myanmar.srt"
            subtitles.write_text(
                "1\n00:00:00,000 --> 00:00:01,000\nမင်္ဂလာပါ။\n",
                encoding="utf-8",
            )
            font_dir = _prepare_test_font(root / "fonts")
            output = root / "output.mp4"
            engine._render_video(
                root / "source.mp4",
                root / "audio.mp3",
                subtitles,
                output,
                1.0,
                "none",
                font_dir,
                "myanmar",
                False,
                [],
                {"x": 0.1, "y": 0.7, "width": 0.8, "height": 0.2},
            )
            self.assertTrue(output.exists())
            self.assertEqual(run.call_count, 2)

    def test_private_downloads_still_rejected(self):
        with patch.object(engine.socket, "getaddrinfo", return_value=[
            (2, 1, 6, "", ("127.0.0.1", 443))
        ]):
            with self.assertRaisesRegex(engine.EngineError, "non-public"):
                engine._public_addresses("test.invalid")

    def test_provider_free_export_keeps_a_real_sixty_one_second_timeline(self):
        if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
            self.skipTest("FFmpeg and ffprobe are required for the long export regression.")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source_fixture = root / "source.mp4"
            narration_fixture = root / "narration.mp3"
            subprocess.run(
                [
                    "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
                    "-f", "lavfi", "-i", "color=c=0x24324a:s=320x568:r=12",
                    "-f", "lavfi", "-i", "sine=frequency=220:sample_rate=48000",
                    "-t", "61", "-c:v", "libx264", "-preset", "veryfast",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-ar", "48000",
                    "-movflags", "+faststart", str(source_fixture),
                ],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            subprocess.run(
                [
                    "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
                    "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000",
                    "-t", "61", "-c:a", "libmp3lame", "-ar", "44100", "-ac", "2",
                    str(narration_fixture),
                ],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            subtitle_fixture = root / "narration.srt"
            subtitle_fixture.write_text(
                "1\n00:00:00,000 --> 00:01:01,000\nမင်္ဂလာပါ။\n",
                encoding="utf-8",
            )
            uploaded_video = root / "uploaded.mp4"

            def download(_url, destination):
                shutil.copyfile(source_fixture, destination)

            def narration(
                _script,
                _language,
                _voice,
                workdir,
                rate_percent=0,
                target_duration=None,
                **_kwargs,
            ):
                audio = workdir / "myanmar.mp3"
                srt = workdir / "myanmar.srt"
                shutil.copyfile(narration_fixture, audio)
                shutil.copyfile(subtitle_fixture, srt)
                return audio, srt, 61.0

            def upload(
                _project_id,
                files,
                languages,
                thumbnails=None,
                _project_title=None,
                **_kwargs,
            ):
                shutil.copyfile(files["myanmar"][0], uploaded_video)
                return ([{"language": "myanmar", "duration": files["myanmar"][3]}], "studio/provider-free")

            with patch.object(engine, "_download_direct_video", side_effect=download), \
                    patch.object(engine, "_probe_video", return_value=61.0), \
                    patch.object(engine, "_probe_video_dimensions", return_value=(320, 568)), \
                    patch.object(engine, "_source_has_audio", return_value=True), \
                    patch.object(engine, "_make_narration", side_effect=narration), \
                    patch.object(
                        engine,
                        "_generate_post_metadata",
                        return_value={
                            "hookTitle": "စမ်းသပ်ခေါင်းစဉ်",
                            "caption": "စမ်းသပ်ဖော်ပြချက်",
                            "hashtags": ["#DramaRecap"] * 5,
                            "source": "gemini",
                        },
                    ), \
                    patch.object(engine, "_find_myanmar_font", return_value=engine._find_myanmar_font()), \
                    patch.object(engine, "_upload_exports", side_effect=upload):
                result = engine.process_project(
                    {
                        "id": "provider-free-long",
                        "sourceUrl": "https://example.test/source.mp4",
                        "transcript": "你好。",
                        "dialogue": [],
                        "myanmarScript": "မင်္ဂလာပါ။ အစမှအဆုံး မဖြတ်တောက်ဘဲ စမ်းသပ်နေသည်။",
                        "englishScript": "Hello.",
                        "globalEdit": "none",
                        "blurBoxes": [],
                        "subtitleBox": None,
                        "subtitleStyle": {
                            "preset": "custom",
                            "primaryColor": "#39FF14",
                            "outlineColor": "#000000",
                            "outlineWidth": 3,
                        },
                        "videoTransform": {
                            "scale": 1.12,
                            "zoom": 1.08,
                            "x": 0.15,
                            "y": -0.1,
                            "mirrorHorizontal": True,
                            "cameraMoves": [
                                {
                                    "startSeconds": 0.5,
                                    "endSeconds": 2.0,
                                    "zoom": 1.12,
                                    "panX": 0.15,
                                    "transitionSeconds": 0.4,
                                },
                                {
                                    "startSeconds": 3.0,
                                    "endSeconds": 4.5,
                                    "zoom": 1.08,
                                    "panX": -0.15,
                                    "panY": 0.1,
                                    "transitionSeconds": 0.4,
                                },
                            ],
                        },
                    },
                    {"myanmarVoice": "my-MM-NilarNeural", "myanmarRate": -10},
                    "export",
                    lambda *_: None,
                    root / "work",
                )

            probe = json.loads(subprocess.run(
                [
                    "ffprobe", "-v", "error",
                    "-show_entries", "format=duration",
                    "-show_entries", "stream=codec_type,codec_name,width,height",
                    "-of", "json", str(uploaded_video),
                ],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            ).stdout)
            video_stream = next(item for item in probe["streams"] if item["codec_type"] == "video")
            audio_stream = next(item for item in probe["streams"] if item["codec_type"] == "audio")
            self.assertGreaterEqual(float(probe["format"]["duration"]), 60.5)
            self.assertEqual(video_stream["codec_name"], "h264")
            self.assertEqual(audio_stream["codec_name"], "aac")
            self.assertLessEqual(int(video_stream["width"]), 1080)
            self.assertLessEqual(int(video_stream["height"]), 1920)
            self.assertEqual(
                int(video_stream["width"]) * 16,
                int(video_stream["height"]) * 9,
            )
            self.assertEqual(result["exports"][0]["duration"], 61.0)


class CapCutExportTests(unittest.TestCase):
    def test_burn_subtitles_uses_utf8_ass_and_configured_font_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            clean_video = root / "myanmar.mp4"
            subtitles = root / "myanmar.srt"
            output = root / "myanmar-capcut.mp4"
            clean_video.write_bytes(b"clean video")
            _write_test_subtitles(subtitles)
            font_dir = _prepare_test_font(root / "fonts")
            with patch.object(engine, "_verify_myanmar_shaping_support"), \
                    patch.object(engine, "_run", side_effect=_fake_render_run) as run:
                engine._burn_subtitles_into_video(
                    clean_video,
                    subtitles,
                    output,
                    font_dir,
                    "myanmar",
                    None,
                    60,
                    {"preset": "custom", "primaryColor": "#FFFFFF", "outlineColor": "#000000", "outlineWidth": 3},
                    "center",
                    160,
                    1080,
                    1920,
                    "1080p",
                    duration=60.0,
                )
            command = run.call_args.args[0]
            subtitle_filter = command[command.index("-vf") + 1]
            self.assertEqual(
                subtitle_filter,
                f"ass=filename='{engine._filter_escape(output.with_suffix('.ass'))}'"
                f":fontsdir='{engine._filter_escape(font_dir)}'",
            )
            ass_content = output.with_suffix(".ass").read_text(encoding="utf-8")
            self.assertIn(f"Style: Default,{engine.MYANMAR_FONT_NAME},", ass_content)
            self.assertIn("မင်္ဂလာပါ။", ass_content)
            self.assertIn("-c:a", command)
            self.assertEqual(command[command.index("-c:a") + 1], "copy")
            self.assertEqual(command[command.index("-t") + 1], "60.000")
            self.assertNotIn("-shortest", command)
            self.assertTrue(output.is_file())

    def test_upload_exports_persists_a_separate_capcut_filename(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            files = {}
            for name, content in (
                ("video.mp4", b"clean"),
                ("captions.srt", b"srt"),
                ("narration.mp3", b"audio"),
                ("capcut.mp4", b"burned"),
            ):
                path = root / name
                path.write_bytes(content)
                files[name] = path

            storage_client = MagicMock()
            with patch.object(engine, "storage_client", return_value=storage_client):
                exports, prefix = engine._upload_exports(
                    "project",
                    {"myanmar": (files["video.mp4"], files["captions.srt"], files["narration.mp3"], 3.5)},
                    ("myanmar",),
                    project_title="Test",
                    capcut_videos={"myanmar": files["capcut.mp4"]},
                )

            export = exports[0]
            self.assertTrue(export["capcutVideoUrl"].endswith("/myanmar-capcut.mp4"))
            self.assertTrue(export["capcutVideoFilename"].endswith("-capcut.mp4"))
            uploaded_names = [call.args[0] for call in storage_client.upload_from_filename.call_args_list]
            self.assertIn(f"{prefix}/{export['capcutVideoFilename']}", uploaded_names)

    def test_write_export_package_contains_all_canonical_assets(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video = root / "video.mp4"
            subtitle = root / "subtitle.srt"
            audio = root / "narration.mp3"
            thumbnail = root / "thumbnail.jpg"
            metadata = root / "metadata.json"
            package = root / "export.zip"
            video.write_bytes(b"video")
            subtitle.write_text("1\n00:00:00,000 --> 00:00:01,000\nမင်္ဂလာပါ။\n", encoding="utf-8")
            audio.write_bytes(b"audio")
            thumbnail.write_bytes(b"jpg")

            engine._write_export_package(
                package,
                metadata,
                video,
                subtitle,
                audio,
                thumbnail,
                {
                    "title": "Test",
                    "description": "Description",
                    "hashtags": ["#Test"],
                    "duration": 1,
                },
            )

            self.assertGreater(metadata.stat().st_size, 0)
            with zipfile.ZipFile(package) as archive:
                self.assertEqual(
                    set(archive.namelist()),
                    {
                        "recap_final.mp4",
                        "recap.srt",
                        "recap_voice.mp3",
                        "thumbnail.jpg",
                        "metadata.json",
                    },
                )
                self.assertEqual(json.loads(archive.read("metadata.json"))["title"], "Test")


if __name__ == "__main__":
    unittest.main()