import { pgTable, text, jsonb, timestamp, index } from "drizzle-orm/pg-core";

// Python owns the runtime repository. Keep this declaration in sync with
// artifacts/api-server/studio/schema.sql for database tooling.
export const studioRecords = pgTable("studio_records", {
  id: text("id").primaryKey(),
  owner: text("owner").notNull(),
  kind: text("kind").notNull(),
  data: jsonb("data").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("studio_records_owner_kind").on(table.owner, table.kind),
]);