import fs from 'fs'
let content = fs.readFileSync('artifacts/recap-studio/src/pages/projects.tsx', 'utf-8')

content = content.replace(
  'import { Label } from "@/components/ui/label"',
  'import { Label } from "@/components/ui/label"\nimport { Checkbox } from "@/components/ui/checkbox"'
)

content = content.replace(
  'const [uploadFile, setUploadFile] = useState<File | null>(null)',
  'const [uploadFile, setUploadFile] = useState<File | null>(null)\n  const [rightsConfirmed, setRightsConfirmed] = useState(false)\n  const [uploadProgress, setUploadProgress] = useState(-1)\n  const [uploadPreviewUrl, setUploadPreviewUrl] = useState<string | null>(null)'
)

// Add video preview to the upload mode logic
content = content.replace(
  'setUploadFile(e.target.files?.[0] || null)',
  'const file = e.target.files?.[0] || null;\n                      setUploadFile(file);\n                      if (file) {\n                        if (uploadPreviewUrl) URL.revokeObjectURL(uploadPreviewUrl);\n                        setUploadPreviewUrl(URL.createObjectURL(file));\n                      } else {\n                        setUploadPreviewUrl(null);\n                      }'
)

// We also need to add the XMLHttprequest for upload
const uploadFunction = `
    if (!rightsConfirmed) {
      toast({ variant: "destructive", title: "သဘောတူညီမှု လိုအပ်ပါသည်", description: "မူပိုင်ခွင့်ရှိကြောင်း အတည်ပြုပါ။" })
      return
    }

    if (createMode === "upload") {
      if (!uploadFile) {
        toast({ variant: "destructive", title: "ဖိုင်လိုအပ်ပါသည်", description: "ဗီဒီယိုဖိုင်တစ်ခု ရွေးချယ်ပါ။" })
        return
      }
      
      const form = new FormData()
      form.append("file", uploadFile)
      
      const xhr = new XMLHttpRequest()
      xhr.open("POST", "/api/studio/uploads")
      xhr.withCredentials = true
      
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          const percent = Math.round((e.loaded / e.total) * 100)
          setUploadProgress(percent)
        }
      }
      
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const body = JSON.parse(xhr.responseText)
            if (!body.sourceObjectPath) {
              throw new Error(body.detail || "Upload failed")
            }
            createProject.mutate({
              data: {
                title: newTitle,
                sourceUrl: "",
                sourceObjectPath: body.sourceObjectPath,
                rightsConfirmed,
              }
            })
          } catch (e: any) {
            setUploadProgress(-1)
            toast({ variant: "destructive", title: "ဖိုင်တင်၍ မရပါ", description: localizeError(e.message) })
          }
        } else {
            setUploadProgress(-1)
            let detail = "Upload failed"
            try { detail = JSON.parse(xhr.responseText).detail || detail } catch (e) {}
            toast({ variant: "destructive", title: "ဖိုင်တင်၍ မရပါ", description: localizeError(detail) })
        }
      }
      
      xhr.onerror = () => {
        setUploadProgress(-1)
        toast({ variant: "destructive", title: "ဖိုင်တင်၍ မရပါ", description: "Network error occurred." })
      }
      
      setUploadProgress(0)
      xhr.send(form)
      return
    }

    if (!sourceUrl.trim()) {
      toast({ variant: "destructive", title: "URL လိုအပ်ပါသည်", description: "ဒေါင်းလုဒ်လုပ်ရန် ဗီဒီယိုလင့်ခ်တစ်ခု ထည့်ပါ။" })
      return
    }

    createProject.mutate({
      data: {
        title: newTitle,
        sourceUrl,
        rightsConfirmed,
      }
    })
`

// Replace the old handleCreate with the new one
content = content.replace(
  /if \(createMode === "upload"\) \{[\s\S]*rightsConfirmed: true,\n      \}\n    \}\)/,
  uploadFunction.trim()
)

fs.writeFileSync('artifacts/recap-studio/src/pages/projects.tsx', content)
