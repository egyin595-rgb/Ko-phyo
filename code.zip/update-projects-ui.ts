import fs from 'fs'
let content = fs.readFileSync('artifacts/recap-studio/src/pages/projects.tsx', 'utf-8')

const videoPreviewStr = `
                    <div 
                      onClick={() => !uploadProgress && fileInputRef.current?.click()}
                      className={\`border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-colors \${
                        uploadFile ? 'border-accent bg-accent/5' : 'border-white/10 bg-background/30 hover:bg-background/50 hover:border-primary/50'
                      }\`}
                    >
                      {uploadPreviewUrl ? (
                        <div className="w-full relative">
                          <video src={uploadPreviewUrl} className="w-full h-32 object-cover rounded-md mb-2 bg-black" muted playsInline />
                          {uploadProgress >= 0 && (
                            <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center rounded-md">
                              <Loader2 className="w-6 h-6 animate-spin text-primary mb-2" />
                              <span className="text-sm font-medium text-white">{uploadProgress}%</span>
                              {uploadProgress === 100 && <span className="text-xs text-white/80 mt-1">normalization wait...</span>}
                            </div>
                          )}
                          <p className="text-sm font-medium text-foreground truncate max-w-full px-2">{uploadFile?.name}</p>
                          <p className="text-xs text-muted-foreground mt-1">{((uploadFile?.size || 0) / (1024*1024)).toFixed(1)} MB</p>
                        </div>
                      ) : (
                        <>
                          <HardDrive className="w-8 h-8 text-muted-foreground mb-2" />
                          <p className="text-sm font-medium text-foreground">ရွေးချယ်ရန် နှိပ်ပါ</p>
                          <p className="text-xs text-muted-foreground mt-1">Max 500 MB</p>
                        </>
                      )}
                    </div>
`

// Need to replace the old div onClick... to the end of uploadFile conditional.
content = content.replace(
  /<div[\s\S]*?onClick=\{\(\) => fileInputRef\.current\?\.click\(\)\}[\s\S]*?<\/div>/,
  videoPreviewStr.trim()
)

// Add checkbox
const checkboxStr = `
              <div className="flex items-start space-x-2 pt-2">
                <Checkbox 
                  id="rights" 
                  checked={rightsConfirmed}
                  onCheckedChange={(c) => setRightsConfirmed(c === true)}
                />
                <div className="grid gap-1.5 leading-none">
                  <Label htmlFor="rights" className="text-xs font-medium text-foreground leading-snug">
                    ဤဗီဒီယိုအား ပြင်ဆင်အသုံးပြုရန် မူပိုင်ခွင့်ရှိကြောင်း အတည်ပြုပါသည်။
                  </Label>
                </div>
              </div>
              <Button 
`

content = content.replace(
  /<Button \n[\s\S]*?className="w-full mt-2/,
  checkboxStr
)

// Also disable button when uploading
content = content.replace(
  'disabled={createProject.isPending}',
  'disabled={createProject.isPending || uploadProgress >= 0}'
)
content = content.replace(
  'disabled={createProject.isPending}',
  'disabled={createProject.isPending || uploadProgress >= 0}'
)

fs.writeFileSync('artifacts/recap-studio/src/pages/projects.tsx', content)
