import fs from 'fs'
let content = fs.readFileSync('artifacts/recap-studio/src/pages/projects.tsx', 'utf-8')

// Add uploadProgress and uploadPreviewUrl to CreateProjectDialog
content = content.replace(
  'const [isUploading, setIsUploading] = useState(false)',
  'const [isUploading, setIsUploading] = useState(false)\n  const [uploadProgress, setUploadProgress] = useState(-1)\n  const [uploadPreviewUrl, setUploadPreviewUrl] = useState<string | null>(null)'
)

// Handle video file change to create preview URL
content = content.replace(
  'setSourceFile(file)',
  'setSourceFile(file)\n                  if (uploadPreviewUrl) URL.revokeObjectURL(uploadPreviewUrl)\n                  setUploadPreviewUrl(URL.createObjectURL(file))'
)
content = content.replace(
  'setSourceFile(null)',
  'setSourceFile(null)\n                    setUploadPreviewUrl(null)'
)
content = content.replace(
  'setSourceFile(null)',
  'setSourceFile(null)\n                    setUploadPreviewUrl(null)'
)
content = content.replace(
  'setSourceFile(null)',
  'setSourceFile(null)\n                    setUploadPreviewUrl(null)'
)

// Replace fetch with XMLHttpRequest
const xhrUpload = `
      if (sourceFile) {
        const formData = new FormData()
        formData.append("file", sourceFile)
        
        sourceObjectPath = await new Promise((resolve, reject) => {
          const xhr = new XMLHttpRequest()
          xhr.open("POST", "/api/studio/uploads")
          xhr.withCredentials = true
          
          xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) {
              setUploadProgress(Math.round((e.loaded / e.total) * 100))
            }
          }
          
          xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
              try {
                const payload = JSON.parse(xhr.responseText)
                resolve(payload.sourceObjectPath)
              } catch (err) {
                reject(new Error("Could not upload the video file."))
              }
            } else {
              try {
                const payload = JSON.parse(xhr.responseText)
                reject(new Error(payload.error || payload.detail || "Could not upload the video file."))
              } catch {
                reject(new Error("Could not upload the video file."))
              }
            }
          }
          
          xhr.onerror = () => reject(new Error("Network error during upload."))
          
          setUploadProgress(0)
          xhr.send(formData)
        })
      }
`

content = content.replace(
  /if \(sourceFile\) \{[\s\S]*?sourceObjectPath = payload\.sourceObjectPath\n      \}/,
  xhrUpload.trim()
)

content = content.replace(
  'setIsUploading(false)',
  'setIsUploading(false)\n      setUploadProgress(-1)'
)

// Add Video Preview to the form
const previewHtml = `
              <p className="text-xs text-muted-foreground">
                  သင့်စက်ထဲမှ MP4၊ MOV၊ MKV သို့မဟုတ် WebM ဖိုင်ကို ရွေးပါ (အများဆုံး ၅၀၀ MB၊ ၁၀ မိနစ်ခန့်)။
              </p>
              {uploadPreviewUrl && (
                <div className="mt-3 rounded-md overflow-hidden relative bg-black max-w-[200px]">
                  <video src={uploadPreviewUrl} className="w-full h-auto" muted playsInline />
                  {uploadProgress >= 0 && (
                    <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center">
                      <span className="text-sm font-medium text-white">{uploadProgress}%</span>
                      {uploadProgress === 100 && <span className="text-[10px] text-white/80 mt-1">normalization wait...</span>}
                    </div>
                  )}
                </div>
              )}
`

content = content.replace(
  /<p className="text-xs text-muted-foreground">[\s\S]*?<\/p>/,
  previewHtml.trim()
)

// Add glass-card and glass-panel to projects
content = content.replace(
  /className="animate-pulse bg-card\/50 h-\[200px\]"/g,
  'className="glass-card border-0 animate-pulse h-[200px]"'
)
content = content.replace(
  /className="border-destructive bg-destructive\/10"/g,
  'className="glass-card border-0 border-destructive bg-destructive/10"'
)
content = content.replace(
  /className="text-center py-20 border border-dashed rounded-xl bg-card\/30"/g,
  'className="glass-card border-0 text-center py-20 bg-background/30"'
)
content = content.replace(
  /className="overflow-hidden border-card-border\/80 transition-all hover:border-primary\/50 hover:shadow-md"/g,
  'className="glass-card border-0 transition-all hover:scale-[1.02] hover:shadow-[0_0_20px_rgba(var(--primary),0.1)]"'
)
content = content.replace(
  /className="flex items-center gap-2"/g,
  'className="flex items-center gap-2 relative z-10"'
)
content = content.replace(
  /className="flex flex-col gap-1\.5 p-4 border-t border-border\/50 bg-muted\/20"/g,
  'className="flex flex-col gap-1.5 p-4 border-t border-white/5 bg-background/50 relative z-10"'
)
content = content.replace(
  /className="flex justify-between items-center text-xs mt-1"/g,
  'className="flex justify-between items-center text-xs mt-1 relative z-10"'
)

fs.writeFileSync('artifacts/recap-studio/src/pages/projects.tsx', content)
