"""Create an original, public-domain test scene; no third-party footage.

Run from the repository root. Calls edge-tts once unless source.mp3 already
exists in the ignored validation directory. Text and illustration are CC0.
"""
import asyncio
import hashlib
import json
import subprocess
from pathlib import Path

import edge_tts
from PIL import Image, ImageDraw

ROOT = Path(".cache/live-validation")
PUBLIC = ROOT / "source.mp4"
TEXT = (
    "小林每天都在公园里画画。一天，她发现长椅上有一本红色的笔记本。"
    "她打开本子，里面写着一位老人的旅行故事。小林决定在原地等待。"
    "傍晚，一位老人着急地走来。小林把笔记本还给了他。"
    "老人笑着说，谢谢你，这里面都是我珍贵的回忆。"
)


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    (ROOT / "source-script.txt").write_text(TEXT, encoding="utf-8")
    audio = ROOT / "source.mp3"
    if not audio.exists() or not audio.stat().st_size:
        asyncio.run(edge_tts.Communicate(TEXT, voice="zh-CN-XiaoxiaoNeural").save(str(audio)))
    image = Image.new("RGB", (1280, 720), "#cde9ef")
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 390, 1280, 720), fill="#63946c")
    draw.ellipse((980, 40, 1100, 160), fill="#ffdf80")
    for x in (120, 1050):
        draw.rectangle((x, 220, x + 35, 480), fill="#806451")
        draw.ellipse((x - 90, 110, x + 130, 340), fill="#32715a")
    for y in (365, 410):
        draw.rounded_rectangle((370, y, 850, y + 30), radius=8, fill="#976e4b")
    for x in (410, 795):
        draw.rectangle((x, 440, x + 20, 520), fill="#374b50")
    draw.polygon(((570, 392), (665, 382), (680, 407), (580, 419)), fill="#b93342")
    draw.line(((582, 402), (666, 393)), fill="#ffedd4", width=4)
    # Keep the lower area simple to make subtitle glyph inspection unambiguous.
    image.save(ROOT / "source-scene.png")
    subprocess.run([
        "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
        "-loop", "1", "-framerate", "30", "-i", str(ROOT / "source-scene.png"),
        "-i", str(audio), "-c:v", "libx264", "-preset", "fast",
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest",
        "-movflags", "+faststart", str(PUBLIC),
    ], check=True)
    metadata = {
        "rights": "Original text and vector scene authored for this test, dedicated to CC0. "
                  "Synthetic Chinese narration generated using edge-tts, not a human recording.",
        "voice": "zh-CN-XiaoxiaoNeural",
        "sha256": hashlib.sha256(PUBLIC.read_bytes()).hexdigest(),
        "bytes": PUBLIC.stat().st_size,
        "sourceText": TEXT,
    }
    (ROOT / "source-provenance.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2))
    print(json.dumps(metadata, ensure_ascii=False))


if __name__ == "__main__":
    main()