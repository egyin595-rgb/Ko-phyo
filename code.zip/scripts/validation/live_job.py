"""Opt-in paid live validation. Never run automatically in CI.

prepare_source.py must have run first and both managed workflows must be up.
Start once; poll/download operations do not enqueue or repeat paid work.
Evidence and the private browser state stay in ignored .cache/live-validation.
"""
import argparse
import hashlib
import json
import os
import ssl
import subprocess
import time
from pathlib import Path
from urllib.parse import urlsplit

import httpx

ROOT = Path(".cache/live-validation")
STATE = ROOT / "browser-state.json"
PROJECT = ROOT / "project.json"
BASE = "https://" + os.environ["REPLIT_DEV_DOMAIN"]


def client():
    session = httpx.Client(base_url=BASE, timeout=120, verify=ssl.create_default_context())
    if STATE.exists():
        for cookie in json.loads(STATE.read_text())["cookies"]:
            session.cookies.set(cookie["name"], cookie["value"], domain=cookie["domain"], path="/")
    return session


def request(session, method, path, **kwargs):
    response = session.request(method, path, **kwargs)
    response.raise_for_status()
    return response


def start(session):
    if PROJECT.exists():
        raise SystemExit("Existing test project found. Refusing to enqueue another paid job.")
    project = request(session, "POST", "/api/studio/projects", json={
        "title": "Original notebook story — live bilingual validation",
        "sourceUrl": (ROOT / "source-url.txt").read_text().strip(),
        "rightsConfirmed": True,
        "globalEdit": "crop",
    }).json()
    PROJECT.write_text(json.dumps(project, ensure_ascii=False, indent=2))
    state = {"cookies": [
        {"name": c.name, "value": c.value, "domain": urlsplit(BASE).hostname,
         "path": "/", "expires": int(time.time()) + 86400, "httpOnly": True,
         "secure": True, "sameSite": "None"}
        for c in session.cookies.jar
    ], "origins": []}
    STATE.write_text(json.dumps(state))
    STATE.chmod(0o600)
    request(session, "POST", f"/api/studio/projects/{project['id']}/run", json={"action": "full"})
    print("Queued one full job", project["id"], flush=True)


def poll(session):
    project = json.loads(PROJECT.read_text())
    last = None
    for _ in range(400):
        project = request(session, "GET", f"/api/studio/projects/{project['id']}").json()
        PROJECT.write_text(json.dumps(project, ensure_ascii=False, indent=2))
        stage = (project["status"], project["stage"], project["progress"])
        if stage != last:
            print(*stage, flush=True)
            last = stage
        if project["status"] in ("completed", "failed"):
            print(json.dumps({"status": project["status"], "error": project["error"],
                              "transcript": project["transcript"], "exports": project["exports"]},
                             ensure_ascii=False), flush=True)
            return
        time.sleep(3)
    raise SystemExit("Polling timed out; job not cancelled. Do not enqueue again.")


def probe(path):
    return json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", str(path),
    ]))


def seconds(value):
    h, m, s = value.replace(",", ".").split(":")
    return int(h) * 3600 + int(m) * 60 + float(s)


def download(session):
    project = request(session, "GET", f"/api/studio/projects/{json.loads(PROJECT.read_text())['id']}").json()
    assert project["status"] == "completed" and len(project["exports"]) == 2
    evidence = {}
    for export in project["exports"]:
        lang = export["language"]
        evidence[lang] = {}
        for field, ext in (("videoUrl", "mp4"), ("audioUrl", "mp3"), ("subtitleUrl", "srt")):
            response = request(session, "GET", export[field])
            path = ROOT / f"{lang}.{ext}"
            path.write_bytes(response.content)
            assert path.stat().st_size > 0
            evidence[lang][ext] = {
                "bytes": len(response.content),
                "sha256": hashlib.sha256(response.content).hexdigest(),
                "contentType": response.headers["content-type"],
                "contentDisposition": response.headers.get("content-disposition"),
            }
        video = probe(ROOT / f"{lang}.mp4")
        audio = probe(ROOT / f"{lang}.mp3")
        streams = {s["codec_type"]: s for s in video["streams"]}
        assert streams["video"]["codec_name"] == "h264"
        assert streams["audio"]["codec_name"] == "aac"
        assert (streams["video"]["width"], streams["video"]["height"]) == (1280, 720)
        assert "subtitle" not in streams, "Subtitles should be burned, not a subtitle stream."
        video_duration = float(video["format"]["duration"])
        audio_duration = float(audio["format"]["duration"])
        assert abs(video_duration - audio_duration) < 0.15
        assert abs(audio_duration - export["duration"]) < 0.1
        cues = (ROOT / f"{lang}.srt").read_text().strip().split("\n\n")
        previous = 0
        for index, cue in enumerate(cues, 1):
            lines = cue.splitlines()
            assert int(lines[0]) == index
            start, end = map(seconds, lines[1].split(" --> "))
            assert abs(start - previous) <= 0.0011 and end > start
            assert end <= audio_duration + 0.08
            previous = end
            assert len(lines) >= 3 and lines[2].strip()
        assert abs(previous - audio_duration) < 0.08
        subprocess.run([
            "ffmpeg", "-nostdin", "-v", "error", "-i", str(ROOT / f"{lang}.mp4"),
            "-f", "null", "-",
        ], check=True)
        subprocess.run([
            "ffmpeg", "-nostdin", "-v", "error", "-y", "-ss", "1",
            "-i", str(ROOT / f"{lang}.mp4"), "-frames:v", "1",
            str(ROOT / f"{lang}-frame.png"),
        ], check=True)
        evidence[lang].update(audioSeconds=audio_duration, videoSeconds=video_duration,
                              cues=len(cues), lastCueEnd=previous, decode="passed")
    (ROOT / "downloads-evidence.json").write_text(json.dumps(evidence, indent=2))
    print(json.dumps(evidence, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=["start", "poll", "download"])
    args = parser.parse_args()
    with client() as session:
        {"start": start, "poll": poll, "download": download}[args.operation](session)