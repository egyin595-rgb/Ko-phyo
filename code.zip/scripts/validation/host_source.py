"""Upload only the original validation fixture and create a short-lived GET URL.

The signed URL stays private in ignored local evidence. No bucket ACL changes.
Use --cleanup after validation to remove the temporary source object.
"""
import argparse
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx
from replit.object_storage import Client

ROOT = Path(".cache/live-validation")
OBJECT = "studio-validation/original-notebook-story.mp4"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cleanup", action="store_true")
    args = parser.parse_args()
    storage = Client(bucket_id=os.environ["DEFAULT_OBJECT_STORAGE_BUCKET_ID"])
    if args.cleanup:
        storage.delete(OBJECT, ignore_not_found=True)
        (ROOT / "source-url.txt").unlink(missing_ok=True)
        print("Temporary source object removed.")
        return
    storage.upload_from_filename(OBJECT, str(ROOT / "source.mp4"))
    response = httpx.post(
        "http://127.0.0.1:1106/object-storage/signed-object-url",
        json={"bucket_name": os.environ["DEFAULT_OBJECT_STORAGE_BUCKET_ID"],
              "object_name": OBJECT, "method": "GET",
              "expires_at": (datetime.now(timezone.utc) + timedelta(hours=3)).isoformat()},
        timeout=30,
    )
    response.raise_for_status()
    path = ROOT / "source-url.txt"
    path.write_text(response.json()["signed_url"])
    path.chmod(0o600)
    print("Original source uploaded; private signed GET URL expires in 3 hours.")


if __name__ == "__main__":
    main()